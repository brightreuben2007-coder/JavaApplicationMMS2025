# CryptoBot — Automated Cryptocurrency Trading Platform

A professional, production-ready cryptocurrency trading bot platform with 13 strategy types, real-time market data, ML-powered predictions, backtesting, and a full-featured web UI.

## Architecture

## Quick Start

### Prerequisites
- Docker & Docker Compose v2
- Node.js 20 (for local dev)
- OpenSSL (for key generation)

### 1. Clone & Configure

```bash
git clone https://github.com/your-org/cryptobot.git
cd cryptobot
cp .env.example .env
# Edit .env with your secret keys
chmod +x start.sh
./start.sh
# start
docker compose up -d

# Access
Service	URL
Frontend	http://localhost:3001
API	http://localhost:3000/api/v1
Grafana	http://localhost:3030 (admin/admin)
Prometheus	http://localhost:9090


Trading Strategies (13)
DCA — Dollar cost averaging with safety orders

Grid — Buy low, sell high within price range

Infinity Grid — No upper bound, captures unlimited upside

Leveraged Grid — Grid with margin (1-125x)

Martingale — Exponential position scaling

MACD — Trend-following crossover

Bollinger Bands — Mean reversion

Arbitrage — Cross-exchange spread detection

Market Making — Bid/ask spread capture

Avellaneda-Stoikov — Quantitative market making

Rebalancing — Portfolio allocation maintenance

TWAP — Time-weighted execution

ML Predictor — LSTM/RF/XGBoost signals

############
Protection Mechanisms
Stop-loss on exchange (survives crashes)

Cooldown after stop-loss

Minimum ROI time-based exits

Volatility auto-pause

Stale order timeout

Daily loss limit

Drawdown circuit breakers

########
Platform Features
SmartTrade terminal (simultaneous TP + SL)

Visual safety orders chart

AI grid suggestion

TradingView chart with indicators

Real-time order book & trade feed

Backtesting with grid search, genetic, Monte Carlo

Hyperopt parameter optimization

ML model training & inference

Copy trading marketplace

Telegram bot control (/status, /profit, /stop, etc.)

PWA with push notifications

Dark mode


############
Authentication
POST /api/v1/auth/register     # Create account
POST /api/v1/auth/login        # Login (returns JWT)
POST /api/v1/auth/refresh      # Refresh access token
POST /api/v1/auth/logout       # Invalidate tokens
GET  /api/v1/auth/me           # Current user
POST /api/v1/auth/2fa/setup    # Enable TOTP
POST /api/v1/auth/2fa/verify   # Verify TOTP

##########
Bots
GET    /api/v1/bots             # List bots
POST   /api/v1/bots             # Create bot
GET    /api/v1/bots/:id         # Get bot
PUT    /api/v1/bots/:id         # Update bot
DELETE /api/v1/bots/:id         # Delete bot
POST   /api/v1/bots/:id/start   # Start bot
POST   /api/v1/bots/:id/stop    # Stop bot
POST   /api/v1/bots/:id/pause   # Pause bot
GET    /api/v1/bots/grid-suggestion  # AI grid suggestion

#########
SmartTrade
POST /api/v1/smarttrade         # Create smart trade
GET  /api/v1/smarttrade         # List smart trades
POST /api/v1/smarttrade/:id/cancel  # Cancel trade

##########
Backtesting
POST /api/v1/backtest           # Run backtest
GET  /api/v1/backtest           # List results
GET  /api/v1/backtest/:id       # Get result
POST /api/v1/backtest/hyperopt  # Run optimization




---

### File: `cryptobot/.env.example`

```bash
# ============================================================
# DATABASE
# ============================================================
DB_USER=cryptobot
DB_PASSWORD=change-me-to-a-secure-password
DATABASE_URL=postgresql://cryptobot:change-me-to-a-secure-password@postgres:5432/cryptobot
DIRECT_DATABASE_URL=postgresql://cryptobot:change-me-to-a-secure-password@localhost:5432/cryptobot
DB_PORT=5432

# ============================================================
# REDIS
# ============================================================
REDIS_URL=redis://:redis-password@redis:6379
REDIS_PASSWORD=change-me-redis-password
REDIS_PORT=6379

# ============================================================
# JWT (Generate with: openssl genrsa -out private.pem 2048)
# ============================================================
JWT_PRIVATE_KEY="-----BEGIN RSA PRIVATE KEY-----
your-private-key-here
-----END RSA PRIVATE KEY-----"
JWT_PUBLIC_KEY="-----BEGIN PUBLIC KEY-----
your-public-key-here
-----END PUBLIC KEY-----"

# ============================================================
# ENCRYPTION (Generate with: openssl rand -base64 64)
# ============================================================
ENCRYPTION_MASTER_KEY=change-me-to-a-64-character-random-string-at-least

# ============================================================
# STRIPE
# ============================================================
STRIPE_SECRET_KEY=sk_live_xxxxxxxxxxxx
STRIPE_WEBHOOK_SECRET=whsec_xxxxxxxxxxxx
STRIPE_PUBLISHABLE_KEY=pk_live_xxxxxxxxxxxx

# ============================================================
# TELEGRAM
# ============================================================
TELEGRAM_BOT_TOKEN=123456789:ABCdefGHIjklMNOpqrsTUVwxyz

# ============================================================
# EMAIL (SMTP or SendGrid)
# ============================================================
SMTP_HOST=smtp.sendgrid.net
SMTP_PORT=587
SMTP_USER=apikey
SMTP_PASS=your-sendgrid-api-key
SENDGRID_API_KEY=your-sendgrid-api-key

# ============================================================
# WEB PUSH (VAPID)
# ============================================================
WEBPUSH_VAPID_PUBLIC=your-vapid-public-key
WEBPUSH_VAPID_PRIVATE=your-vapid-private-key

# ============================================================
# FRONTEND
# ============================================================
FRONTEND_URL=http://localhost:3001
NEXT_PUBLIC_API_URL=http://localhost:3000/api/v1
NEXT_PUBLIC_WS_URL=ws://localhost:3000
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_live_xxxxxxxxxxxx

# ============================================================
# SERVICE PORTS
# ============================================================
API_PORT=3000
FRONTEND_PORT=3001
VAULT_PORT=3003
MARKET_DATA_PORT=3004
BACKTEST_PORT=3005
RISK_PORT=3006
NOTIFICATION_PORT=3007
ML_PORT=3008
BILLING_PORT=3009
HTTP_PORT=80
HTTPS_PORT=443
PROMETHEUS_PORT=9090
GRAFANA_PORT=3030

# ============================================================
# GRAFANA
# ============================================================
GRAFANA_USER=admin
GRAFANA_PASSWORD=change-me-grafana-password

# ============================================================
# INTERNAL AUTH
# ============================================================
VAULT_AUTH_TOKEN=internal-vault-token-change-me
VAULT_URL=http://vault:3003

# ============================================================
# LOGGING
# ============================================================
LOG_LEVEL=info
NODE_ENV=production