const API_BASE = process.env.NEXT_PUBLIC_API_URL || "http://localhost:3000/api/v1";

interface RequestOptions {
  method?: string;
  body?: unknown;
  headers?: Record<string, string>;
  params?: Record<string, string>;
}

class ApiClient {
  private accessToken: string | null = null;
  private refreshPromise: Promise<string | null> | null = null;

  setAccessToken(token: string | null): void {
    this.accessToken = token;
  }

  getAccessToken(): string | null {
    return this.accessToken;
  }

  private async refreshAccessToken(): Promise<string | null> {
    if (this.refreshPromise) return this.refreshPromise;

    this.refreshPromise = (async () => {
      try {
        const res = await fetch(`${API_BASE}/auth/refresh`, {
          method: "POST",
          credentials: "include",
          headers: { "Content-Type": "application/json" },
        });

        if (!res.ok) {
          this.accessToken = null;
          return null;
        }

        const data = await res.json();
        if (data.success && data.data?.accessToken) {
          this.accessToken = data.data.accessToken;
          return this.accessToken;
        }
        return null;
      } catch {
        this.accessToken = null;
        return null;
      } finally {
        this.refreshPromise = null;
      }
    })();

    return this.refreshPromise;
  }

  async request<T = any>(path: string, options: RequestOptions = {}): Promise<T> {
    const url = new URL(`${API_BASE}${path}`);

    if (options.params) {
      Object.entries(options.params).forEach(([key, value]) => {
        url.searchParams.set(key, value);
      });
    }

    const headers: Record<string, string> = {
      "Content-Type": "application/json",
      ...options.headers,
    };

    if (this.accessToken) {
      headers["Authorization"] = `Bearer ${this.accessToken}`;
    }

    let res: Response;
    try {
      res = await fetch(url.toString(), {
        method: options.method || "GET",
        headers,
        body: options.body ? JSON.stringify(options.body) : undefined,
        credentials: "include",
        signal: AbortSignal.timeout(30000),
      });
    } catch (err: any) {
      if (err.name === "TimeoutError" || err.name === "AbortError") {
        throw new ApiError("Request timed out", "TIMEOUT", 408);
      }
      throw new ApiError("Network error — please check your connection", "NETWORK", 0);
    }

    // Token expired — refresh and retry once
    if (res.status === 401 && this.accessToken && !path.includes("/auth/")) {
      const newToken = await this.refreshAccessToken();
      if (newToken) {
        headers["Authorization"] = `Bearer ${newToken}`;
        try {
          res = await fetch(url.toString(), {
            method: options.method || "GET",
            headers,
            body: options.body ? JSON.stringify(options.body) : undefined,
            credentials: "include",
            signal: AbortSignal.timeout(30000),
          });
        } catch {
          throw new ApiError("Network error", "NETWORK", 0);
        }
      }
    }

    // Try to parse JSON, handle non-JSON responses
    let data: any;
    try {
      data = await res.json();
    } catch {
      if (!res.ok) {
        throw new ApiError(
          `Server error: ${res.status} ${res.statusText}`,
          "PARSE_ERROR",
          res.status
        );
      }
      return {} as T;
    }

    if (!res.ok || data.success === false) {
      throw new ApiError(
        data.error?.message || `Request failed with status ${res.status}`,
        data.error?.code || "UNKNOWN",
        res.status
      );
    }

    return data;
  }

  get<T = any>(path: string, params?: Record<string, string>): Promise<T> {
    return this.request<T>(path, { method: "GET", params });
  }

  post<T = any>(path: string, body?: unknown): Promise<T> {
    return this.request<T>(path, { method: "POST", body });
  }

  put<T = any>(path: string, body?: unknown): Promise<T> {
    return this.request<T>(path, { method: "PUT", body });
  }

  patch<T = any>(path: string, body?: unknown): Promise<T> {
    return this.request<T>(path, { method: "PATCH", body });
  }

  delete<T = any>(path: string): Promise<T> {
    return this.request<T>(path, { method: "DELETE" });
  }
}

export class ApiError extends Error {
  code: string;
  status: number;

  constructor(message: string, code: string, status: number) {
    super(message);
    this.name = "ApiError";
    this.code = code;
    this.status = status;
  }
}

export const api = new ApiClient();
export default api;