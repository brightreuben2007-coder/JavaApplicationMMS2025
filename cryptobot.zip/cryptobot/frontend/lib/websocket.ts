import { io, Socket } from "socket.io-client";

const WS_URL = process.env.NEXT_PUBLIC_WS_URL || "http://localhost:3000";

class WebSocketClient {
  private socket: Socket | null = null;
  private listeners: Map<string, Set<(...args: any[]) => void>> = new Map();
  private reconnectAttempts: number = 0;
  private maxReconnectAttempts: number = 10;

  connect(token: string): void {
    if (this.socket?.connected) return;

    this.socket = io(WS_URL, {
      auth: { token },
      transports: ["websocket", "polling"],
      reconnection: true,
      reconnectionDelay: 1000,
      reconnectionDelayMax: 30000,
      reconnectionAttempts: this.maxReconnectAttempts,
    });

    this.socket.on("connect", () => {
      this.reconnectAttempts = 0;
      console.log("[WS] Connected");
    });

    this.socket.on("disconnect", (reason) => {
      console.log("[WS] Disconnected:", reason);
    });

    this.socket.on("connect_error", (error) => {
      console.error("[WS] Connection error:", error.message);
    });

    // Re-bind all listeners
    for (const [event, callbacks] of this.listeners.entries()) {
      for (const cb of callbacks) {
        this.socket.on(event, cb);
      }
    }
  }

  disconnect(): void {
    if (this.socket) {
      this.socket.disconnect();
      this.socket = null;
    }
  }

  on(event: string, callback: (...args: any[]) => void): void {
    if (!this.listeners.has(event)) {
      this.listeners.set(event, new Set());
    }
    this.listeners.get(event)!.add(callback);

    if (this.socket) {
      this.socket.on(event, callback);
    }
  }

  off(event: string, callback: (...args: any[]) => void): void {
    this.listeners.get(event)?.delete(callback);
    if (this.socket) {
      this.socket.off(event, callback);
    }
  }

  emit(event: string, ...args: any[]): void {
    if (this.socket) {
      this.socket.emit(event, ...args);
    }
  }

  /**
   * Subscribe to market data for a pair.
   */
  subscribeMarket(exchange: string, pair: string): void {
    this.emit("subscribe:market", { exchange, pair });
  }

  /**
   * Subscribe to candles for a pair and timeframe.
   */
  subscribeCandles(exchange: string, pair: string, timeframe: string): void {
    this.emit("subscribe:candles", { exchange, pair, timeframe });
  }

  /**
   * Subscribe to bot status updates.
   */
  subscribeBots(): void {
    this.emit("subscribe:bots");
  }

  /**
   * Subscribe to alerts.
   */
  subscribeAlerts(): void {
    this.emit("subscribe:alerts");
  }

  /**
   * Subscribe to backtest/hyperopt progress.
   */
  subscribeBacktest(jobId: string): void {
    this.emit("subscribe:backtest", { jobId });
  }

  /**
   * Unsubscribe from market data.
   */
  unsubscribeMarket(exchange: string, pair: string): void {
    this.emit("unsubscribe:market", { exchange, pair });
  }

  isConnected(): boolean {
    return this.socket?.connected || false;
  }
}

export const ws = new WebSocketClient();
export default ws;