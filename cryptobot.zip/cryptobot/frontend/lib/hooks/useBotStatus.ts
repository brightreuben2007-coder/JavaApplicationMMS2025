import { useEffect } from "react";
import { useBotStore } from "../store/botStore";
import ws from "../websocket";

export function useBotStatus() {
  const bots = useBotStore((s) => s.bots);
  const fetchBots = useBotStore((s) => s.fetchBots);

  useEffect(() => {
    fetchBots();

    ws.on("bot:status", (data: any) => {
      // Refresh bots when status changes
      fetchBots();
    });

    ws.subscribeBots();

    return () => {
      ws.off("bot:status", () => {});
    };
  }, [fetchBots]);

  const activeBots = bots.filter((b) => b.status === "active");
  const pausedBots = bots.filter((b) => b.status === "paused");
  const stoppedBots = bots.filter((b) => b.status === "stopped");
  const totalPnl = bots.reduce((sum, b) => sum + (b.totalPnl || 0), 0);

  return { bots, activeBots, pausedBots, stoppedBots, totalPnl };
}