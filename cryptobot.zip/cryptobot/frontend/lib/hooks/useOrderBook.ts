import { useEffect, useCallback } from "react";
import { useMarketStore } from "../store/marketStore";
import ws from "../websocket";
import api from "../api";

export function useOrderBook(exchange: string, pair: string) {
  const setOrderBook = useMarketStore((s) => s.setOrderBook);
  const orderBook = useMarketStore((s) => s.orderBook);

  useEffect(() => {
    if (!exchange || !pair) return;

    // Subscribe to WebSocket
    ws.on("orderbook", (data: any) => {
      if (data.symbol === pair) {
        setOrderBook({
          bids: data.bids || [],
          asks: data.asks || [],
          timestamp: data.timestamp || Date.now(),
        });
      }
    });

    ws.subscribeMarket(exchange, pair);

    // Fetch initial snapshot
    api.get(`/ticker/${exchange}/${pair}`).catch(() => {});

    return () => {
      ws.unsubscribeMarket(exchange, pair);
    };
  }, [exchange, pair, setOrderBook]);

  const spread = orderBook?.bids?.[0] && orderBook?.asks?.[0]
    ? {
        absolute: orderBook.asks[0].price - orderBook.bids[0].price,
        percent: ((orderBook.asks[0].price - orderBook.bids[0].price) / orderBook.bids[0].price) * 100,
      }
    : null;

  const midPrice = orderBook?.bids?.[0] && orderBook?.asks?.[0]
    ? (orderBook.bids[0].price + orderBook.asks[0].price) / 2
    : null;

  return { orderBook, spread, midPrice };
}