"use client";

import { useCallback } from "react";

interface ShareData {
  title?: string;
  text?: string;
  url?: string;
}

export function useWebShare() {
  const isSupported =
    typeof navigator !== "undefined" && "share" in navigator;

  const share = useCallback(
    async (data: ShareData): Promise<boolean> => {
      if (!isSupported) return false;

      try {
        await navigator.share(data);
        return true;
      } catch (err: any) {
        // User cancelled or error
        if (err.name !== "AbortError") {
          console.warn("Share failed:", err.message);
        }
        return false;
      }
    },
    [isSupported]
  );

  return { isSupported, share };
}