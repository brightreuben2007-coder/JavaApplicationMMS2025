import { useEffect, useCallback } from "react";
import { useMarketStore } from "../store/marketStore";
import ws from "../websocket";
import api from "../api";

export function useCandles(exchange: string, pair: string, timeframe: string) {
  const setCandles = useMarketStore((s) => s.setCandles);
  const candles = useMarketStore((s) => s.candles);

  useEffect(() => {
    if (!exchange || !pair || !timeframe) return;

    // Fetch historical candles
    api
      .get(`/candles/${exchange}/${pair}/${timeframe}`, { limit: "200" })
      .then((res) => {
        const formatted = (res.data || []).map((c: any) => ({
          time: c.timestamp / 1000,
          open: c.open,
          high: c.high,
          low: c.low,
          close: c.close,
          volume: c.volume,
        }));
        setCandles(formatted);
      })
      .catch(() => {});

    // Subscribe to real-time candles
    ws.on("candles:update", (data: any) => {
      setCandles((prev: any[]) => {
        const candle = {
          time: data.timestamp / 1000,
          open: data.open,
          high: data.high,
          low: data.low,
          close: data.close,
          volume: data.volume,
        };

        // Update last candle or append new
        const existing = [...prev];
        const lastIdx = existing.length - 1;
        if (lastIdx >= 0 && existing[lastIdx]?.time === candle.time) {
          existing[lastIdx] = candle;
        } else {
          existing.push(candle);
        }

        return existing.slice(-300);
      });
    });

    ws.subscribeCandles(exchange, pair, timeframe);

    return () => {
      ws.off("candles:update", () => {});
    };
  }, [exchange, pair, timeframe, setCandles]);

  return { candles };
}