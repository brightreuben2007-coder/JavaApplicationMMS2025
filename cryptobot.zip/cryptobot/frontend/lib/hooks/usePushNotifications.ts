"use client";

import { useState, useEffect, useCallback } from "react";
import api from "../api";

interface PushState {
  isSupported: boolean;
  isSubscribed: boolean;
  isLoading: boolean;
  error: string | null;
}

function urlBase64ToUint8Array(base64String: string): Uint8Array {
  const padding = "=".repeat((4 - (base64String.length % 4)) % 4);
  const base64 = (base64String + padding).replace(/-/g, "+").replace(/_/g, "/");
  const rawData = window.atob(base64);
  const outputArray = new Uint8Array(rawData.length);
  for (let i = 0; i < rawData.length; ++i) {
    outputArray[i] = rawData.charCodeAt(i);
  }
  return outputArray;
}

export function usePushNotifications(userId: string | null) {
  const [state, setState] = useState<PushState>({
    isSupported: false,
    isSubscribed: false,
    isLoading: true,
    error: null,
  });

  // Check support
  useEffect(() => {
    const supported =
      "serviceWorker" in navigator &&
      "PushManager" in window &&
      "Notification" in window;

    setState((prev) => ({ ...prev, isSupported: supported, isLoading: false }));
  }, []);

  // Check current subscription
  useEffect(() => {
    if (!state.isSupported) return;

    navigator.serviceWorker.ready.then((registration) => {
      registration.pushManager.getSubscription().then((subscription) => {
        setState((prev) => ({
          ...prev,
          isSubscribed: !!subscription,
          isLoading: false,
        }));
      });
    });
  }, [state.isSupported]);

  const subscribe = useCallback(async () => {
    if (!state.isSupported) {
      setState((prev) => ({ ...prev, error: "Push notifications not supported" }));
      return;
    }

    setState((prev) => ({ ...prev, isLoading: true, error: null }));

    try {
      const permission = await Notification.requestPermission();
      if (permission !== "granted") {
        setState((prev) => ({
          ...prev,
          isLoading: false,
          error: "Permission denied",
        }));
        return;
      }

      const registration = await navigator.serviceWorker.ready;

      // Get VAPID public key from server
      const vapidRes = await api.get("/push/subscribe");
      const vapidPublicKey = vapidRes?.data?.vapidPublicKey;

      if (!vapidPublicKey) {
        throw new Error("VAPID public key not available");
      }

      const subscription = await registration.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: urlBase64ToUint8Array(vapidPublicKey),
      });

      // Send subscription to server
      await api.post("/push/subscribe", {
        userId,
        subscription: subscription.toJSON(),
      });

      setState((prev) => ({ ...prev, isSubscribed: true, isLoading: false }));
    } catch (err: any) {
      setState((prev) => ({
        ...prev,
        isLoading: false,
        error: err.message || "Failed to subscribe",
      }));
    }
  }, [state.isSupported, userId]);

  const unsubscribe = useCallback(async () => {
    setState((prev) => ({ ...prev, isLoading: true }));

    try {
      const registration = await navigator.serviceWorker.ready;
      const subscription = await registration.pushManager.getSubscription();

      if (subscription) {
        await subscription.unsubscribe();
        await api.post("/push/unsubscribe", {
          userId,
          endpoint: subscription.endpoint,
        });
      }

      setState((prev) => ({ ...prev, isSubscribed: false, isLoading: false }));
    } catch (err: any) {
      setState((prev) => ({
        ...prev,
        isLoading: false,
        error: err.message || "Failed to unsubscribe",
      }));
    }
  }, [userId]);

  return {
    ...state,
    subscribe,
    unsubscribe,
  };
}