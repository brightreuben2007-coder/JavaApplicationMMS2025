import { create } from "zustand";
import { persist } from "zustand/middleware";
import api from "../api";
import ws from "../websocket";

interface User {
  id: string;
  email: string;
  planTier: string;
  onboardingCompleted: boolean;
  demoMode: boolean;
  hasTotp: boolean;
  hasWebAuthn: boolean;
}

interface AuthState {
  user: User | null;
  accessToken: string | null;
  isLoading: boolean;
  requiresTotp: boolean;
  error: string | null;
  isInitialized: boolean;

  login: (email: string, password: string, totpCode?: string) => Promise<void>;
  register: (email: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
  refreshToken: () => Promise<string | null>;
  fetchCurrentUser: () => Promise<void>;
  clearError: () => void;
  initialize: () => Promise<void>;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set, get) => ({
      user: null,
      accessToken: null,
      isLoading: false,
      requiresTotp: false,
      error: null,
      isInitialized: false,

      initialize: async () => {
        const token = get().accessToken;
        if (token) {
          api.setAccessToken(token);
          ws.connect(token);
          try {
            const res = await api.get("/auth/me");
            set({ user: res.data, isInitialized: true });
          } catch {
            // Token expired, try refresh
            const newToken = await get().refreshToken();
            if (newToken) {
              try {
                const res = await api.get("/auth/me");
                set({ user: res.data, isInitialized: true });
              } catch {
                set({ user: null, accessToken: null, isInitialized: true });
              }
            } else {
              set({ user: null, accessToken: null, isInitialized: true });
            }
          }
        } else {
          set({ isInitialized: true });
        }
      },

      login: async (email, password, totpCode) => {
        set({ isLoading: true, error: null, requiresTotp: false });
        try {
          const res = await api.post("/auth/login", { email, password, totpCode });

          if (res.data?.requiresTotp) {
            set({ requiresTotp: true, isLoading: false });
            return;
          }

          const { user, accessToken } = res.data;
          api.setAccessToken(accessToken);
          ws.connect(accessToken);
          set({ user, accessToken, requiresTotp: false, isLoading: false });
        } catch (err: any) {
          set({ error: err.message || "Login failed", isLoading: false });
          throw err;
        }
      },

      register: async (email, password) => {
        set({ isLoading: true, error: null });
        try {
          const res = await api.post("/auth/register", { email, password });
          const { user, accessToken } = res.data;
          api.setAccessToken(accessToken);
          ws.connect(accessToken);
          set({ user, accessToken, isLoading: false });
        } catch (err: any) {
          set({ error: err.message || "Registration failed", isLoading: false });
          throw err;
        }
      },

      logout: async () => {
        try {
          await api.post("/auth/logout");
        } catch {
          // Ignore network errors during logout
        }
        api.setAccessToken(null);
        ws.disconnect();
        set({ user: null, accessToken: null, isInitialized: true });

        // Clear persisted state
        if (typeof window !== "undefined") {
          localStorage.removeItem("cryptobot-auth");
        }

        window.location.href = "/login";
      },

      refreshToken: async () => {
        try {
          const res = await api.post("/auth/refresh");
          const { accessToken } = res.data;
          api.setAccessToken(accessToken);
          ws.connect(accessToken);
          set({ accessToken });
          return accessToken;
        } catch {
          set({ user: null, accessToken: null });
          api.setAccessToken(null);
          ws.disconnect();
          return null;
        }
      },

      fetchCurrentUser: async () => {
        try {
          const res = await api.get("/auth/me");
          set({ user: res.data });
        } catch {
          // If unauthorized, try refresh
          if (get().accessToken) {
            const newToken = await get().refreshToken();
            if (newToken) {
              try {
                const res = await api.get("/auth/me");
                set({ user: res.data });
              } catch {
                set({ user: null, accessToken: null });
              }
            }
          }
        }
      },

      clearError: () => set({ error: null }),
    }),
    {
      name: "cryptobot-auth",
      partialize: (state) => ({
        accessToken: state.accessToken,
        user: state.user,
      }),
    }
  )
);