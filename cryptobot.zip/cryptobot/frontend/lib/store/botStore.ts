import { create } from "zustand";
import api from "../api";

interface Bot {
  id: string;
  name: string;
  exchange: string;
  pair: string;
  strategyType: string;
  config: any;
  status: "active" | "paused" | "stopped" | "error";
  paperTrading: boolean;
  totalPnl: number;
  totalTrades: number;
  winRate: number;
  createdAt: string;
}

interface BotState {
  bots: Bot[];
  selectedBot: Bot | null;
  isLoading: boolean;
  error: string | null;

  fetchBots: () => Promise<void>;
  fetchBot: (id: string) => Promise<void>;
  createBot: (data: any) => Promise<Bot>;
  updateBot: (id: string, data: any) => Promise<void>;
  deleteBot: (id: string) => Promise<void>;
  startBot: (id: string) => Promise<void>;
  stopBot: (id: string) => Promise<void>;
  pauseBot: (id: string) => Promise<void>;
}

export const useBotStore = create<BotState>((set, get) => ({
  bots: [],
  selectedBot: null,
  isLoading: false,
  error: null,

  fetchBots: async () => {
    set({ isLoading: true });
    try {
      const res = await api.get("/bots");
      set({ bots: res.data, isLoading: false });
    } catch (err: any) {
      set({ error: err.message, isLoading: false });
    }
  },

  fetchBot: async (id) => {
    try {
      const res = await api.get(`/bots/${id}`);
      set({ selectedBot: res.data });
    } catch (err: any) {
      set({ error: err.message });
    }
  },

  createBot: async (data) => {
    const res = await api.post("/bots", data);
    set((state) => ({ bots: [res.data, ...state.bots] }));
    return res.data;
  },

  updateBot: async (id, data) => {
    const res = await api.put(`/bots/${id}`, data);
    set((state) => ({
      bots: state.bots.map((b) => (b.id === id ? { ...b, ...res.data } : b)),
      selectedBot: state.selectedBot?.id === id ? { ...state.selectedBot, ...res.data } : state.selectedBot,
    }));
  },

  deleteBot: async (id) => {
    await api.delete(`/bots/${id}`);
    set((state) => ({
      bots: state.bots.filter((b) => b.id !== id),
      selectedBot: state.selectedBot?.id === id ? null : state.selectedBot,
    }));
  },

  startBot: async (id) => {
    const res = await api.post(`/bots/${id}/start`);
    set((state) => ({
      bots: state.bots.map((b) => (b.id === id ? { ...b, status: "active" } : b)),
    }));
  },

  stopBot: async (id) => {
    await api.post(`/bots/${id}/stop`);
    set((state) => ({
      bots: state.bots.map((b) => (b.id === id ? { ...b, status: "stopped" } : b)),
    }));
  },

  pauseBot: async (id) => {
    await api.post(`/bots/${id}/pause`);
    set((state) => ({
      bots: state.bots.map((b) => (b.id === id ? { ...b, status: "paused" } : b)),
    }));
  },
}));