import { create } from "zustand";
import api from "../api";

interface PortfolioSummary {
  totalValue: number;
  unrealizedPnl: number;
  realizedPnl: number;
  totalPnl: number;
  activePositions: number;
  totalBots: number;
  activeBots: number;
}

interface Position {
  id: string;
  pair: string;
  side: string;
  entryPrice: number;
  currentPrice: number;
  quantity: number;
  unrealizedPnl: number;
  leverage: number;
  openedAt: string;
}

interface PortfolioState {
  summary: PortfolioSummary | null;
  positions: Position[];
  isLoading: boolean;

  fetchSummary: () => Promise<void>;
  fetchPositions: () => Promise<void>;
}

export const usePortfolioStore = create<PortfolioState>((set) => ({
  summary: null,
  positions: [],
  isLoading: false,

  fetchSummary: async () => {
    set({ isLoading: true });
    try {
      const res = await api.get("/portfolio/summary");
      set({ summary: res.data, isLoading: false });
    } catch {
      set({ isLoading: false });
    }
  },

  fetchPositions: async () => {
    try {
      const res = await api.get("/portfolio/positions");
      set({ positions: res.data });
    } catch {
      // Silent
    }
  },
}));