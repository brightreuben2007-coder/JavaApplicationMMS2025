import { create } from "zustand";

interface Ticker {
  symbol: string;
  last: number;
  bid: number;
  ask: number;
  high24h: number;
  low24h: number;
  volume24h: number;
  changePercent24h: number;
  timestamp: number;
}

interface OrderBookLevel {
  price: number;
  quantity: number;
}

interface OrderBook {
  bids: OrderBookLevel[];
  asks: OrderBookLevel[];
  timestamp: number;
}

interface TradeTick {
  id: string;
  price: number;
  quantity: number;
  side: "buy" | "sell";
  timestamp: number;
}

interface MarketState {
  selectedExchange: string;
  selectedPair: string;
  selectedTimeframe: string;
  ticker: Ticker | null;
  orderBook: OrderBook | null;
  trades: TradeTick[];
  candles: Array<{
    time: number;
    open: number;
    high: number;
    low: number;
    close: number;
    volume: number;
  }>;

  setSelectedExchange: (exchange: string) => void;
  setSelectedPair: (pair: string) => void;
  setSelectedTimeframe: (timeframe: string) => void;
  setTicker: (ticker: Ticker) => void;
  setOrderBook: (orderBook: OrderBook) => void;
  addTrade: (trade: TradeTick) => void;
  setCandles: (candles: any[]) => void;
}

export const useMarketStore = create<MarketState>((set) => ({
  selectedExchange: "binance",
  selectedPair: "BTC/USDT",
  selectedTimeframe: "1h",
  ticker: null,
  orderBook: null,
  trades: [],
  candles: [],

  setSelectedExchange: (exchange) => set({ selectedExchange: exchange }),
  setSelectedPair: (pair) => set({ selectedPair: pair }),
  setSelectedTimeframe: (timeframe) => set({ selectedTimeframe: timeframe }),
  setTicker: (ticker) => set({ ticker }),
  setOrderBook: (orderBook) => set({ orderBook }),
  addTrade: (trade) =>
    set((state) => ({
      trades: [trade, ...state.trades].slice(0, 100),
    })),
  setCandles: (candles) => set({ candles }),
}));