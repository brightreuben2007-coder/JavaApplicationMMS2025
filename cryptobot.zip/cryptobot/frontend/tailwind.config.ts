import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: "class",
  content: [
    "./app/**/*.{ts,tsx}",
    "./components/**/*.{ts,tsx}",
    "./lib/**/*.{ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        brand: {
          50: "#eef7ff",
          100: "#d9edff",
          200: "#bce0ff",
          300: "#8ecdff",
          400: "#59b0ff",
          500: "#338dff",
          600: "#1b6ef5",
          700: "#1458e1",
          800: "#1748b6",
          900: "#193f8f",
          950: "#142757",
        },
        profit: "#22c55e",
        loss: "#ef4444",
        warning: "#f59e0b",
        surface: {
          DEFAULT: "#ffffff",
          dark: "#0f172a",
        },
        card: {
          DEFAULT: "#f8fafc",
          dark: "#1e293b",
        },
      },
      fontFamily: {
        sans: ["Inter", "system-ui", "sans-serif"],
        mono: ["JetBrains Mono", "monospace"],
      },
    },
  },
  plugins: [],
};
export default config;