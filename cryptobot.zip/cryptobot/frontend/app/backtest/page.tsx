"use client";

import { useState, useEffect, useRef } from "react";
import { LineChart, Play, Download, Zap, TrendingUp, TrendingDown, Activity } from "lucide-react";
import { useMarketStore } from "@/lib/store/marketStore";
import api from "@/lib/api";

interface BacktestResults {
  jobId: string;
  status: string;
  metrics?: {
    totalReturnPercent: number;
    sharpeRatio: number;
    sortinoRatio: number;
    maxDrawdownPercent: number;
    winRate: number;
    profitFactor: number;
    totalTrades: number;
    winningTrades: number;
    losingTrades: number;
    avgWin: number;
    avgLoss: number;
    largestWin: number;
    largestLoss: number;
    expectancy: number;
    avgTradeDurationMs: number;
  };
  equityCurve?: Array<{ timestamp: number; equity: number }>;
  trades?: Array<{
    entryTimestamp: number;
    exitTimestamp: number;
    entryPrice: number;
    exitPrice: number;
    quantity: number;
    pnl: number;
    pnlPercent: number;
    exitReason: string;
  }>;
  error?: string;
}

const TIMEFRAMES = ["1m", "5m", "15m", "1h", "4h", "1d"];
const STRATEGIES = ["dca", "grid", "macd", "bollinger", "martingale"];

export default function BacktestPage() {
  const { selectedPair, selectedExchange } = useMarketStore();
  const [pair, setPair] = useState(selectedPair);
  const [timeframe, setTimeframe] = useState("1h");
  const [dateStart, setDateStart] = useState("2024-01-01");
  const [dateEnd, setDateEnd] = useState("2024-06-01");
  const [initialBalance, setInitialBalance] = useState(10000);
  const [strategyType, setStrategyType] = useState("dca");
  const [isRunning, setIsRunning] = useState(false);
  const [progress, setProgress] = useState(0);
  const [results, setResults] = useState<BacktestResults | null>(null);
  const [error, setError] = useState<string | null>(null);

  // Refs for cleanup
  const pollRef = useRef<NodeJS.Timeout | null>(null);
  const mountedRef = useRef(true);

  // Cleanup on unmount
  useEffect(() => {
    mountedRef.current = true;
    return () => {
      mountedRef.current = false;
      if (pollRef.current) {
        clearInterval(pollRef.current);
        pollRef.current = null;
      }
    };
  }, []);

  const runBacktest = async () => {
    setIsRunning(true);
    setError(null);
    setResults(null);
    setProgress(0);

    try {
      const res = await api.post("/backtest", {
        pair,
        exchange: selectedExchange,
        timeframe,
        dateStart: new Date(dateStart).toISOString(),
        dateEnd: new Date(dateEnd).toISOString(),
        initialBalance,
        strategyConfig: { type: strategyType },
      });

      const jobId = res.data?.jobId;
      if (!jobId) {
        throw new Error("No job ID returned");
      }

      // Poll for results with cleanup
      pollRef.current = setInterval(async () => {
        if (!mountedRef.current) {
          if (pollRef.current) clearInterval(pollRef.current);
          return;
        }

        try {
          const status = await api.get(`/backtest/job/${jobId}`);

          if (!mountedRef.current) return;

          const data = status.data || status;

          // Update progress
          if (data.progress) {
            setProgress(data.progress);
          }

          if (data.status === "completed") {
            if (pollRef.current) {
              clearInterval(pollRef.current);
              pollRef.current = null;
            }
            setResults(data);
            setIsRunning(false);
            setProgress(100);
          } else if (data.status === "failed") {
            if (pollRef.current) {
              clearInterval(pollRef.current);
              pollRef.current = null;
            }
            setError(data.error || "Backtest failed");
            setIsRunning(false);
          }
        } catch (err: any) {
          // Don't stop polling on network errors — retry
          console.warn("Poll error:", err.message);
        }
      }, 2000);
    } catch (err: any) {
      if (!mountedRef.current) return;
      setError(err.message || "Failed to start backtest");
      setIsRunning(false);
    }
  };

  const handleCancel = () => {
    if (pollRef.current) {
      clearInterval(pollRef.current);
      pollRef.current = null;
    }
    setIsRunning(false);
    setProgress(0);
  };

  const formatDuration = (ms: number): string => {
    if (ms <= 0) return "N/A";
    const hours = Math.floor(ms / 3600000);
    const minutes = Math.floor((ms % 3600000) / 60000);
    if (hours > 24) {
      const days = Math.floor(hours / 24);
      return `${days}d ${hours % 24}h`;
    }
    return `${hours}h ${minutes}m`;
  };

  // Group trades by exit reason
  const exitReasons = results?.trades
    ? Object.entries(
        results.trades.reduce((acc: Record<string, number>, t) => {
          acc[t.exitReason] = (acc[t.exitReason] || 0) + 1;
          return acc;
        }, {})
      )
    : [];

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      <div className="flex items-center gap-2">
        <LineChart className="w-5 h-5 text-brand-500" />
        <h1 className="text-xl font-bold text-slate-900 dark:text-white">Backtesting</h1>
      </div>

      {error && (
        <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 text-red-600 dark:text-red-400 p-3 rounded-lg text-sm flex items-center justify-between">
          <span>{error}</span>
          <button onClick={() => setError(null)} className="text-red-400 hover:text-red-600">&times;</button>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Config Panel */}
        <div className="card p-4 space-y-4">
          <h2 className="font-semibold text-sm">Configuration</h2>

          <div>
            <label className="text-xs text-slate-500 block mb-1">Trading Pair</label>
            <input
              value={pair}
              onChange={(e) => setPair(e.target.value.toUpperCase())}
              className="input text-sm"
              placeholder="BTC/USDT"
              disabled={isRunning}
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs text-slate-500 block mb-1">Start Date</label>
              <input
                type="date"
                value={dateStart}
                onChange={(e) => setDateStart(e.target.value)}
                className="input text-sm"
                disabled={isRunning}
              />
            </div>
            <div>
              <label className="text-xs text-slate-500 block mb-1">End Date</label>
              <input
                type="date"
                value={dateEnd}
                onChange={(e) => setDateEnd(e.target.value)}
                className="input text-sm"
                disabled={isRunning}
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs text-slate-500 block mb-1">Timeframe</label>
              <select
                value={timeframe}
                onChange={(e) => setTimeframe(e.target.value)}
                className="input text-sm"
                disabled={isRunning}
              >
                {TIMEFRAMES.map((tf) => (
                  <option key={tf} value={tf}>{tf}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="text-xs text-slate-500 block mb-1">Strategy</label>
              <select
                value={strategyType}
                onChange={(e) => setStrategyType(e.target.value)}
                className="input text-sm"
                disabled={isRunning}
              >
                {STRATEGIES.map((s) => (
                  <option key={s} value={s}>{s.toUpperCase()}</option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label className="text-xs text-slate-500 block mb-1">Initial Balance (USDT)</label>
            <input
              type="number"
              value={initialBalance}
              onChange={(e) => setInitialBalance(parseInt(e.target.value) || 0)}
              className="input text-sm"
              min={100}
              step={1000}
              disabled={isRunning}
            />
          </div>

          <div className="flex gap-2">
            <button
              onClick={runBacktest}
              disabled={isRunning}
              className="btn-primary flex-1 flex items-center justify-center gap-2"
            >
              {isRunning ? (
                <>
                  <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full" />
                  Running...
                </>
              ) : (
                <>
                  <Play className="w-4 h-4" /> Run Backtest
                </>
              )}
            </button>
            {isRunning && (
              <button onClick={handleCancel} className="btn-secondary">
                Cancel
              </button>
            )}
          </div>

          {/* Progress bar */}
          {isRunning && (
            <div className="space-y-1">
              <div className="h-1.5 bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden">
                <div
                  className="h-full bg-brand-500 rounded-full transition-all duration-500"
                  style={{ width: `${Math.max(5, progress)}%` }}
                />
              </div>
              <p className="text-xs text-slate-500 text-center">Processing... {progress}%</p>
            </div>
          )}
        </div>

        {/* Results Panel */}
        <div className="lg:col-span-2 card p-4 min-h-[400px]">
          <h2 className="font-semibold text-sm mb-4">Results</h2>

          {results ? (
            <div className="space-y-6">
              {/* Performance Metrics */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                {[
                  { label: "Total Return", value: `${(results.metrics?.totalReturnPercent || 0) >= 0 ? "+" : ""}${(results.metrics?.totalReturnPercent || 0).toFixed(2)}%`, color: (results.metrics?.totalReturnPercent || 0) >= 0 ? "text-emerald-500" : "text-red-500" },
                  { label: "Sharpe Ratio", value: (results.metrics?.sharpeRatio || 0).toFixed(2), color: "text-slate-700 dark:text-slate-300" },
                  { label: "Sortino Ratio", value: (results.metrics?.sortinoRatio || 0).toFixed(2), color: "text-slate-700 dark:text-slate-300" },
                  { label: "Max Drawdown", value: `${(results.metrics?.maxDrawdownPercent || 0).toFixed(2)}%`, color: "text-red-500" },
                  { label: "Win Rate", value: `${(results.metrics?.winRate || 0).toFixed(1)}%`, color: "text-slate-700 dark:text-slate-300" },
                  { label: "Profit Factor", value: (results.metrics?.profitFactor || 0) > 999 ? "∞" : (results.metrics?.profitFactor || 0).toFixed(2), color: "text-slate-700 dark:text-slate-300" },
                  { label: "Total Trades", value: String(results.metrics?.totalTrades || 0), color: "text-slate-700 dark:text-slate-300" },
                  { label: "Expectancy", value: `$${(results.metrics?.expectancy || 0).toFixed(2)}`, color: (results.metrics?.expectancy || 0) >= 0 ? "text-emerald-500" : "text-red-500" },
                  { label: "Avg Win", value: `$${(results.metrics?.avgWin || 0).toFixed(2)}`, color: "text-emerald-500" },
                  { label: "Avg Loss", value: `$${Math.abs(results.metrics?.avgLoss || 0).toFixed(2)}`, color: "text-red-500" },
                  { label: "Largest Win", value: `$${(results.metrics?.largestWin || 0).toFixed(2)}`, color: "text-emerald-500" },
                  { label: "Largest Loss", value: `$${Math.abs(results.metrics?.largestLoss || 0).toFixed(2)}`, color: "text-red-500" },
                  { label: "Avg Duration", value: formatDuration(results.metrics?.avgTradeDurationMs || 0), color: "text-slate-700 dark:text-slate-300" },
                  { label: "W/L Ratio", value: `${results.metrics?.winningTrades || 0}W / ${results.metrics?.losingTrades || 0}L`, color: "text-slate-700 dark:text-slate-300" },
                ].map((m) => (
                  <div key={m.label} className="bg-slate-50 dark:bg-slate-800/50 rounded-lg p-3">
                    <div className="text-xs text-slate-500">{m.label}</div>
                    <div className={`font-mono font-bold text-sm ${m.color}`}>{m.value}</div>
                  </div>
                ))}
              </div>

              {/* Exit Reasons */}
              {exitReasons.length > 0 && (
                <div>
                  <h3 className="text-sm font-semibold mb-2">Exit Reasons</h3>
                  <div className="flex flex-wrap gap-2">
                    {exitReasons.map(([reason, count]) => (
                      <span
                        key={reason}
                        className="text-xs px-2 py-1 rounded-full bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-400"
                      >
                        {reason}: {count}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {/* Trade Log */}
              {results.trades && results.trades.length > 0 && (
                <div>
                  <h3 className="text-sm font-semibold mb-2">Recent Trades</h3>
                  <div className="overflow-auto max-h-64">
                    <table className="w-full text-xs">
                      <thead>
                        <tr className="text-slate-400 border-b border-slate-100 dark:border-slate-800">
                          <th className="text-left py-1">Entry</th>
                          <th className="text-left py-1">Exit</th>
                          <th className="text-right py-1">Price</th>
                          <th className="text-right py-1">Exit $</th>
                          <th className="text-right py-1">Qty</th>
                          <th className="text-right py-1">PnL</th>
                          <th className="text-right py-1">Reason</th>
                        </tr>
                      </thead>
                      <tbody>
                        {results.trades.slice(-20).map((t, i) => (
                          <tr key={i} className="border-b border-slate-50 dark:border-slate-800/50">
                            <td className="py-1 font-mono text-slate-500">
                              {new Date(t.entryTimestamp).toLocaleDateString()}
                            </td>
                            <td className="py-1 font-mono text-slate-500">
                              {new Date(t.exitTimestamp).toLocaleDateString()}
                            </td>
                            <td className="py-1 text-right font-mono">${t.entryPrice.toFixed(2)}</td>
                            <td className="py-1 text-right font-mono">${t.exitPrice.toFixed(2)}</td>
                            <td className="py-1 text-right font-mono">{t.quantity.toFixed(4)}</td>
                            <td className={`py-1 text-right font-mono font-medium ${t.pnl >= 0 ? "text-emerald-500" : "text-red-500"}`}>
                              {t.pnl >= 0 ? "+" : ""}{t.pnl.toFixed(2)}
                            </td>
                            <td className="py-1 text-right text-slate-400">{t.exitReason}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center h-64 text-slate-400">
              <LineChart className="w-12 h-12 mb-3" />
              <p className="text-sm">{isRunning ? "Backtest in progress..." : "Configure and run a backtest to see results"}</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}