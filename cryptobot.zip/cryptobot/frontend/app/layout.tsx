import type { Metadata, Viewport } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import { Providers } from "./providers";
import { Sidebar } from "@/components/layout/Sidebar";
import { TopBar } from "@/components/layout/TopBar";
import { MetricsBar } from "@/components/layout/MetricsBar";
import { MobileBottomNav } from "@/components/layout/MobileBottomNav";

const inter = Inter({ subsets: ["latin"] });

export const metadata: Metadata = {
  title: "CryptoBot — Automated Trading Platform",
  description: "Professional cryptocurrency trading bot with DCA, Grid, Market Making, and ML strategies",
  manifest: "/manifest.json",
  appleWebApp: {
    capable: true,
    statusBarStyle: "black-translucent",
    title: "CryptoBot",
  },
  applicationName: "CryptoBot",
  formatDetection: {
    telephone: false,
  },
};

export const viewport: Viewport = {
  themeColor: [
    { media: "(prefers-color-scheme: light)", color: "#ffffff" },
    { media: "(prefers-color-scheme: dark)", color: "#0f172a" },
  ],
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <link rel="apple-touch-icon" href="/icons/icon-192.png" />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="mobile-web-app-capable" content="yes" />
      </head>
      <body className={inter.className}>
        <Providers>
          <div className="flex h-screen overflow-hidden">
            {/* Desktop Sidebar — hidden on mobile */}
            <div className="hidden md:block">
              <Sidebar />
            </div>
            <div className="flex-1 flex flex-col overflow-hidden">
              <TopBar />
              <MetricsBar />
              <main className="flex-1 overflow-auto p-4 pb-20 md:pb-4">{children}</main>
            </div>
          </div>
          {/* Mobile Bottom Nav */}
          <MobileBottomNav />
        </Providers>
      </body>
    </html>
  );
}