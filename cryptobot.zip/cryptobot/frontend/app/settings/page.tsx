"use client";

import { useState } from "react";
import { Settings, Key, Shield, Bell, AlertTriangle, CreditCard, Server } from "lucide-react";
import { useAuthStore } from "@/lib/store/authStore";

type SettingsTab = "credentials" | "security" | "notifications" | "risk" | "billing";

const TABS: Array<{ id: SettingsTab; label: string; icon: any }> = [
  { id: "credentials", label: "Exchange Credentials", icon: Key },
  { id: "security", label: "Security", icon: Shield },
  { id: "notifications", label: "Notifications", icon: Bell },
  { id: "risk", label: "Risk Limits", icon: AlertTriangle },
  { id: "billing", label: "Billing", icon: CreditCard },
];

export default function SettingsPage() {
  const [activeTab, setActiveTab] = useState<SettingsTab>("credentials");
  const user = useAuthStore((s) => s.user);

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="flex items-center gap-2">
        <Settings className="w-5 h-5 text-brand-500" />
        <h1 className="text-xl font-bold text-slate-900 dark:text-white">Settings</h1>
      </div>

      <div className="flex gap-6">
        {/* Tab sidebar */}
        <div className="w-56 flex-shrink-0 space-y-1">
          {TABS.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                activeTab === tab.id
                  ? "bg-brand-50 dark:bg-brand-900/20 text-brand-600 dark:text-brand-400"
                  : "text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800"
              }`}
            >
              <tab.icon className="w-4 h-4" />
              {tab.label}
            </button>
          ))}
        </div>

        {/* Tab content */}
        <div className="flex-1 card p-6 min-h-[400px]">
          {activeTab === "credentials" && (
            <div className="space-y-4">
              <h2 className="font-semibold">Exchange Credentials</h2>
              <p className="text-sm text-slate-500">Connect your exchange accounts via API keys. Never enable withdrawal permissions.</p>
              <div className="flex items-center justify-center py-12 text-slate-400">
                <div className="text-center">
                  <Server className="w-10 h-10 mx-auto mb-2" />
                  <p className="text-sm">No exchange credentials connected yet</p>
                  <button className="btn-primary mt-3 text-sm">Connect Exchange</button>
                </div>
              </div>
            </div>
          )}

          {activeTab === "security" && (
            <div className="space-y-4">
              <h2 className="font-semibold">Security</h2>
              <div className="space-y-3">
                <div className="flex items-center justify-between py-3 border-b border-slate-100 dark:border-slate-800">
                  <div>
                    <div className="text-sm font-medium">Two-Factor Authentication</div>
                    <div className="text-xs text-slate-500">{user?.hasTotp ? "Enabled" : "Not configured"}</div>
                  </div>
                  <button className="btn-secondary text-sm">{user?.hasTotp ? "Disable" : "Setup 2FA"}</button>
                </div>
                <div className="flex items-center justify-between py-3 border-b border-slate-100 dark:border-slate-800">
                  <div>
                    <div className="text-sm font-medium">Passkey (WebAuthn)</div>
                    <div className="text-xs text-slate-500">{user?.hasWebAuthn ? "Registered" : "Not configured"}</div>
                  </div>
                  <button className="btn-secondary text-sm">Add Passkey</button>
                </div>
                <div className="flex items-center justify-between py-3">
                  <div>
                    <div className="text-sm font-medium">IP Whitelist</div>
                    <div className="text-xs text-slate-500">Restrict access to specific IPs</div>
                  </div>
                  <button className="btn-secondary text-sm">Configure</button>
                </div>
              </div>
            </div>
          )}

          {activeTab === "notifications" && (
            <div className="space-y-4">
              <h2 className="font-semibold">Notifications</h2>
              <div className="space-y-3">
                {["Deal Opened", "Deal Closed", "Take Profit Hit", "Stop Loss Hit", "Risk Alerts", "Daily Summary"].map((event) => (
                  <div key={event} className="flex items-center justify-between py-2 border-b border-slate-100 dark:border-slate-800">
                    <span className="text-sm">{event}</span>
                    <div className="flex gap-3">
                      {["Telegram", "Email", "Push"].map((ch) => (
                        <label key={ch} className="flex items-center gap-1 text-xs text-slate-500">
                          <input type="checkbox" defaultChecked className="rounded w-3 h-3" /> {ch}
                        </label>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === "risk" && (
            <div className="space-y-4">
              <h2 className="font-semibold">Risk Limits</h2>
              <div className="grid grid-cols-2 gap-4">
                {[
                  { label: "Max Daily Loss %", value: "10", desc: "Pause all bots if daily loss exceeds" },
                  { label: "Max Total Exposure %", value: "200", desc: "Maximum leverage-adjusted exposure" },
                  { label: "Drawdown Pause %", value: "15", desc: "Pause bots at this drawdown level" },
                  { label: "Drawdown Liquidate %", value: "30", desc: "Close all positions at this level" },
                ].map((limit) => (
                  <div key={limit.label}>
                    <label className="text-xs text-slate-500 block mb-1">{limit.label}</label>
                    <input type="number" defaultValue={limit.value} className="input text-sm" />
                    <p className="text-[10px] text-slate-400 mt-0.5">{limit.desc}</p>
                  </div>
                ))}
              </div>
              <button className="btn-primary mt-4">Save Risk Limits</button>
            </div>
          )}

          {activeTab === "billing" && (
            <div className="space-y-4">
              <h2 className="font-semibold">Billing</h2>
              <div className="bg-slate-50 dark:bg-slate-800/50 rounded-xl p-5">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="text-lg font-bold capitalize">{user?.planTier || "Free"} Plan</div>
                    <div className="text-sm text-slate-500">
                      {user?.planTier === "free" ? "1 bot, paper trading" : 
                       user?.planTier === "starter" ? "5 bots, all strategies" :
                       user?.planTier === "pro" ? "Unlimited bots, ML access" : "Custom enterprise"}
                    </div>
                  </div>
                  <button className="btn-primary">{user?.planTier === "free" ? "Upgrade" : "Manage"}</button>
                </div>
              </div>
              <div className="space-y-2">
                {["Starter — $19/month", "Pro — $49/month", "Enterprise — $199/month"].map((plan) => (
                  <div key={plan} className="flex items-center justify-between p-3 border border-slate-200 dark:border-slate-700 rounded-lg">
                    <span className="text-sm font-medium">{plan}</span>
                    <button className="btn-secondary text-xs">Select</button>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}