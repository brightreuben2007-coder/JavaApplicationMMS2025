"use client";

import { useState } from "react";
import { Brain, Play, BarChart3, Activity } from "lucide-react";
import api from "@/lib/api";
import { useMarketStore } from "@/lib/store/marketStore";

export default function MLDashboardPage() {
  const { selectedPair } = useMarketStore();
  const [pair, setPair] = useState(selectedPair);
  const [modelType, setModelType] = useState("random_forest");
  const [training, setTraining] = useState(false);
  const [result, setResult] = useState<any>(null);

  const FEATURES = ["rsi_14", "ema_9_distance", "ema_21_distance", "macd_histogram", "bb_position", "volume_ratio", "price_momentum_1", "price_momentum_3"];

  const handleTrain = async () => {
    setTraining(true);
    try {
      const res = await api.post("/ml/train", {
        userId: "mock-user",
        name: `${modelType}_${pair}`,
        pair,
        exchange: "binance",
        timeframe: "1h",
        modelType,
        features: FEATURES,
        predictionHorizon: 1,
        lookbackPeriod: 90,
      });
      setResult({ jobId: res.data.modelId, status: "Training started..." });
    } catch (err: any) {
      setResult({ error: err.message });
    } finally {
      setTraining(false);
    }
  };

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      <div className="flex items-center gap-2">
        <Brain className="w-5 h-5 text-brand-500" />
        <h1 className="text-xl font-bold text-slate-900 dark:text-white">ML Lab</h1>
        <span className="text-xs bg-brand-100 dark:bg-brand-900/30 text-brand-600 dark:text-brand-400 px-2 py-0.5 rounded-full">Experimental</span>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Training Config */}
        <div className="card p-5 space-y-4">
          <h2 className="font-semibold text-sm">Train Model</h2>

          <div>
            <label className="text-xs text-slate-500 block mb-1">Trading Pair</label>
            <input value={pair} onChange={(e) => setPair(e.target.value)} className="input text-sm" />
          </div>

          <div>
            <label className="text-xs text-slate-500 block mb-1">Model Type</label>
            <select value={modelType} onChange={(e) => setModelType(e.target.value)} className="input text-sm">
              <option value="random_forest">Random Forest</option>
              <option value="xgboost">XGBoost</option>
              <option value="lstm">LSTM (Deep Learning)</option>
            </select>
          </div>

          <div>
            <label className="text-xs text-slate-500 block mb-2">Features ({FEATURES.length})</label>
            <div className="grid grid-cols-2 gap-1">
              {FEATURES.map((f) => (
                <label key={f} className="flex items-center gap-1.5 text-xs text-slate-600 dark:text-slate-400">
                  <input type="checkbox" defaultChecked className="rounded w-3 h-3" />
                  {f}
                </label>
              ))}
            </div>
          </div>

          <button onClick={handleTrain} disabled={training} className="btn-primary w-full flex items-center justify-center gap-2">
            {training ? <><div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full" /> Training...</> : <><Play className="w-4 h-4" /> Start Training</>}
          </button>

          {result && (
            <div className={`p-3 rounded-lg text-sm ${result.error ? "bg-red-50 dark:bg-red-900/20 text-red-600" : "bg-emerald-50 dark:bg-emerald-900/20 text-emerald-600"}`}>
              {result.error || result.status}
            </div>
          )}
        </div>

        {/* Performance Dashboard */}
        <div className="card p-5">
          <h2 className="font-semibold text-sm mb-4">Model Performance</h2>
          <div className="flex flex-col items-center justify-center h-64 text-slate-400">
            <BarChart3 className="w-12 h-12 mb-3" />
            <p className="text-sm text-center">Train a model to see performance metrics</p>
            <p className="text-xs mt-1">Accuracy, precision, recall, and feature importance</p>
          </div>
        </div>
      </div>
    </div>
  );
}