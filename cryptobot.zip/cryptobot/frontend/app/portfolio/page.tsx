"use client";

import { useEffect, useState } from "react";
import { usePortfolioStore } from "@/lib/store/portfolioStore";
import { Wallet, TrendingUp, TrendingDown, Activity } from "lucide-react";

export default function PortfolioPage() {
  const { summary, positions, fetchSummary, fetchPositions, isLoading } = usePortfolioStore();

  useEffect(() => {
    fetchSummary();
    fetchPositions();
  }, [fetchSummary, fetchPositions]);

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      <div className="flex items-center gap-2">
        <Wallet className="w-5 h-5 text-brand-500" />
        <h1 className="text-xl font-bold text-slate-900 dark:text-white">Portfolio</h1>
      </div>

      {/* Summary Cards */}
      {summary && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <div className="card p-4">
            <div className="text-xs text-slate-500">Total Value</div>
            <div className="text-xl font-bold font-mono">
              ${summary.totalValue.toLocaleString(undefined, { minimumFractionDigits: 2 })}
            </div>
          </div>
          <div className="card p-4">
            <div className="text-xs text-slate-500">Total P&L</div>
            <div className={`text-xl font-bold font-mono ${summary.totalPnl >= 0 ? "text-emerald-500" : "text-red-500"}`}>
              {summary.totalPnl >= 0 ? "+" : ""}${Math.abs(summary.totalPnl).toLocaleString(undefined, { minimumFractionDigits: 2 })}
            </div>
          </div>
          <div className="card p-4">
            <div className="text-xs text-slate-500">Active Bots</div>
            <div className="text-xl font-bold">{summary.activeBots} / {summary.totalBots}</div>
          </div>
          <div className="card p-4">
            <div className="text-xs text-slate-500">Active Positions</div>
            <div className="text-xl font-bold">{summary.activePositions}</div>
          </div>
        </div>
      )}

      {/* Positions */}
      <div className="card overflow-hidden">
        <div className="px-4 py-3 border-b border-slate-200 dark:border-slate-700">
          <h2 className="font-semibold text-sm">Open Positions</h2>
        </div>
        {positions.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-12 text-slate-400">
            <Activity className="w-8 h-8 mb-2" />
            <p className="text-sm">No open positions</p>
          </div>
        ) : (
          <table className="w-full text-sm">
            <thead>
              <tr className="text-xs text-slate-400 border-b border-slate-100 dark:border-slate-800">
                <th className="text-left px-4 py-2">Pair</th>
                <th className="text-left px-4 py-2">Side</th>
                <th className="text-right px-4 py-2">Entry</th>
                <th className="text-right px-4 py-2">Current</th>
                <th className="text-right px-4 py-2">Size</th>
                <th className="text-right px-4 py-2">P&L</th>
              </tr>
            </thead>
            <tbody>
              {positions.map((pos: any) => (
                <tr key={pos.id} className="border-b border-slate-100 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/50">
                  <td className="px-4 py-2 font-mono font-medium">{pos.pair}</td>
                  <td className="px-4 py-2">
                    <span className={`text-xs px-1.5 py-0.5 rounded-full font-medium ${pos.side === "buy" ? "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400" : "bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400"}`}>
                      {pos.side === "buy" ? "Long" : "Short"}
                    </span>
                  </td>
                  <td className="px-4 py-2 text-right font-mono">${pos.entryPrice?.toFixed(2)}</td>
                  <td className="px-4 py-2 text-right font-mono">${pos.currentPrice?.toFixed(2)}</td>
                  <td className="px-4 py-2 text-right font-mono">{pos.quantity?.toFixed(4)}</td>
                  <td className={`px-4 py-2 text-right font-mono font-medium ${pos.unrealizedPnl >= 0 ? "text-emerald-500" : "text-red-500"}`}>
                    {pos.unrealizedPnl >= 0 ? "+" : ""}${pos.unrealizedPnl?.toFixed(2)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}