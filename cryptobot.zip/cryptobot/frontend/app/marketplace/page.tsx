"use client";

import { useState, useEffect } from "react";
import { Store, Star, TrendingUp, User, Download, Tag } from "lucide-react";
import api from "@/lib/api";

interface MarketStrategy {
  id: string;
  name: string;
  description: string;
  tier: string;
  thirtyDayROI: number;
  totalSubscribers: number;
  rating: number;
  price: number;
  author: { email: string };
  tags: string[];
}

export default function MarketplacePage() {
  const [strategies, setStrategies] = useState<MarketStrategy[]>([]);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState<"strategies" | "providers">("strategies");

  useEffect(() => {
    api.get("/marketplace")
      .then((res) => setStrategies(res.data || []))
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      <div className="flex items-center gap-2">
        <Store className="w-5 h-5 text-brand-500" />
        <h1 className="text-xl font-bold text-slate-900 dark:text-white">Marketplace</h1>
      </div>

      <div className="flex gap-2">
        {(["strategies", "providers"] as const).map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={`px-4 py-2 rounded-lg text-sm font-medium capitalize transition-colors ${
              tab === t ? "bg-brand-500 text-white" : "bg-slate-100 dark:bg-slate-700 text-slate-500"
            }`}
          >
            {t}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {loading ? (
          Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="card p-5 animate-pulse">
              <div className="h-4 bg-slate-200 dark:bg-slate-700 rounded w-3/4 mb-3" />
              <div className="h-3 bg-slate-200 dark:bg-slate-700 rounded w-full mb-2" />
              <div className="h-3 bg-slate-200 dark:bg-slate-700 rounded w-2/3" />
            </div>
          ))
        ) : strategies.length === 0 ? (
          <div className="col-span-full flex flex-col items-center justify-center py-16 text-slate-400">
            <Store className="w-12 h-12 mb-3" />
            <p className="text-sm">No strategies listed yet. Be the first to publish!</p>
          </div>
        ) : (
          strategies.map((s) => (
            <div key={s.id} className="card p-5 hover:shadow-md transition-shadow">
              <div className="flex items-start justify-between mb-3">
                <div>
                  <h3 className="font-semibold text-sm">{s.name}</h3>
                  <div className="flex items-center gap-1 text-xs text-slate-500 mt-0.5">
                    <User className="w-3 h-3" />
                    {s.author.email}
                  </div>
                </div>
                <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${
                  s.tier === "free" ? "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400" :
                  s.tier === "paid" ? "bg-brand-100 text-brand-700 dark:bg-brand-900/30 dark:text-brand-400" :
                  "bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400"
                }`}>
                  {s.tier === "free" ? "Free" : s.tier === "paid" ? `$${s.price}` : "Subscription"}
                </span>
              </div>

              <p className="text-xs text-slate-500 line-clamp-2 mb-3">{s.description}</p>

              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-1 text-sm">
                  <Star className="w-4 h-4 text-amber-500 fill-amber-500" />
                  <span className="font-bold">{s.rating.toFixed(1)}</span>
                </div>
                <div className="flex items-center gap-1 text-xs text-emerald-500">
                  <TrendingUp className="w-3 h-3" />
                  <span className="font-bold">{s.thirtyDayROI.toFixed(1)}% (30d)</span>
                </div>
                <div className="flex items-center gap-1 text-xs text-slate-500">
                  <Download className="w-3 h-3" />
                  <span>{s.totalSubscribers}</span>
                </div>
              </div>

              <button className="btn-primary w-full text-sm py-2">
                {s.tier === "free" ? "Import Strategy" : s.tier === "paid" ? `Buy for $${s.price}` : "Subscribe"}
              </button>
            </div>
          ))
        )}
      </div>
    </div>
  );
}