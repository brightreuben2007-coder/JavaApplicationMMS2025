"use client";

import { useState, useCallback } from "react";
import { useMarketStore } from "@/lib/store/marketStore";
import { useCandles } from "@/lib/hooks/useCandles";
import { TradingChart } from "@/components/chart/TradingChart";
import { SmartTradePanel } from "@/components/smarttrade/SmartTradePanel";
import { TPLevelsBuilder } from "@/components/smarttrade/TPLevelsBuilder";
import { TradePreviewChart } from "@/components/smarttrade/TradePreviewChart";
import api from "@/lib/api";
import { Zap, TrendingUp, Target, Shield } from "lucide-react";

interface TakeProfitLevel {
  id: string;
  price: number;
  percentageToClose: number;
  trailing: boolean;
  trailingDeviation: number;
}

interface SmartTradeConfig {
  side: "buy" | "sell";
  entryType: "market" | "limit";
  entryPrice: number | null;
  entryQuantity: number;
  takeProfitLevels: TakeProfitLevel[];
  stopLoss: { price: number; percentage: number } | null;
  trailingStop: { enabled: boolean; deviation: number };
  leverage: number;
}

export default function SmartTradePage() {
  const { selectedExchange, selectedPair, selectedTimeframe } = useMarketStore();
  const { candles } = useCandles(selectedExchange, selectedPair, selectedTimeframe);
  const [isPlacing, setIsPlacing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  const [trade, setTrade] = useState<SmartTradeConfig>({
    side: "buy",
    entryType: "market",
    entryPrice: null,
    entryQuantity: 0.01,
    takeProfitLevels: [
      { id: "tp-1", price: 52000, percentageToClose: 50, trailing: false, trailingDeviation: 1 },
      { id: "tp-2", price: 53000, percentageToClose: 30, trailing: false, trailingDeviation: 1 },
      { id: "tp-3", price: 54000, percentageToClose: 20, trailing: true, trailingDeviation: 1.5 },
    ],
    stopLoss: { price: 48000, percentage: 4 },
    trailingStop: { enabled: true, deviation: 2 },
    leverage: 1,
  });

  const currentPrice = candles.length > 0 ? candles[candles.length - 1]?.close || 50500 : 50500;

  const handlePlaceTrade = async () => {
    setIsPlacing(true);
    setError(null);
    setSuccess(null);

    try {
      await api.post("/smarttrade", {
        credentialId: "mock-credential",
        exchange: selectedExchange,
        pair: selectedPair,
        ...trade,
      });

      setSuccess("Trade placed successfully!");
      setTimeout(() => setSuccess(null), 5000);
    } catch (err: any) {
      setError(err.message || "Failed to place trade");
    } finally {
      setIsPlacing(false);
    }
  };

  return (
    <div className="h-full flex flex-col gap-4">
      <div className="flex items-center gap-2">
        <Zap className="w-5 h-5 text-brand-500" />
        <h1 className="text-xl font-bold text-slate-900 dark:text-white">SmartTrade Terminal</h1>
        <span className="text-sm text-slate-500 ml-2">
          One-click trades with simultaneous TP + SL
        </span>
      </div>

      {error && (
        <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 text-red-600 p-3 rounded-lg text-sm">
          {error}
          <button onClick={() => setError(null)} className="float-right">&times;</button>
        </div>
      )}

      {success && (
        <div className="bg-emerald-50 dark:bg-emerald-900/20 border border-emerald-200 dark:border-emerald-800 text-emerald-600 p-3 rounded-lg text-sm">
          {success}
        </div>
      )}

      <div className="flex-1 min-h-0 grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Chart */}
        <div className="lg:col-span-2 card overflow-hidden">
          <TradePreviewChart
            candles={candles}
            timeframe={selectedTimeframe}
            pair={selectedPair}
            entryPrice={trade.entryPrice || currentPrice}
            takeProfitLevels={trade.takeProfitLevels}
            stopLoss={trade.stopLoss}
            side={trade.side}
          />
        </div>

        {/* Trade Builder */}
        <div className="card overflow-auto">
          <SmartTradePanel
            trade={trade}
            onChange={setTrade}
            currentPrice={currentPrice}
            onPlaceTrade={handlePlaceTrade}
            isPlacing={isPlacing}
          />
        </div>
      </div>
    </div>
  );
}