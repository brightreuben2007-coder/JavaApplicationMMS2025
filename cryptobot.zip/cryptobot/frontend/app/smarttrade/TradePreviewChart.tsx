"use client";

import { useEffect, useRef } from "react";
import { createChart, IChartApi, CandlestickData, Time, LineStyle } from "lightweight-charts";
import { useMarketStore } from "@/lib/store/marketStore";

interface TradePreviewChartProps {
  candles: any[];
  timeframe: string;
  pair: string;
  entryPrice: number;
  takeProfitLevels: Array<{ id: string; price: number; percentageToClose: number }>;
  stopLoss: { price: number } | null;
  side: "buy" | "sell";
}

export function TradePreviewChart({ candles, timeframe, pair, entryPrice, takeProfitLevels, stopLoss, side }: TradePreviewChartProps) {
  const chartContainerRef = useRef<HTMLDivElement>(null);
  const chartRef = useRef<IChartApi | null>(null);
  const { selectedTimeframe, setSelectedTimeframe } = useMarketStore();

  const TIMEFRAMES = ["1m", "5m", "15m", "1h", "4h", "1d"];

  useEffect(() => {
    if (!chartContainerRef.current) return;
    const isDark = document.documentElement.classList.contains("dark");

    const chart = createChart(chartContainerRef.current, {
      layout: { background: { color: "transparent" }, textColor: isDark ? "#94a3b8" : "#475569" },
      grid: { vertLines: { color: isDark ? "#1e293b" : "#e2e8f0" }, horzLines: { color: isDark ? "#1e293b" : "#e2e8f0" } },
      rightPriceScale: { borderColor: isDark ? "#334155" : "#cbd5e1" },
      timeScale: { borderColor: isDark ? "#334155" : "#cbd5e1" },
    });

    chartRef.current = chart;

    return () => { chart.remove(); };
  }, []);

  // Update candles
  useEffect(() => {
    if (!chartRef.current || candles.length === 0) return;
    const chart = chartRef.current;

    // Remove old series
    chart.series().forEach((s: any) => chart.removeSeries(s));

    const candleData: CandlestickData[] = candles.map((c: any) => ({
      time: c.time as Time,
      open: c.open,
      high: c.high,
      low: c.low,
      close: c.close,
    }));

    const candleSeries = chart.addCandlestickSeries({
      upColor: "#22c55e", downColor: "#ef4444",
      borderUpColor: "#22c55e", borderDownColor: "#ef4444",
      wickUpColor: "#22c55e", wickDownColor: "#ef4444",
    });
    candleSeries.setData(candleData);

    // Entry line
    const entrySeries = chart.addLineSeries({
      color: "#6366f1", lineWidth: 2, lineStyle: LineStyle.Dashed,
      lastValueVisible: true, priceLineVisible: false,
    });
    const entryData = candleData.map((c) => ({ time: c.time, value: entryPrice }));
    entrySeries.setData(entryData);

    // Take Profit lines
    const tpColors = ["#22c55e", "#16a34a", "#15803d"];
    takeProfitLevels.forEach((tp, i) => {
      const tpSeries = chart.addLineSeries({
        color: tpColors[i] || "#22c55e", lineWidth: 1.5, lineStyle: LineStyle.Dotted,
        lastValueVisible: true, priceLineVisible: false,
      });
      const tpData = candleData.map((c) => ({ time: c.time, value: tp.price }));
      tpSeries.setData(tpData);
    });

    // Stop Loss line
    if (stopLoss?.price) {
      const slSeries = chart.addLineSeries({
        color: "#ef4444", lineWidth: 1.5, lineStyle: LineStyle.Dotted,
        lastValueVisible: true, priceLineVisible: false,
      });
      const slData = candleData.map((c) => ({ time: c.time, value: stopLoss.price }));
      slSeries.setData(slData);
    }

    chart.timeScale().fitContent();
  }, [candles, entryPrice, takeProfitLevels, stopLoss]);

  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center justify-between px-3 py-2 border-b border-slate-200 dark:border-slate-700">
        <div className="flex items-center gap-2">
          <span className="text-sm font-bold text-slate-700 dark:text-slate-300">{pair}</span>
          <div className="flex items-center gap-1 text-xs text-slate-400">
            <span className="w-3 h-0.5 bg-indigo-500 rounded-full" /> Entry
            <span className="w-3 h-0.5 bg-emerald-500 rounded-full" /> TP
            <span className="w-3 h-0.5 bg-red-500 rounded-full" /> SL
          </div>
        </div>
        <div className="flex items-center gap-1">
          {TIMEFRAMES.map((tf) => (
            <button
              key={tf}
              onClick={() => setSelectedTimeframe(tf)}
              className={`px-2 py-0.5 text-xs rounded ${timeframe === tf ? "bg-brand-500 text-white" : "text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800"}`}
            >
              {tf}
            </button>
          ))}
        </div>
      </div>
      <div ref={chartContainerRef} className="flex-1" />
    </div>
  );
}