"use client";

import { TPLevelsBuilder } from "./TPLevelsBuilder";
import { TrendingUp, TrendingDown, Target, Shield } from "lucide-react";

interface SmartTradePanelProps {
  trade: any;
  onChange: (trade: any) => void;
  currentPrice: number;
  onPlaceTrade: () => void;
  isPlacing: boolean;
}

export function SmartTradePanel({ trade, onChange, currentPrice, onPlaceTrade, isPlacing }: SmartTradePanelProps) {
  const update = (key: string, value: any) => {
    onChange({ ...trade, [key]: value });
  };

  const calculatePnL = () => {
    const qty = trade.entryQuantity || 0;
    const entry = trade.entryType === "market" ? currentPrice : (trade.entryPrice || currentPrice);
    const tpAvg = trade.takeProfitLevels.length > 0
      ? trade.takeProfitLevels.reduce((sum: number, tp: any) => sum + tp.price * tp.percentageToClose / 100, 0)
      : entry;
    const profit = (tpAvg - entry) * qty;
    const loss = trade.stopLoss ? (trade.stopLoss.price - entry) * qty : 0;
    return { profit, loss };
  };

  const pnl = calculatePnL();

  return (
    <div className="p-4 space-y-5">
      <h3 className="font-semibold text-sm text-slate-700 dark:text-slate-300">Trade Builder</h3>

      {/* Buy/Sell Toggle */}
      <div className="flex gap-2">
        <button
          onClick={() => update("side", "buy")}
          className={`flex-1 py-2.5 rounded-lg text-sm font-bold flex items-center justify-center gap-2 transition-all ${
            trade.side === "buy"
              ? "bg-emerald-500 text-white shadow-lg"
              : "bg-slate-100 dark:bg-slate-700 text-slate-500"
          }`}
        >
          <TrendingUp className="w-4 h-4" /> Buy / Long
        </button>
        <button
          onClick={() => update("side", "sell")}
          className={`flex-1 py-2.5 rounded-lg text-sm font-bold flex items-center justify-center gap-2 transition-all ${
            trade.side === "sell"
              ? "bg-red-500 text-white shadow-lg"
              : "bg-slate-100 dark:bg-slate-700 text-slate-500"
          }`}
        >
          <TrendingDown className="w-4 h-4" /> Sell / Short
        </button>
      </div>

      {/* Entry */}
      <div className="space-y-3">
        <div>
          <label className="text-xs font-medium text-slate-500 mb-1 block">Entry Type</label>
          <div className="flex gap-2">
            <button
              onClick={() => update("entryType", "market")}
              className={`flex-1 py-2 text-xs rounded-lg transition-all ${
                trade.entryType === "market" ? "bg-brand-500 text-white" : "bg-slate-100 dark:bg-slate-700"
              }`}
            >
              Market
            </button>
            <button
              onClick={() => update("entryType", "limit")}
              className={`flex-1 py-2 text-xs rounded-lg transition-all ${
                trade.entryType === "limit" ? "bg-brand-500 text-white" : "bg-slate-100 dark:bg-slate-700"
              }`}
            >
              Limit
            </button>
          </div>
        </div>

        {trade.entryType === "limit" && (
          <div>
            <label className="text-xs font-medium text-slate-500 mb-1 block">Limit Price</label>
            <input
              type="number"
              value={trade.entryPrice || ""}
              onChange={(e) => update("entryPrice", parseFloat(e.target.value) || null)}
              className="input text-sm"
              placeholder={currentPrice.toString()}
            />
          </div>
        )}

        <div>
          <label className="text-xs font-medium text-slate-500 mb-1 block">
            Quantity ({trade.entryType === "market" ? `est. $${(currentPrice * (trade.entryQuantity || 0)).toFixed(2)}` : ""})
          </label>
          <input
            type="number"
            value={trade.entryQuantity}
            onChange={(e) => update("entryQuantity", parseFloat(e.target.value) || 0)}
            className="input text-sm"
            step={0.001}
            min={0}
          />
        </div>
      </div>

      {/* Take Profit Levels */}
      <div>
        <div className="flex items-center gap-2 mb-3">
          <Target className="w-4 h-4 text-emerald-500" />
          <span className="text-xs font-medium text-slate-500">Take Profit Targets</span>
        </div>
        <TPLevelsBuilder
          levels={trade.takeProfitLevels}
          currentPrice={currentPrice}
          onChange={(levels) => update("takeProfitLevels", levels)}
        />
      </div>

      {/* Stop Loss */}
      <div>
        <div className="flex items-center gap-2 mb-3">
          <Shield className="w-4 h-4 text-red-500" />
          <span className="text-xs font-medium text-slate-500">Stop Loss</span>
        </div>
        <div className="grid grid-cols-2 gap-2">
          <div>
            <label className="text-xs text-slate-400">Price</label>
            <input
              type="number"
              value={trade.stopLoss?.price || ""}
              onChange={(e) => update("stopLoss", { ...trade.stopLoss, price: parseFloat(e.target.value) || 0 })}
              className="input text-sm"
            />
          </div>
          <div>
            <label className="text-xs text-slate-400">Or % from Entry</label>
            <input
              type="number"
              value={trade.stopLoss?.percentage || ""}
              onChange={(e) => update("stopLoss", { ...trade.stopLoss, percentage: parseFloat(e.target.value) || 0 })}
              className="input text-sm"
              placeholder="e.g., 4"
            />
          </div>
        </div>
        <label className="flex items-center gap-2 mt-2">
          <input
            type="checkbox"
            checked={trade.trailingStop?.enabled || false}
            onChange={(e) => update("trailingStop", { ...trade.trailingStop, enabled: e.target.checked })}
            className="rounded"
          />
          <span className="text-xs text-slate-500">Trailing Stop ({trade.trailingStop?.deviation || 2}%)</span>
        </label>
      </div>

      {/* P&L Preview */}
      <div className="bg-slate-50 dark:bg-slate-800/50 rounded-lg p-3 grid grid-cols-2 gap-3">
        <div>
          <div className="text-xs text-slate-500">Max Profit</div>
          <div className="font-mono font-bold text-emerald-500">
            ${pnl.profit.toFixed(2)}
          </div>
        </div>
        <div>
          <div className="text-xs text-slate-500">Max Loss</div>
          <div className="font-mono font-bold text-red-500">
            ${pnl.loss.toFixed(2)}
          </div>
        </div>
      </div>

      {/* Place Button */}
      <button
        onClick={onPlaceTrade}
        disabled={isPlacing}
        className={`w-full py-3 rounded-lg text-sm font-bold transition-all ${
          trade.side === "buy"
            ? "bg-emerald-500 hover:bg-emerald-600 text-white"
            : "bg-red-500 hover:bg-red-600 text-white"
        } disabled:opacity-50`}
      >
        {isPlacing ? "Placing..." : `${trade.side === "buy" ? "Buy" : "Sell"} ${trade.entryQuantity} at ${trade.entryType === "market" ? "Market" : "$" + (trade.entryPrice || currentPrice)}`}
      </button>
    </div>
  );
}