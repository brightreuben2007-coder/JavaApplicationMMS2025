"use client";

import { Plus, Trash2, GripVertical } from "lucide-react";
import { v4 as uuidv4 } from "uuid";

interface TPLevel {
  id: string;
  price: number;
  percentageToClose: number;
  trailing: boolean;
  trailingDeviation: number;
}

interface TPLevelsBuilderProps {
  levels: TPLevel[];
  currentPrice: number;
  onChange: (levels: TPLevel[]) => void;
}

export function TPLevelsBuilder({ levels, currentPrice, onChange }: TPLevelsBuilderProps) {
  const addLevel = () => {
    const lastPrice = levels.length > 0 ? levels[levels.length - 1]?.price || currentPrice * 1.05 : currentPrice * 1.02;
    onChange([
      ...levels,
      {
        id: uuidv4(),
        price: lastPrice * 1.02,
        percentageToClose: Math.max(10, 100 - levels.reduce((s, l) => s + l.percentageToClose, 0)),
        trailing: false,
        trailingDeviation: 1,
      },
    ]);
  };

  const removeLevel = (id: string) => {
    if (levels.length <= 1) return;
    onChange(levels.filter((l) => l.id !== id));
  };

  const updateLevel = (id: string, updates: Partial<TPLevel>) => {
    onChange(levels.map((l) => (l.id === id ? { ...l, ...updates } : l)));
  };

  const totalPercentage = levels.reduce((sum, l) => sum + l.percentageToClose, 0);

  return (
    <div className="space-y-2">
      {levels.map((level, i) => (
        <div
          key={level.id}
          className="flex items-center gap-1.5 p-2 bg-white dark:bg-slate-800 rounded-lg border border-slate-200 dark:border-slate-700"
        >
          <GripVertical className="w-3 h-3 text-slate-400 cursor-grab" />
          <span className="text-xs text-slate-400 w-5">TP{i + 1}</span>
          <input
            type="number"
            value={level.price}
            onChange={(e) => updateLevel(level.id, { price: parseFloat(e.target.value) || 0 })}
            className="input text-xs w-20 py-1"
            placeholder="Price"
          />
          <div className="flex items-center gap-1">
            <input
              type="number"
              value={level.percentageToClose}
              onChange={(e) => updateLevel(level.id, { percentageToClose: Math.min(100, Math.max(0, parseFloat(e.target.value) || 0)) })}
              className="input text-xs w-12 py-1"
              placeholder="%"
            />
            <span className="text-xs text-slate-400">%</span>
          </div>
          <label className="flex items-center gap-1 text-xs text-slate-500">
            <input
              type="checkbox"
              checked={level.trailing}
              onChange={(e) => updateLevel(level.id, { trailing: e.target.checked })}
              className="rounded w-3 h-3"
            />
            Trail
          </label>
          <button
            onClick={() => removeLevel(level.id)}
            disabled={levels.length <= 1}
            className="p-1 text-slate-400 hover:text-red-500 disabled:opacity-30"
          >
            <Trash2 className="w-3 h-3" />
          </button>
        </div>
      ))}

      <div className="flex items-center justify-between">
        <button
          onClick={addLevel}
          disabled={levels.length >= 5}
          className="flex items-center gap-1 text-xs text-brand-500 hover:text-brand-600 disabled:opacity-50"
        >
          <Plus className="w-3 h-3" /> Add Target
        </button>
        <span className={`text-xs ${totalPercentage !== 100 ? "text-amber-500" : "text-emerald-500"}`}>
          {totalPercentage}% allocated
        </span>
      </div>
    </div>
  );
}