"use client";

import { useEffect, useState } from "react";
import { useMarketStore } from "@/lib/store/marketStore";
import { useBotStore } from "@/lib/store/botStore";
import { TradingChart } from "@/components/chart/TradingChart";
import { OrderBook } from "@/components/orderbook/OrderBook";
import { TradesFeed } from "@/components/orderbook/TradesFeed";
import { BotTable } from "@/components/bots/BotTable";
import { useOrderBook } from "@/lib/hooks/useOrderBook";
import { useCandles } from "@/lib/hooks/useCandles";
import { useBotStatus } from "@/lib/hooks/useBotStatus";
import ws from "@/lib/websocket";
import {
  Panel,
  PanelGroup,
  PanelResizeHandle,
} from "react-resizable-panels";

export default function DashboardPage() {
  const { selectedExchange, selectedPair, selectedTimeframe, setTicker } = useMarketStore();
  const { orderBook, spread, midPrice } = useOrderBook(selectedExchange, selectedPair);
  const { candles } = useCandles(selectedExchange, selectedPair, selectedTimeframe);
  const { bots, activeBots, totalPnl } = useBotStatus();
  const [showDepthChart, setShowDepthChart] = useState(false);

  // Listen for ticker updates
  useEffect(() => {
    ws.on("ticker", (data: any) => {
      if (data.symbol === selectedPair) {
        setTicker(data);
      }
    });
    return () => { ws.off("ticker", () => {}); };
  }, [selectedPair, setTicker]);

  return (
    <div className="h-full flex flex-col gap-3">
      {/* Main Content */}
      <PanelGroup direction="horizontal" className="flex-1 min-h-0">
        {/* Chart */}
        <Panel defaultSize={60} minSize={30}>
          <div className="h-full card overflow-hidden">
            <TradingChart
              candles={candles}
              timeframe={selectedTimeframe}
              pair={selectedPair}
            />
          </div>
        </Panel>

        <PanelResizeHandle className="w-1.5 bg-transparent hover:bg-brand-500/30 transition-colors rounded-full mx-1" />

        {/* Order Book & Trades */}
        <Panel defaultSize={25} minSize={15}>
          <div className="h-full flex flex-col gap-3">
            <div className="flex-1 min-h-0 card overflow-hidden">
              <OrderBook
                orderBook={orderBook}
                spread={spread}
                midPrice={midPrice}
                pair={selectedPair}
              />
            </div>
            <div className="h-48 card overflow-hidden">
              <TradesFeed pair={selectedPair} />
            </div>
          </div>
        </Panel>
      </PanelGroup>

      {/* Bot Table */}
      <div className="h-48 min-h-[12rem] card overflow-hidden">
        <BotTable bots={bots} />
      </div>
    </div>
  );
}