"use client";

import { useRef, useEffect } from "react";
import { createChart, IChartApi, ISeriesApi, AreaData, Time } from "lightweight-charts";

interface DepthChartProps {
  bids: Array<{ price: number; quantity: number }>;
  asks: Array<{ price: number; quantity: number }>;
  midPrice: number | null;
}

export function DepthChart({ bids, asks, midPrice }: DepthChartProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const chartRef = useRef<IChartApi | null>(null);

  useEffect(() => {
    if (!containerRef.current) return;

    const chart = createChart(containerRef.current, {
      layout: {
        background: { color: "transparent" },
        textColor: document.documentElement.classList.contains("dark") ? "#94a3b8" : "#475569",
      },
      grid: {
        vertLines: { visible: false },
        horzLines: { color: document.documentElement.classList.contains("dark") ? "#1e293b" : "#e2e8f0" },
      },
      rightPriceScale: { visible: false },
      timeScale: { visible: false },
      crosshair: { mode: 0 },
      width: containerRef.current.clientWidth,
      height: 200,
    });

    chartRef.current = chart;
    return () => { chart.remove(); };
  }, []);

  useEffect(() => {
    if (!chartRef.current || bids.length === 0 || asks.length === 0) return;

    const chart = chartRef.current;
    chart.removeSeries(chart.series()[0] as any);
    chart.removeSeries(chart.series()[0] as any);

    // Cumulative bids (descending)
    let bidCumulative = 0;
    const bidArea: AreaData[] = bids
      .sort((a, b) => b.price - a.price)
      .map((b) => {
        bidCumulative += b.quantity;
        return { time: bids.indexOf(b) as Time, value: bidCumulative };
      });

    // Cumulative asks (ascending)
    let askCumulative = 0;
    const askArea: AreaData[] = asks
      .sort((a, b) => a.price - b.price)
      .map((a) => {
        askCumulative += a.quantity;
        return { time: asks.indexOf(a) as Time, value: askCumulative };
      });

    const bidSeries = chart.addAreaSeries({
      lineColor: "#22c55e",
      topColor: "rgba(34, 197, 94, 0.4)",
      bottomColor: "rgba(34, 197, 94, 0.05)",
      lineWidth: 1,
    });
    bidSeries.setData(bidArea);

    const askSeries = chart.addAreaSeries({
      lineColor: "#ef4444",
      topColor: "rgba(239, 68, 68, 0.4)",
      bottomColor: "rgba(239, 68, 68, 0.05)",
      lineWidth: 1,
    });
    askSeries.setData(askArea);
  }, [bids, asks]);

  return (
    <div className="flex flex-col h-full">
      <div className="px-3 py-1.5 border-b border-slate-200 dark:border-slate-700">
        <span className="text-xs font-medium text-slate-500">Depth Chart</span>
        {midPrice && (
          <span className="text-xs text-slate-400 ml-2 font-mono">
            Mid: ${midPrice.toFixed(2)}
          </span>
        )}
      </div>
      <div ref={containerRef} className="flex-1" />
    </div>
  );
}