"use client";

import { useEffect, useRef } from "react";
import type { IChartApi, ISeriesApi, LineData } from "lightweight-charts";

interface IndicatorOverlayProps {
  chart: IChartApi | null;
  ema9Data: LineData[];
  ema21Data: LineData[];
}

export function IndicatorOverlay({ chart, ema9Data, ema21Data }: IndicatorOverlayProps) {
  const ema9SeriesRef = useRef<ISeriesApi<"Line"> | null>(null);
  const ema21SeriesRef = useRef<ISeriesApi<"Line"> | null>(null);

  useEffect(() => {
    if (!chart) return;

    // EMA 9
    if (!ema9SeriesRef.current) {
      ema9SeriesRef.current = chart.addLineSeries({
        color: "#6366f1",
        lineWidth: 1.5,
        lineStyle: 0,
        lastValueVisible: true,
        priceLineVisible: false,
      });
    }
    ema9SeriesRef.current.setData(ema9Data);

    // EMA 21
    if (!ema21SeriesRef.current) {
      ema21SeriesRef.current = chart.addLineSeries({
        color: "#f59e0b",
        lineWidth: 1.5,
        lineStyle: 0,
        lastValueVisible: true,
        priceLineVisible: false,
      });
    }
    ema21SeriesRef.current.setData(ema21Data);

    return () => {
      if (ema9SeriesRef.current) {
        chart.removeSeries(ema9SeriesRef.current);
        ema9SeriesRef.current = null;
      }
      if (ema21SeriesRef.current) {
        chart.removeSeries(ema21SeriesRef.current);
        ema21SeriesRef.current = null;
      }
    };
  }, [chart, ema9Data, ema21Data]);

  return null; // Rendered via lightweight-charts
}