"use client";

import { useEffect, useRef, useState, useCallback } from "react";
import { createChart, IChartApi, ISeriesApi, CandlestickData, Time, LineData } from "lightweight-charts";
import { useMarketStore } from "@/lib/store/marketStore";
import { IndicatorOverlay } from "./IndicatorOverlay";

interface TradingChartProps {
  candles: Array<{
    time: number;
    open: number;
    high: number;
    low: number;
    close: number;
    volume: number;
  }>;
  timeframe: string;
  pair: string;
}

const TIMEFRAMES = ["1m", "5m", "15m", "1h", "4h", "1d", "1w"] as const;

export function TradingChart({ candles, timeframe, pair }: TradingChartProps) {
  const chartContainerRef = useRef<HTMLDivElement>(null);
  const chartRef = useRef<IChartApi | null>(null);
  const candleSeriesRef = useRef<ISeriesApi<"Candlestick"> | null>(null);
  const volumeSeriesRef = useRef<ISeriesApi<"Histogram"> | null>(null);
  const { selectedTimeframe, setSelectedTimeframe } = useMarketStore();
  const [activeIndicators, setActiveIndicators] = useState<Set<string>>(new Set(["EMA"]));

  // Initialize chart
  useEffect(() => {
    if (!chartContainerRef.current) return;

    const chart = createChart(chartContainerRef.current, {
      layout: {
        background: { color: "transparent" },
        textColor: document.documentElement.classList.contains("dark") ? "#94a3b8" : "#475569",
      },
      grid: {
        vertLines: { color: document.documentElement.classList.contains("dark") ? "#1e293b" : "#e2e8f0" },
        horzLines: { color: document.documentElement.classList.contains("dark") ? "#1e293b" : "#e2e8f0" },
      },
      crosshair: {
        mode: 0,
        vertLine: { color: "#6366f1", width: 1, style: 2 },
        horzLine: { color: "#6366f1", width: 1, style: 2 },
      },
      rightPriceScale: {
        borderColor: document.documentElement.classList.contains("dark") ? "#334155" : "#cbd5e1",
      },
      timeScale: {
        borderColor: document.documentElement.classList.contains("dark") ? "#334155" : "#cbd5e1",
        timeVisible: true,
        secondsVisible: false,
      },
    });

    // Candlestick series
    const candleSeries = chart.addCandlestickSeries({
      upColor: "#22c55e",
      downColor: "#ef4444",
      borderUpColor: "#22c55e",
      borderDownColor: "#ef4444",
      wickUpColor: "#22c55e",
      wickDownColor: "#ef4444",
    });

    // Volume series
    const volumeSeries = chart.addHistogramSeries({
      color: document.documentElement.classList.contains("dark") ? "#334155" : "#cbd5e1",
      priceFormat: { type: "volume" },
      priceScaleId: "volume",
    });

    chart.priceScale("volume").applyOptions({
      scaleMargins: { top: 0.85, bottom: 0 },
    });

    chartRef.current = chart;
    candleSeriesRef.current = candleSeries;
    volumeSeriesRef.current = volumeSeries;

    return () => {
      chart.remove();
      chartRef.current = null;
    };
  }, []);

  // Update candles
  useEffect(() => {
    if (!candleSeriesRef.current || !volumeSeriesRef.current) return;

    const candleData: CandlestickData[] = candles.map((c) => ({
      time: c.time as Time,
      open: c.open,
      high: c.high,
      low: c.low,
      close: c.close,
    }));

    const volumeData = candles.map((c) => ({
      time: c.time as Time,
      value: c.volume,
      color: c.close >= c.open
        ? "rgba(34, 197, 94, 0.3)"
        : "rgba(239, 68, 68, 0.3)",
    }));

    candleSeriesRef.current.setData(candleData);
    volumeSeriesRef.current.setData(volumeData);

    // Fit content
    if (chartRef.current && candles.length > 0) {
      chartRef.current.timeScale().fitContent();
    }
  }, [candles]);

  // Toggle dark mode
  useEffect(() => {
    const observer = new MutationObserver(() => {
      if (chartRef.current) {
        const isDark = document.documentElement.classList.contains("dark");
        chartRef.current.applyOptions({
          layout: { textColor: isDark ? "#94a3b8" : "#475569" },
          grid: {
            vertLines: { color: isDark ? "#1e293b" : "#e2e8f0" },
            horzLines: { color: isDark ? "#1e293b" : "#e2e8f0" },
          },
          rightPriceScale: { borderColor: isDark ? "#334155" : "#cbd5e1" },
          timeScale: { borderColor: isDark ? "#334155" : "#cbd5e1" },
        });
      }
    });
    observer.observe(document.documentElement, { attributes: true, attributeFilter: ["class"] });
    return () => observer.disconnect();
  }, []);

  // Calculate EMA
  const calculateEMA = useCallback((data: number[], period: number): number[] => {
    const ema: number[] = [];
    const multiplier = 2 / (period + 1);
    let prev = data[0] || 0;
    ema.push(prev);
    for (let i = 1; i < data.length; i++) {
      prev = ((data[i] || 0) - prev) * multiplier + prev;
      ema.push(prev);
    }
    return ema;
  }, []);

  const ema9Data: LineData[] = candles.length > 0
    ? calculateEMA(candles.map(c => c.close), 9).map((v, i) => ({
        time: candles[i]?.time as Time || 0,
        value: v,
      }))
    : [];

  const ema21Data: LineData[] = candles.length > 0
    ? calculateEMA(candles.map(c => c.close), 21).map((v, i) => ({
        time: candles[i]?.time as Time || 0,
        value: v,
      }))
    : [];

  const toggleIndicator = (indicator: string) => {
    setActiveIndicators((prev) => {
      const next = new Set(prev);
      if (next.has(indicator)) next.delete(indicator);
      else next.add(indicator);
      return next;
    });
  };

  return (
    <div className="flex flex-col h-full">
      {/* Toolbar */}
      <div className="flex items-center justify-between px-3 py-2 border-b border-slate-200 dark:border-slate-700">
        <div className="flex items-center gap-1">
          {TIMEFRAMES.map((tf) => (
            <button
              key={tf}
              onClick={() => setSelectedTimeframe(tf)}
              className={`px-2.5 py-1 text-xs font-medium rounded transition-colors ${
                timeframe === tf
                  ? "bg-brand-500 text-white"
                  : "text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800"
              }`}
            >
              {tf}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-1">
          <button
            onClick={() => toggleIndicator("EMA")}
            className={`px-2 py-1 text-xs font-medium rounded transition-colors ${
              activeIndicators.has("EMA")
                ? "bg-brand-50 dark:bg-brand-900/20 text-brand-600"
                : "text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800"
            }`}
          >
            EMA
          </button>
          <button
            onClick={() => toggleIndicator("MACD")}
            className={`px-2 py-1 text-xs font-medium rounded transition-colors ${
              activeIndicators.has("MACD")
                ? "bg-brand-50 dark:bg-brand-900/20 text-brand-600"
                : "text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800"
            }`}
          >
            MACD
          </button>
          <button
            onClick={() => toggleIndicator("RSI")}
            className={`px-2 py-1 text-xs font-medium rounded transition-colors ${
              activeIndicators.has("RSI")
                ? "bg-brand-50 dark:bg-brand-900/20 text-brand-600"
                : "text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800"
            }`}
          >
            RSI
          </button>
          <button
            onClick={() => toggleIndicator("BB")}
            className={`px-2 py-1 text-xs font-medium rounded transition-colors ${
              activeIndicators.has("BB")
                ? "bg-brand-50 dark:bg-brand-900/20 text-brand-600"
                : "text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800"
            }`}
          >
            Bollinger
          </button>
        </div>
      </div>

      {/* Chart */}
      <div className="flex-1 relative" ref={chartContainerRef}>
        {candles.length === 0 && (
          <div className="absolute inset-0 flex items-center justify-center text-slate-400 text-sm">
            Loading chart data...
          </div>
        )}

        {/* EMA overlay */}
        {activeIndicators.has("EMA") && candles.length > 0 && (
          <IndicatorOverlay
            chart={chartRef.current}
            ema9Data={ema9Data}
            ema21Data={ema21Data}
          />
        )}
      </div>
    </div>
  );
}