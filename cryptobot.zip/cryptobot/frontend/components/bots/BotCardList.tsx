"use client";

import { useBotStatus } from "@/lib/hooks/useBotStatus";
import { BotTable } from "@/components/bots/BotTable";
import { BotCardList } from "@/components/bots/BotCardList";
import { useRouter } from "next/navigation";
import { Plus, Zap } from "lucide-react";
import { useIsMobile } from "@/lib/hooks/useMediaQuery";

export default function BotsPage() {
  const { bots } = useBotStatus();
  const router = useRouter();
  const isMobile = useIsMobile();

  return (
    <div className="h-full flex flex-col gap-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-slate-900 dark:text-white">Trading Bots</h1>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
            Manage your automated trading strategies
          </p>
        </div>
        <button onClick={() => router.push("/bots/new")} className="btn-primary flex items-center gap-2">
          <Plus className="w-4 h-4" /> New Bot
        </button>
      </div>

      <div className="flex-1">
        {isMobile ? (
          <BotCardList bots={bots} />
        ) : (
          <div className="card overflow-hidden h-full">
            <BotTable bots={bots} />
          </div>
        )}
      </div>
    </div>
  );
}