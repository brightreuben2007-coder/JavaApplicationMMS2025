"use client";

import { useBotStatus } from "@/lib/hooks/useBotStatus";
import { BotTable } from "@/components/bots/BotTable";
import { useRouter } from "next/navigation";
import { Plus, Zap } from "lucide-react";

export default function BotsPage() {
  const { bots } = useBotStatus();
  const router = useRouter();

  return (
    <div className="h-full flex flex-col gap-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-slate-900 dark:text-white">Trading Bots</h1>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
            Manage your automated trading strategies
          </p>
        </div>
        <button onClick={() => router.push("/bots/new")} className="btn-primary flex items-center gap-2">
          <Plus className="w-4 h-4" /> New Bot
        </button>
      </div>

      <div className="flex-1 card overflow-hidden">
        <BotTable bots={bots} />
      </div>
    </div>
  );
}