"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useBotStore } from "@/lib/store/botStore";
import { useMarketStore } from "@/lib/store/marketStore";
import { StrategySelector } from "@/components/bots/StrategySelector";
import { DCAConfigForm } from "@/components/bots/DCAConfigForm";
import { GridConfigForm } from "@/components/bots/GridConfigForm";
import { BotReviewStep } from "@/components/bots/BotReviewStep";
import { ChevronRight, ChevronLeft, Check, Search } from "lucide-react";

const STEPS = ["Strategy", "Configure", "Review"] as const;
type Step = (typeof STEPS)[number];

const STRATEGY_CONFIG_FORMS: Record<string, any> = {
  dca: DCAConfigForm,
  grid: GridConfigForm,
  "grid-infinity": GridConfigForm,
  "grid-leveraged": GridConfigForm,
  martingale: DCAConfigForm,
  macd: DCAConfigForm,
  bollinger: DCAConfigForm,
  marketmaking: DCAConfigForm,
  avellaneda: DCAConfigForm,
  rebalancing: DCAConfigForm,
  twap: DCAConfigForm,
  ml: DCAConfigForm,
};

const EXCHANGES = ["binance", "bybit", "kraken", "coinbase", "kucoin"];
const POPULAR_PAIRS = ["BTC/USDT", "ETH/USDT", "SOL/USDT", "BNB/USDT", "ADA/USDT", "DOGE/USDT"];

export default function NewBotPage() {
  const router = useRouter();
  const createBot = useBotStore((s) => s.createBot);
  const [step, setStep] = useState<number>(0);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Bot config state
  const [botName, setBotName] = useState("");
  const [exchange, setExchange] = useState("binance");
  const [pair, setPair] = useState("BTC/USDT");
  const [customPair, setCustomPair] = useState("");
  const [strategyType, setStrategyType] = useState<string>("dca");
  const [strategyConfig, setStrategyConfig] = useState<any>({});
  const [paperTrading, setPaperTrading] = useState(true);

  const currentStep = STEPS[step] || "Strategy";

  const handleNext = () => {
    if (step < STEPS.length - 1) {
      setStep(step + 1);
      setError(null);
    }
  };

  const handleBack = () => {
    if (step > 0) {
      setStep(step - 1);
      setError(null);
    }
  };

  const handleCreate = async () => {
    setIsSubmitting(true);
    setError(null);

    try {
      const finalPair = customPair || pair;

      await createBot({
        name: botName || `${strategyType.toUpperCase()} ${finalPair}`,
        credentialId: "mock-credential-id", // Would come from user's connected exchanges
        exchange,
        pair: finalPair,
        strategyType,
        config: strategyConfig,
        paperTrading,
      });

      router.push("/bots");
    } catch (err: any) {
      setError(err.message || "Failed to create bot");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="max-w-3xl mx-auto h-full flex flex-col gap-6">
      {/* Header */}
      <div>
        <h1 className="text-xl font-bold text-slate-900 dark:text-white">Create New Bot</h1>
        <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
          Step {step + 1} of {STEPS.length}: {currentStep}
        </p>
      </div>

      {/* Step indicator */}
      <div className="flex items-center gap-2">
        {STEPS.map((s, i) => (
          <div key={s} className="flex items-center gap-2">
            <div
              className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium transition-colors ${
                i < step
                  ? "bg-emerald-500 text-white"
                  : i === step
                  ? "bg-brand-500 text-white"
                  : "bg-slate-200 dark:bg-slate-700 text-slate-500"
              }`}
            >
              {i < step ? <Check className="w-4 h-4" /> : i + 1}
            </div>
            <span className={`text-sm hidden sm:block ${
              i <= step ? "text-slate-700 dark:text-slate-300" : "text-slate-400"
            }`}>
              {s}
            </span>
            {i < STEPS.length - 1 && (
              <div className={`w-8 h-0.5 ${i < step ? "bg-emerald-500" : "bg-slate-200 dark:bg-slate-700"}`} />
            )}
          </div>
        ))}
      </div>

      {/* Error */}
      {error && (
        <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 text-red-600 dark:text-red-400 p-3 rounded-lg text-sm">
          {error}
        </div>
      )}

      {/* Step Content */}
      <div className="flex-1 card p-6 overflow-auto">
        {/* Step 0: Select Strategy */}
        {step === 0 && (
          <div className="space-y-6">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium mb-1.5">Exchange</label>
                <select
                  value={exchange}
                  onChange={(e) => setExchange(e.target.value)}
                  className="input"
                >
                  {EXCHANGES.map((ex) => (
                    <option key={ex} value={ex}>{ex}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium mb-1.5">Trading Pair</label>
                <select
                  value={customPair || pair}
                  onChange={(e) => {
                    if (POPULAR_PAIRS.includes(e.target.value)) {
                      setPair(e.target.value);
                      setCustomPair("");
                    } else {
                      setCustomPair(e.target.value);
                    }
                  }}
                  className="input"
                >
                  {POPULAR_PAIRS.map((p) => (
                    <option key={p} value={p}>{p}</option>
                  ))}
                  <option value="custom">Custom pair...</option>
                </select>
                {(customPair && !POPULAR_PAIRS.includes(customPair)) && (
                  <input
                    type="text"
                    value={customPair}
                    onChange={(e) => setCustomPair(e.target.value.toUpperCase())}
                    className="input mt-2"
                    placeholder="e.g., LINK/USDT"
                  />
                )}
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium mb-3">Choose a Strategy</label>
              <StrategySelector
                selected={strategyType}
                onSelect={setStrategyType}
              />
            </div>

            <div className="flex items-center gap-2">
              <input
                type="checkbox"
                id="paper-trading"
                checked={paperTrading}
                onChange={(e) => setPaperTrading(e.target.checked)}
                className="rounded"
              />
              <label htmlFor="paper-trading" className="text-sm text-slate-600 dark:text-slate-400">
                Start with paper trading (recommended)
              </label>
            </div>
          </div>
        )}

        {/* Step 1: Configure */}
        {step === 1 && (
          <div className="space-y-6">
            <div>
              <label className="block text-sm font-medium mb-1.5">Bot Name</label>
              <input
                type="text"
                value={botName}
                onChange={(e) => setBotName(e.target.value)}
                className="input"
                placeholder={`${strategyType.toUpperCase()} ${customPair || pair}`}
              />
            </div>

            {strategyType === "dca" || strategyType === "martingale" ? (
              <DCAConfigForm
                config={strategyConfig}
                onChange={setStrategyConfig}
                pair={customPair || pair}
                isMartingale={strategyType === "martingale"}
              />
            ) : strategyType.startsWith("grid") ? (
              <GridConfigForm
                config={strategyConfig}
                onChange={setStrategyConfig}
                pair={customPair || pair}
                exchange={exchange}
                isInfinity={strategyType === "grid-infinity"}
                isLeveraged={strategyType === "grid-leveraged"}
              />
            ) : (
              <div className="text-center py-8 text-slate-500">
                <p>Configuration form for <strong>{strategyType}</strong> coming soon.</p>
                <p className="text-sm mt-1">Default settings will be used.</p>
              </div>
            )}
          </div>
        )}

        {/* Step 2: Review */}
        {step === 2 && (
          <BotReviewStep
            name={botName || `${strategyType.toUpperCase()} ${customPair || pair}`}
            exchange={exchange}
            pair={customPair || pair}
            strategyType={strategyType}
            config={strategyConfig}
            paperTrading={paperTrading}
          />
        )}
      </div>

      {/* Navigation */}
      <div className="flex items-center justify-between">
        <button
          onClick={handleBack}
          disabled={step === 0}
          className="btn-secondary flex items-center gap-2 disabled:opacity-50"
        >
          <ChevronLeft className="w-4 h-4" /> Back
        </button>

        {step < STEPS.length - 1 ? (
          <button onClick={handleNext} className="btn-primary flex items-center gap-2">
            Continue <ChevronRight className="w-4 h-4" />
          </button>
        ) : (
          <button
            onClick={handleCreate}
            disabled={isSubmitting}
            className="btn-primary flex items-center gap-2"
          >
            {isSubmitting ? (
              <>
                <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full" />
                Creating...
              </>
            ) : (
              <>
                <Check className="w-4 h-4" /> Create Bot
              </>
            )}
          </button>
        )}
      </div>
    </div>
  );
}