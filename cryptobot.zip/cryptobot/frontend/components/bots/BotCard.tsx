"use client";

import { useRef, useState, useCallback } from "react";
import { useRouter } from "next/navigation";
import { clsx } from "clsx";
import { Play, Pause, Square, ChevronRight, Info } from "lucide-react";

interface Bot {
  id: string;
  name: string;
  exchange: string;
  pair: string;
  strategyType: string;
  status: "active" | "paused" | "stopped" | "error";
  paperTrading: boolean;
  totalPnl: number;
  totalTrades: number;
  winRate: number;
}

interface BotCardProps {
  bot: Bot;
  onPause: (id: string) => void;
  onStart: (id: string) => void;
  onStop: (id: string) => void;
}

const SWIPE_THRESHOLD = 60;
const SWIPE_VELOCITY_THRESHOLD = 0.5;

const STATUS_COLORS: Record<string, string> = {
  active: "bg-emerald-500",
  paused: "bg-amber-500",
  stopped: "bg-slate-400",
  error: "bg-red-500",
};

const STRATEGY_LABELS: Record<string, string> = {
  dca: "DCA",
  grid: "Grid",
  "grid-infinity": "Infinity Grid",
  "grid-leveraged": "Lev Grid",
  martingale: "Martingale",
  macd: "MACD",
  bollinger: "Bollinger",
};

export function BotCard({ bot, onPause, onStart, onStop }: BotCardProps) {
  const router = useRouter();
  const cardRef = useRef<HTMLDivElement>(null);
  const [offset, setOffset] = useState(0);
  const [swiping, setSwiping] = useState(false);
  const touchStart = useRef({ x: 0, y: 0, time: 0 });
  const currentOffset = useRef(0);

  // Touch handlers
  const handleTouchStart = useCallback((e: React.TouchEvent) => {
    const touch = e.touches[0];
    if (!touch) return;
    touchStart.current = {
      x: touch.clientX,
      y: touch.clientY,
      time: Date.now(),
    };
    currentOffset.current = offset;
    setSwiping(true);
  }, [offset]);

  const handleTouchMove = useCallback((e: React.TouchEvent) => {
    if (!swiping) return;
    const touch = e.touches[0];
    if (!touch) return;

    const deltaX = touch.clientX - touchStart.current.x;
    const deltaY = touch.clientY - touchStart.current.y;

    // Only track horizontal swipes (ignore vertical scrolls)
    if (Math.abs(deltaY) > Math.abs(deltaX) * 1.5) {
      setSwiping(false);
      setOffset(0);
      return;
    }

    // Clamp offset to reveal action buttons
    const newOffset = Math.max(-160, Math.min(160, deltaX));
    setOffset(newOffset);
  }, [swiping]);

  const handleTouchEnd = useCallback((e: React.TouchEvent) => {
    setSwiping(false);

    const touch = e.changedTouches[0];
    if (!touch) {
      setOffset(0);
      return;
    }

    const deltaX = touch.clientX - touchStart.current.x;
    const deltaTime = Date.now() - touchStart.current.time;
    const velocity = Math.abs(deltaX) / deltaTime;

    // Swipe left → pause (if active)
    if (deltaX < -SWIPE_THRESHOLD || (deltaX < 0 && velocity > SWIPE_VELOCITY_THRESHOLD)) {
      if (bot.status === "active") {
        onPause(bot.id);
      } else if (bot.status === "paused") {
        onStop(bot.id);
      }
      setOffset(0);
      return;
    }

    // Swipe right → view details
    if (deltaX > SWIPE_THRESHOLD || (deltaX > 0 && velocity > SWIPE_VELOCITY_THRESHOLD)) {
      router.push(`/bots/${bot.id}`);
      return;
    }

    // Snap back
    setOffset(0);
  }, [bot.id, bot.status, onPause, onStop, router]);

  // Mouse handlers for desktop testing
  const handleMouseDown = useCallback((e: React.MouseEvent) => {
    touchStart.current = { x: e.clientX, y: e.clientY, time: Date.now() };
    currentOffset.current = offset;
    setSwiping(true);
  }, [offset]);

  const handleMouseMove = useCallback((e: React.MouseEvent) => {
    if (!swiping) return;
    const deltaX = e.clientX - touchStart.current.x;
    const newOffset = Math.max(-160, Math.min(160, deltaX));
    setOffset(newOffset);
  }, [swiping]);

  const handleMouseUp = useCallback((e: React.MouseEvent) => {
    setSwiping(false);
    const deltaX = e.clientX - touchStart.current.x;

    if (deltaX < -SWIPE_THRESHOLD) {
      if (bot.status === "active") onPause(bot.id);
      else if (bot.status === "paused") onStop(bot.id);
    } else if (deltaX > SWIPE_THRESHOLD) {
      router.push(`/bots/${bot.id}`);
    }
    setOffset(0);
  }, [bot.id, bot.status, onPause, onStop, router]);

  return (
    <div className="relative overflow-hidden rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800">
      {/* Action backgrounds revealed by swipe */}
      {/* Left action — View Details */}
      <div
        className={clsx(
          "absolute inset-y-0 left-0 flex items-center pl-4 transition-opacity duration-200",
          offset > 20 ? "opacity-100" : "opacity-0"
        )}
      >
        <div className="flex items-center gap-2 text-brand-500">
          <Info className="w-5 h-5" />
          <span className="text-sm font-medium">Details</span>
        </div>
      </div>

      {/* Right action — Pause/Stop */}
      <div
        className={clsx(
          "absolute inset-y-0 right-0 flex items-center pr-4 transition-opacity duration-200",
          offset < -20 ? "opacity-100" : "opacity-0"
        )}
      >
        {bot.status === "active" && (
          <div className="flex items-center gap-2 text-amber-500">
            <Pause className="w-5 h-5" />
            <span className="text-sm font-medium">Pause</span>
          </div>
        )}
        {bot.status === "paused" && (
          <div className="flex items-center gap-2 text-red-500">
            <Square className="w-5 h-5" />
            <span className="text-sm font-medium">Stop</span>
          </div>
        )}
        {bot.status === "stopped" && (
          <div className="flex items-center gap-2 text-emerald-500">
            <Play className="w-5 h-5" />
            <span className="text-sm font-medium">Start</span>
          </div>
        )}
      </div>

      {/* Card content — slides with touch */}
      <div
        ref={cardRef}
        className={clsx(
          "relative bg-white dark:bg-slate-800 p-4 transition-transform cursor-pointer select-none",
          swiping ? "duration-0" : "duration-300"
        )}
        style={{ transform: `translateX(${offset}px)` }}
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={() => { setSwiping(false); setOffset(0); }}
        onClick={() => offset === 0 && router.push(`/bots/${bot.id}`)}
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            {/* Status dot */}
            <div className={clsx("w-2.5 h-2.5 rounded-full", STATUS_COLORS[bot.status] || "bg-slate-400")} />

            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-semibold text-sm text-slate-900 dark:text-white">
                  {bot.name}
                </h3>
                {bot.paperTrading && (
                  <span className="text-[10px] bg-amber-100 dark:bg-amber-900/30 text-amber-700 dark:text-amber-400 px-1.5 py-0.5 rounded-full font-medium">
                    Paper
                  </span>
                )}
              </div>
              <div className="flex items-center gap-2 text-xs text-slate-500 mt-0.5">
                <span className="font-mono">{bot.pair}</span>
                <span>·</span>
                <span className="bg-slate-100 dark:bg-slate-700 px-1.5 py-0.5 rounded text-[10px]">
                  {STRATEGY_LABELS[bot.strategyType] || bot.strategyType}
                </span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <div className="text-right">
              <div className={`text-sm font-bold font-mono ${(bot.totalPnl || 0) >= 0 ? "text-emerald-500" : "text-red-500"}`}>
                {(bot.totalPnl || 0) >= 0 ? "+" : ""}${(bot.totalPnl || 0).toFixed(2)}
              </div>
              <div className="text-[10px] text-slate-400">
                {bot.totalTrades || 0} trades · {(bot.winRate || 0).toFixed(0)}% win
              </div>
            </div>
            <ChevronRight className="w-4 h-4 text-slate-400" />
          </div>
        </div>

        {/* Swipe hint — shown briefly on first render */}
        <div className="flex items-center justify-center gap-4 mt-2 text-[10px] text-slate-400 opacity-50">
          <span>← Swipe right for details</span>
          <span>Swipe left for actions →</span>
        </div>
      </div>
    </div>
  );
}