"use client";

import { Shield, TrendingUp, Settings, Target } from "lucide-react";

const STRATEGY_LABELS: Record<string, string> = {
  dca: "DCA",
  grid: "Grid",
  "grid-infinity": "Infinity Grid",
  "grid-leveraged": "Leveraged Grid",
  martingale: "Martingale",
  macd: "MACD Swing",
  bollinger: "Bollinger Bands",
  marketmaking: "Market Maker",
  avellaneda: "A-S Market Maker",
  rebalancing: "Portfolio Rebalancer",
  twap: "TWAP",
  ml: "ML Predictor",
};

interface BotReviewStepProps {
  name: string;
  exchange: string;
  pair: string;
  strategyType: string;
  config: any;
  paperTrading: boolean;
}

export function BotReviewStep({ name, exchange, pair, strategyType, config, paperTrading }: BotReviewStepProps) {
  return (
    <div className="space-y-6">
      <h2 className="text-lg font-bold text-slate-900 dark:text-white">Review Your Bot</h2>

      {/* Summary Card */}
      <div className="bg-slate-50 dark:bg-slate-800/50 rounded-xl p-5 space-y-4">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-lg bg-brand-100 dark:bg-brand-900/30">
            <Settings className="w-5 h-5 text-brand-600 dark:text-brand-400" />
          </div>
          <div>
            <h3 className="font-semibold text-slate-900 dark:text-white">{name}</h3>
            <p className="text-sm text-slate-500">{STRATEGY_LABELS[strategyType] || strategyType} on {exchange}</p>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div className="bg-white dark:bg-slate-800 rounded-lg p-3">
            <div className="text-xs text-slate-500">Trading Pair</div>
            <div className="font-mono font-bold">{pair}</div>
          </div>
          <div className="bg-white dark:bg-slate-800 rounded-lg p-3">
            <div className="text-xs text-slate-500">Mode</div>
            <div className="flex items-center gap-2">
              <Shield className={`w-4 h-4 ${paperTrading ? "text-amber-500" : "text-emerald-500"}`} />
              <span className="font-medium">{paperTrading ? "Paper Trading" : "Live Trading"}</span>
            </div>
          </div>
        </div>

        {/* Config Details */}
        {config && Object.keys(config).length > 0 && (
          <div className="bg-white dark:bg-slate-800 rounded-lg p-3">
            <div className="text-xs text-slate-500 mb-2">Configuration</div>
            <div className="grid grid-cols-2 gap-2">
              {Object.entries(config).slice(0, 8).map(([key, value]) => (
                <div key={key} className="flex justify-between text-sm">
                  <span className="text-slate-500">{key.replace(/([A-Z])/g, " $1").trim()}</span>
                  <span className="font-mono font-medium">{typeof value === "boolean" ? (value ? "Yes" : "No") : String(value)}</span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Warnings */}
      {strategyType === "martingale" && (
        <div className="bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 p-4 rounded-lg">
          <div className="flex items-center gap-2">
            <Target className="w-4 h-4 text-amber-500" />
            <span className="text-sm font-medium text-amber-700 dark:text-amber-400">High Risk Strategy</span>
          </div>
          <p className="text-xs text-amber-600 dark:text-amber-400 mt-1">
            Martingale exponentially increases position sizes. Ensure you have sufficient capital to withstand multiple safety orders.
          </p>
        </div>
      )}

      {!paperTrading && (
        <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 p-4 rounded-lg">
          <div className="flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-red-500" />
            <span className="text-sm font-medium text-red-700 dark:text-red-400">Live Trading Mode</span>
          </div>
          <p className="text-xs text-red-600 dark:text-red-400 mt-1">
            This bot will use real funds. Start with paper trading first if you&apos;re testing a new strategy.
          </p>
        </div>
      )}
    </div>
  );
}