"use client";

import { useRouter } from "next/navigation";
import { Bot, Play, Pause, Square, Trash2, TrendingUp, TrendingDown } from "lucide-react";
import { useBotStore } from "@/lib/store/botStore";
import { useState } from "react";

interface Bot {
  id: string;
  name: string;
  exchange: string;
  pair: string;
  strategyType: string;
  status: "active" | "paused" | "stopped" | "error";
  paperTrading: boolean;
  totalPnl: number;
  totalTrades: number;
  winRate: number;
  createdAt: string;
}

interface BotTableProps {
  bots: Bot[];
}

const STATUS_STYLES: Record<string, string> = {
  active: "badge-green",
  paused: "badge-yellow",
  stopped: "bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-400 text-xs font-medium px-2 py-0.5 rounded-full",
  error: "badge-red",
};

const STRATEGY_LABELS: Record<string, string> = {
  dca: "DCA",
  grid: "Grid",
  "grid-infinity": "Infinity Grid",
  "grid-leveraged": "Leveraged Grid",
  martingale: "Martingale",
  macd: "MACD",
  bollinger: "Bollinger",
  arbitrage: "Arbitrage",
  marketmaking: "Market Maker",
  avellaneda: "A-S MM",
  rebalancing: "Rebalance",
  twap: "TWAP",
  ml: "ML",
};

export function BotTable({ bots }: BotTableProps) {
  const router = useRouter();
  const { startBot, stopBot, pauseBot, deleteBot } = useBotStore();
  const [confirmDelete, setConfirmDelete] = useState<string | null>(null);

  const handleAction = async (botId: string, action: "start" | "stop" | "pause") => {
    try {
      if (action === "start") await startBot(botId);
      if (action === "stop") await stopBot(botId);
      if (action === "pause") await pauseBot(botId);
    } catch (err: any) {
      console.error(`Failed to ${action} bot:`, err.message);
    }
  };

  const handleDelete = async (botId: string) => {
    if (confirmDelete !== botId) {
      setConfirmDelete(botId);
      setTimeout(() => setConfirmDelete(null), 3000);
      return;
    }
    try {
      await deleteBot(botId);
      setConfirmDelete(null);
    } catch (err: any) {
      console.error("Failed to delete bot:", err.message);
    }
  };

  if (bots.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-full gap-3">
        <Bot className="w-8 h-8 text-slate-300 dark:text-slate-600" />
        <div className="text-center">
          <p className="text-sm text-slate-500 dark:text-slate-400 font-medium">No bots yet</p>
          <button
            onClick={() => router.push("/bots/new")}
            className="btn-primary mt-2 text-sm"
          >
            Create Your First Bot
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center justify-between px-3 py-2 border-b border-slate-200 dark:border-slate-700">
        <span className="text-xs font-medium text-slate-500">
          Trading Bots ({bots.length})
        </span>
        <button
          onClick={() => router.push("/bots/new")}
          className="btn-primary text-xs py-1 px-3"
        >
          + New Bot
        </button>
      </div>

      <div className="flex-1 overflow-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-slate-200 dark:border-slate-700 text-xs text-slate-400">
              <th className="text-left px-3 py-2 font-medium">Name</th>
              <th className="text-left px-3 py-2 font-medium">Pair</th>
              <th className="text-left px-3 py-2 font-medium hidden sm:table-cell">Strategy</th>
              <th className="text-left px-3 py-2 font-medium hidden md:table-cell">Status</th>
              <th className="text-right px-3 py-2 font-medium hidden lg:table-cell">P&L</th>
              <th className="text-right px-3 py-2 font-medium hidden lg:table-cell">Win Rate</th>
              <th className="text-right px-3 py-2 font-medium">Actions</th>
            </tr>
          </thead>
          <tbody>
            {bots.map((bot) => (
              <tr
                key={bot.id}
                className="border-b border-slate-100 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/50 cursor-pointer"
                onClick={() => router.push(`/bots/${bot.id}`)}
              >
                <td className="px-3 py-2">
                  <div>
                    <span className="font-medium text-slate-700 dark:text-slate-300">{bot.name}</span>
                    {bot.paperTrading && (
                      <span className="ml-1.5 text-[10px] bg-amber-100 dark:bg-amber-900/30 text-amber-700 dark:text-amber-400 px-1.5 py-0.5 rounded">
                        Paper
                      </span>
                    )}
                  </div>
                  <span className="text-xs text-slate-400">{bot.exchange}</span>
                </td>
                <td className="px-3 py-2 font-mono text-xs text-slate-600 dark:text-slate-400">
                  {bot.pair}
                </td>
                <td className="px-3 py-2 hidden sm:table-cell">
                  <span className="text-xs bg-slate-100 dark:bg-slate-700 px-1.5 py-0.5 rounded text-slate-600 dark:text-slate-400">
                    {STRATEGY_LABELS[bot.strategyType] || bot.strategyType}
                  </span>
                </td>
                <td className="px-3 py-2 hidden md:table-cell">
                  <span className={STATUS_STYLES[bot.status] || ""}>
                    {bot.status}
                  </span>
                </td>
                <td className={`px-3 py-2 text-right hidden lg:table-cell font-mono text-xs ${
                  (bot.totalPnl || 0) >= 0 ? "text-emerald-500" : "text-red-500"
                }`}>
                  {(bot.totalPnl || 0) >= 0 ? "+" : ""}${(bot.totalPnl || 0).toFixed(2)}
                </td>
                <td className="px-3 py-2 text-right hidden lg:table-cell text-xs text-slate-500">
                  {(bot.winRate || 0).toFixed(1)}%
                </td>
                <td className="px-3 py-2 text-right">
                  <div className="flex items-center justify-end gap-0.5" onClick={(e) => e.stopPropagation()}>
                    {bot.status !== "active" && (
                      <button
                        onClick={() => handleAction(bot.id, "start")}
                        className="p-1 rounded hover:bg-emerald-100 dark:hover:bg-emerald-900/30 text-emerald-600 transition-colors"
                        title="Start"
                      >
                        <Play className="w-3.5 h-3.5" />
                      </button>
                    )}
                    {bot.status === "active" && (
                      <button
                        onClick={() => handleAction(bot.id, "pause")}
                        className="p-1 rounded hover:bg-amber-100 dark:hover:bg-amber-900/30 text-amber-600 transition-colors"
                        title="Pause"
                      >
                        <Pause className="w-3.5 h-3.5" />
                      </button>
                    )}
                    {bot.status !== "stopped" && (
                      <button
                        onClick={() => handleAction(bot.id, "stop")}
                        className="p-1 rounded hover:bg-red-100 dark:hover:bg-red-900/30 text-red-600 transition-colors"
                        title="Stop"
                      >
                        <Square className="w-3.5 h-3.5" />
                      </button>
                    )}
                    {bot.status === "stopped" && (
                      <button
                        onClick={() => handleDelete(bot.id)}
                        className={`p-1 rounded transition-colors ${
                          confirmDelete === bot.id
                            ? "bg-red-500 text-white"
                            : "hover:bg-red-100 dark:hover:bg-red-900/30 text-red-500"
                        }`}
                        title={confirmDelete === bot.id ? "Click again to confirm" : "Delete"}
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}