"use client";

import { useEffect, useState } from "react";
import { AIGridSuggestion } from "./AIGridSuggestion";
import { Sparkles, AlertTriangle } from "lucide-react";

interface GridConfig {
  upperPrice?: number;
  lowerPrice?: number;
  gridLevels?: number;
  quantityPerGrid?: number;
  mode?: "spot" | "futures";
  leverage?: number;
  trailingUpperBound?: boolean;
  autoCompound?: boolean;
}

interface GridConfigFormProps {
  config: GridConfig;
  onChange: (config: GridConfig) => void;
  pair: string;
  exchange: string;
  isInfinity?: boolean;
  isLeveraged?: boolean;
}

const DEFAULTS: GridConfig = {
  upperPrice: 70000,
  lowerPrice: 60000,
  gridLevels: 20,
  quantityPerGrid: 0.001,
  mode: "spot",
  leverage: 1,
  trailingUpperBound: false,
  autoCompound: true,
};

export function GridConfigForm({ config, onChange, pair, exchange, isInfinity, isLeveraged }: GridConfigFormProps) {
  const [localConfig, setLocalConfig] = useState<GridConfig>({ ...DEFAULTS, ...config });
  const [useAI, setUseAI] = useState(false);

  useEffect(() => {
    onChange(localConfig);
  }, [localConfig, onChange]);

  const update = (key: keyof GridConfig, value: any) => {
    setLocalConfig((prev) => ({ ...prev, [key]: value }));
  };

  const handleAISuggestion = (suggestion: any) => {
    update("lowerPrice", suggestion.suggestedLower);
    update("upperPrice", suggestion.suggestedUpper);
    update("gridLevels", suggestion.suggestedLevels);
    update("quantityPerGrid", suggestion.suggestedQtyPerGrid);
    setUseAI(true);
  };

  const gridSpacing = ((localConfig.upperPrice || 70000) - (localConfig.lowerPrice || 60000)) / ((localConfig.gridLevels || 20) - 1);

  // Liquidation price estimate for leveraged grids
  const liquidationPrice = isLeveraged
    ? ((localConfig.upperPrice || 70000) + (localConfig.lowerPrice || 60000)) / 2 * (1 - 1 / (localConfig.leverage || 1) + 0.005)
    : null;

  return (
    <div className="space-y-6">
      {/* AI Suggestion */}
      {!isInfinity && (
        <AIGridSuggestion
          pair={pair}
          exchange={exchange}
          onApply={handleAISuggestion}
        />
      )}

      {/* Price Range */}
      {!isInfinity && (
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium mb-1.5">
              Lower Price {useAI && <span className="text-brand-500 text-xs">(AI)</span>}
            </label>
            <input
              type="number"
              value={localConfig.lowerPrice}
              onChange={(e) => { update("lowerPrice", parseFloat(e.target.value) || 0); setUseAI(false); }}
              className="input"
            />
          </div>
          <div>
            <label className="block text-sm font-medium mb-1.5">
              Upper Price {useAI && <span className="text-brand-500 text-xs">(AI)</span>}
            </label>
            <input
              type="number"
              value={localConfig.upperPrice}
              onChange={(e) => { update("upperPrice", parseFloat(e.target.value) || 0); setUseAI(false); }}
              className="input"
            />
          </div>
        </div>
      )}

      {/* Infinity Grid Floor */}
      {isInfinity && (
        <div>
          <label className="block text-sm font-medium mb-1.5">Grid Floor Price (No Upper Bound)</label>
          <input
            type="number"
            value={localConfig.lowerPrice}
            onChange={(e) => update("lowerPrice", parseFloat(e.target.value) || 0)}
            className="input"
          />
          <p className="text-xs text-slate-500 mt-1">
            Grid will expand upward infinitely as price rises
          </p>
        </div>
      )}

      {/* Grid Levels */}
      <div>
        <div className="flex items-center justify-between mb-1.5">
          <label className="text-sm font-medium">
            Grid Levels ({localConfig.gridLevels})
          </label>
          <span className="text-xs text-slate-500">
            Spacing: ${gridSpacing.toFixed(2)}
          </span>
        </div>
        <input
          type="range"
          value={localConfig.gridLevels}
          onChange={(e) => update("gridLevels", parseInt(e.target.value))}
          min={5}
          max={100}
          className="w-full"
        />
        <div className="flex justify-between text-xs text-slate-400 mt-1">
          <span>5</span>
          <span>100</span>
        </div>
      </div>

      {/* Quantity Per Grid */}
      <div>
        <label className="block text-sm font-medium mb-1.5">Quantity Per Grid</label>
        <input
          type="number"
          value={localConfig.quantityPerGrid}
          onChange={(e) => update("quantityPerGrid", parseFloat(e.target.value) || 0)}
          className="input"
          min={0}
          step={0.0001}
        />
      </div>

      {/* Mode & Leverage */}
      {isLeveraged && (
        <div className="space-y-3">
          <div>
            <label className="block text-sm font-medium mb-1.5">Leverage ({localConfig.leverage}x)</label>
            <input
              type="range"
              value={localConfig.leverage}
              onChange={(e) => update("leverage", parseInt(e.target.value))}
              min={1}
              max={125}
              className="w-full"
            />
            <div className="flex justify-between text-xs text-slate-400 mt-1">
              <span>1x</span>
              <span>125x</span>
            </div>
          </div>

          {liquidationPrice && (
            <div className="flex items-start gap-2 p-3 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg">
              <AlertTriangle className="w-4 h-4 text-red-500 flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-sm font-medium text-red-600 dark:text-red-400">
                  Estimated Liquidation: ${liquidationPrice.toFixed(2)}
                </p>
                <p className="text-xs text-red-500 mt-0.5">
                  This is an estimate. Actual liquidation depends on exchange maintenance margin.
                </p>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Options */}
      <div className="space-y-3">
        {!isInfinity && (
          <label className="flex items-center gap-3">
            <input
              type="checkbox"
              checked={localConfig.trailingUpperBound}
              onChange={(e) => update("trailingUpperBound", e.target.checked)}
              className="rounded"
            />
            <span className="text-sm">Trailing upper bound (grid moves up with price)</span>
          </label>
        )}
        <label className="flex items-center gap-3">
          <input
            type="checkbox"
            checked={localConfig.autoCompound}
            onChange={(e) => update("autoCompound", e.target.checked)}
            className="rounded"
          />
          <span className="text-sm">Auto-compound (reinvest grid profits)</span>
        </label>
      </div>
    </div>
  );
}