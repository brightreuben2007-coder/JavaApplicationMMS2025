"use client";

import { useState } from "react";
import { Sparkles, Loader2 } from "lucide-react";
import api from "@/lib/api";

interface AISuggestion {
  suggestedLower: number;
  suggestedUpper: number;
  suggestedLevels: number;
  suggestedQtyPerGrid: number;
  explanation: string;
  volatility: number;
  priceRange: number;
}

interface AIGridSuggestionProps {
  pair: string;
  exchange: string;
  onApply: (suggestion: AISuggestion) => void;
}

export function AIGridSuggestion({ pair, exchange, onApply }: AIGridSuggestionProps) {
  const [loading, setLoading] = useState(false);
  const [suggestion, setSuggestion] = useState<AISuggestion | null>(null);
  const [error, setError] = useState<string | null>(null);

  const fetchSuggestion = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await api.get("/bots/grid-suggestion", {
        pair,
        exchange,
        balance: "1000",
      });
      setSuggestion(res.data);
    } catch (err: any) {
      setError(err.message || "Failed to get AI suggestion");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="border border-brand-200 dark:border-brand-800 bg-brand-50/50 dark:bg-brand-900/10 rounded-lg p-4">
      {!suggestion ? (
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-brand-500" />
            <div>
              <span className="text-sm font-medium text-brand-700 dark:text-brand-400">AI Grid Suggestion</span>
              <p className="text-xs text-brand-600/70 dark:text-brand-400/70 mt-0.5">
                Analyzes 7-day price range and volatility
              </p>
            </div>
          </div>
          <button
            onClick={fetchSuggestion}
            disabled={loading}
            className="btn-primary text-xs py-1.5 px-3 flex items-center gap-1.5"
          >
            {loading ? (
              <><Loader2 className="w-3 h-3 animate-spin" /> Analyzing...</>
            ) : (
              <><Sparkles className="w-3 h-3" /> Analyze {pair}</>
            )}
          </button>
        </div>
      ) : (
        <div>
          <div className="flex items-center gap-2 mb-3">
            <Sparkles className="w-4 h-4 text-brand-500" />
            <span className="text-sm font-medium text-brand-700 dark:text-brand-400">AI Suggestion Ready</span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-3">
            <div className="bg-white dark:bg-slate-800 rounded-lg p-2 text-center">
              <div className="text-xs text-slate-500">Lower</div>
              <div className="font-mono text-sm font-bold">${suggestion.suggestedLower.toFixed(0)}</div>
            </div>
            <div className="bg-white dark:bg-slate-800 rounded-lg p-2 text-center">
              <div className="text-xs text-slate-500">Upper</div>
              <div className="font-mono text-sm font-bold">${suggestion.suggestedUpper.toFixed(0)}</div>
            </div>
            <div className="bg-white dark:bg-slate-800 rounded-lg p-2 text-center">
              <div className="text-xs text-slate-500">Levels</div>
              <div className="font-mono text-sm font-bold">{suggestion.suggestedLevels}</div>
            </div>
            <div className="bg-white dark:bg-slate-800 rounded-lg p-2 text-center">
              <div className="text-xs text-slate-500">Per Grid</div>
              <div className="font-mono text-sm font-bold">{suggestion.suggestedQtyPerGrid.toFixed(4)}</div>
            </div>
          </div>

          <p className="text-xs text-slate-500 mb-3">{suggestion.explanation}</p>

          <div className="flex gap-2">
            <button
              onClick={() => onApply(suggestion)}
              className="btn-primary text-xs py-1.5 px-3"
            >
              Apply Suggestion
            </button>
            <button
              onClick={() => setSuggestion(null)}
              className="btn-secondary text-xs py-1.5 px-3"
            >
              Dismiss
            </button>
          </div>
        </div>
      )}

      {error && (
        <p className="text-xs text-red-500 mt-2">{error}</p>
      )}
    </div>
  );
}