"use client";

import { useEffect, useState } from "react";
import { SafetyOrdersPreview } from "./SafetyOrdersPreview";
import { Info } from "lucide-react";

interface DCAConfig {
  baseOrderSize?: number;
  safetyOrderSize?: number;
  maxSafetyOrders?: number;
  priceDeviationPercent?: number;
  safetyOrderVolumeScale?: number;
  safetyOrderStepScale?: number;
  takeProfitPercent?: number;
  trailingTakeProfit?: boolean;
  trailingDeviationPercent?: number;
  cooldownBetweenDealsMinutes?: number;
}

interface DCAConfigFormProps {
  config: DCAConfig;
  onChange: (config: DCAConfig) => void;
  pair: string;
  isMartingale?: boolean;
}

const DEFAULTS: DCAConfig = {
  baseOrderSize: 100,
  safetyOrderSize: 50,
  maxSafetyOrders: 5,
  priceDeviationPercent: 2,
  safetyOrderVolumeScale: 1.5,
  safetyOrderStepScale: 1.2,
  takeProfitPercent: 2,
  trailingTakeProfit: false,
  trailingDeviationPercent: 0.5,
  cooldownBetweenDealsMinutes: 30,
};

export function DCAConfigForm({ config, onChange, pair, isMartingale }: DCAConfigFormProps) {
  const [localConfig, setLocalConfig] = useState<DCAConfig>({ ...DEFAULTS, ...config });

  useEffect(() => {
    onChange(localConfig);
  }, [localConfig, onChange]);

  const update = (key: keyof DCAConfig, value: any) => {
    setLocalConfig((prev) => ({ ...prev, [key]: value }));
  };

  const currentPrice = 50000; // Would come from market data
  const safetyOrders = [];
  let cumulativeDeviation = 0;

  for (let i = 0; i < (localConfig.maxSafetyOrders || 5); i++) {
    cumulativeDeviation += (localConfig.priceDeviationPercent || 2) * Math.pow(localConfig.safetyOrderStepScale || 1.2, i);
    safetyOrders.push({
      index: i,
      triggerPrice: currentPrice * (1 - cumulativeDeviation / 100),
      quantity: (localConfig.safetyOrderSize || 50) * Math.pow(localConfig.safetyOrderVolumeScale || 1.5, i),
    });
  }

  const maxInvestment = (localConfig.baseOrderSize || 100) +
    safetyOrders.reduce((sum, so) => sum + so.quantity, 0);
  const avgEntry = currentPrice; // Simplified

  return (
    <div className="space-y-6">
      {/* Base Order */}
      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium mb-1.5">Base Order Size (USDT)</label>
          <input
            type="number"
            value={localConfig.baseOrderSize}
            onChange={(e) => update("baseOrderSize", parseFloat(e.target.value) || 0)}
            className="input"
            min={1}
            step={10}
          />
        </div>
        <div>
          <label className="block text-sm font-medium mb-1.5">Take Profit (%)</label>
          <input
            type="number"
            value={localConfig.takeProfitPercent}
            onChange={(e) => update("takeProfitPercent", parseFloat(e.target.value) || 0)}
            className="input"
            min={0.1}
            step={0.1}
          />
        </div>
      </div>

      {/* Safety Orders */}
      <div>
        <div className="flex items-center justify-between mb-1.5">
          <label className="text-sm font-medium">
            Safety Orders ({localConfig.maxSafetyOrders})
          </label>
          <span className="text-xs text-amber-500 font-medium">
            Max investment: ${maxInvestment.toFixed(2)}
          </span>
        </div>
        <input
          type="range"
          value={localConfig.maxSafetyOrders}
          onChange={(e) => update("maxSafetyOrders", parseInt(e.target.value))}
          min={0}
          max={20}
          className="w-full"
        />
        <div className="flex justify-between text-xs text-slate-400 mt-1">
          <span>0</span>
          <span>20</span>
        </div>
      </div>

      {/* Safety Order Parameters */}
      <div className="grid grid-cols-3 gap-3">
        <div>
          <label className="block text-xs font-medium mb-1 text-slate-500">Deviation %</label>
          <input
            type="number"
            value={localConfig.priceDeviationPercent}
            onChange={(e) => update("priceDeviationPercent", parseFloat(e.target.value) || 0)}
            className="input text-sm"
            min={0.1}
            step={0.1}
          />
        </div>
        <div>
          <label className="block text-xs font-medium mb-1 text-slate-500">
            {isMartingale ? "Volume Multiplier" : "Volume Scale"}
          </label>
          <input
            type="number"
            value={localConfig.safetyOrderVolumeScale}
            onChange={(e) => update("safetyOrderVolumeScale", parseFloat(e.target.value) || 0)}
            className="input text-sm"
            min={1}
            step={0.1}
          />
        </div>
        <div>
          <label className="block text-xs font-medium mb-1 text-slate-500">Step Scale</label>
          <input
            type="number"
            value={localConfig.safetyOrderStepScale}
            onChange={(e) => update("safetyOrderStepScale", parseFloat(e.target.value) || 0)}
            className="input text-sm"
            min={1}
            step={0.1}
          />
        </div>
      </div>

      {/* Trailing TP */}
      <div className="flex items-center gap-3">
        <input
          type="checkbox"
          id="trailing-tp"
          checked={localConfig.trailingTakeProfit}
          onChange={(e) => update("trailingTakeProfit", e.target.checked)}
          className="rounded"
        />
        <label htmlFor="trailing-tp" className="text-sm">Trailing Take Profit</label>
        {localConfig.trailingTakeProfit && (
          <input
            type="number"
            value={localConfig.trailingDeviationPercent}
            onChange={(e) => update("trailingDeviationPercent", parseFloat(e.target.value) || 0)}
            className="input w-20 text-sm"
            min={0.1}
            step={0.1}
            placeholder="%"
          />
        )}
      </div>

      {/* Cooldown */}
      <div>
        <label className="block text-sm font-medium mb-1.5">Cooldown Between Deals (minutes)</label>
        <input
          type="number"
          value={localConfig.cooldownBetweenDealsMinutes}
          onChange={(e) => update("cooldownBetweenDealsMinutes", parseInt(e.target.value) || 0)}
          className="input w-32"
          min={0}
          max={1440}
        />
      </div>

      {/* Safety Orders Preview */}
      <div className="border border-slate-200 dark:border-slate-700 rounded-lg p-4">
        <div className="flex items-center gap-2 mb-3">
          <Info className="w-4 h-4 text-slate-400" />
          <span className="text-sm font-medium">Safety Orders Preview</span>
        </div>
        <SafetyOrdersPreview
          safetyOrders={safetyOrders}
          basePrice={currentPrice}
          avgEntry={avgEntry}
          takeProfitPercent={localConfig.takeProfitPercent || 2}
        />
      </div>
    </div>
  );
}