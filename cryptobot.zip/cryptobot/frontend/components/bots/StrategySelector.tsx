"use client";

import {
  TrendingUp, Grid3X3, Infinity, Coins, ArrowLeftRight,
  BarChart3, Layers, Brain, Repeat, Clock, Sigma,
} from "lucide-react";

interface StrategyOption {
  id: string;
  name: string;
  description: string;
  icon: any;
  risk: "low" | "medium" | "high";
  tags: string[];
}

const STRATEGIES: StrategyOption[] = [
  {
    id: "dca",
    name: "DCA",
    description: "Dollar cost averaging with safety orders. Accumulates on dips.",
    icon: TrendingUp,
    risk: "low",
    tags: ["beginner", "accumulation"],
  },
  {
    id: "grid",
    name: "Grid",
    description: "Buy low, sell high within a price range. Best for sideways markets.",
    icon: Grid3X3,
    risk: "medium",
    tags: ["popular", "range-bound"],
  },
  {
    id: "grid-infinity",
    name: "Infinity Grid",
    description: "Grid with no upper bound. Captures unlimited upside in bull runs.",
    icon: Infinity,
    risk: "medium",
    tags: ["bullish", "trending"],
  },
  {
    id: "grid-leveraged",
    name: "Leveraged Grid",
    description: "Grid trading with margin. Amplifies profits and risks.",
    icon: Coins,
    risk: "high",
    tags: ["advanced", "leverage"],
  },
  {
    id: "martingale",
    name: "Martingale",
    description: "Doubles position size on losses. High risk, fast recovery potential.",
    icon: BarChart3,
    risk: "high",
    tags: ["aggressive", "recovery"],
  },
  {
    id: "macd",
    name: "MACD Swing",
    description: "Trend-following using MACD crossovers with TP/SL.",
    icon: TrendingUp,
    risk: "medium",
    tags: ["trending", "signal-based"],
  },
  {
    id: "bollinger",
    name: "Bollinger Bands",
    description: "Mean reversion at band extremes. Buy low band, sell high band.",
    icon: Layers,
    risk: "medium",
    tags: ["mean-reversion", "volatility"],
  },
  {
    id: "marketmaking",
    name: "Market Maker",
    description: "Place simultaneous bid/ask to capture spread.",
    icon: ArrowLeftRight,
    risk: "medium",
    tags: ["advanced", "liquidity"],
  },
  {
    id: "avellaneda",
    name: "A-S Market Maker",
    description: "Quantitative model adjusting spreads by inventory risk.",
    icon: Sigma,
    risk: "high",
    tags: ["quant", "institutional"],
  },
  {
    id: "rebalancing",
    name: "Portfolio Rebalancer",
    description: "Maintains target asset allocation. Auto-buys dips, sells peaks.",
    icon: Repeat,
    risk: "low",
    tags: ["passive", "portfolio"],
  },
  {
    id: "twap",
    name: "TWAP Accumulator",
    description: "Time-weighted execution over a period. Minimizes market impact.",
    icon: Clock,
    risk: "low",
    tags: ["execution", "large-orders"],
  },
  {
    id: "ml",
    name: "ML Predictor",
    description: "LSTM model predicts price direction. AI-powered signals.",
    icon: Brain,
    risk: "high",
    tags: ["ai", "experimental"],
  },
];

const RISK_COLORS: Record<string, string> = {
  low: "text-emerald-500 bg-emerald-50 dark:bg-emerald-900/20",
  medium: "text-amber-500 bg-amber-50 dark:bg-amber-900/20",
  high: "text-red-500 bg-red-50 dark:bg-red-900/20",
};

interface StrategySelectorProps {
  selected: string;
  onSelect: (id: string) => void;
}

export function StrategySelector({ selected, onSelect }: StrategySelectorProps) {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
      {STRATEGIES.map((strategy) => {
        const isSelected = selected === strategy.id;
        return (
          <button
            key={strategy.id}
            onClick={() => onSelect(strategy.id)}
            className={`text-left p-4 rounded-xl border-2 transition-all ${
              isSelected
                ? "border-brand-500 bg-brand-50 dark:bg-brand-900/20 shadow-sm"
                : "border-slate-200 dark:border-slate-700 hover:border-slate-300 dark:hover:border-slate-600"
            }`}
          >
            <div className="flex items-start gap-3">
              <div className={`p-2 rounded-lg ${isSelected ? "bg-brand-100 dark:bg-brand-800" : "bg-slate-100 dark:bg-slate-800"}`}>
                <strategy.icon className={`w-5 h-5 ${isSelected ? "text-brand-600 dark:text-brand-400" : "text-slate-500"}`} />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <h3 className="font-medium text-sm text-slate-900 dark:text-white">{strategy.name}</h3>
                  <span className={`text-[10px] px-1.5 py-0.5 rounded-full font-medium ${RISK_COLORS[strategy.risk]}`}>
                    {strategy.risk}
                  </span>
                </div>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 line-clamp-2">
                  {strategy.description}
                </p>
                <div className="flex gap-1 mt-2">
                  {strategy.tags.map((tag) => (
                    <span
                      key={tag}
                      className="text-[10px] px-1.5 py-0.5 rounded bg-slate-100 dark:bg-slate-700 text-slate-500 dark:text-slate-400"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </button>
        );
      })}
    </div>
  );
}