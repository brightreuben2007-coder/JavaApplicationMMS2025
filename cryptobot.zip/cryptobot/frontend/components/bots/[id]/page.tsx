"use client";

import { useEffect } from "react";
import { useParams, useRouter } from "next/navigation";
import { useBotStore } from "@/lib/store/botStore";
import { ArrowLeft, Play, Pause, Square, BarChart3, Activity } from "lucide-react";

export default function BotDetailPage() {
  const { id } = useParams<{ id: string }>();
  const router = useRouter();
  const { selectedBot, fetchBot, startBot, stopBot, pauseBot } = useBotStore();

  useEffect(() => {
    if (id) fetchBot(id);
  }, [id, fetchBot]);

  if (!selectedBot) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="animate-spin w-8 h-8 border-4 border-brand-500 border-t-transparent rounded-full" />
      </div>
    );
  }

  const bot = selectedBot;

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex items-center gap-4">
        <button onClick={() => router.push("/bots")} className="p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800">
          <ArrowLeft className="w-5 h-5" />
        </button>
        <div className="flex-1">
          <h1 className="text-xl font-bold text-slate-900 dark:text-white">{bot.name}</h1>
          <p className="text-sm text-slate-500">{bot.strategyType} on {bot.pair}</p>
        </div>
        <div className="flex gap-2">
          {bot.status !== "active" && (
            <button onClick={() => startBot(bot.id)} className="btn-primary flex items-center gap-2">
              <Play className="w-4 h-4" /> Start
            </button>
          )}
          {bot.status === "active" && (
            <button onClick={() => pauseBot(bot.id)} className="btn-secondary flex items-center gap-2">
              <Pause className="w-4 h-4" /> Pause
            </button>
          )}
          {bot.status !== "stopped" && (
            <button onClick={() => stopBot(bot.id)} className="btn-danger flex items-center gap-2">
              <Square className="w-4 h-4" /> Stop
            </button>
          )}
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <div className="card p-3">
          <div className="text-xs text-slate-500">Status</div>
          <div className={`text-lg font-bold capitalize ${
            bot.status === "active" ? "text-emerald-500" : bot.status === "error" ? "text-red-500" : "text-slate-600"
          }`}>{bot.status}</div>
        </div>
        <div className="card p-3">
          <div className="text-xs text-slate-500">Total P&L</div>
          <div className={`text-lg font-bold font-mono ${(bot.totalPnl || 0) >= 0 ? "text-emerald-500" : "text-red-500"}`}>
            {(bot.totalPnl || 0) >= 0 ? "+" : ""}${(bot.totalPnl || 0).toFixed(2)}
          </div>
        </div>
        <div className="card p-3">
          <div className="text-xs text-slate-500">Total Trades</div>
          <div className="text-lg font-bold font-mono">{bot.totalTrades || 0}</div>
        </div>
        <div className="card p-3">
          <div className="text-xs text-slate-500">Win Rate</div>
          <div className="text-lg font-bold font-mono">{(bot.winRate || 0).toFixed(1)}%</div>
        </div>
      </div>

      {/* Config */}
      <div className="card p-4">
        <h2 className="font-semibold mb-3">Configuration</h2>
        <pre className="text-xs bg-slate-50 dark:bg-slate-800 p-3 rounded-lg overflow-auto max-h-64">
          {JSON.stringify(bot.config, null, 2)}
        </pre>
      </div>
    </div>
  );
}