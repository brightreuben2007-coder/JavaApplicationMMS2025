"use client";

import { ArrowDown, ArrowUp, Target } from "lucide-react";

interface SafetyOrder {
  index: number;
  triggerPrice: number;
  quantity: number;
}

interface SafetyOrdersPreviewProps {
  safetyOrders: SafetyOrder[];
  basePrice: number;
  avgEntry: number;
  takeProfitPercent: number;
}

export function SafetyOrdersPreview({
  safetyOrders,
  basePrice,
  avgEntry,
  takeProfitPercent,
}: SafetyOrdersPreviewProps) {
  const maxInvestment = safetyOrders.reduce((sum, so) => sum + so.quantity, 0) + 100; // + base order
  const takeProfitPrice = avgEntry * (1 + takeProfitPercent / 100);

  return (
    <div className="space-y-3">
      {/* Summary */}
      <div className="flex gap-3 text-sm">
        <div className="flex-1 bg-white dark:bg-slate-800 rounded-lg p-2 text-center">
          <div className="text-xs text-slate-500">Entry</div>
          <div className="font-mono font-bold text-slate-700 dark:text-slate-300">${basePrice.toFixed(0)}</div>
        </div>
        <div className="flex-1 bg-white dark:bg-slate-800 rounded-lg p-2 text-center">
          <div className="text-xs text-slate-500">Avg Entry</div>
          <div className="font-mono font-bold text-slate-700 dark:text-slate-300">${avgEntry.toFixed(0)}</div>
        </div>
        <div className="flex-1 bg-emerald-50 dark:bg-emerald-900/20 rounded-lg p-2 text-center">
          <div className="text-xs text-emerald-600 dark:text-emerald-400">Take Profit</div>
          <div className="font-mono font-bold text-emerald-600 dark:text-emerald-400">${takeProfitPrice.toFixed(0)}</div>
        </div>
        <div className="flex-1 bg-amber-50 dark:bg-amber-900/20 rounded-lg p-2 text-center">
          <div className="text-xs text-amber-600 dark:text-amber-400">Max Investment</div>
          <div className="font-mono font-bold text-amber-600 dark:text-amber-400">${maxInvestment.toFixed(0)}</div>
        </div>
      </div>

      {/* Safety Orders Table */}
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-xs text-slate-400 border-b border-slate-200 dark:border-slate-700">
              <th className="text-left py-1.5 font-medium">Order #</th>
              <th className="text-left py-1.5 font-medium">Trigger Price</th>
              <th className="text-right py-1.5 font-medium">Order Size</th>
              <th className="text-right py-1.5 font-medium">Cum. Invested</th>
              <th className="text-right py-1.5 font-medium">Avg Entry</th>
              <th className="text-right py-1.5 font-medium">Req. TP Move</th>
            </tr>
          </thead>
          <tbody>
            {safetyOrders.map((so, i) => {
              const cumInvested = 100 + safetyOrders.slice(0, i + 1).reduce((s, o) => s + o.quantity, 0);
              const runningAvg = basePrice * (1 - (i + 1) * 0.02); // Simplified
              const requiredTP = takeProfitPercent + (i + 1) * 0.5;

              return (
                <tr key={so.index} className="border-b border-slate-100 dark:border-slate-800 text-xs">
                  <td className="py-1.5">
                    <span className="inline-flex items-center gap-1">
                      <ArrowDown className="w-3 h-3 text-amber-500" />
                      SO#{so.index + 1}
                    </span>
                  </td>
                  <td className="py-1.5 font-mono text-slate-600 dark:text-slate-400">
                    ${so.triggerPrice.toFixed(0)}
                  </td>
                  <td className="py-1.5 text-right font-mono text-slate-600 dark:text-slate-400">
                    ${so.quantity.toFixed(0)}
                  </td>
                  <td className="py-1.5 text-right font-mono text-slate-600 dark:text-slate-400">
                    ${cumInvested.toFixed(0)}
                  </td>
                  <td className="py-1.5 text-right font-mono text-slate-600 dark:text-slate-400">
                    ${runningAvg.toFixed(0)}
                  </td>
                  <td className="py-1.5 text-right font-mono text-emerald-500">
                    +{requiredTP.toFixed(1)}%
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {safetyOrders.length === 0 && (
        <p className="text-sm text-slate-400 text-center py-4">
          No safety orders configured. Add safety orders to average down on dips.
        </p>
      )}
    </div>
  );
}