"use client";

import { useEffect, useState } from "react";
import ws from "@/lib/websocket";

interface Trade {
  id: string;
  price: number;
  quantity: number;
  side: "buy" | "sell";
  timestamp: number;
}

interface TradesFeedProps {
  pair: string;
}

export function TradesFeed({ pair }: TradesFeedProps) {
  const [trades, setTrades] = useState<Trade[]>([]);

  useEffect(() => {
    ws.on("trades", (data: any) => {
      if (data.symbol === pair || data.symbol === pair.replace("/", "")) {
        const trade: Trade = {
          id: data.id || String(Date.now()),
          price: parseFloat(data.price || "0"),
          quantity: parseFloat(data.quantity || data.qty || "0"),
          side: data.side === "sell" ? "sell" : "buy",
          timestamp: data.timestamp || Date.now(),
        };

        setTrades((prev) => [trade, ...prev].slice(0, 50));
      }
    });

    return () => { ws.off("trades", () => {}); };
  }, [pair]);

  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center px-3 py-1.5 border-b border-slate-200 dark:border-slate-700">
        <span className="text-xs font-medium text-slate-500">Recent Trades</span>
        <div className="ml-auto flex items-center gap-2 text-[10px] text-slate-400">
          <span>Price</span>
          <span>Qty</span>
          <span>Time</span>
        </div>
      </div>

      <div className="flex-1 overflow-auto">
        {trades.length === 0 ? (
          <div className="flex items-center justify-center h-full text-slate-400 text-xs">
            Waiting for trades...
          </div>
        ) : (
          trades.map((trade, i) => (
            <div
              key={`${trade.id}-${i}`}
              className="flex items-center px-2 py-0.5 text-xs font-mono hover:bg-slate-50 dark:hover:bg-slate-800/50"
            >
              <span className={`w-16 ${trade.side === "buy" ? "text-emerald-500" : "text-red-500"}`}>
                {trade.price.toFixed(2)}
              </span>
              <span className="w-16 text-right text-slate-600 dark:text-slate-400">
                {trade.quantity.toFixed(4)}
              </span>
              <span className="w-16 text-right text-slate-400 dark:text-slate-500 text-[10px]">
                {new Date(trade.timestamp).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" })}
              </span>
            </div>
          ))
        )}
      </div>
    </div>
  );
}