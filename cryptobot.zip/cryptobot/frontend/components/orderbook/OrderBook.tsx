"use client";

import { useRef, useEffect } from "react";
import { ChevronDown, ChevronUp } from "lucide-react";

interface OrderBookLevel {
  price: number;
  quantity: number;
}

interface OrderBookProps {
  orderBook: {
    bids: OrderBookLevel[];
    asks: OrderBookLevel[];
    timestamp: number;
  } | null;
  spread: { absolute: number; percent: number } | null;
  midPrice: number | null;
  pair: string;
}

export function OrderBook({ orderBook, spread, midPrice, pair }: OrderBookProps) {
  const asksContainerRef = useRef<HTMLDivElement>(null);
  const bidsContainerRef = useRef<HTMLDivElement>(null);

  // Auto-scroll to center
  useEffect(() => {
    if (asksContainerRef.current) {
      asksContainerRef.current.scrollTop = asksContainerRef.current.scrollHeight;
    }
    if (bidsContainerRef.current) {
      bidsContainerRef.current.scrollTop = 0;
    }
  }, [orderBook]);

  if (!orderBook) {
    return (
      <div className="flex flex-col h-full">
        <div className="px-3 py-2 border-b border-slate-200 dark:border-slate-700">
          <span className="text-xs font-medium text-slate-500">Order Book</span>
        </div>
        <div className="flex-1 flex items-center justify-center text-slate-400 text-sm">
          Loading order book...
        </div>
      </div>
    );
  }

  const maxQuantity = Math.max(
    ...orderBook.bids.map((b) => b.quantity),
    ...orderBook.asks.map((a) => a.quantity),
    1
  );

  const renderLevels = (
    levels: OrderBookLevel[],
    side: "bid" | "ask",
    limit: number = 12
  ) => {
    return levels.slice(0, limit).map((level, i) => (
      <div
        key={`${side}-${level.price}-${i}`}
        className="relative flex items-center px-2 py-0.5 text-xs font-mono group hover:bg-slate-50 dark:hover:bg-slate-800/50"
      >
        {/* Depth bar */}
        <div
          className={`absolute inset-y-0 right-0 transition-all ${
            side === "bid"
              ? "bg-emerald-500/10"
              : "bg-red-500/10"
          }`}
          style={{ width: `${(level.quantity / maxQuantity) * 70}%` }}
        />
        <span className={`relative z-10 w-20 text-left ${
          side === "bid" ? "text-emerald-500" : "text-red-500"
        }`}>
          {level.price.toFixed(2)}
        </span>
        <span className="relative z-10 w-20 text-right text-slate-600 dark:text-slate-400">
          {level.quantity.toFixed(4)}
        </span>
        <span className="relative z-10 w-24 text-right text-slate-400 dark:text-slate-500 text-[10px]">
          {(level.price * level.quantity).toFixed(2)}
        </span>
      </div>
    ));
  };

  const [base, quote] = pair.split("/");

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="px-3 py-2 border-b border-slate-200 dark:border-slate-700">
        <span className="text-xs font-medium text-slate-500">Order Book</span>
      </div>

      {/* Column headers */}
      <div className="flex items-center px-2 py-1 text-[10px] text-slate-400 font-medium border-b border-slate-100 dark:border-slate-800">
        <span className="w-20">Price ({quote})</span>
        <span className="w-20 text-right">Qty ({base})</span>
        <span className="w-24 text-right">Total ({quote})</span>
      </div>

      {/* Asks */}
      <div className="flex-1 min-h-0 overflow-auto" ref={asksContainerRef}>
        {renderLevels(orderBook.asks, "ask", 12)}
      </div>

      {/* Spread */}
      {spread && midPrice && (
        <div className="flex items-center justify-between px-3 py-1.5 bg-slate-50 dark:bg-slate-800/50 border-y border-slate-200 dark:border-slate-700">
          <span className="text-sm font-mono font-bold text-slate-700 dark:text-slate-300">
            ${midPrice.toFixed(2)}
          </span>
          <span className="text-xs text-slate-500">
            Spread: ${spread.absolute.toFixed(2)} ({spread.percent.toFixed(3)}%)
          </span>
        </div>
      )}

      {/* Bids */}
      <div className="flex-1 min-h-0 overflow-auto" ref={bidsContainerRef}>
        {renderLevels(orderBook.bids, "bid", 12)}
      </div>
    </div>
  );
}