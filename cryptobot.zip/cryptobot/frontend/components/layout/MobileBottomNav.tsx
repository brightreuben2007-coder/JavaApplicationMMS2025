"use client";

import { usePathname, useRouter } from "next/navigation";
import {
  LayoutDashboard, Bot, Wallet, Store, Settings, Zap,
} from "lucide-react";
import { clsx } from "clsx";

const NAV_ITEMS = [
  { href: "/dashboard", label: "Home", icon: LayoutDashboard },
  { href: "/bots", label: "Bots", icon: Bot },
  { href: "/smarttrade", label: "Trade", icon: Zap },
  { href: "/portfolio", label: "Portfolio", icon: Wallet },
  { href: "/marketplace", label: "Market", icon: Store },
];

export function MobileBottomNav() {
  const pathname = usePathname();
  const router = useRouter();

  return (
    <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-700 z-50 safe-area-bottom">
      <div className="flex items-center justify-around h-16">
        {NAV_ITEMS.map((item) => {
          const isActive = pathname?.startsWith(item.href);
          return (
            <button
              key={item.href}
              onClick={() => router.push(item.href)}
              className={clsx(
                "flex flex-col items-center justify-center gap-1 px-3 py-1.5 rounded-lg min-w-[60px] transition-colors",
                isActive
                  ? "text-brand-500"
                  : "text-slate-400 hover:text-slate-600 dark:hover:text-slate-300"
              )}
            >
              <item.icon className={clsx("w-5 h-5", isActive && "fill-brand-100")} />
              <span className="text-[10px] font-medium">{item.label}</span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}