"use client";

import { useAuthStore } from "@/lib/store/authStore";
import { useMarketStore } from "@/lib/store/marketStore";
import { Search, Bell, LogOut, Sun, Moon, X } from "lucide-react";
import { useState, useEffect, useRef } from "react";

const POPULAR_PAIRS = [
  "BTC/USDT", "ETH/USDT", "SOL/USDT", "BNB/USDT", "XRP/USDT",
  "ADA/USDT", "DOGE/USDT", "AVAX/USDT", "DOT/USDT", "LINK/USDT",
];

export function TopBar() {
  const user = useAuthStore((s) => s.user);
  const logout = useAuthStore((s) => s.logout);
  const { selectedPair, setSelectedPair, selectedExchange } = useMarketStore();
  const [pairSearch, setPairSearch] = useState("");
  const [showSearch, setShowSearch] = useState(false);
  const [dark, setDark] = useState<boolean>(false);
  const [mounted, setMounted] = useState(false);
  const searchRef = useRef<HTMLDivElement>(null);

  // Initialize dark mode from localStorage
  useEffect(() => {
    setMounted(true);
    const saved = localStorage.getItem("cryptobot-theme");
    const prefersDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
    const isDark = saved === "dark" || (!saved && prefersDark);
    setDark(isDark);
    document.documentElement.classList.toggle("dark", isDark);
  }, []);

  // Close search on outside click
  useEffect(() => {
    const handleClick = (e: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(e.target as Node)) {
        setShowSearch(false);
      }
    };
    document.addEventListener("mousedown", handleClick);
    return () => document.removeEventListener("mousedown", handleClick);
  }, []);

  const filteredPairs = POPULAR_PAIRS.filter((p) =>
    p.toLowerCase().includes(pairSearch.toLowerCase())
  );

  const toggleDark = () => {
    const newDark = !dark;
    setDark(newDark);
    localStorage.setItem("cryptobot-theme", newDark ? "dark" : "light");
    document.documentElement.classList.toggle("dark", newDark);
  };

  const handlePairSelect = (pair: string) => {
    setSelectedPair(pair);
    setShowSearch(false);
    setPairSearch("");
  };

  // Prevent hydration mismatch
  if (!mounted) {
    return (
      <header className="h-14 border-b border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900" />
    );
  }

  return (
    <header className="h-14 border-b border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 flex items-center justify-between px-4 flex-shrink-0">
      <div className="relative" ref={searchRef}>
        <button
          onClick={() => setShowSearch(!showSearch)}
          className="flex items-center gap-2 px-3 py-1.5 bg-slate-100 dark:bg-slate-800 rounded-lg text-sm font-mono hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
        >
          <span className="text-slate-400 text-xs">{selectedExchange}</span>
          <span className="font-bold text-slate-900 dark:text-white">{selectedPair}</span>
          <Search className="w-3 h-3 text-slate-400" />
        </button>

        {showSearch && (
          <div className="absolute top-full left-0 mt-1 w-80 card p-3 z-50 animate-slideUp shadow-lg">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-medium text-slate-500">Select Pair</span>
              <button
                onClick={() => setShowSearch(false)}
                className="p-0.5 rounded hover:bg-slate-100 dark:hover:bg-slate-700"
              >
                <X className="w-3 h-3" />
              </button>
            </div>
            <div className="relative">
              <Search className="absolute left-2 top-2.5 w-3.5 h-3.5 text-slate-400" />
              <input
                type="text"
                value={pairSearch}
                onChange={(e) => setPairSearch(e.target.value)}
                className="input pl-8 py-2 text-sm"
                placeholder="Search pairs..."
                autoFocus
              />
            </div>
            <div className="mt-2 max-h-64 overflow-auto">
              {filteredPairs.length > 0 ? (
                filteredPairs.map((pair) => (
                  <button
                    key={pair}
                    onClick={() => handlePairSelect(pair)}
                    className={`w-full text-left px-3 py-2 text-sm rounded-lg transition-colors ${
                      pair === selectedPair
                        ? "bg-brand-50 dark:bg-brand-900/20 text-brand-600 dark:text-brand-400 font-medium"
                        : "hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300"
                    }`}
                  >
                    {pair}
                  </button>
                ))
              ) : (
                <p className="text-sm text-slate-400 text-center py-4">No pairs found</p>
              )}
            </div>
          </div>
        )}
      </div>

      <div className="flex items-center gap-1">
        {/* Dark mode toggle */}
        <button
          onClick={toggleDark}
          className="p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          title={dark ? "Switch to light mode" : "Switch to dark mode"}
        >
          {dark ? (
            <Sun className="w-4 h-4 text-amber-500" />
          ) : (
            <Moon className="w-4 h-4 text-slate-500" />
          )}
        </button>

        {/* Notifications */}
        <button className="p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors relative">
          <Bell className="w-4 h-4 text-slate-500 dark:text-slate-400" />
          <span className="absolute top-1.5 right-1.5 w-1.5 h-1.5 bg-red-500 rounded-full" />
        </button>

        {/* User info */}
        <div className="hidden sm:flex items-center gap-2 ml-2">
          <div className="w-7 h-7 rounded-full bg-brand-100 dark:bg-brand-900/30 flex items-center justify-center">
            <span className="text-xs font-bold text-brand-600 dark:text-brand-400">
              {user?.email?.charAt(0).toUpperCase() || "U"}
            </span>
          </div>
          <span className="text-sm text-slate-600 dark:text-slate-400 max-w-[120px] truncate">
            {user?.email}
          </span>
        </div>

        {/* Logout */}
        <button
          onClick={logout}
          className="p-2 rounded-lg hover:bg-red-50 dark:hover:bg-red-900/20 text-slate-400 hover:text-red-500 transition-colors"
          title="Sign out"
        >
          <LogOut className="w-4 h-4" />
        </button>
      </div>
    </header>
  );
}