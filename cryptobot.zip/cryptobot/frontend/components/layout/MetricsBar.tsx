"use client";

import { usePortfolioStore } from "@/lib/store/portfolioStore";
import { useBotStore } from "@/lib/store/botStore";
import { useEffect } from "react";
import { TrendingUp, TrendingDown, Activity, Bot } from "lucide-react";

export function MetricsBar() {
  const summary = usePortfolioStore((s) => s.summary);
  const fetchSummary = usePortfolioStore((s) => s.fetchSummary);
  const bots = useBotStore((s) => s.bots);

  useEffect(() => {
    fetchSummary();
    const interval = setInterval(fetchSummary, 30000);
    return () => clearInterval(interval);
  }, [fetchSummary]);

  if (!summary) return null;

  const metrics = [
    {
      label: "Portfolio Value",
      value: `$${summary.totalValue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`,
      icon: Activity,
      color: "text-slate-600 dark:text-slate-400",
    },
    {
      label: "Total P&L",
      value: `${summary.totalPnl >= 0 ? "+" : ""}$${Math.abs(summary.totalPnl).toLocaleString(undefined, { minimumFractionDigits: 2 })}`,
      icon: summary.totalPnl >= 0 ? TrendingUp : TrendingDown,
      color: summary.totalPnl >= 0 ? "text-profit" : "text-loss",
    },
    {
      label: "Active Bots",
      value: `${summary.activeBots} / ${summary.totalBots}`,
      icon: Bot,
      color: "text-brand-500",
    },
    {
      label: "Positions",
      value: String(summary.activePositions),
      icon: Activity,
      color: "text-slate-600 dark:text-slate-400",
    },
  ];

  return (
    <div className="flex gap-4 px-4 py-2 border-b border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900/50 overflow-x-auto">
      {metrics.map((metric) => (
        <div key={metric.label} className="flex items-center gap-2 flex-shrink-0">
          <metric.icon className={`w-4 h-4 ${metric.color}`} />
          <span className="text-xs text-slate-500 dark:text-slate-400">{metric.label}</span>
          <span className={`text-sm font-semibold font-mono ${metric.color}`}>{metric.value}</span>
        </div>
      ))}
    </div>
  );
}