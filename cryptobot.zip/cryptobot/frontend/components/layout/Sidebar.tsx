"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  LayoutDashboard, Bot, LineChart, Wallet, Store, Settings,
  Zap, Brain, Users, ChevronLeft, ChevronRight, X,
} from "lucide-react";
import { useState, useEffect, useRef } from "react";
import { clsx } from "clsx";
import { useIsMobile } from "@/lib/hooks/useMediaQuery";

const navItems = [
  { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { href: "/smarttrade", label: "SmartTrade", icon: Zap },
  { href: "/bots", label: "Bots", icon: Bot },
  { href: "/backtest", label: "Backtest", icon: LineChart },
  { href: "/portfolio", label: "Portfolio", icon: Wallet },
  { href: "/marketplace", label: "Marketplace", icon: Store },
  { href: "/ml", label: "ML Lab", icon: Brain },
  { href: "/copytrading", label: "Copy Trading", icon: Users },
  { href: "/settings", label: "Settings", icon: Settings },
];

export function Sidebar() {
  const pathname = usePathname();
  const isMobile = useIsMobile();
  const [collapsed, setCollapsed] = useState(isMobile);
  const [mobileOpen, setMobileOpen] = useState(false);
  const sidebarRef = useRef<HTMLDivElement>(null);
  const touchStartX = useRef(0);

  // Collapse on mobile by default
  useEffect(() => {
    setCollapsed(isMobile);
  }, [isMobile]);

  // Close on route change (mobile)
  useEffect(() => {
    setMobileOpen(false);
  }, [pathname]);

  // Swipe gesture
  const handleTouchStart = (e: React.TouchEvent) => {
    touchStartX.current = e.touches[0]?.clientX || 0;
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    const diff = (e.changedTouches[0]?.clientX || 0) - touchStartX.current;
    if (diff > 80) setMobileOpen(true);
    if (diff < -80) setMobileOpen(false);
  };

  const sidebarContent = (
    <aside
      ref={sidebarRef}
      className={clsx(
        "flex flex-col h-full border-r border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 transition-all duration-300",
        collapsed && !isMobile ? "w-16" : "w-56"
      )}
      onTouchStart={handleTouchStart}
      onTouchEnd={handleTouchEnd}
    >
      <div className="flex items-center justify-between p-4 border-b border-slate-200 dark:border-slate-700">
        {(!collapsed || isMobile) && (
          <span className="text-xl font-bold text-brand-500">CryptoBot</span>
        )}
        {isMobile ? (
          <button
            onClick={() => setMobileOpen(false)}
            className="p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        ) : (
          <button
            onClick={() => setCollapsed(!collapsed)}
            className="p-1 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800"
          >
            {collapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
          </button>
        )}
      </div>

      <nav className="flex-1 p-2 space-y-1 overflow-auto">
        {navItems.map((item) => {
          const isActive = pathname?.startsWith(item.href);
          return (
            <Link
              key={item.href}
              href={item.href}
              className={clsx(
                "flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors",
                isActive
                  ? "bg-brand-50 dark:bg-brand-900/20 text-brand-600 dark:text-brand-400"
                  : "text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800"
              )}
              onClick={() => isMobile && setMobileOpen(false)}
            >
              <item.icon className="w-5 h-5 flex-shrink-0" />
              {(!collapsed || isMobile) && <span>{item.label}</span>}
            </Link>
          );
        })}
      </nav>

      <div className="p-3 border-t border-slate-200 dark:border-slate-700">
        {(!collapsed || isMobile) && (
          <div className="text-xs text-slate-400 text-center">v1.0.0</div>
        )}
      </div>
    </aside>
  );

  // Mobile: render as overlay
  if (isMobile) {
    return (
      <>
        {/* Hamburger trigger */}
        <button
          onClick={() => setMobileOpen(true)}
          className="md:hidden fixed top-3 left-3 z-40 p-2 rounded-lg bg-white dark:bg-slate-800 shadow-lg border border-slate-200 dark:border-slate-700"
        >
          <ChevronRight className="w-5 h-5" />
        </button>

        {/* Overlay */}
        {mobileOpen && (
          <div
            className="fixed inset-0 bg-black/50 z-40 md:hidden"
            onClick={() => setMobileOpen(false)}
          />
        )}

        {/* Slide-in sidebar */}
        <div
          className={clsx(
            "fixed left-0 top-0 bottom-0 z-50 transition-transform duration-300 md:hidden",
            mobileOpen ? "translate-x-0" : "-translate-x-full"
          )}
        >
          {sidebarContent}
        </div>
      </>
    );
  }

  // Desktop: render normally
  return sidebarContent;
}