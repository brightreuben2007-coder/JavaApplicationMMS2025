import type { StrategyType, BotConfig } from "./bot.types";

export type ConditionOperator = "AND" | "OR" | "NOT";
export type ConditionBlockType = "trigger" | "filter" | "logic";

export interface ConditionBlock {
  id: string;
  type: ConditionBlockType;
  label: string;
  condition: string;
  params: Record<string, number | string | boolean>;
  parentId: string | null;
  operator: ConditionOperator | null;
  children: ConditionBlock[];
}

export interface Strategy {
  id: string;
  userId: string;
  name: string;
  description: string | null;
  strategyType: StrategyType;
  config: BotConfig;
  conditionBlocks: ConditionBlock[] | null;
  isPublic: boolean;
  tags: string[];
  version: number;
  createdAt: Date;
  updatedAt: Date;
}

export interface StrategyTemplate {
  name: string;
  description: string;
  strategyType: StrategyType;
  config: BotConfig;
  icon: string;
  riskLevel: "low" | "medium" | "high";
  expectedMonthlyROI: string;
  recommendedCapital: string;
  tags: string[];
}

export interface BacktestMetrics {
  totalReturn: number;
  totalReturnPercent: number;
  sharpeRatio: number;
  sortinoRatio: number;
  calmarRatio: number;
  omegaRatio: number;
  maxDrawdown: number;
  maxDrawdownPercent: number;
  winRate: number;
  profitFactor: number;
  totalTrades: number;
  avgTradeDurationMs: number;
  avgProfitPerTrade: number;
  avgLossPerTrade: number;
  bestTrade: { profit: number; date: Date };
  worstTrade: { loss: number; date: Date };
  mae: number;
  mfe: number;
}

export interface OptimizationConfig {
  strategyId: string;
  paramSearchSpace: Record<string, { min: number; max: number; step: number }>;
  optimizationTarget: "sharpe" | "profit" | "drawdown";
  algorithm: "grid" | "random" | "bayesian" | "genetic";
  dateRange: { start: Date; end: Date };
  timeframe: string;
}

export interface HyperoptJob {
  id: string;
  userId: string;
  progress: number;
  totalCombinations: number;
  completedCombinations: number;
  bestResult: BacktestMetrics | null;
  bestParams: Record<string, number> | null;
  status: "queued" | "running" | "completed" | "failed";
  createdAt: Date;
  completedAt: Date | null;
}