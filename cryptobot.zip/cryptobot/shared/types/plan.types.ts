export type PlanTier = "free" | "starter" | "pro" | "enterprise";

export interface PlanDefinition {
  id: string;
  name: string;
  tier: PlanTier;
  price: number;
  maxBots: number;
  maxDeals: number;
  mlAccess: boolean;
  marketplaceAccess: boolean;
  apiAccess: boolean;
  features: string[];
  stripeProductId: string | null;
}

export interface UserPlanInfo {
  planId: string;
  tier: PlanTier;
  status: "active" | "expired" | "cancelled" | "past_due";
  currentPeriodEnd: Date | null;
  usage: {
    botsUsed: number;
    botsLimit: number;
    dealsToday: number;
    dealsLimit: number;
  };
}