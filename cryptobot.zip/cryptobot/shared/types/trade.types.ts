import type { TradeSide, TradeStatus, OrderType } from "./bot.types";

export interface Trade {
  id: string;
  botId: string;
  userId: string;
  exchange: string;
  pair: string;
  side: TradeSide;
  orderType: OrderType;
  quantity: number;
  price: number | null;
  filledPrice: number | null;
  fee: number;
  feeCurrency: string | null;
  status: TradeStatus;
  exchangeOrderId: string | null;
  slippage: number | null;
  isSafetyOrder: boolean;
  dealId: string | null;
  createdAt: Date;
  filledAt: Date | null;
}

export interface Position {
  id: string;
  botId: string;
  userId: string;
  exchange: string;
  pair: string;
  entryPrice: number;
  currentPrice: number;
  quantity: number;
  unrealizedPnl: number;
  realizedPnl: number;
  stopLoss: number | null;
  takeProfit: { price: number; percentage: number }[] | null;
  trailingStop: { deviation: number; activated: boolean; currentPrice: number } | null;
  safetyOrders: SafetyOrderState[] | null;
  leverage: number;
  minimumROI: Record<string, number> | null;
  status: "open" | "closed";
  openedAt: Date;
  closedAt: Date | null;
}

export interface SafetyOrderState {
  index: number;
  triggerPrice: number;
  quantity: number;
  filled: boolean;
  filledPrice: number | null;
  filledAt: Date | null;
}

export interface DealTimeline {
  dealId: string;
  pair: string;
  entryTime: Date;
  entryPrice: number;
  safetyOrderFills: { time: Date; price: number; orderIndex: number }[];
  takeProfitFill: { time: Date; price: number; profitPercent: number } | null;
  stopLossFill: { time: Date; price: number; lossPercent: number } | null;
  totalDuration: number | null;
  status: "open" | "closed_profit" | "closed_loss";
}

export interface AggregatedDealStats {
  totalDeals: number;
  profitableDeals: number;
  unprofitableDeals: number;
  winRate: number;
  avgProfitPerDeal: number;
  avgLossPerDeal: number;
  bestDeal: { profit: number; pair: string; date: Date };
  worstDeal: { loss: number; pair: string; date: Date };
  avgDealDurationMs: number;
  longestWinningStreak: number;
  currentStreak: number;
  profitFactor: number;
}