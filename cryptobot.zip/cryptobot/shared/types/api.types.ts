// ============================================================
// API RESPONSE STANDARD WRAPPER
// ============================================================

export interface ApiResponse<T = unknown> {
  success: true;
  data: T;
  meta?: ResponseMeta;
}

export interface ApiError {
  success: false;
  error: {
    code: ErrorCode;
    message: string;
    details?: unknown;
    timestamp: string;
    requestId: string;
  };
}

export type ApiResult<T = unknown> = ApiResponse<T> | ApiError;

export interface ResponseMeta {
  pagination?: PaginationMeta;
  timing?: {
    durationMs: number;
  };
}

export interface PaginationMeta {
  page: number;
  limit: number;
  total: number;
  totalPages: number;
  hasNext: boolean;
  hasPrev: boolean;
}

export interface PaginatedResponse<T> extends ApiResponse<T[]> {
  meta: ResponseMeta & { pagination: PaginationMeta };
}

// ============================================================
// ERROR CODES
// ============================================================

export enum ErrorCode {
  // Auth (AUTH_)
  AUTH_INVALID_CREDENTIALS = "AUTH_INVALID_CREDENTIALS",
  AUTH_TOTP_REQUIRED = "AUTH_TOTP_REQUIRED",
  AUTH_TOTP_INVALID = "AUTH_TOTP_INVALID",
  AUTH_TOKEN_EXPIRED = "AUTH_TOKEN_EXPIRED",
  AUTH_TOKEN_INVALID = "AUTH_TOKEN_INVALID",
  AUTH_UNAUTHORIZED = "AUTH_UNAUTHORIZED",
  AUTH_FORBIDDEN = "AUTH_FORBIDDEN",
  AUTH_IP_NOT_WHITELISTED = "AUTH_IP_NOT_WHITELISTED",
  AUTH_WEB_AUTHN_FAILED = "AUTH_WEB_AUTHN_FAILED",

  // Validation (VAL_)
  VAL_INVALID_INPUT = "VAL_INVALID_INPUT",
  VAL_MISSING_FIELD = "VAL_MISSING_FIELD",
  VAL_INVALID_FORMAT = "VAL_INVALID_FORMAT",

  // Resource (RES_)
  RES_NOT_FOUND = "RES_NOT_FOUND",
  RES_ALREADY_EXISTS = "RES_ALREADY_EXISTS",
  RES_CONFLICT = "RES_CONFLICT",
  RES_GONE = "RES_GONE",

  // Rate Limiting (RATE_)
  RATE_LIMIT_EXCEEDED = "RATE_LIMIT_EXCEEDED",

  // Plan/Billing (PLAN_)
  PLAN_LIMIT_REACHED = "PLAN_LIMIT_REACHED",
  PLAN_FEATURE_NOT_AVAILABLE = "PLAN_FEATURE_NOT_AVAILABLE",
  PLAN_EXPIRED = "PLAN_EXPIRED",
  PLAN_PAYMENT_FAILED = "PLAN_PAYMENT_FAILED",

  // Exchange (EXCH_)
  EXCH_INVALID_CREDENTIALS = "EXCH_INVALID_CREDENTIALS",
  EXCH_WITHDRAWAL_ENABLED = "EXCH_WITHDRAWAL_ENABLED",
  EXCH_INSUFFICIENT_BALANCE = "EXCH_INSUFFICIENT_BALANCE",
  EXCH_RATE_LIMIT = "EXCH_RATE_LIMIT",
  EXCH_MAINTENANCE = "EXCH_MAINTENANCE",
  EXCH_ORDER_FAILED = "EXCH_ORDER_FAILED",
  EXCH_UNSUPPORTED_PAIR = "EXCH_UNSUPPORTED_PAIR",

  // Bot (BOT_)
  BOT_ALREADY_RUNNING = "BOT_ALREADY_RUNNING",
  BOT_NOT_ACTIVE = "BOT_NOT_ACTIVE",
  BOT_MAX_DEALS_REACHED = "BOT_MAX_DEALS_REACHED",
  BOT_CONFIG_INVALID = "BOT_CONFIG_INVALID",
  BOT_PROTECTION_TRIGGERED = "BOT_PROTECTION_TRIGGERED",

  // Trade (TRD_)
  TRD_INVALID_ORDER = "TRD_INVALID_ORDER",
  TRD_MINIMUM_NOT_MET = "TRD_MINIMUM_NOT_MET",
  TRD_POSITION_NOT_FOUND = "TRD_POSITION_NOT_FOUND",

  // Marketplace (MKT_)
  MKT_STRATEGY_NOT_FOUND = "MKT_STRATEGY_NOT_FOUND",
  MKT_ALREADY_PURCHASED = "MKT_ALREADY_PURCHASED",
  MKT_INSUFFICIENT_RIGHTS = "MKT_INSUFFICIENT_RIGHTS",

  // Server (SRV_)
  SRV_INTERNAL_ERROR = "SRV_INTERNAL_ERROR",
  SRV_SERVICE_UNAVAILABLE = "SRV_SERVICE_UNAVAILABLE",
  SRV_DATABASE_ERROR = "SRV_DATABASE_ERROR",
  SRV_REDIS_ERROR = "SRV_REDIS_ERROR",
  SRV_TIMEOUT = "SRV_TIMEOUT",
}

export const ErrorCodeHttpStatus: Record<ErrorCode, number> = {
  [ErrorCode.AUTH_INVALID_CREDENTIALS]: 401,
  [ErrorCode.AUTH_TOTP_REQUIRED]: 403,
  [ErrorCode.AUTH_TOTP_INVALID]: 401,
  [ErrorCode.AUTH_TOKEN_EXPIRED]: 401,
  [ErrorCode.AUTH_TOKEN_INVALID]: 401,
  [ErrorCode.AUTH_UNAUTHORIZED]: 401,
  [ErrorCode.AUTH_FORBIDDEN]: 403,
  [ErrorCode.AUTH_IP_NOT_WHITELISTED]: 403,
  [ErrorCode.AUTH_WEB_AUTHN_FAILED]: 401,
  [ErrorCode.VAL_INVALID_INPUT]: 400,
  [ErrorCode.VAL_MISSING_FIELD]: 400,
  [ErrorCode.VAL_INVALID_FORMAT]: 400,
  [ErrorCode.RES_NOT_FOUND]: 404,
  [ErrorCode.RES_ALREADY_EXISTS]: 409,
  [ErrorCode.RES_CONFLICT]: 409,
  [ErrorCode.RES_GONE]: 410,
  [ErrorCode.RATE_LIMIT_EXCEEDED]: 429,
  [ErrorCode.PLAN_LIMIT_REACHED]: 403,
  [ErrorCode.PLAN_FEATURE_NOT_AVAILABLE]: 403,
  [ErrorCode.PLAN_EXPIRED]: 403,
  [ErrorCode.PLAN_PAYMENT_FAILED]: 402,
  [ErrorCode.EXCH_INVALID_CREDENTIALS]: 400,
  [ErrorCode.EXCH_WITHDRAWAL_ENABLED]: 400,
  [ErrorCode.EXCH_INSUFFICIENT_BALANCE]: 400,
  [ErrorCode.EXCH_RATE_LIMIT]: 429,
  [ErrorCode.EXCH_MAINTENANCE]: 503,
  [ErrorCode.EXCH_ORDER_FAILED]: 502,
  [ErrorCode.EXCH_UNSUPPORTED_PAIR]: 400,
  [ErrorCode.BOT_ALREADY_RUNNING]: 409,
  [ErrorCode.BOT_NOT_ACTIVE]: 400,
  [ErrorCode.BOT_MAX_DEALS_REACHED]: 400,
  [ErrorCode.BOT_CONFIG_INVALID]: 400,
  [ErrorCode.BOT_PROTECTION_TRIGGERED]: 400,
  [ErrorCode.TRD_INVALID_ORDER]: 400,
  [ErrorCode.TRD_MINIMUM_NOT_MET]: 400,
  [ErrorCode.TRD_POSITION_NOT_FOUND]: 404,
  [ErrorCode.MKT_STRATEGY_NOT_FOUND]: 404,
  [ErrorCode.MKT_ALREADY_PURCHASED]: 409,
  [ErrorCode.MKT_INSUFFICIENT_RIGHTS]: 403,
  [ErrorCode.SRV_INTERNAL_ERROR]: 500,
  [ErrorCode.SRV_SERVICE_UNAVAILABLE]: 503,
  [ErrorCode.SRV_DATABASE_ERROR]: 500,
  [ErrorCode.SRV_REDIS_ERROR]: 500,
  [ErrorCode.SRV_TIMEOUT]: 504,
};