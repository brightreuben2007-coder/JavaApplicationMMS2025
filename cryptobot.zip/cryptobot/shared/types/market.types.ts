export type Timeframe = "1m" | "5m" | "15m" | "1h" | "4h" | "1d" | "1w";

export interface OHLCV {
  timestamp: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

export interface Ticker {
  symbol: string;
  last: number;
  bid: number;
  ask: number;
  high24h: number;
  low24h: number;
  volume24h: number;
  quoteVolume24h: number;
  change24h: number;
  changePercent24h: number;
  timestamp: number;
}

export interface OrderBookLevel {
  price: number;
  quantity: number;
}

export interface OrderBook {
  symbol: string;
  bids: OrderBookLevel[];
  asks: OrderBookLevel[];
  timestamp: number;
  exchange: string;
}

export interface TradeTick {
  id: string;
  price: number;
  quantity: number;
  side: "buy" | "sell";
  timestamp: number;
}

export interface FundingRate {
  symbol: string;
  rate: number;
  nextFundingTimestamp: number;
  markPrice: number;
  indexPrice: number;
}

export interface Liquidation {
  symbol: string;
  side: "buy" | "sell";
  quantity: number;
  price: number;
  timestamp: number;
}

export interface AIGridSuggestion {
  suggestedLower: number;
  suggestedUpper: number;
  suggestedLevels: number;
  suggestedQtyPerGrid: number;
  explanation: string;
  volatility: number;
  priceRange: number;
  avgCandleSize: number;
}

export interface ExchangePairInfo {
  symbol: string;
  baseAsset: string;
  quoteAsset: string;
  minQty: number;
  maxQty: number;
  stepSize: number;
  tickSize: number;
  minNotional: number;
  isSpot: boolean;
  isFutures: boolean;
  maxLeverage: number;
}