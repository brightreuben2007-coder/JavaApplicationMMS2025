export type BotStatus = "active" | "paused" | "stopped" | "error";
export type StrategyType =
  | "dca"
  | "grid"
  | "grid-infinity"
  | "grid-leveraged"
  | "martingale"
  | "macd"
  | "bollinger"
  | "arbitrage"
  | "marketmaking"
  | "avellaneda"
  | "rebalancing"
  | "twap"
  | "ml";
export type OrderType = "market" | "limit" | "stop" | "stop-limit";
export type TradeSide = "buy" | "sell";
export type TradeStatus = "pending" | "open" | "filled" | "cancelled" | "expired" | "rejected";
export type GridMode = "spot" | "futures";
export type DealStartConditionType =
  | "webhook"
  | "rsi"
  | "price_breakout"
  | "bollinger"
  | "ema_cross"
  | "macd_cross"
  | "scheduled"
  | "manual";

export interface DCAConfig {
  baseOrderSize: number;
  safetyOrderSize: number;
  maxSafetyOrders: number;
  priceDeviationPercent: number;
  safetyOrderVolumeScale: number;
  safetyOrderStepScale: number;
  takeProfitPercent: number;
  trailingTakeProfit: boolean;
  trailingDeviationPercent: number;
  dealStartConditions: DealStartCondition[];
  cooldownBetweenDealsMinutes: number;
  minimumROI: Record<string, number>;
}

export interface GridConfig {
  upperPrice: number;
  lowerPrice: number;
  gridLevels: number;
  quantityPerGrid: number;
  mode: GridMode;
  leverage: number;
  trailingUpperBound: boolean;
  autoCompound: boolean;
}

export interface InfinityGridConfig {
  lowerPrice: number;
  initialQuantity: number;
  gridSpacingPercent: number;
  autoCompound: boolean;
}

export interface MarketMakingConfig {
  spreadPercent: number;
  orderAmount: number;
  orderRefreshIntervalMs: number;
  maxOpenOrders: number;
  inventoryTargetPercent: number;
  inventorySkewFactor: number;
  hangingOrdersEnabled: boolean;
  hangingOrdersKeptRatio: number;
}

export interface AvellanedaConfig {
  gamma: number;
  sigma: number;
  kappa: number;
  targetInventory: number;
  inventorySkewFactor: number;
  orderRefreshTimeMs: number;
  hangingOrdersEnabled: boolean;
  hangingOrdersKeptRatio: number;
}

export interface RebalancingConfig {
  targetAllocations: { asset: string; percentage: number }[];
  rebalanceTriggerPercent: number;
  rebalanceIntervalMinutes: number;
  useLimitOrders: boolean;
}

export interface TWAPConfig {
  totalAmount: number;
  durationMinutes: number;
  intervalSeconds: number;
  side: TradeSide;
}

export interface DealStartCondition {
  type: DealStartConditionType;
  params: Record<string, number | string | boolean>;
}

export type BotConfig =
  | DCAConfig
  | GridConfig
  | InfinityGridConfig
  | MarketMakingConfig
  | AvellanedaConfig
  | RebalancingConfig
  | TWAPConfig;

export interface ProtectionConfig {
  stoplossOnExchange: boolean;
  stoplossPercent: number;
  cooldownMinutes: number;
  maxOpenDeals: number;
  minimumROI: Record<string, number>;
  volatilityProtectionEnabled: boolean;
  volatilityThreshold: number;
  staleOrderTimeoutMinutes: number;
}

export interface PairListConfig {
  mode: "static" | "volume" | "performance" | "volatility";
  pairs?: string[];
  maxPairs?: number;
  topVolumeCount?: number;
  momentumDays?: number;
  volatilityRange?: { min: number; max: number };
  blacklist: string[];
}

export interface Bot {
  id: string;
  userId: string;
  credentialId: string;
  name: string;
  exchange: string;
  pair: string;
  strategyType: StrategyType;
  config: BotConfig;
  status: BotStatus;
  paperTrading: boolean;
  maxActiveDeals: number;
  maxDailyDeals: number;
  totalPnl: number;
  totalTrades: number;
  winRate: number;
  pairlistConfig: PairListConfig | null;
  protectionConfig: ProtectionConfig | null;
  dealStartConditions: DealStartCondition[] | null;
  version: number;
  createdAt: Date;
  updatedAt: Date;
}

export interface BotCreateInput {
  name: string;
  credentialId: string;
  exchange: string;
  pair: string;
  strategyType: StrategyType;
  config: BotConfig;
  paperTrading?: boolean;
  pairlistConfig?: PairListConfig;
  protectionConfig?: ProtectionConfig;
  dealStartConditions?: DealStartCondition[];
}

export interface BotUpdateInput {
  name?: string;
  config?: BotConfig;
  status?: BotStatus;
  paperTrading?: boolean;
  pairlistConfig?: PairListConfig;
  protectionConfig?: ProtectionConfig;
  dealStartConditions?: DealStartCondition[];
}