export type SmartTradeEntry = "market" | "limit";
export type SmartTradeSide = "buy" | "sell";
export type SmartTradeStatus = "pending" | "entry_filled" | "tp_partial" | "tp_complete" | "sl_triggered" | "cancelled";

export interface TakeProfitLevel {
  id: string;
  price: number;
  percentageToClose: number;
  trailing: boolean;
  trailingDeviation: number;
  status: "pending" | "placed" | "filled" | "cancelled";
}

export interface TrailingStopConfig {
  enabled: boolean;
  deviation: number;
  currentStopPrice: number | null;
  highestPrice: number | null;
  activated: boolean;
}

export interface SmartTradeConfig {
  exchange: string;
  pair: string;
  side: SmartTradeSide;
  entryType: SmartTradeEntry;
  entryPrice: number | null;
  entryQuantity: number;
  takeProfitLevels: TakeProfitLevel[];
  stopLoss: { price: number; percentage: number } | null;
  trailingStop: TrailingStopConfig;
  leverage: number;
}

export interface SmartTrade {
  id: string;
  userId: string;
  credentialId: string;
  exchange: string;
  pair: string;
  side: SmartTradeSide;
  entryType: SmartTradeEntry;
  entryPrice: number | null;
  entryQty: number;
  tpLevels: TakeProfitLevel[];
  stopLoss: number | null;
  trailingStop: TrailingStopConfig | null;
  status: SmartTradeStatus;
  exchangeOrderIds: Record<string, string> | null;
  createdAt: Date;
  closedAt: Date | null;
}