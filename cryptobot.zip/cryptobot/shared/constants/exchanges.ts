export interface ExchangeInfo {
  id: string;
  name: string;
  logo: string;
  supportedModes: ("spot" | "futures" | "margin")[];
  features: string[];
  requiresPassphrase: boolean;
  makerFee: number;
  takerFee: number;
  minOrderSize: Record<string, number>;
}

export const SUPPORTED_EXCHANGES: ExchangeInfo[] = [
  {
    id: "binance",
    name: "Binance",
    logo: "/exchanges/binance.svg",
    supportedModes: ["spot", "futures", "margin"],
    features: [
      "spot_trading",
      "futures_trading",
      "hedge_mode",
      "coin_m_futures",
      "usd_m_futures",
      "portfolio_margin",
    ],
    requiresPassphrase: false,
    makerFee: 0.001,
    takerFee: 0.001,
    minOrderSize: { BTCUSDT: 0.00001, ETHUSDT: 0.0001 },
  },
  {
    id: "bybit",
    name: "Bybit",
    logo: "/exchanges/bybit.svg",
    supportedModes: ["spot", "futures", "margin"],
    features: ["spot_trading", "futures_trading", "unified_margin", "copy_trading_api"],
    requiresPassphrase: false,
    makerFee: 0.001,
    takerFee: 0.001,
    minOrderSize: { BTCUSDT: 0.001, ETHUSDT: 0.01 },
  },
  {
    id: "kraken",
    name: "Kraken",
    logo: "/exchanges/kraken.svg",
    supportedModes: ["spot", "futures", "margin"],
    features: ["spot_trading", "futures_trading", "staking_yield"],
    requiresPassphrase: false,
    makerFee: 0.0016,
    takerFee: 0.0026,
    minOrderSize: {},
  },
  {
    id: "coinbase",
    name: "Coinbase",
    logo: "/exchanges/coinbase.svg",
    supportedModes: ["spot"],
    features: ["spot_trading", "advanced_trade_api", "recurring_buy"],
    requiresPassphrase: false,
    makerFee: 0.004,
    takerFee: 0.006,
    minOrderSize: {},
  },
  {
    id: "kucoin",
    name: "KuCoin",
    logo: "/exchanges/kucoin.svg",
    supportedModes: ["spot", "futures", "margin"],
    features: ["spot_trading", "futures_trading", "lending"],
    requiresPassphrase: true,
    makerFee: 0.001,
    takerFee: 0.001,
    minOrderSize: {},
  },
];

export const getExchangeInfo = (exchangeId: string): ExchangeInfo | undefined =>
  SUPPORTED_EXCHANGES.find((e) => e.id === exchangeId);