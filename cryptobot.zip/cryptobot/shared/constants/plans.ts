import type { PlanDefinition } from "../types/plan.types";

export const PLANS: PlanDefinition[] = [
  {
    id: "plan_free",
    name: "Free",
    tier: "free",
    price: 0,
    maxBots: 1,
    maxDeals: 10,
    mlAccess: false,
    marketplaceAccess: false,
    apiAccess: false,
    features: ["1 trading bot", "Paper trading", "Basic DCA strategy", "1 exchange connection"],
    stripeProductId: null,
  },
  {
    id: "plan_starter",
    name: "Starter",
    tier: "starter",
    price: 19,
    maxBots: 5,
    maxDeals: 50,
    mlAccess: false,
    marketplaceAccess: true,
    apiAccess: false,
    features: [
      "5 trading bots",
      "All strategies (DCA, Grid, MACD, Bollinger)",
      "SmartTrade terminal",
      "Backtesting (30 days history)",
      "Marketplace access",
      "Telegram notifications",
      "3 exchange connections",
    ],
    stripeProductId: "prod_starter",
  },
  {
    id: "plan_pro",
    name: "Pro",
    tier: "pro",
    price: 49,
    maxBots: 0, // unlimited
    maxDeals: 0, // unlimited
    mlAccess: true,
    marketplaceAccess: true,
    apiAccess: true,
    features: [
      "Unlimited trading bots",
      "All strategies including ML-powered",
      "SmartTrade terminal",
      "Full backtesting (unlimited history)",
      "Hyperopt parameter optimization",
      "Marketplace (buy & sell strategies)",
      "Copy trading",
      "Telegram/Discord/Email notifications",
      "Unlimited exchange connections",
      "Priority support",
      "API access",
    ],
    stripeProductId: "prod_pro",
  },
  {
    id: "plan_enterprise",
    name: "Enterprise",
    tier: "enterprise",
    price: 199,
    maxBots: 0,
    maxDeals: 0,
    mlAccess: true,
    marketplaceAccess: true,
    apiAccess: true,
    features: [
      "Everything in Pro",
      "Custom strategy development",
      "Dedicated account manager",
      "SLA guarantee",
      "Custom exchange integrations",
      "Team management",
      "Audit logs export",
      "White-label option",
    ],
    stripeProductId: "prod_enterprise",
  },
];

export const getPlanById = (planId: string): PlanDefinition | undefined =>
  PLANS.find((p) => p.id === planId);

export const getPlanByTier = (tier: string): PlanDefinition | undefined =>
  PLANS.find((p) => p.tier === tier);

export const isUnlimited = (value: number): boolean => value === 0;