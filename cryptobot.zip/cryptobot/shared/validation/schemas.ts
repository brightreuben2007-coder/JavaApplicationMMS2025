import { z } from "zod";

// ============================================================
// PRIMITIVES
// ============================================================
const uuidSchema = z.string().uuid();
const emailSchema = z.string().email().max(255).toLowerCase().trim();
const passwordSchema = z.string().min(8).max(128);
const exchangeSchema = z.enum(["binance", "bybit", "kraken", "coinbase", "kucoin"]);
const pairSchema = z.string().regex(/^[A-Z0-9]{2,10}\/[A-Z0-9]{2,10}$/, "Invalid pair format (e.g., BTC/USDT)");
const timeframeSchema = z.enum(["1m", "5m", "15m", "1h", "4h", "1d", "1w"]);
const tradeSideSchema = z.enum(["buy", "sell"]);
const orderTypeSchema = z.enum(["market", "limit", "stop", "stop-limit"]);
const botStatusSchema = z.enum(["active", "paused", "stopped", "error"]);
const strategyTypeSchema = z.enum([
  "dca", "grid", "grid-infinity", "grid-leveraged", "martingale",
  "macd", "bollinger", "arbitrage", "marketmaking", "avellaneda",
  "rebalancing", "twap", "ml",
]);

// ============================================================
// AUTH SCHEMAS
// ============================================================
export const registerSchema = z.object({
  email: emailSchema,
  password: passwordSchema,
}).strict();

export const loginSchema = z.object({
  email: emailSchema,
  password: z.string(),
  totpCode: z.string().length(6).optional(),
}).strict();

export const totpSetupSchema = z.object({
  token: z.string().length(6),
}).strict();

export const webauthnRegistrationOptionsSchema = z.object({
  email: emailSchema,
}).strict();

export const webauthnRegistrationVerificationSchema = z.object({
  id: z.string(),
  rawId: z.string(),
  response: z.object({
    clientDataJSON: z.string(),
    attestationObject: z.string(),
  }),
  type: z.literal("public-key"),
}).strict();

export const webauthnAuthenticationOptionsSchema = z.object({
  email: emailSchema,
}).strict();

export const webauthnAuthenticationVerificationSchema = z.object({
  id: z.string(),
  rawId: z.string(),
  response: z.object({
    clientDataJSON: z.string(),
    authenticatorData: z.string(),
    signature: z.string(),
    userHandle: z.string().optional(),
  }),
  type: z.literal("public-key"),
}).strict();

// ============================================================
// CREDENTIAL SCHEMAS
// ============================================================
export const createCredentialSchema = z.object({
  exchange: exchangeSchema,
  label: z.string().min(1).max(100),
  apiKey: z.string().min(1).max(500),
  apiSecret: z.string().min(1).max(500),
  passphrase: z.string().max(500).optional(),
}).strict();

export const updateCredentialSchema = z.object({
  label: z.string().min(1).max(100).optional(),
  apiKey: z.string().min(1).max(500).optional(),
  apiSecret: z.string().min(1).max(500).optional(),
  passphrase: z.string().max(500).optional(),
}).strict();

// ============================================================
// BOT SCHEMAS
// ============================================================
const dealStartConditionSchema = z.object({
  type: z.enum(["webhook", "rsi", "price_breakout", "bollinger", "ema_cross", "macd_cross", "scheduled", "manual"]),
  params: z.record(z.union([z.number(), z.string(), z.boolean()])),
});

const minimumROISchema = z.record(z.string().regex(/^\d+$/), z.number().min(0));

const protectionConfigSchema = z.object({
  stoplossOnExchange: z.boolean().default(true),
  stoplossPercent: z.number().min(0.1).max(100).default(10),
  cooldownMinutes: z.number().int().min(0).max(1440).default(30),
  maxOpenDeals: z.number().int().min(1).max(100).default(5),
  minimumROI: minimumROISchema.default({ "0": 3, "60": 2, "120": 1 }),
  volatilityProtectionEnabled: z.boolean().default(false),
  volatilityThreshold: z.number().min(1).max(100).default(10),
  staleOrderTimeoutMinutes: z.number().int().min(1).max(1440).default(60),
}).strict();

const pairListConfigSchema = z.object({
  mode: z.enum(["static", "volume", "performance", "volatility"]),
  pairs: z.array(pairSchema).optional(),
  maxPairs: z.number().int().min(1).max(100).optional(),
  topVolumeCount: z.number().int().min(1).max(100).optional(),
  momentumDays: z.number().int().min(1).max(30).optional(),
  volatilityRange: z.object({ min: z.number(), max: z.number() }).optional(),
  blacklist: z.array(pairSchema).default([]),
}).strict();

// DCA Config
const dcaConfigSchema = z.object({
  baseOrderSize: z.number().positive(),
  safetyOrderSize: z.number().positive(),
  maxSafetyOrders: z.number().int().min(0).max(50),
  priceDeviationPercent: z.number().min(0.1).max(100),
  safetyOrderVolumeScale: z.number().min(1).max(5),
  safetyOrderStepScale: z.number().min(1).max(3),
  takeProfitPercent: z.number().min(0.1).max(1000),
  trailingTakeProfit: z.boolean().default(false),
  trailingDeviationPercent: z.number().min(0.1).max(100).default(1),
  dealStartConditions: z.array(dealStartConditionSchema).default([]),
  cooldownBetweenDealsMinutes: z.number().int().min(0).max(1440).default(30),
  minimumROI: minimumROISchema.default({}),
}).strict();

// Grid Config
const gridConfigSchema = z.object({
  upperPrice: z.number().positive(),
  lowerPrice: z.number().positive(),
  gridLevels: z.number().int().min(2).max(1000),
  quantityPerGrid: z.number().positive(),
  mode: z.enum(["spot", "futures"]).default("spot"),
  leverage: z.number().min(1).max(125).default(1),
  trailingUpperBound: z.boolean().default(false),
  autoCompound: z.boolean().default(true),
}).strict().refine(d => d.upperPrice > d.lowerPrice, { message: "upperPrice must be greater than lowerPrice" });

// Infinity Grid Config
const infinityGridConfigSchema = z.object({
  lowerPrice: z.number().positive(),
  initialQuantity: z.number().positive(),
  gridSpacingPercent: z.number().min(0.1).max(100),
  autoCompound: z.boolean().default(true),
}).strict();

// Market Making Config
const marketMakingConfigSchema = z.object({
  spreadPercent: z.number().min(0.01).max(10),
  orderAmount: z.number().positive(),
  orderRefreshIntervalMs: z.number().int().min(1000).max(300000).default(30000),
  maxOpenOrders: z.number().int().min(2).max(100).default(10),
  inventoryTargetPercent: z.number().min(0).max(100).default(50),
  inventorySkewFactor: z.number().min(0).max(1).default(0.5),
  hangingOrdersEnabled: z.boolean().default(false),
  hangingOrdersKeptRatio: z.number().min(0).max(1).default(0.7),
}).strict();

// Avellaneda Config
const avellanedaConfigSchema = z.object({
  gamma: z.number().min(0.001).max(10),
  sigma: z.number().min(0.001).max(10),
  kappa: z.number().min(0.1).max(100),
  targetInventory: z.number(),
  inventorySkewFactor: z.number().min(0).max(1).default(0.5),
  orderRefreshTimeMs: z.number().int().min(1000).max(300000).default(30000),
  hangingOrdersEnabled: z.boolean().default(true),
  hangingOrdersKeptRatio: z.number().min(0).max(1).default(0.7),
}).strict();

// Rebalancing Config
const rebalancingConfigSchema = z.object({
  targetAllocations: z.array(z.object({
    asset: z.string().min(1).max(10),
    percentage: z.number().min(0).max(100),
  })).min(2),
  rebalanceTriggerPercent: z.number().min(0.1).max(100).default(5),
  rebalanceIntervalMinutes: z.number().int().min(1).max(10080).default(360),
  useLimitOrders: z.boolean().default(true),
}).strict().refine(d => {
  const total = d.targetAllocations.reduce((sum, a) => sum + a.percentage, 0);
  return Math.abs(total - 100) < 0.01;
}, { message: "Allocation percentages must sum to 100" });

// TWAP Config
const twapConfigSchema = z.object({
  totalAmount: z.number().positive(),
  durationMinutes: z.number().int().min(1).max(1440),
  intervalSeconds: z.number().int().min(15).max(3600).default(60),
  side: tradeSideSchema,
}).strict();

// Union config schema based on strategy type
export const botConfigSchema = z.discriminatedUnion("strategyType", [
  z.object({ strategyType: z.literal("dca"), config: dcaConfigSchema }),
  z.object({ strategyType: z.literal("grid"), config: gridConfigSchema }),
  z.object({ strategyType: z.literal("grid-infinity"), config: infinityGridConfigSchema }),
  z.object({ strategyType: z.literal("grid-leveraged"), config: gridConfigSchema.extend({ leverage: z.number().min(2).max(125) }) }),
  z.object({ strategyType: z.literal("marketmaking"), config: marketMakingConfigSchema }),
  z.object({ strategyType: z.literal("avellaneda"), config: avellanedaConfigSchema }),
  z.object({ strategyType: z.literal("rebalancing"), config: rebalancingConfigSchema }),
  z.object({ strategyType: z.literal("twap"), config: twapConfigSchema }),
  z.object({ strategyType: z.literal("macd"), config: dcaConfigSchema }),
  z.object({ strategyType: z.literal("bollinger"), config: dcaConfigSchema }),
  z.object({ strategyType: z.literal("martingale"), config: dcaConfigSchema }),
  z.object({ strategyType: z.literal("arbitrage"), config: dcaConfigSchema }),
  z.object({ strategyType: z.literal("ml"), config: dcaConfigSchema }),
]);

export const createBotSchema = z.object({
  name: z.string().min(1).max(100),
  credentialId: uuidSchema,
  exchange: exchangeSchema,
  pair: pairSchema,
  strategyType: strategyTypeSchema,
  config: z.record(z.unknown()),
  paperTrading: z.boolean().default(true),
  maxActiveDeals: z.number().int().min(1).max(100).optional(),
  maxDailyDeals: z.number().int().min(1).max(1000).optional(),
  pairlistConfig: pairListConfigSchema.optional(),
  protectionConfig: protectionConfigSchema.optional(),
  dealStartConditions: z.array(dealStartConditionSchema).optional(),
}).strict();

export const updateBotSchema = z.object({
  name: z.string().min(1).max(100).optional(),
  config: z.record(z.unknown()).optional(),
  status: botStatusSchema.optional(),
  paperTrading: z.boolean().optional(),
  maxActiveDeals: z.number().int().min(1).max(100).optional(),
  pairlistConfig: pairListConfigSchema.optional(),
  protectionConfig: protectionConfigSchema.optional(),
  dealStartConditions: z.array(dealStartConditionSchema).optional(),
}).strict();

// ============================================================
// SMARTTRADE SCHEMAS
// ============================================================
const takeProfitLevelSchema = z.object({
  id: z.string().uuid().default(() => crypto.randomUUID()),
  price: z.number().positive(),
  percentageToClose: z.number().min(1).max(100),
  trailing: z.boolean().default(false),
  trailingDeviation: z.number().min(0.01).max(100).default(1),
});

export const createSmartTradeSchema = z.object({
  credentialId: uuidSchema,
  exchange: exchangeSchema,
  pair: pairSchema,
  side: tradeSideSchema,
  entryType: z.enum(["market", "limit"]),
  entryPrice: z.number().positive().nullable().optional(),
  entryQuantity: z.number().positive(),
  takeProfitLevels: z.array(takeProfitLevelSchema).min(1).max(10),
  stopLoss: z.object({
    price: z.number().positive().optional(),
    percentage: z.number().min(0.1).max(100).optional(),
  }).optional(),
  trailingStop: z.object({
    enabled: z.boolean().default(false),
    deviation: z.number().min(0.1).max(100).default(2),
  }).optional(),
  leverage: z.number().min(1).max(125).default(1),
}).strict().refine(d => {
  if (d.entryType === "limit" && !d.entryPrice) {
    return false;
  }
  return true;
}, { message: "entryPrice is required for limit orders" });

// ============================================================
// STRATEGY SCHEMAS
// ============================================================
const conditionBlockSchema: z.ZodType<any> = z.lazy(() =>
  z.object({
    id: z.string().uuid(),
    type: z.enum(["trigger", "filter", "logic"]),
    label: z.string(),
    condition: z.string(),
    params: z.record(z.union([z.number(), z.string(), z.boolean()])),
    parentId: z.string().uuid().nullable(),
    operator: z.enum(["AND", "OR", "NOT"]).nullable(),
    children: z.array(conditionBlockSchema).default([]),
  })
);

export const createStrategySchema = z.object({
  name: z.string().min(1).max(255),
  description: z.string().max(5000).optional(),
  strategyType: strategyTypeSchema,
  config: z.record(z.unknown()),
  conditionBlocks: z.array(conditionBlockSchema).optional(),
  isPublic: z.boolean().default(false),
  tags: z.array(z.string().max(50)).max(20).default([]),
}).strict();

export const updateStrategySchema = z.object({
  name: z.string().min(1).max(255).optional(),
  description: z.string().max(5000).optional(),
  config: z.record(z.unknown()).optional(),
  conditionBlocks: z.array(conditionBlockSchema).optional(),
  isPublic: z.boolean().optional(),
  tags: z.array(z.string().max(50)).max(20).optional(),
}).strict();

// ============================================================
// BACKTEST & HYPEROPT SCHEMAS
// ============================================================
export const createBacktestSchema = z.object({
  strategyId: uuidSchema.optional(),
  strategyConfig: z.record(z.unknown()).optional(),
  pair: pairSchema,
  timeframe: timeframeSchema,
  dateStart: z.string().datetime(),
  dateEnd: z.string().datetime(),
  initialBalance: z.number().positive().default(10000),
  feeRate: z.number().min(0).max(0.1).default(0.001),
  slippagePercent: z.number().min(0).max(10).default(0.1),
}).strict().refine(d => d.strategyId || d.strategyConfig, {
  message: "Either strategyId or strategyConfig must be provided",
});

export const createHyperoptSchema = z.object({
  strategyId: uuidSchema,
  paramSearchSpace: z.record(
    z.string(),
    z.object({ min: z.number(), max: z.number(), step: z.number().positive() })
  ),
  optimizationTarget: z.enum(["sharpe", "profit", "drawdown"]),
  algorithm: z.enum(["grid", "random", "bayesian", "genetic"]),
  dateRange: z.object({ start: z.string().datetime(), end: z.string().datetime() }),
  timeframe: timeframeSchema.default("1h"),
  pair: pairSchema,
  initialBalance: z.number().positive().default(10000),
}).strict();

// ============================================================
// MARKETPLACE SCHEMAS
// ============================================================
export const publishMarketplaceStrategySchema = z.object({
  strategyId: uuidSchema,
  tier: z.enum(["free", "paid", "subscription"]),
  price: z.number().min(0).optional(),
  subscriptionPrice: z.number().min(0).optional(),
}).strict();

export const createMarketplaceReviewSchema = z.object({
  strategyId: uuidSchema,
  rating: z.number().int().min(1).max(5),
  body: z.string().max(2000).optional(),
}).strict();

// ============================================================
// COPY TRADING SCHEMAS
// ============================================================
export const registerSignalProviderSchema = z.object({
  name: z.string().min(1).max(255),
  bio: z.string().max(2000).optional(),
  subscriptionPrice: z.number().min(0).default(0),
  performanceFee: z.number().min(0).max(50).default(0),
  tradingStyleTags: z.array(z.string().max(50)).max(10).default([]),
}).strict();

export const subscribeToProviderSchema = z.object({
  providerId: uuidSchema,
  credentialId: uuidSchema,
  capitalAllocation: z.number().positive(),
}).strict();

// ============================================================
// ML SCHEMAS
// ============================================================
export const trainMLModelSchema = z.object({
  name: z.string().min(1).max(255),
  pair: pairSchema,
  timeframe: timeframeSchema,
  modelType: z.enum(["random_forest", "xgboost", "lstm"]),
  features: z.array(z.string()).min(2),
  predictionHorizon: z.number().int().min(1).max(100).default(1),
  lookbackPeriod: z.number().int().min(10).max(1000).default(50),
  trainTestSplit: z.number().min(0.5).max(0.9).default(0.8),
}).strict();

// ============================================================
// WEBHOOK SCHEMAS
// ============================================================
export const tradingViewWebhookSchema = z.object({
  action: z.enum(["buy", "sell", "close"]),
  pair: z.string(),
  price: z.number().positive().optional(),
  amount: z.number().positive().optional(),
  botName: z.string().optional(),
  strategy: z.string().optional(),
}).passthrough();

// ============================================================
// BILLING SCHEMAS
// ============================================================
export const createSubscriptionSchema = z.object({
  planId: z.string().uuid(),
  paymentMethodId: z.string().optional(),
}).strict();

export const cancelSubscriptionSchema = z.object({
  immediate: z.boolean().default(false),
}).strict();

// ============================================================
// PAGINATION & QUERY SCHEMAS
// ============================================================
export const paginationQuerySchema = z.object({
  page: z.coerce.number().int().min(1).default(1),
  limit: z.coerce.number().int().min(1).max(100).default(20),
  sortBy: z.string().optional(),
  sortOrder: z.enum(["asc", "desc"]).default("desc"),
});

export const dateRangeQuerySchema = z.object({
  start: z.string().datetime().optional(),
  end: z.string().datetime().optional(),
});

// ============================================================
// SETTINGS SCHEMAS
// ============================================================
export const updateSecuritySettingsSchema = z.object({
  ipWhitelist: z.array(z.string().ip()).max(20).optional(),
  totpEnabled: z.boolean().optional(),
}).strict();

export const updateNotificationSettingsSchema = z.object({
  telegramEnabled: z.boolean().optional(),
  discordEnabled: z.boolean().optional(),
  emailEnabled: z.boolean().optional(),
  pushEnabled: z.boolean().optional(),
  notificationEvents: z.array(z.object({
    event: z.string(),
    channels: z.array(z.enum(["telegram", "discord", "email", "push", "app"])),
  })).optional(),
}).strict();

export const updateRiskSettingsSchema = z.object({
  maxDailyLossPercent: z.number().min(0.5).max(100).optional(),
  maxTotalExposurePercent: z.number().min(10).max(200).optional(),
  drawdownPausePercent: z.number().min(1).max(50).optional(),
  drawdownLiquidatePercent: z.number().min(5).max(100).optional(),
}).strict();