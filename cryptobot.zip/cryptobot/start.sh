#!/bin/bash
set -e

echo "============================================"
echo "   CryptoBot — Automated Trading Platform"
echo "============================================"
echo ""

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Check prerequisites
check_prerequisites() {
    echo -e "${BLUE}[1/5] Checking prerequisites...${NC}"
    
    if ! command -v docker &> /dev/null; then
        echo -e "${RED}Docker is required. Install: https://docs.docker.com/get-docker/${NC}"
        exit 1
    fi
    
    if ! command -v docker compose &> /dev/null && ! docker compose version &> /dev/null 2>&1; then
        echo -e "${RED}Docker Compose v2 is required.${NC}"
        exit 1
    fi
    
    if ! command -v openssl &> /dev/null; then
        echo -e "${RED}OpenSSL is required for key generation.${NC}"
        exit 1
    fi
    
    echo -e "${GREEN}✓ All prerequisites met${NC}"
}

# Generate secrets
generate_secrets() {
    echo -e "${BLUE}[2/5] Generating security keys...${NC}"
    
    mkdir -p infrastructure/secrets
    
    if [ ! -f infrastructure/secrets/jwt_private_key.pem ]; then
        openssl genrsa -out infrastructure/secrets/jwt_private_key.pem 2048 2>/dev/null
        openssl rsa -in infrastructure/secrets/jwt_private_key.pem -pubout -out infrastructure/secrets/jwt_public_key.pem 2>/dev/null
        echo -e "${GREEN}✓ JWT keys generated${NC}"
    else
        echo -e "${YELLOW}JWT keys already exist, skipping${NC}"
    fi
    
    if [ ! -f infrastructure/secrets/encryption_master_key.txt ]; then
        openssl rand -base64 64 | tr -d '\n' > infrastructure/secrets/encryption_master_key.txt
        echo -e "${GREEN}✓ Encryption key generated${NC}"
    else
        echo -e "${YELLOW}Encryption key already exists, skipping${NC}"
    fi
    
    if [ ! -f infrastructure/secrets/db_password.txt ]; then
        openssl rand -base64 32 | tr -d '\n' > infrastructure/secrets/db_password.txt
        echo -e "${GREEN}✓ Database password generated${NC}"
    else
        echo -e "${YELLOW}Database password already exists, skipping${NC}"
    fi
    
    # Create placeholder secret files if missing
    for secret in stripe_secret_key stripe_webhook_secret telegram_bot_token sendgrid_api_key webpush_vapid_private smtp_password; do
        if [ ! -f "infrastructure/secrets/${secret}.txt" ]; then
            echo "change-me" > "infrastructure/secrets/${secret}.txt"
        fi
    done
}

# Setup environment
setup_env() {
    echo -e "${BLUE}[3/5] Setting up environment...${NC}"
    
    if [ ! -f .env ]; then
        cp .env.example .env
        
        # Auto-fill generated secrets
        JWT_PRIVATE=$(cat infrastructure/secrets/jwt_private_key.pem | awk '{printf "%s\\n", $0}')
        JWT_PUBLIC=$(cat infrastructure/secrets/jwt_public_key.pem | awk '{printf "%s\\n", $0}')
        ENC_KEY=$(cat infrastructure/secrets/encryption_master_key.txt)
        DB_PASS=$(cat infrastructure/secrets/db_password.txt)
        
        # Use sed differently based on OS
        if [[ "$OSTYPE" == "darwin"* ]]; then
            sed -i '' "s|JWT_PRIVATE_KEY=.*|JWT_PRIVATE_KEY=\"${JWT_PRIVATE}\"|" .env
            sed -i '' "s|JWT_PUBLIC_KEY=.*|JWT_PUBLIC_KEY=\"${JWT_PUBLIC}\"|" .env
            sed -i '' "s|ENCRYPTION_MASTER_KEY=.*|ENCRYPTION_MASTER_KEY=${ENC_KEY}|" .env
            sed -i '' "s|DB_PASSWORD=.*|DB_PASSWORD=${DB_PASS}|" .env
            sed -i '' "s|REDIS_PASSWORD=.*|REDIS_PASSWORD=change-me-redis-password|" .env
        else
            sed -i "s|JWT_PRIVATE_KEY=.*|JWT_PRIVATE_KEY=\"${JWT_PRIVATE}\"|" .env
            sed -i "s|JWT_PUBLIC_KEY=.*|JWT_PUBLIC_KEY=\"${JWT_PUBLIC}\"|" .env
            sed -i "s|ENCRYPTION_MASTER_KEY=.*|ENCRYPTION_MASTER_KEY=${ENC_KEY}|" .env
            sed -i "s|DB_PASSWORD=.*|DB_PASSWORD=${DB_PASS}|" .env
            sed -i "s|REDIS_PASSWORD=.*|REDIS_PASSWORD=change-me-redis-password|" .env
        fi
        
        echo -e "${GREEN}✓ .env file created with generated keys${NC}"
        echo -e "${YELLOW}⚠️  Edit .env to add your Stripe, Telegram, and email credentials${NC}"
    else
        echo -e "${YELLOW}.env already exists, skipping${NC}"
    fi
}

# Build containers
build_containers() {
    echo -e "${BLUE}[4/5] Building Docker images...${NC}"
    docker compose build --parallel 2>&1 | tail -5
    echo -e "${GREEN}✓ Docker images built${NC}"
}

# Start services
start_services() {
    echo -e "${BLUE}[5/5] Starting services...${NC}"
    docker compose up -d
    
    echo ""
    echo -e "${YELLOW}Waiting for services to be healthy...${NC}"
    sleep 20
    
    # Run database migrations
    echo -e "${BLUE}Running database migrations...${NC}"
    docker compose exec -T api-gateway npx prisma migrate deploy 2>/dev/null || echo -e "${YELLOW}Migration skipped (may need manual run)${NC}"
    
    echo ""
    echo "============================================"
    echo -e "${GREEN}   CryptoBot is running!${NC}"
    echo "============================================"
    echo ""
    echo "   Frontend:  http://localhost:3001"
    echo "   API:       http://localhost:3000/api/v1"
    echo "   Grafana:   http://localhost:3030"
    echo ""
    echo "   Stop:      docker compose down"
    echo "   Logs:      docker compose logs -f [service]"
    echo "   Status:    docker compose ps"
    echo ""
}

# Main
check_prerequisites
generate_secrets
setup_env
build_containers
start_services