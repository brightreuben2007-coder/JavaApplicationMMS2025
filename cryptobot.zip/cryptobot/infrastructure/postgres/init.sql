-- CryptoBot PostgreSQL Initialization
-- Run once when database is created

-- Enable extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- Set timezone
SET timezone = 'UTC';

-- Create indexes for performance
-- These are created by Prisma migrations, but adding explicit ones
-- for documentation and manual optimization

-- Audit logs partitioning (optional — for high volume)
-- CREATE TABLE audit_logs_partitioned (
--     LIKE "AuditLog" INCLUDING ALL
-- ) PARTITION BY RANGE (created_at);

-- Create role for read replicas (if needed)
-- CREATE ROLE cryptobot_readonly WITH LOGIN PASSWORD 'readonly-password';
-- GRANT CONNECT ON DATABASE cryptobot TO cryptobot_readonly;
-- GRANT USAGE ON SCHEMA public TO cryptobot_readonly;
-- GRANT SELECT ON ALL TABLES IN SCHEMA public TO cryptobot_readonly;

-- Vacuum settings
ALTER SYSTEM SET autovacuum = on;
ALTER SYSTEM SET autovacuum_vacuum_scale_factor = 0.01;
ALTER SYSTEM SET autovacuum_analyze_scale_factor = 0.005;

-- Output confirmation
DO $$
BEGIN
    RAISE NOTICE 'CryptoBot database initialized successfully';
END $$;