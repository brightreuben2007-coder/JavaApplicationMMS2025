import { EventEmitter } from "node:events";
import { logger } from "./utils/logger";

export type RiskLevel = "normal" | "warning" | "danger" | "critical" | "halted";

export interface RiskLimits {
  maxDailyLossPercent: number;
  maxTotalExposurePercent: number;
  drawdownPausePercent: number;
  drawdownLiquidatePercent: number;
  maxPositionSizePercent: number;
  maxLeveragePerBot: number;
  maxConcurrentBots: number;
  maxCorrelatedPairs: number;
}

export interface UserPortfolio {
  userId: string;
  totalValue: number;
  initialDailyValue: number;
  positions: PositionRisk[];
  bots: BotRisk[];
  lastUpdated: number;
}

export interface PositionRisk {
  id: string;
  pair: string;
  side: "long" | "short";
  size: number;
  entryPrice: number;
  currentPrice: number;
  unrealizedPnl: number;
  leverage: number;
  liquidationPrice: number | null;
  exchange: string;
  correlatedPairs: string[];
}

export interface BotRisk {
  botId: string;
  userId: string;
  pair: string;
  strategyType: string;
  openDeals: number;
  totalPnl: number;
  dailyPnl: number;
  leverage: number;
  status: "active" | "paused" | "stopped";
}

export interface RiskEvent {
  type: "drawdown_warning" | "drawdown_pause" | "drawdown_liquidate" | 
        "exposure_exceeded" | "position_too_large" | "correlation_risk" |
        "volatility_spike" | "liquidation_risk" | "circuit_breaker" |
        "counterparty_risk" | "daily_loss_limit";
  level: RiskLevel;
  userId: string;
  botId?: string;
  message: string;
  data: Record<string, any>;
  timestamp: number;
}

export interface CounterpartyStatus {
  exchange: string;
  status: "operational" | "maintenance" | "degraded" | "down";
  withdrawalStatus: "normal" | "delayed" | "suspended";
  insuranceFundBalance: number | null;
  lastIncident: string | null;
  lastChecked: number;
}

const DEFAULT_LIMITS: RiskLimits = {
  maxDailyLossPercent: 10,
  maxTotalExposurePercent: 200,
  drawdownPausePercent: 15,
  drawdownLiquidatePercent: 30,
  maxPositionSizePercent: 25,
  maxLeveragePerBot: 5,
  maxConcurrentBots: 20,
  maxCorrelatedPairs: 3,
};

/**
 * Risk Engine.
 * Central risk management evaluating portfolio-level and bot-level risks.
 * Implements circuit breakers that pause or liquidate positions when limits are hit.
 */
export class RiskEngine extends EventEmitter {
  private limits: Map<string, RiskLimits> = new Map();
  private defaultLimits: RiskLimits;
  private portfolios: Map<string, UserPortfolio> = new Map();
  private dailyPnL: Map<string, { startValue: number; currentValue: number; date: string }> = new Map();
  private circuitBreakers: Map<string, { level: RiskLevel; triggeredAt: number; reason: string }> = new Map();
  private counterpartyStatus: Map<string, CounterpartyStatus> = new Map();
  private riskEvents: RiskEvent[] = [];
  private maxEventsStored: number = 1000;

  constructor(defaultLimits?: Partial<RiskLimits>) {
    super();
    this.defaultLimits = { ...DEFAULT_LIMITS, ...defaultLimits };
  }

  // ============================================================
  // USER & LIMIT MANAGEMENT
  // ============================================================

  /**
   * Set custom risk limits for a user.
   */
  setUserLimits(userId: string, limits: Partial<RiskLimits>): void {
    const userLimits = this.limits.get(userId) || { ...this.defaultLimits };
    this.limits.set(userId, { ...userLimits, ...limits });
    logger.info(`Risk limits updated for user ${userId}`, limits);
  }

  /**
   * Get risk limits for a user.
   */
  getUserLimits(userId: string): RiskLimits {
    return this.limits.get(userId) || this.defaultLimits;
  }

  /**
   * Update portfolio snapshot for a user.
   */
  updatePortfolio(portfolio: UserPortfolio): void {
    const previous = this.portfolios.get(portfolio.userId);
    this.portfolios.set(portfolio.userId, portfolio);

    // Track daily PnL
    const today = new Date().toISOString().split("T")[0] || "";
    const daily = this.dailyPnL.get(portfolio.userId);

    if (!daily || daily.date !== today) {
      this.dailyPnL.set(portfolio.userId, {
        startValue: portfolio.totalValue,
        currentValue: portfolio.totalValue,
        date: today,
      });
    } else {
      daily.currentValue = portfolio.totalValue;
    }

    // Check all risk limits
    this.evaluateAllRisks(portfolio);
  }

  /**
   * Update a single bot's risk data.
   */
  updateBotRisk(bot: BotRisk): void {
    const portfolio = this.portfolios.get(bot.userId);
    if (!portfolio) return;

    const existingIdx = portfolio.bots.findIndex((b) => b.botId === bot.botId);
    if (existingIdx >= 0) {
      portfolio.bots[existingIdx] = bot;
    } else {
      portfolio.bots.push(bot);
    }

    this.updatePortfolio(portfolio);
  }

  // ============================================================
  // RISK EVALUATION
  // ============================================================

  /**
   * Evaluate all risk checks for a portfolio.
   */
  private evaluateAllRisks(portfolio: UserPortfolio): void {
    const limits = this.getUserLimits(portfolio.userId);
    const userId = portfolio.userId;

    // Skip if circuit breaker is active
    const breaker = this.circuitBreakers.get(userId);
    if (breaker?.level === "halted") return;

    // 1. Daily loss limit
    this.checkDailyLoss(portfolio, limits);

    // 2. Drawdown check
    this.checkDrawdown(portfolio, limits);

    // 3. Total exposure
    this.checkExposure(portfolio, limits);

    // 4. Position size concentration
    this.checkPositionConcentration(portfolio, limits);

    // 5. Correlation risk
    this.checkCorrelationRisk(portfolio, limits);

    // 6. Liquidation proximity
    this.checkLiquidationRisk(portfolio);

    // 7. Bot-level risks
    this.checkBotRisks(portfolio, limits);
  }

  /**
   * Check if daily loss limit is exceeded.
   */
  private checkDailyLoss(portfolio: UserPortfolio, limits: RiskLimits): void {
    const daily = this.dailyPnL.get(portfolio.userId);
    if (!daily || daily.startValue <= 0) return;

    const dailyLossPercent = ((daily.startValue - daily.currentValue) / daily.startValue) * 100;

    if (dailyLossPercent >= limits.maxDailyLossPercent) {
      this.triggerRiskEvent({
        type: "daily_loss_limit",
        level: "critical",
        userId: portfolio.userId,
        message: `Daily loss ${dailyLossPercent.toFixed(2)}% exceeds limit ${limits.maxDailyLossPercent}%`,
        data: { dailyLossPercent, limit: limits.maxDailyLossPercent, startValue: daily.startValue, currentValue: daily.currentValue },
        timestamp: Date.now(),
      });

      this.activateCircuitBreaker(portfolio.userId, "halted", `Daily loss limit: ${dailyLossPercent.toFixed(2)}%`);
    }
  }

  /**
   * Check drawdown from peak.
   */
  private checkDrawdown(portfolio: UserPortfolio, limits: RiskLimits): void {
    const peakValue = Math.max(portfolio.initialDailyValue, portfolio.totalValue);
    const drawdownPercent = peakValue > 0 
      ? ((peakValue - portfolio.totalValue) / peakValue) * 100 
      : 0;

    if (drawdownPercent >= limits.drawdownLiquidatePercent) {
      this.triggerRiskEvent({
        type: "drawdown_liquidate",
        level: "critical",
        userId: portfolio.userId,
        message: `Drawdown ${drawdownPercent.toFixed(2)}% triggers LIQUIDATION (limit: ${limits.drawdownLiquidatePercent}%)`,
        data: { drawdownPercent, peakValue, currentValue: portfolio.totalValue, limit: limits.drawdownLiquidatePercent },
        timestamp: Date.now(),
      });
      this.activateCircuitBreaker(portfolio.userId, "halted", `Drawdown liquidation: ${drawdownPercent.toFixed(2)}%`);
    } else if (drawdownPercent >= limits.drawdownPausePercent) {
      this.triggerRiskEvent({
        type: "drawdown_pause",
        level: "danger",
        userId: portfolio.userId,
        message: `Drawdown ${drawdownPercent.toFixed(2)}% triggers PAUSE (limit: ${limits.drawdownPausePercent}%)`,
        data: { drawdownPercent, peakValue, currentValue: portfolio.totalValue, limit: limits.drawdownPausePercent },
        timestamp: Date.now(),
      });
      this.activateCircuitBreaker(portfolio.userId, "danger", `Drawdown pause: ${drawdownPercent.toFixed(2)}%`);
    }
  }

  /**
   * Check total exposure relative to portfolio value.
   */
  private checkExposure(portfolio: UserPortfolio, limits: RiskLimits): void {
    const totalExposure = portfolio.positions.reduce((sum, p) => sum + Math.abs(p.size * p.currentPrice * (p.leverage || 1)), 0);
    const exposurePercent = portfolio.totalValue > 0 ? (totalExposure / portfolio.totalValue) * 100 : 0;

    if (exposurePercent > limits.maxTotalExposurePercent) {
      this.triggerRiskEvent({
        type: "exposure_exceeded",
        level: "warning",
        userId: portfolio.userId,
        message: `Total exposure ${exposurePercent.toFixed(1)}% exceeds limit ${limits.maxTotalExposurePercent}%`,
        data: { exposurePercent, totalExposure, portfolioValue: portfolio.totalValue, limit: limits.maxTotalExposurePercent },
        timestamp: Date.now(),
      });
    }
  }

  /**
   * Check if any single position is too large.
   */
  private checkPositionConcentration(portfolio: UserPortfolio, limits: RiskLimits): void {
    for (const position of portfolio.positions) {
      const positionValue = Math.abs(position.size * position.currentPrice * (position.leverage || 1));
      const positionPercent = portfolio.totalValue > 0 ? (positionValue / portfolio.totalValue) * 100 : 0;

      if (positionPercent > limits.maxPositionSizePercent) {
        this.triggerRiskEvent({
          type: "position_too_large",
          level: "warning",
          userId: portfolio.userId,
          message: `Position ${position.pair} (${positionPercent.toFixed(1)}%) exceeds max ${limits.maxPositionSizePercent}%`,
          data: { positionId: position.id, pair: position.pair, positionPercent, limit: limits.maxPositionSizePercent },
          timestamp: Date.now(),
        });
      }
    }
  }

  /**
   * Check for excessive correlation across positions.
   */
  private checkCorrelationRisk(portfolio: UserPortfolio, limits: RiskLimits): void {
    const correlationGroups: Map<string, PositionRisk[]> = new Map();

    for (const position of portfolio.positions) {
      for (const correlated of position.correlatedPairs) {
        if (!correlationGroups.has(correlated)) {
          correlationGroups.set(correlated, []);
        }
        correlationGroups.get(correlated)!.push(position);
      }
    }

    for (const [group, positions] of correlationGroups.entries()) {
      if (positions.length > limits.maxCorrelatedPairs) {
        this.triggerRiskEvent({
          type: "correlation_risk",
          level: "warning",
          userId: portfolio.userId,
          message: `${positions.length} correlated positions in group "${group}" exceeds limit ${limits.maxCorrelatedPairs}`,
          data: { group, count: positions.length, limit: limits.maxCorrelatedPairs, pairs: positions.map(p => p.pair) },
          timestamp: Date.now(),
        });
      }
    }
  }

  /**
   * Check proximity to liquidation prices.
   */
  private checkLiquidationRisk(portfolio: UserPortfolio): void {
    for (const position of portfolio.positions) {
      if (!position.liquidationPrice || position.liquidationPrice <= 0) continue;

      let distancePercent: number;
      if (position.side === "long") {
        distancePercent = ((position.currentPrice - position.liquidationPrice) / position.currentPrice) * 100;
      } else {
        distancePercent = ((position.liquidationPrice - position.currentPrice) / position.currentPrice) * 100;
      }

      if (distancePercent < 3) {
        this.triggerRiskEvent({
          type: "liquidation_risk",
          level: distancePercent < 1 ? "critical" : "danger",
          userId: portfolio.userId,
          message: `Position ${position.pair} is ${distancePercent.toFixed(1)}% from liquidation at $${position.liquidationPrice}`,
          data: { positionId: position.id, pair: position.pair, distancePercent, liquidationPrice: position.liquidationPrice, currentPrice: position.currentPrice, side: position.side },
          timestamp: Date.now(),
        });
      }
    }
  }

  /**
   * Check individual bot risks.
   */
  private checkBotRisks(portfolio: UserPortfolio, limits: RiskLimits): void {
    for (const bot of portfolio.bots) {
      if (bot.leverage > limits.maxLeveragePerBot) {
        this.triggerRiskEvent({
          type: "position_too_large",
          level: "warning",
          userId: portfolio.userId,
          botId: bot.botId,
          message: `Bot ${bot.botId} leverage ${bot.leverage}x exceeds max ${limits.maxLeveragePerBot}x`,
          data: { botId: bot.botId, leverage: bot.leverage, limit: limits.maxLeveragePerBot },
          timestamp: Date.now(),
        });
      }

      if (portfolio.bots.filter(b => b.status === "active").length > limits.maxConcurrentBots) {
        this.triggerRiskEvent({
          type: "circuit_breaker",
          level: "warning",
          userId: portfolio.userId,
          message: `${portfolio.bots.length} active bots exceeds limit ${limits.maxConcurrentBots}`,
          data: { activeBots: portfolio.bots.length, limit: limits.maxConcurrentBots },
          timestamp: Date.now(),
        });
      }
    }
  }

  // ============================================================
  // VOLATILITY DETECTION
  // ============================================================

  /**
   * Check for abnormal volatility based on recent candles.
   */
  checkVolatilitySpike(
    userId: string,
    pair: string,
    candleBodyPercent: number,
    threshold: number = 5
  ): boolean {
    if (candleBodyPercent > threshold * 1.5) {
      this.triggerRiskEvent({
        type: "volatility_spike",
        level: "danger",
        userId,
        message: `Volatility spike on ${pair}: ${candleBodyPercent.toFixed(2)}% candle body`,
        data: { pair, candleBodyPercent, threshold },
        timestamp: Date.now(),
      });
      return true;
    }

    if (candleBodyPercent > threshold) {
      this.triggerRiskEvent({
        type: "volatility_spike",
        level: "warning",
        userId,
        message: `Elevated volatility on ${pair}: ${candleBodyPercent.toFixed(2)}% candle body`,
        data: { pair, candleBodyPercent, threshold },
        timestamp: Date.now(),
      });
      return true;
    }

    return false;
  }

  // ============================================================
  // CIRCUIT BREAKERS
  // ============================================================

  /**
   * Activate a circuit breaker for a user.
   */
  private activateCircuitBreaker(userId: string, level: RiskLevel, reason: string): void {
    const existing = this.circuitBreakers.get(userId);
    if (existing && existing.level === "halted") return; // Already halted

    this.circuitBreakers.set(userId, {
      level,
      triggeredAt: Date.now(),
      reason,
    });

    this.triggerRiskEvent({
      type: "circuit_breaker",
      level,
      userId,
      message: `Circuit breaker activated: ${reason}`,
      data: { level, reason },
      timestamp: Date.now(),
    });

    logger.warn(`Circuit breaker ${level} for user ${userId}: ${reason}`);
  }

  /**
   * Release the circuit breaker for a user.
   */
  releaseCircuitBreaker(userId: string): void {
    const breaker = this.circuitBreakers.get(userId);
    if (breaker) {
      this.circuitBreakers.delete(userId);
      logger.info(`Circuit breaker released for user ${userId}`);
      this.emit("circuit_breaker:released", userId);
    }
  }

  /**
   * Check if a user's circuit breaker is active.
   */
  isCircuitBreakerActive(userId: string): { active: boolean; level: RiskLevel; reason: string } {
    const breaker = this.circuitBreakers.get(userId);
    if (!breaker) {
      return { active: false, level: "normal", reason: "" };
    }
    return { active: true, level: breaker.level, reason: breaker.reason };
  }

  /**
   * Get all active circuit breakers.
   */
  getActiveBreakers(): Array<{ userId: string; level: RiskLevel; reason: string; triggeredAt: number }> {
    return Array.from(this.circuitBreakers.entries()).map(([userId, breaker]) => ({
      userId,
      level: breaker.level,
      reason: breaker.reason,
      triggeredAt: breaker.triggeredAt,
    }));
  }

  // ============================================================
  // COUNTERPARTY MONITORING
  // ============================================================

  /**
   * Update counterparty (exchange) status.
   */
  updateCounterpartyStatus(status: CounterpartyStatus): void {
    this.counterpartyStatus.set(status.exchange, status);

    if (status.status === "down" || status.status === "maintenance") {
      this.triggerRiskEvent({
        type: "counterparty_risk",
        level: status.withdrawalStatus === "suspended" ? "critical" : "warning",
        userId: "*", // All users affected
        message: `Exchange ${status.exchange}: ${status.status}${status.withdrawalStatus === "suspended" ? " (withdrawals suspended)" : ""}`,
        data: { exchange: status.exchange, status: status.status, withdrawalStatus: status.withdrawalStatus },
        timestamp: Date.now(),
      });

      logger.warn(`Counterparty risk: ${status.exchange} ${status.status}`);
    }
  }

  /**
   * Get counterparty status for a specific exchange.
   */
  getCounterpartyStatus(exchange: string): CounterpartyStatus | null {
    return this.counterpartyStatus.get(exchange) || null;
  }

  /**
   * Get all counterparty statuses.
   */
  getAllCounterpartyStatuses(): CounterpartyStatus[] {
    return Array.from(this.counterpartyStatus.values());
  }

  /**
   * Check if an exchange is safe to trade on.
   */
  isExchangeSafe(exchange: string): boolean {
    const status = this.counterpartyStatus.get(exchange);
    if (!status) return true; // Unknown = assume safe
    return status.status === "operational" && status.withdrawalStatus !== "suspended";
  }

  // ============================================================
  // RISK EVENT MANAGEMENT
  // ============================================================

  /**
   * Record and emit a risk event.
   */
  private triggerRiskEvent(event: RiskEvent): void {
    this.riskEvents.unshift(event);

    if (this.riskEvents.length > this.maxEventsStored) {
      this.riskEvents = this.riskEvents.slice(0, this.maxEventsStored);
    }

    logger.warn(`Risk event [${event.level.toUpperCase()}]: ${event.message}`);
    this.emit("risk:event", event);
  }

  /**
   * Get recent risk events.
   */
  getRiskEvents(
    userId?: string,
    level?: RiskLevel,
    limit: number = 50,
    since?: number
  ): RiskEvent[] {
    let events = this.riskEvents;

    if (userId) {
      events = events.filter((e) => e.userId === userId || e.userId === "*");
    }
    if (level) {
      events = events.filter((e) => e.level === level);
    }
    if (since) {
      events = events.filter((e) => e.timestamp >= since);
    }

    return events.slice(0, limit);
  }

  /**
   * Get risk summary for a user.
   */
  getRiskSummary(userId: string): {
    riskLevel: RiskLevel;
    activeBreaker: boolean;
    breakerLevel: RiskLevel;
    dailyPnlPercent: number;
    totalExposurePercent: number;
    recentEvents: number;
    unsafeExchanges: string[];
  } {
    const limits = this.getUserLimits(userId);
    const portfolio = this.portfolios.get(userId);
    const breaker = this.isCircuitBreakerActive(userId);

    // Calculate daily PnL
    const daily = this.dailyPnL.get(userId);
    const dailyPnlPercent = daily && daily.startValue > 0
      ? ((daily.currentValue - daily.startValue) / daily.startValue) * 100
      : 0;

    // Calculate exposure
    const totalExposure = portfolio?.positions.reduce((sum, p) => sum + Math.abs(p.size * p.currentPrice * (p.leverage || 1)), 0) || 0;
    const totalExposurePercent = portfolio && portfolio.totalValue > 0
      ? (totalExposure / portfolio.totalValue) * 100
      : 0;

    // Determine overall risk level
    let riskLevel: RiskLevel = "normal";
    if (breaker.active && breaker.level === "halted") riskLevel = "halted";
    else if (breaker.active) riskLevel = breaker.level;
    else if (dailyPnlPercent < -limits.maxDailyLossPercent) riskLevel = "critical";
    else if (dailyPnlPercent < -limits.maxDailyLossPercent * 0.7) riskLevel = "danger";
    else if (dailyPnlPercent < -limits.maxDailyLossPercent * 0.4) riskLevel = "warning";

    // Count recent events (last hour)
    const recentEvents = this.getRiskEvents(userId, undefined, 100, Date.now() - 3600000).length;

    // Unsafe exchanges
    const unsafeExchanges = Array.from(this.counterpartyStatus.values())
      .filter((s) => s.status !== "operational" || s.withdrawalStatus === "suspended")
      .map((s) => s.exchange);

    return {
      riskLevel,
      activeBreaker: breaker.active,
      breakerLevel: breaker.level,
      dailyPnlPercent: Math.round(dailyPnlPercent * 100) / 100,
      totalExposurePercent: Math.round(totalExposurePercent * 100) / 100,
      recentEvents,
      unsafeExchanges,
    };
  }

  /**
   * Get global risk statistics.
   */
  getGlobalStats(): {
    totalUsers: number;
    totalEvents: number;
    activeBreakers: number;
    riskLevels: Record<string, number>;
    topRiskyUsers: Array<{ userId: string; riskLevel: RiskLevel; dailyPnlPercent: number }>;
  } {
    const userRiskLevels: Record<string, number> = {};
    const riskyUsers: Array<{ userId: string; riskLevel: RiskLevel; dailyPnlPercent: number }> = [];

    for (const userId of this.portfolios.keys()) {
      const summary = this.getRiskSummary(userId);
      userRiskLevels[summary.riskLevel] = (userRiskLevels[summary.riskLevel] || 0) + 1;

      if (summary.riskLevel !== "normal") {
        riskyUsers.push({ userId, riskLevel: summary.riskLevel, dailyPnlPercent: summary.dailyPnlPercent });
      }
    }

    riskyUsers.sort((a, b) => b.dailyPnlPercent - a.dailyPnlPercent);

    return {
      totalUsers: this.portfolios.size,
      totalEvents: this.riskEvents.length,
      activeBreakers: this.circuitBreakers.size,
      riskLevels: userRiskLevels,
      topRiskyUsers: riskyUsers.slice(0, 10),
    };
  }

  /**
   * Reset daily PnL tracking (called at midnight).
   */
  resetDailyTracking(): void {
    const today = new Date().toISOString().split("T")[0] || "";
    for (const [userId, portfolio] of this.portfolios.entries()) {
      this.dailyPnL.set(userId, {
        startValue: portfolio.totalValue,
        currentValue: portfolio.totalValue,
        date: today,
      });
    }
    // Release non-halted breakers
    for (const [userId, breaker] of this.circuitBreakers.entries()) {
      if (breaker.level !== "halted") {
        this.releaseCircuitBreaker(userId);
      }
    }
    logger.info("Daily risk tracking reset");
  }
}