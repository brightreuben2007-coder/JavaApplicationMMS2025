import { RiskEngine, type UserPortfolio } from "../riskEngine";

describe("Risk Engine", () => {
  let engine: RiskEngine;

  const mockPortfolio: UserPortfolio = {
    userId: "test-user-1",
    totalValue: 10000,
    initialDailyValue: 10000,
    positions: [
      {
        id: "pos-1",
        pair: "BTC/USDT",
        side: "long",
        size: 0.1,
        entryPrice: 50000,
        currentPrice: 51000,
        unrealizedPnl: 100,
        leverage: 2,
        liquidationPrice: 25000,
        exchange: "binance",
        correlatedPairs: ["ETH/USDT"],
      },
      {
        id: "pos-2",
        pair: "ETH/USDT",
        side: "long",
        size: 1,
        entryPrice: 3000,
        currentPrice: 2900,
        unrealizedPnl: -100,
        leverage: 1,
        liquidationPrice: null,
        exchange: "binance",
        correlatedPairs: ["BTC/USDT"],
      },
    ],
    bots: [
      {
        botId: "bot-1",
        userId: "test-user-1",
        pair: "BTC/USDT",
        strategyType: "dca",
        openDeals: 2,
        totalPnl: 500,
        dailyPnl: 50,
        leverage: 2,
        status: "active",
      },
    ],
    lastUpdated: Date.now(),
  };

  beforeEach(() => {
    engine = new RiskEngine();
  });

  it("should initialize with default limits", () => {
    const limits = engine.getUserLimits("any-user");
    expect(limits.maxDailyLossPercent).toBe(10);
    expect(limits.drawdownPausePercent).toBe(15);
  });

  it("should set custom user limits", () => {
    engine.setUserLimits("test-user-1", { maxDailyLossPercent: 5 });
    const limits = engine.getUserLimits("test-user-1");
    expect(limits.maxDailyLossPercent).toBe(5);
    // Other limits unchanged
    expect(limits.drawdownPausePercent).toBe(15);
  });

  it("should update portfolio without errors", () => {
    engine.updatePortfolio(mockPortfolio);
    // Should not throw
  });

  it("should detect position concentration", (done) => {
    const portfolio = {
      ...mockPortfolio,
      positions: [
        {
          ...mockPortfolio.positions[0]!,
          size: 10, // Much larger — 10 BTC = $510,000 at $51k with 2x leverage
          currentPrice: 51000,
        },
      ],
      totalValue: 10000, // $10k portfolio but $510k position with leverage
    };

    engine.once("risk:event", (event) => {
      expect(event.type).toBe("position_too_large");
      done();
    });

    engine.updatePortfolio(portfolio);
  });

  it("should trigger drawdown warning on significant loss", (done) => {
    const portfolio = {
      ...mockPortfolio,
      totalValue: 8000, // -20% from initial
      initialDailyValue: 10000,
    };

    engine.once("risk:event", (event) => {
      expect(event.type).toContain("drawdown");
      done();
    });

    engine.updatePortfolio(portfolio);
  });

  it("should trigger daily loss limit on large daily loss", (done) => {
    // First update sets the daily start value
    engine.updatePortfolio({ ...mockPortfolio, totalValue: 10000, initialDailyValue: 10000 });

    // Second update drops below -10%
    engine.once("risk:event", (event) => {
      expect(event.type).toBe("daily_loss_limit");
      expect(event.level).toBe("critical");
      done();
    });

    engine.updatePortfolio({ ...mockPortfolio, totalValue: 8900, initialDailyValue: 10000 });
  });

  it("should activate circuit breaker on critical risk", (done) => {
    engine.updatePortfolio({ ...mockPortfolio, totalValue: 10000, initialDailyValue: 10000 });

    engine.once("risk:event", (event) => {
      if (event.type === "circuit_breaker") {
        expect(event.level).toBe("halted");
        done();
      }
    });

    // Trigger daily loss limit (-10% = critical circuit breaker)
    engine.updatePortfolio({ ...mockPortfolio, totalValue: 8950, initialDailyValue: 10000 });
  });

  it("should release circuit breaker", () => {
    engine.updatePortfolio({ ...mockPortfolio, totalValue: 10000, initialDailyValue: 10000 });
    engine.updatePortfolio({ ...mockPortfolio, totalValue: 8950, initialDailyValue: 10000 });

    expect(engine.isCircuitBreakerActive("test-user-1").active).toBe(true);

    engine.releaseCircuitBreaker("test-user-1");
    expect(engine.isCircuitBreakerActive("test-user-1").active).toBe(false);
  });

  it("should detect volatility spike", () => {
    const triggered = engine.checkVolatilitySpike("test-user-1", "BTC/USDT", 8, 5);
    expect(triggered).toBe(true);
  });

  it("should not trigger on normal volatility", () => {
    const triggered = engine.checkVolatilitySpike("test-user-1", "BTC/USDT", 2, 5);
    expect(triggered).toBe(false);
  });

  it("should track counterparty status", () => {
    engine.updateCounterpartyStatus({
      exchange: "binance",
      status: "maintenance",
      withdrawalStatus: "normal",
      insuranceFundBalance: 1000000,
      lastIncident: null,
      lastChecked: Date.now(),
    });

    const status = engine.getCounterpartyStatus("binance");
    expect(status?.status).toBe("maintenance");
    expect(engine.isExchangeSafe("binance")).toBe(false);
  });

  it("should return risk summary for user", () => {
    engine.updatePortfolio(mockPortfolio);

    const summary = engine.getRiskSummary("test-user-1");
    expect(summary.riskLevel).toBeDefined();
    expect(summary.dailyPnlPercent).toBeDefined();
    expect(summary.activeBreaker).toBeDefined();
  });

  it("should get risk events filtered by user", () => {
    engine.updatePortfolio(mockPortfolio);

    const events = engine.getRiskEvents("test-user-1");
    expect(Array.isArray(events)).toBe(true);
  });

  it("should get global stats", () => {
    engine.updatePortfolio(mockPortfolio);

    const stats = engine.getGlobalStats();
    expect(stats.totalUsers).toBeGreaterThanOrEqual(1);
    expect(stats.totalEvents).toBeGreaterThanOrEqual(0);
  });

  it("should reset daily tracking", () => {
    engine.updatePortfolio(mockPortfolio);

    // Trigger a circuit breaker
    engine.updatePortfolio({ ...mockPortfolio, totalValue: 8950, initialDailyValue: 10000 });

    engine.resetDailyTracking();

    // Non-halted breakers should be released
    const activeBreakers = engine.getActiveBreakers();
    const testUserBreaker = activeBreakers.find((b) => b.userId === "test-user-1");
    expect(testUserBreaker).toBeUndefined();
  });
});