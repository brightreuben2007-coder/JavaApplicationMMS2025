import dotenv from "dotenv";
dotenv.config();

import express from "express";
import helmet from "helmet";
import promClient from "prom-client";
import Redis from "ioredis";
import { RiskEngine, type RiskLimits } from "./riskEngine";
import { logger } from "./utils/logger";

const app = express();
const PORT = parseInt(process.env.PORT || "3006", 10);
const REDIS_URL = process.env.REDIS_URL || "redis://localhost:6379";

// Metrics
const register = new promClient.Registry();
promClient.collectDefaultMetrics({ register, prefix: "risk_manager_" });

const riskEventsCounter = new promClient.Counter({
  name: "risk_manager_events_total",
  help: "Total risk events triggered",
  labelNames: ["type", "level"],
  registers: [register],
});

const activeBreakersGauge = new promClient.Gauge({
  name: "risk_manager_active_breakers",
  help: "Number of active circuit breakers",
  registers: [register],
});

const portfoliosGauge = new promClient.Gauge({
  name: "risk_manager_tracked_portfolios",
  help: "Number of portfolios being tracked",
  registers: [register],
});

// Risk engine
const riskEngine = new RiskEngine({
  maxDailyLossPercent: 10,
  maxTotalExposurePercent: 200,
  drawdownPausePercent: 15,
  drawdownLiquidatePercent: 30,
  maxPositionSizePercent: 25,
  maxLeveragePerBot: 5,
  maxConcurrentBots: 20,
  maxCorrelatedPairs: 3,
});

// Redis
const redis = new Redis(REDIS_URL, { maxRetriesPerRequest: 3 });
const publisher = redis.duplicate();

// Risk event -> Redis pub/sub
riskEngine.on("risk:event", (event) => {
  riskEventsCounter.inc({ type: event.type, level: event.level });

  publisher.publish(`alert:user:${event.userId}`, JSON.stringify({
    type: "risk_alert",
    ...event,
  })).catch((err) => logger.error("Failed to publish risk alert", { error: err.message }));

  if (event.level === "critical" || event.level === "halted") {
    publisher.publish("alert:broadcast", JSON.stringify({
      type: "critical_risk",
      ...event,
    })).catch(() => {});
  }
});

// Express setup
app.use(helmet());
app.use(express.json());

app.get("/health", (_req, res) => {
  res.json({
    status: "healthy",
    service: "risk-manager",
    trackedPortfolios: portfoliosGauge.get(),
    activeBreakers: activeBreakersGauge.get(),
    uptime: process.uptime(),
  });
});

app.get("/metrics", async (_req, res) => {
  activeBreakersGauge.set(riskEngine.getActiveBreakers().length);
  portfoliosGauge.set((riskEngine as any).portfolios.size || 0);
  res.set("Content-Type", register.contentType);
  res.end(await register.metrics());
});

// API Routes
app.get("/api/risk/summary/:userId", (req, res) => {
  const summary = riskEngine.getRiskSummary(req.params.userId);
  res.json({ success: true, data: summary });
});

app.get("/api/risk/events", (req, res) => {
  const userId = req.query.userId as string | undefined;
  const level = req.query.level as any;
  const limit = parseInt(req.query.limit as string) || 50;
  const since = req.query.since ? parseInt(req.query.since as string) : undefined;

  const events = riskEngine.getRiskEvents(userId, level, limit, since);
  res.json({ success: true, data: events });
});

app.get("/api/risk/breakers", (_req, res) => {
  const breakers = riskEngine.getActiveBreakers();
  res.json({ success: true, data: breakers });
});

app.post("/api/risk/breakers/:userId/release", (req, res) => {
  riskEngine.releaseCircuitBreaker(req.params.userId);
  res.json({ success: true, data: { message: "Circuit breaker released" } });
});

app.get("/api/risk/counterparties", (_req, res) => {
  const statuses = riskEngine.getAllCounterpartyStatuses();
  res.json({ success: true, data: statuses });
});

app.get("/api/risk/counterparties/:exchange", (req, res) => {
  const status = riskEngine.getCounterpartyStatus(req.params.exchange);
  if (!status) {
    res.status(404).json({ success: false, error: { message: "Exchange not found" } });
    return;
  }
  res.json({ success: true, data: status });
});

app.post("/api/risk/limits/:userId", (req, res) => {
  riskEngine.setUserLimits(req.params.userId, req.body as Partial<RiskLimits>);
  res.json({ success: true, data: riskEngine.getUserLimits(req.params.userId) });
});

app.get("/api/risk/limits/:userId", (req, res) => {
  const limits = riskEngine.getUserLimits(req.params.userId);
  res.json({ success: true, data: limits });
});

app.get("/api/risk/global", (_req, res) => {
  const stats = riskEngine.getGlobalStats();
  res.json({ success: true, data: stats });
});

// Redis listener for external risk triggers
async function setupRedisListeners(): Promise<void> {
  const subscriber = redis.duplicate();

  subscriber.subscribe("risk:portfolio:update", "risk:volatility:check", "risk:counterparty:update");

  subscriber.on("message", (channel, message) => {
    try {
      const data = JSON.parse(message);

      switch (channel) {
        case "risk:portfolio:update":
          riskEngine.updatePortfolio(data);
          break;

        case "risk:volatility:check":
          riskEngine.checkVolatilitySpike(
            data.userId,
            data.pair,
            data.candleBodyPercent,
            data.threshold
          );
          break;

        case "risk:counterparty:update":
          riskEngine.updateCounterpartyStatus(data);
          break;
      }
    } catch (error) {
      logger.error("Failed to process risk message", { channel, error });
    }
  });

  logger.info("Risk manager Redis listeners active");
}

// Start server
app.listen(PORT, async () => {
  await setupRedisListeners();
  logger.info(`Risk Manager started on port ${PORT}`);
});

// Daily reset at midnight
const scheduleMidnightReset = () => {
  const now = new Date();
  const msUntilMidnight = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1).getTime() - now.getTime();

  setTimeout(() => {
    riskEngine.resetDailyTracking();
    scheduleMidnightReset(); // Recur
  }, msUntilMidnight);
};

scheduleMidnightReset();

// Graceful shutdown
process.on("SIGTERM", async () => {
  logger.info("Shutting down risk manager...");
  await redis.quit();
  await publisher.quit();
  process.exit(0);
});

process.on("SIGINT", async () => {
  await redis.quit();
  await publisher.quit();
  process.exit(0);
});