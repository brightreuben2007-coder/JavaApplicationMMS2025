import { OrderBookManager } from "../orderBookManager";

describe("OrderBook Manager", () => {
  let manager: OrderBookManager;

  beforeEach(() => {
    manager = new OrderBookManager();
  });

  it("should apply snapshot and retrieve order book", () => {
    manager.applySnapshot("binance", "BTC/USDT", {
      symbol: "BTC/USDT",
      bids: [
        { price: 50000, quantity: 1.5 },
        { price: 49900, quantity: 2.0 },
        { price: 49800, quantity: 0.5 },
      ],
      asks: [
        { price: 50100, quantity: 1.0 },
        { price: 50200, quantity: 1.5 },
        { price: 50300, quantity: 3.0 },
      ],
      timestamp: Date.now(),
      exchange: "binance",
    });

    const ob = manager.getOrderBook("binance", "BTC/USDT");
    expect(ob).not.toBeNull();
    expect(ob?.bids.length).toBe(3);
    expect(ob?.asks.length).toBe(3);
    expect(ob?.bids[0]?.price).toBe(50000);
    expect(ob?.asks[0]?.price).toBe(50100);
  });

  it("should apply delta updates", () => {
    manager.applySnapshot("binance", "BTC/USDT", {
      symbol: "BTC/USDT",
      bids: [{ price: 50000, quantity: 1.0 }],
      asks: [{ price: 50100, quantity: 1.0 }],
      timestamp: Date.now(),
      exchange: "binance",
    });

    // Apply delta: update bid, remove ask, add new ask
    const success = manager.applyDelta("binance", "BTC/USDT",
      [{ price: 50000, quantity: 2.0 }], // Increased bid
      [{ price: 50100, quantity: 0 }, { price: 50200, quantity: 1.5 }] // Remove 50100, add 50200
    );

    expect(success).toBe(true);

    const ob = manager.getOrderBook("binance", "BTC/USDT");
    expect(ob?.bids[0]?.quantity).toBe(2.0);
    expect(ob?.asks.length).toBe(1); // Only 50200 remains
    expect(ob?.asks[0]?.price).toBe(50200);
  });

  it("should return false for delta on unknown pair", () => {
    const success = manager.applyDelta("binance", "unknown", [], []);
    expect(success).toBe(false);
  });

  it("should calculate mid price", () => {
    manager.applySnapshot("binance", "BTC/USDT", {
      symbol: "BTC/USDT",
      bids: [{ price: 50000, quantity: 1.0 }],
      asks: [{ price: 50100, quantity: 1.0 }],
      timestamp: Date.now(),
      exchange: "binance",
    });

    const mid = manager.getMidPrice("binance", "BTC/USDT");
    expect(mid).toBe(50050);
  });

  it("should calculate spread", () => {
    manager.applySnapshot("binance", "BTC/USDT", {
      symbol: "BTC/USDT",
      bids: [{ price: 50000, quantity: 1.0 }],
      asks: [{ price: 50100, quantity: 1.0 }],
      timestamp: Date.now(),
      exchange: "binance",
    });

    const spread = manager.getSpread("binance", "BTC/USDT");
    expect(spread?.absolute).toBe(100);
    expect(spread?.percent).toBeCloseTo(0.2, 1);
  });

  it("should detect stale order book", () => {
    manager.applySnapshot("binance", "BTC/USDT", {
      symbol: "BTC/USDT",
      bids: [{ price: 50000, quantity: 1.0 }],
      asks: [{ price: 50100, quantity: 1.0 }],
      timestamp: Date.now() - 120000,
      exchange: "binance",
    });

    expect(manager.needsSnapshot("binance", "BTC/USDT", 60000)).toBe(true);
  });
});