import { PriceAggregator } from "../priceAggregator";

describe("Price Aggregator", () => {
  let aggregator: PriceAggregator;

  beforeEach(() => {
    aggregator = new PriceAggregator();
  });

  it("should calculate VWAP across exchanges", () => {
    aggregator.updatePrice("binance", "BTC/USDT", 49900, 50100, 50000, 1000);
    aggregator.updatePrice("bybit", "BTC/USDT", 49800, 50200, 50100, 500);

    const vwap = aggregator.getVWAP("BTC/USDT");
    expect(vwap).not.toBeNull();
    expect(vwap?.exchanges).toBe(2);
    // VWAP = (50000 * 1000 + 50100 * 500) / 1500 = 50033.33
    expect(vwap?.price).toBeCloseTo(50033.33, 1);
  });

  it("should find best bid", () => {
    aggregator.updatePrice("binance", "BTC/USDT", 49900, 50100, 50000, 1000);
    aggregator.updatePrice("kraken", "BTC/USDT", 49950, 50050, 50000, 500);

    const best = aggregator.getBestBid("BTC/USDT");
    expect(best?.exchange).toBe("kraken");
    expect(best?.price).toBe(49950);
  });

  it("should find best ask", () => {
    aggregator.updatePrice("binance", "BTC/USDT", 49900, 50100, 50000, 1000);
    aggregator.updatePrice("kraken", "BTC/USDT", 49950, 50050, 50000, 500);

    const best = aggregator.getBestAsk("BTC/USDT");
    expect(best?.exchange).toBe("kraken");
    expect(best?.price).toBe(50050);
  });

  it("should clean stale prices", () => {
    // Set a price with old timestamp by directly accessing the map
    const pairMap = (aggregator as any).prices;
    pairMap.set("BTC/USDT", new Map());
    pairMap.get("BTC/USDT").set("binance", {
      exchange: "binance",
      bid: 50000,
      ask: 50100,
      last: 50050,
      volume24h: 100,
      timestamp: Date.now() - 120000,
    });

    aggregator.cleanStalePrices(60000);
    const prices = aggregator.getPrices("BTC/USDT");
    expect(prices.length).toBe(0);
  });
});