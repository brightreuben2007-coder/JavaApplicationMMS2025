import { OHLVCAggregator } from "../ohlcvAggregator";

describe("OHLCV Aggregator", () => {
  let aggregator: OHLVCAggregator;

  beforeEach(() => {
    aggregator = new OHLVCAggregator();
  });

  it("should build 1m candle from trades", (done) => {
    const pair = "BTC/USDT";
    const baseTime = 1700000000000;

    aggregator.on("candle", (p: string, tf: string, candle: any) => {
      expect(p).toBe(pair);
      expect(tf).toBe("1m");
      expect(candle.open).toBe(50000);
      expect(candle.high).toBe(50100);
      expect(candle.low).toBe(49900);
      expect(candle.close).toBe(50050);
      done();
    });

    aggregator.processTrade(pair, 50000, 0.1, baseTime);
    aggregator.processTrade(pair, 50100, 0.2, baseTime + 1000);
    aggregator.processTrade(pair, 49900, 0.15, baseTime + 2000);
    aggregator.processTrade(pair, 50050, 0.05, baseTime + 60001); // Next minute triggers completion
  });

  it("should aggregate 1m into 5m candles", (done) => {
    const pair = "ETH/USDT";
    const baseTime = 1700000000000;

    let fiveMinCandles = 0;

    aggregator.on("candle", (_p: string, tf: string, candle: any) => {
      if (tf === "5m") {
        fiveMinCandles++;
        if (fiveMinCandles === 1) {
          expect(candle.volume).toBeGreaterThan(0);
          done();
        }
      }
    });

    // Feed 5 one-minute candles
    for (let i = 0; i < 5; i++) {
      aggregator.processOHLCV(pair, "1m", {
        timestamp: baseTime + i * 60000,
        open: 3000 + i,
        high: 3005 + i,
        low: 2995 + i,
        close: 3002 + i,
        volume: 10,
      });
    }
  });

  it("should store and retrieve candles", () => {
    const pair = "SOL/USDT";

    aggregator.processOHLCV(pair, "1m", {
      timestamp: Date.now(),
      open: 100,
      high: 105,
      low: 99,
      close: 102,
      volume: 50,
    });

    const candles = aggregator.getCandles(pair, "1m", 10);
    expect(candles.length).toBeGreaterThan(0);
    expect(candles[0]?.close).toBe(102);
  });

  it("should return null for unknown pair", () => {
    const candle = aggregator.getLatestCandle("unknown", "1m");
    expect(candle).toBeNull();
  });
});