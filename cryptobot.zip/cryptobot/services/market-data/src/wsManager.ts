import { EventEmitter } from "node:events";
import { ExchangeAdapter } from "./adapters/exchange.adapter";
import { BinanceAdapter } from "./adapters/binance.adapter";
import { BybitAdapter } from "./adapters/bybit.adapter";
import { KrakenAdapter } from "./adapters/kraken.adapter";
import { CoinbaseAdapter } from "./adapters/coinbase.adapter";
import { KucoinAdapter } from "./adapters/kucoin.adapter";
import type { Ticker, OHLCV, OrderBook, TradeTick, FundingRate } from "./adapters/exchange.adapter";
import { logger } from "./utils/logger";

interface Subscription {
  exchange: string;
  pair: string;
  type: "ticker" | "orderbook" | "trades" | "candles";
  timeframe?: string;
  depth?: number;
  userId?: string;
}

export type { Ticker, OHLCV, OrderBook, TradeTick, FundingRate };

/**
 * WebSocket Manager.
 * Manages connections to multiple exchanges and routes data to subscribers.
 */
export class WebSocketManager extends EventEmitter {
  private adapters: Map<string, ExchangeAdapter> = new Map();
  private subscriptions: Map<string, Set<Subscription>> = new Map();
  private isRunning: boolean = false;

  constructor() {
    super();
  }

  /**
   * Initialize exchange adapters.
   */
  async initialize(): Promise<void> {
    // Binance Spot
    const binanceAdapter = new BinanceAdapter(false);
    this.setupAdapterEvents(binanceAdapter);
    this.adapters.set("binance", binanceAdapter);

    // Binance Futures
    const binanceFuturesAdapter = new BinanceAdapter(true);
    this.setupAdapterEvents(binanceFuturesAdapter);
    this.adapters.set("binance-futures", binanceFuturesAdapter);

    // Bybit Spot
    const bybitAdapter = new BybitAdapter("spot");
    this.setupAdapterEvents(bybitAdapter);
    this.adapters.set("bybit", bybitAdapter);

    // Bybit Linear (USDT perpetuals)
    const bybitLinearAdapter = new BybitAdapter("linear");
    this.setupAdapterEvents(bybitLinearAdapter);
    this.adapters.set("bybit-linear", bybitLinearAdapter);

    // Kraken
    const krakenAdapter = new KrakenAdapter();
    this.setupAdapterEvents(krakenAdapter);
    this.adapters.set("kraken", krakenAdapter);

    // Coinbase
    const coinbaseAdapter = new CoinbaseAdapter();
    this.setupAdapterEvents(coinbaseAdapter);
    this.adapters.set("coinbase", coinbaseAdapter);

    // KuCoin
    const kucoinAdapter = new KucoinAdapter();
    this.setupAdapterEvents(kucoinAdapter);
    this.adapters.set("kucoin", kucoinAdapter);

    logger.info(`Initialized ${this.adapters.size} exchange adapters: ${Array.from(this.adapters.keys()).join(", ")}`);
  }

  private setupAdapterEvents(adapter: ExchangeAdapter): void {
    adapter.on("onTicker", (ticker: Ticker) => {
      this.emit("ticker", adapter.getExchangeId(), ticker);
    });

    adapter.on("onCandle", (candle: OHLCV) => {
      this.emit("candle", adapter.getExchangeId(), candle);
    });

    adapter.on("onOrderBook", (orderBook: OrderBook) => {
      this.emit("orderbook", adapter.getExchangeId(), orderBook);
    });

    adapter.on("onTrade", (trade: TradeTick) => {
      this.emit("trade", adapter.getExchangeId(), trade);
    });

    adapter.on("onConnected", () => {
      logger.info(`${adapter.getExchangeId()} connected`);
      this.emit("exchange:connected", adapter.getExchangeId());
    });

    adapter.on("onDisconnected", (reason: string) => {
      logger.warn(`${adapter.getExchangeId()} disconnected: ${reason}`);
      this.emit("exchange:disconnected", adapter.getExchangeId(), reason);
    });

    adapter.on("onError", (error: Error) => {
      logger.error(`${adapter.getExchangeId()} error: ${error.message}`);
      this.emit("exchange:error", adapter.getExchangeId(), error);
    });
  }

  async connectAll(): Promise<void> {
    this.isRunning = true;
    const connectPromises: Promise<void>[] = [];

    for (const [name, adapter] of this.adapters.entries()) {
      connectPromises.push(
        adapter.connect().catch((error) => {
          logger.error(`Failed to connect to ${name}: ${error.message}`);
        })
      );
    }

    await Promise.allSettled(connectPromises);
    logger.info(`Connected to exchanges: ${Array.from(this.adapters.entries()).filter(([, a]) => a.isExchangeConnected()).map(([n]) => n).join(", ")}`);
  }

  async disconnectAll(): Promise<void> {
    this.isRunning = false;
    const disconnectPromises: Promise<void>[] = [];

    for (const adapter of this.adapters.values()) {
      disconnectPromises.push(adapter.disconnect());
    }

    await Promise.allSettled(disconnectPromises);
    logger.info("All exchange connections closed");
  }

  async subscribeTicker(exchange: string, pair: string): Promise<void> {
    const adapter = this.getAdapter(exchange);
    await adapter.subscribeTicker(pair);
    this.addSubscription({ exchange, pair, type: "ticker" });
  }

  async subscribeOrderBook(exchange: string, pair: string, depth: number = 20): Promise<void> {
    const adapter = this.getAdapter(exchange);
    await adapter.subscribeOrderBook(pair, depth);
    this.addSubscription({ exchange, pair, type: "orderbook", depth });
  }

  async subscribeTrades(exchange: string, pair: string): Promise<void> {
    const adapter = this.getAdapter(exchange);
    await adapter.subscribeTrades(pair);
    this.addSubscription({ exchange, pair, type: "trades" });
  }

  async subscribeCandles(exchange: string, pair: string, timeframe: string): Promise<void> {
    const adapter = this.getAdapter(exchange);
    await adapter.subscribeCandles(pair, timeframe);
    this.addSubscription({ exchange, pair, type: "candles", timeframe });
  }

  async unsubscribeTicker(exchange: string, pair: string): Promise<void> {
    const adapter = this.getAdapter(exchange);
    await adapter.unsubscribeTicker(pair);
    this.removeSubscription({ exchange, pair, type: "ticker" });
  }

  async fetchHistoricalOHLCV(exchange: string, pair: string, timeframe: string, since?: number, limit?: number): Promise<OHLCV[]> {
    const adapter = this.getAdapter(exchange);
    return adapter.fetchHistoricalOHLCV(pair, timeframe, since, limit);
  }

  async fetchTicker(exchange: string, pair: string): Promise<Ticker> {
    const adapter = this.getAdapter(exchange);
    return adapter.fetchTicker(pair);
  }

  private getAdapter(exchange: string): ExchangeAdapter {
    const adapter = this.adapters.get(exchange);
    if (adapter) return adapter;

    const availableExchanges = Array.from(this.adapters.keys()).join(", ");
    throw new Error(`No adapter found for exchange: "${exchange}". Available: ${availableExchanges}`);
  }

  private addSubscription(sub: Subscription): void {
    const key = this.subscriptionKey(sub);
    if (!this.subscriptions.has(key)) {
      this.subscriptions.set(key, new Set());
    }
    this.subscriptions.get(key)!.add(sub);
  }

  private removeSubscription(sub: Subscription): void {
    const key = this.subscriptionKey(sub);
    this.subscriptions.delete(key);
  }

  private subscriptionKey(sub: Subscription): string {
    return `${sub.exchange}:${sub.pair}:${sub.type}${sub.timeframe ? ":" + sub.timeframe : ""}`;
  }

  getActiveSubscriptions(): { exchange: string; pair: string; type: string }[] {
    const subs: { exchange: string; pair: string; type: string }[] = [];
    for (const [key] of this.subscriptions.entries()) {
      const parts = key.split(":");
      if (parts.length >= 3) {
        subs.push({
          exchange: parts[0] || "",
          pair: parts[1] || "",
          type: parts[2] || "",
        });
      }
    }
    return subs;
  }

  getConnectionStatus(): Record<string, boolean> {
    const status: Record<string, boolean> = {};
    for (const [name, adapter] of this.adapters.entries()) {
      status[name] = adapter.isExchangeConnected();
    }
    return status;
  }
}