import dotenv from "dotenv";
dotenv.config();

import express from "express";
import helmet from "helmet";
import promClient from "prom-client";
import Redis from "ioredis";
import { WebSocketManager } from "./wsManager";
import { OHLVCAggregator } from "./ohlcvAggregator";
import { OrderBookManager } from "./orderBookManager";
import { PriceAggregator } from "./priceAggregator";
import { logger } from "./utils/logger";

const app = express();
const PORT = parseInt(process.env.PORT || "3004", 10);
const REDIS_URL = process.env.REDIS_URL || "redis://localhost:6379";

// Metrics
const register = new promClient.Registry();
promClient.collectDefaultMetrics({ register, prefix: "market_data_" });

const tickerCounter = new promClient.Counter({
  name: "market_data_tickers_total",
  help: "Total ticker updates received",
  labelNames: ["exchange"],
  registers: [register],
});

const candleCounter = new promClient.Counter({
  name: "market_data_candles_total",
  help: "Total candle updates received",
  labelNames: ["exchange", "timeframe"],
  registers: [register],
});

const activeSubscriptions = new promClient.Gauge({
  name: "market_data_active_subscriptions",
  help: "Number of active market data subscriptions",
  registers: [register],
});

// Core services
const wsManager = new WebSocketManager();
const ohlcvAggregator = new OHLVCAggregator();
const orderBookManager = new OrderBookManager();
const priceAggregator = new PriceAggregator();

// Redis
const redis = new Redis(REDIS_URL, { maxRetriesPerRequest: 3 });
const publisher = redis.duplicate();

// Express
app.use(helmet());
app.use(express.json());

app.get("/health", (_req, res) => {
  res.json({
    status: "healthy",
    service: "market-data",
    connections: wsManager.getConnectionStatus(),
    subscriptions: wsManager.getActiveSubscriptions().length,
    uptime: process.uptime(),
  });
});

app.get("/metrics", async (_req, res) => {
  activeSubscriptions.set(wsManager.getActiveSubscriptions().length);
  res.set("Content-Type", register.contentType);
  res.end(await register.metrics());
});

// REST API for historical data
app.get("/api/candles/:exchange/:pair/:timeframe", async (req, res) => {
  try {
    const { exchange, pair, timeframe } = req.params;
    const since = req.query.since ? parseInt(req.query.since as string) : undefined;
    const limit = req.query.limit ? parseInt(req.query.limit as string) : 100;

    const candles = await wsManager.fetchHistoricalOHLCV(exchange, pair, timeframe, since, limit);
    res.json({ success: true, data: candles });
  } catch (error) {
    res.status(500).json({ success: false, error: { message: (error as Error).message } });
  }
});

app.get("/api/ticker/:exchange/:pair", async (req, res) => {
  try {
    const { exchange, pair } = req.params;
    const ticker = await wsManager.fetchTicker(exchange, pair);
    res.json({ success: true, data: ticker });
  } catch (error) {
    res.status(500).json({ success: false, error: { message: (error as Error).message } });
  }
});

// Setup market data pipeline
function setupMarketDataPipeline(): void {
  // When ticker received, publish to Redis and update price aggregator
  wsManager.on("ticker", (exchange: string, ticker: any) => {
    tickerCounter.inc({ exchange });

    const channel = `market:${exchange}:${ticker.symbol}:ticker`;
    publisher.publish(channel, JSON.stringify({
      ...ticker,
      timestamp: Date.now(),
    })).catch(err => logger.error("Redis publish error", { error: err.message }));

    // Update price aggregator
    priceAggregator.updatePrice(exchange, ticker.symbol, ticker.bid, ticker.ask, ticker.last, ticker.volume24h);

    // Cache in Redis
    redis.setex(`cache:${channel}`, 10, JSON.stringify(ticker)).catch(() => {});
  });

  // When candle received, process through OHLCV aggregator and publish
  wsManager.on("candle", (exchange: string, candle: any) => {
    // OHLCV aggregator builds higher timeframes
    ohlcvAggregator.processOHLCV(candle.symbol || "unknown", "1m", candle);
  });

  ohlcvAggregator.on("candle", (pair: string, timeframe: string, candle: any) => {
    candleCounter.inc({ exchange: "aggregated", timeframe });

    const channel = `candles:binance:${pair}:${timeframe}`;
    publisher.publish(channel, JSON.stringify(candle)).catch(() => {});

    // Cache latest candles
    redis.setex(`cache:${channel}`, timeframe === "1m" ? 120 : 3600, JSON.stringify(candle)).catch(() => {});
  });

  // When order book received, update order book manager and publish
  wsManager.on("orderbook", (exchange: string, orderBook: any) => {
    orderBookManager.applySnapshot(exchange, orderBook.symbol, orderBook);

    const channel = `market:${exchange}:${orderBook.symbol}:orderbook`;
    publisher.publish(channel, JSON.stringify(orderBook)).catch(() => {});

    redis.setex(`cache:${channel}`, 5, JSON.stringify(orderBook)).catch(() => {});
  });

  // When trade received, publish to Redis
  wsManager.on("trade", (exchange: string, trade: any) => {
    const channel = `market:${exchange}:${trade.symbol || "unknown"}:trades`;
    publisher.publish(channel, JSON.stringify(trade)).catch(() => {});
  });
}

// Start server
async function start(): Promise<void> {
  try {
    await wsManager.initialize();
    setupMarketDataPipeline();
    await wsManager.connectAll();

    app.listen(PORT, () => {
      logger.info(`Market Data Service started on port ${PORT}`);
      logger.info(`Connected exchanges: ${Object.keys(wsManager.getConnectionStatus()).join(", ")}`);
    });
  } catch (error) {
    logger.error("Failed to start Market Data Service", { error });
    process.exit(1);
  }
}

// Graceful shutdown
const shutdown = async (signal: string) => {
  logger.info(`Received ${signal}. Shutting down...`);
  await wsManager.disconnectAll();
  await redis.quit();
  await publisher.quit();
  process.exit(0);
};

process.on("SIGTERM", () => shutdown("SIGTERM"));
process.on("SIGINT", () => shutdown("SIGINT"));

start();