import { EventEmitter } from "node:events";
import type { OHLCV } from "./adapters/exchange.adapter";
import { logger } from "./utils/logger";

interface CandleBuilder {
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
  startTimestamp: number;
  trades: number;
}

const TIMEFRAME_MS: Record<string, number> = {
  "1m": 60000,
  "5m": 300000,
  "15m": 900000,
  "1h": 3600000,
  "4h": 14400000,
  "1d": 86400000,
  "1w": 604800000,
};

const TIMEFRAME_SOURCES: Record<string, string> = {
  "5m": "1m",
  "15m": "5m",
  "1h": "15m",
  "4h": "1h",
  "1d": "4h",
  "1w": "1d",
};

/**
 * OHLCV Aggregator.
 * Builds candles from trades and aggregates lower timeframes into higher ones.
 */
export class OHLVCAggregator extends EventEmitter {
  private candles: Map<string, CandleBuilder> = new Map();
  private completedCandles: Map<string, OHLCV[]> = new Map();
  private maxStoredCandles: number = 1000;

  /**
   * Process a trade tick and update the 1-minute candle.
   */
  processTrade(pair: string, price: number, quantity: number, timestamp: number): void {
    const minuteStart = Math.floor(timestamp / 60000) * 60000;
    const key = `${pair}:1m:${minuteStart}`;

    let candle = this.candles.get(key);

    if (!candle) {
      candle = {
        open: price,
        high: price,
        low: price,
        close: price,
        volume: 0,
        startTimestamp: minuteStart,
        trades: 0,
      };
      this.candles.set(key, candle);
    }

    candle.high = Math.max(candle.high, price);
    candle.low = Math.min(candle.low, price);
    candle.close = price;
    candle.volume += quantity;
    candle.trades++;

    // Check if candle is complete
    if (timestamp >= minuteStart + 60000) {
      this.completeCandle(pair, "1m", key, candle);
    }
  }

  /**
   * Process a 1-minute OHLCV candle and build higher timeframes.
   */
  processOHLCV(pair: string, timeframe: string, candle: OHLCV): void {
    // Store completed candle
    this.storeCandle(pair, timeframe, candle);

    // Build higher timeframe if applicable
    const higherTF = Object.entries(TIMEFRAME_SOURCES).find(([, src]) => src === timeframe)?.[0];
    if (higherTF) {
      this.aggregateToHigherTF(pair, higherTF, candle);
    }

    this.emit("candle", pair, timeframe, candle);
  }

  /**
   * Aggregate a candle into a higher timeframe.
   */
  private aggregateToHigherTF(pair: string, higherTF: string, candle: OHLCV): void {
    const tfMs = TIMEFRAME_MS[higherTF] || 3600000;
    const periodStart = Math.floor(candle.timestamp / tfMs) * tfMs;
    const key = `${pair}:${higherTF}:${periodStart}`;

    let building = this.candles.get(key);

    if (!building) {
      building = {
        open: candle.open,
        high: candle.high,
        low: candle.low,
        close: candle.close,
        volume: candle.volume,
        startTimestamp: periodStart,
        trades: 0,
      };
      this.candles.set(key, building);
    } else {
      building.high = Math.max(building.high, candle.high);
      building.low = Math.min(building.low, candle.low);
      building.close = candle.close;
      building.volume += candle.volume;
      building.trades++;
    }

    // Check if higher timeframe candle is complete
    if (candle.timestamp >= periodStart + tfMs) {
      this.completeCandle(pair, higherTF, key, building);
    }
  }

  /**
   * Finalize a candle and emit it.
   */
  private completeCandle(pair: string, timeframe: string, key: string, builder: CandleBuilder): void {
    const completed: OHLCV = {
      timestamp: builder.startTimestamp,
      open: builder.open,
      high: builder.high,
      low: builder.low,
      close: builder.close,
      volume: builder.volume,
    };

    this.storeCandle(pair, timeframe, completed);
    this.candles.delete(key);

    this.emit("candle", pair, timeframe, completed);
  }

  /**
   * Store a completed candle in memory.
   */
  private storeCandle(pair: string, timeframe: string, candle: OHLCV): void {
    const key = `${pair}:${timeframe}`;
    if (!this.completedCandles.has(key)) {
      this.completedCandles.set(key, []);
    }

    const candles = this.completedCandles.get(key)!;
    candles.push(candle);

    // Trim to max size
    if (candles.length > this.maxStoredCandles) {
      candles.splice(0, candles.length - this.maxStoredCandles);
    }
  }

  /**
   * Get stored candles for a pair and timeframe.
   */
  getCandles(pair: string, timeframe: string, limit: number = 100): OHLCV[] {
    const key = `${pair}:${timeframe}`;
    const candles = this.completedCandles.get(key) || [];
    return candles.slice(-limit);
  }

  /**
   * Get the latest candle for a pair and timeframe.
   */
  getLatestCandle(pair: string, timeframe: string): OHLCV | null {
    const candles = this.getCandles(pair, timeframe, 1);
    return candles[0] || null;
  }
}