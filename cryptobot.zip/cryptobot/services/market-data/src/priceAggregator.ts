import { logger } from "./utils/logger";

interface ExchangePrice {
  exchange: string;
  bid: number;
  ask: number;
  last: number;
  volume24h: number;
  timestamp: number;
}

/**
 * Price Aggregator.
 * Aggregates prices across multiple exchanges and calculates
 * volume-weighted average price (VWAP).
 */
export class PriceAggregator {
  private prices: Map<string, Map<string, ExchangePrice>> = new Map();

  /**
   * Update price data for a pair on an exchange.
   */
  updatePrice(
    exchange: string,
    pair: string,
    bid: number,
    ask: number,
    last: number,
    volume24h: number
  ): void {
    if (!this.prices.has(pair)) {
      this.prices.set(pair, new Map());
    }

    this.prices.get(pair)!.set(exchange, {
      exchange,
      bid,
      ask,
      last,
      volume24h,
      timestamp: Date.now(),
    });
  }

  /**
   * Get the volume-weighted average price across all exchanges.
   */
  getVWAP(pair: string): { price: number; totalVolume: number; exchanges: number } | null {
    const exchangePrices = this.prices.get(pair);
    if (!exchangePrices || exchangePrices.size === 0) return null;

    let totalWeightedPrice = 0;
    let totalVolume = 0;

    const validPrices = Array.from(exchangePrices.values()).filter(
      (p) => p.volume24h > 0 && Date.now() - p.timestamp < 60000
    );

    if (validPrices.length === 0) return null;

    for (const price of validPrices) {
      totalWeightedPrice += price.last * price.volume24h;
      totalVolume += price.volume24h;
    }

    return {
      price: totalVolume > 0 ? totalWeightedPrice / totalVolume : validPrices[0]?.last || 0,
      totalVolume,
      exchanges: validPrices.length,
    };
  }

  /**
   * Get the best bid across all exchanges.
   */
  getBestBid(pair: string): { exchange: string; price: number; volume: number } | null {
    const exchangePrices = this.prices.get(pair);
    if (!exchangePrices) return null;

    let best: { exchange: string; price: number; volume: number } | null = null;

    for (const [exchange, price] of exchangePrices.entries()) {
      if (!best || price.bid > best.price) {
        best = { exchange, price: price.bid, volume: price.volume24h };
      }
    }

    return best;
  }

  /**
   * Get the best ask across all exchanges.
   */
  getBestAsk(pair: string): { exchange: string; price: number; volume: number } | null {
    const exchangePrices = this.prices.get(pair);
    if (!exchangePrices) return null;

    let best: { exchange: string; price: number; volume: number } | null = null;

    for (const [exchange, price] of exchangePrices.entries()) {
      if (!best || price.ask < best.price) {
        best = { exchange, price: price.ask, volume: price.volume24h };
      }
    }

    return best;
  }

  /**
   * Get all prices for a pair.
   */
  getPrices(pair: string): ExchangePrice[] {
    const exchangePrices = this.prices.get(pair);
    if (!exchangePrices) return [];
    return Array.from(exchangePrices.values());
  }

  /**
   * Clean stale prices (older than maxAgeMs).
   */
  cleanStalePrices(maxAgeMs: number = 60000): void {
    const now = Date.now();
    for (const [pair, exchangePrices] of this.prices.entries()) {
      for (const [exchange, price] of exchangePrices.entries()) {
        if (now - price.timestamp > maxAgeMs) {
          exchangePrices.delete(exchange);
        }
      }
      if (exchangePrices.size === 0) {
        this.prices.delete(pair);
      }
    }
  }
}