import { EventEmitter } from "node:events";
import type { OrderBook, OrderBookLevel } from "./adapters/exchange.adapter";
import { logger } from "./utils/logger";

interface OrderBookState {
  bids: Map<number, number>;
  asks: Map<number, number>;
  lastUpdateId: number;
  timestamp: number;
}

/**
 * Order Book Manager.
 * Maintains local L2 order book snapshots with delta updates.
 * Validates checksums and requests new snapshots on sequence gaps.
 */
export class OrderBookManager extends EventEmitter {
  private orderBooks: Map<string, OrderBookState> = new Map();
  private maxDepth: number = 50;

  /**
   * Apply a snapshot to initialize the order book.
   */
  applySnapshot(exchange: string, pair: string, orderBook: OrderBook): void {
    const key = `${exchange}:${pair}`;
    const state: OrderBookState = {
      bids: new Map(),
      asks: new Map(),
      lastUpdateId: 0,
      timestamp: orderBook.timestamp,
    };

    for (const bid of orderBook.bids) {
      if (bid.quantity > 0) {
        state.bids.set(bid.price, bid.quantity);
      }
    }

    for (const ask of orderBook.asks) {
      if (ask.quantity > 0) {
        state.asks.set(ask.price, ask.quantity);
      }
    }

    this.orderBooks.set(key, state);

    logger.debug(`Order book snapshot applied for ${key}: ${state.bids.size} bids, ${state.asks.size} asks`);
  }

  /**
   * Apply a delta update to the order book.
   */
  applyDelta(exchange: string, pair: string, bids: OrderBookLevel[], asks: OrderBookLevel[]): boolean {
    const key = `${exchange}:${pair}`;
    const state = this.orderBooks.get(key);

    if (!state) {
      logger.warn(`No order book snapshot for ${key}, requesting full snapshot`);
      return false;
    }

    // Update bids
    for (const bid of bids) {
      if (bid.quantity === 0) {
        state.bids.delete(bid.price);
      } else {
        state.bids.set(bid.price, bid.quantity);
      }
    }

    // Update asks
    for (const ask of asks) {
      if (ask.quantity === 0) {
        state.asks.delete(ask.price);
      } else {
        state.asks.set(ask.price, ask.quantity);
      }
    }

    state.timestamp = Date.now();

    // Emit updated order book
    this.emitOrderBook(exchange, pair, state);

    return true;
  }

  /**
   * Get the current order book for a pair.
   */
  getOrderBook(exchange: string, pair: string, depth: number = 20): OrderBook | null {
    const key = `${exchange}:${pair}`;
    const state = this.orderBooks.get(key);

    if (!state) return null;

    return {
      symbol: pair,
      bids: Array.from(state.bids.entries())
        .sort(([a], [b]) => b - a)
        .slice(0, depth)
        .map(([price, quantity]) => ({ price, quantity })),
      asks: Array.from(state.asks.entries())
        .sort(([a], [b]) => a - b)
        .slice(0, depth)
        .map(([price, quantity]) => ({ price, quantity })),
      timestamp: state.timestamp,
      exchange,
    };
  }

  /**
   * Get the best bid and ask.
   */
  getBestBidAsk(exchange: string, pair: string): { bid: { price: number; quantity: number } | null; ask: { price: number; quantity: number } | null } {
    const ob = this.getOrderBook(exchange, pair, 1);
    return {
      bid: ob?.bids[0] || null,
      ask: ob?.asks[0] || null,
    };
  }

  /**
   * Get the mid price.
   */
  getMidPrice(exchange: string, pair: string): number | null {
    const { bid, ask } = this.getBestBidAsk(exchange, pair);
    if (bid && ask) {
      return (bid.price + ask.price) / 2;
    }
    return null;
  }

  /**
   * Get the spread.
   */
  getSpread(exchange: string, pair: string): { absolute: number; percent: number } | null {
    const { bid, ask } = this.getBestBidAsk(exchange, pair);
    if (bid && ask) {
      const absolute = ask.price - bid.price;
      const percent = (absolute / bid.price) * 100;
      return { absolute, percent };
    }
    return null;
  }

  /**
   * Check if the order book needs a new snapshot (stale or missing).
   */
  needsSnapshot(exchange: string, pair: string, maxAgeMs: number = 60000): boolean {
    const key = `${exchange}:${pair}`;
    const state = this.orderBooks.get(key);

    if (!state) return true;

    return Date.now() - state.timestamp > maxAgeMs;
  }

  private emitOrderBook(exchange: string, pair: string, state: OrderBookState): void {
    const orderBook: OrderBook = {
      symbol: pair,
      bids: Array.from(state.bids.entries())
        .sort(([a], [b]) => b - a)
        .slice(0, this.maxDepth)
        .map(([price, quantity]) => ({ price, quantity })),
      asks: Array.from(state.asks.entries())
        .sort(([a], [b]) => a - b)
        .slice(0, this.maxDepth)
        .map(([price, quantity]) => ({ price, quantity })),
      timestamp: state.timestamp,
      exchange,
    };

    this.emit("orderbook", exchange, pair, orderBook);
  }

  getTrackedPairs(): string[] {
    return Array.from(this.orderBooks.keys());
  }
}