import { ExchangeAdapter } from "./exchange.adapter";
import type { Ticker, OHLCV, OrderBook, TradeTick, FundingRate } from "./exchange.adapter";
import ccxt, { binance } from "ccxt";
import WebSocket from "ws";
import { logger } from "../utils/logger";

interface BinanceStreamMessage {
  stream: string;
  data: any;
}

/**
 * Binance exchange adapter using WebSocket streams.
 * Handles spot, futures (USD-M and COIN-M).
 */
export class BinanceAdapter extends ExchangeAdapter {
  private ws: WebSocket | null = null;
  private wsUrl: string = "wss://stream.binance.com:9443/ws";
  private wsFuturesUrl: string = "wss://fstream.binance.com/ws";
  private rest: binance;
  private streamIds: Set<string> = new Set();
  private orderBookDepth: number = 20;
  private useFutures: boolean = false;
  private pingInterval: NodeJS.Timeout | null = null;
  private orderBookCache: Map<string, { lastUpdateId: number; bids: Map<number, number>; asks: Map<number, number> }> = new Map();

  constructor(useFutures: boolean = false) {
    super("binance");
    this.useFutures = useFutures;
    this.rest = new ccxt.binance({
      enableRateLimit: true,
      options: { defaultType: useFutures ? "future" : "spot" },
    }) as binance;
  }

  async connect(): Promise<void> {
    if (this.isConnected) return;

    const url = this.useFutures ? this.wsFuturesUrl : this.wsUrl;

    return new Promise((resolve, reject) => {
      this.ws = new WebSocket(url);

      this.ws.on("open", () => {
        this.isConnected = true;
        this.resetReconnect();
        this.startPing();
        logger.info(`Binance WebSocket connected (${this.useFutures ? "futures" : "spot"})`);
        this.emit("onConnected");

        // Resubscribe to all pairs
        this.resubscribeAll();
        resolve();
      });

      this.ws.on("message", (data: WebSocket.Data) => {
        try {
          const message = JSON.parse(data.toString());
          this.handleMessage(message);
        } catch (error) {
          logger.error("Failed to parse Binance WebSocket message", { error });
        }
      });

      this.ws.on("error", (error) => {
        logger.error("Binance WebSocket error", { error: error.message });
        this.emit("onError", error);
      });

      this.ws.on("close", (code, reason) => {
        this.isConnected = false;
        this.stopPing();
        logger.warn(`Binance WebSocket closed: ${code} - ${reason.toString()}`);
        this.scheduleReconnect();
      });

      // Timeout
      setTimeout(() => {
        if (!this.isConnected) {
          reject(new Error("Binance WebSocket connection timeout"));
        }
      }, 15000);
    });
  }

  async disconnect(): Promise<void> {
    this.stopPing();
    if (this.ws) {
      this.ws.close(1000, "Client disconnect");
      this.ws = null;
    }
    this.isConnected = false;
    this.orderBookCache.clear();
    logger.info("Binance WebSocket disconnected");
  }

  private startPing(): void {
    this.stopPing();
    this.pingInterval = setInterval(() => {
      if (this.ws?.readyState === WebSocket.OPEN) {
        this.ws.ping();
      }
    }, 180000); // Every 3 minutes
  }

  private stopPing(): void {
    if (this.pingInterval) {
      clearInterval(this.pingInterval);
      this.pingInterval = null;
    }
  }

  private async resubscribeAll(): Promise<void> {
    const streams: string[] = [];
    for (const pair of this.pairs) {
      const symbol = pair.replace("/", "").toLowerCase();
      if (this.streamIds.has(`${symbol}@ticker`)) streams.push(`${symbol}@ticker`);
      if (this.streamIds.has(`${symbol}@depth${this.orderBookDepth}`)) streams.push(`${symbol}@depth${this.orderBookDepth}@100ms`);
      if (this.streamIds.has(`${symbol}@trade`)) streams.push(`${symbol}@trade`);
      if (this.streamIds.has(`${symbol}@kline_1m`)) streams.push(`${symbol}@kline_1m`);
    }

    if (streams.length > 0 && this.ws?.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify({
        method: "SUBSCRIBE",
        params: streams,
        id: Date.now(),
      }));
    }
  }

  private handleMessage(message: any): void {
    // Handle combined streams
    if (message.stream) {
      this.handleStreamMessage(message.stream, message.data);
      return;
    }

    // Handle single stream
    if (message.e) {
      this.handleEventMessage(message);
      return;
    }
  }

  private handleStreamMessage(stream: string, data: any): void {
    const parts = stream.split("@");
    const symbol = parts[0]?.toUpperCase() || "";
    const eventType = parts[1] || "";

    if (eventType === "ticker") {
      this.emit("onTicker", this.parseTicker(symbol, data));
    } else if (eventType.startsWith("depth")) {
      this.handleOrderBookUpdate(symbol, data);
    } else if (eventType === "trade") {
      this.emit("onTrade", {
        id: data.t?.toString() || "",
        price: parseFloat(data.p || "0"),
        quantity: parseFloat(data.q || "0"),
        side: data.m ? "sell" : "buy",
        timestamp: data.T || Date.now(),
      });
    } else if (eventType.startsWith("kline_")) {
      const kline = data.k;
      this.emit("onCandle", {
        timestamp: kline.t,
        open: parseFloat(kline.o),
        high: parseFloat(kline.h),
        low: parseFloat(kline.l),
        close: parseFloat(kline.c),
        volume: parseFloat(kline.v),
      });
    }
  }

  private handleEventMessage(data: any): void {
    switch (data.e) {
      case "24hrTicker":
        this.emit("onTicker", this.parseTicker(data.s, data));
        break;
      case "trade":
        this.emit("onTrade", {
          id: data.t?.toString() || "",
          price: parseFloat(data.p || "0"),
          quantity: parseFloat(data.q || "0"),
          side: data.m ? "sell" : "buy",
          timestamp: data.T || Date.now(),
        });
        break;
    }
  }

  private parseTicker(symbol: string, data: any): Ticker {
    return {
      symbol: `${symbol.slice(0, -4)}/${symbol.slice(-4)}`,
      last: parseFloat(data.c || data.l || "0"),
      bid: parseFloat(data.b || "0"),
      ask: parseFloat(data.a || "0"),
      high24h: parseFloat(data.h || "0"),
      low24h: parseFloat(data.l || "0"),
      volume24h: parseFloat(data.v || "0"),
      quoteVolume24h: parseFloat(data.q || "0"),
      change24h: parseFloat(data.p || "0"),
      changePercent24h: parseFloat(data.P || "0"),
      timestamp: data.E || Date.now(),
    };
  }

  private handleOrderBookUpdate(symbol: string, data: any): void {
    const pair = `${symbol.slice(0, -4)}/${symbol.slice(-4)}`;
    let cache = this.orderBookCache.get(pair);

    if (!cache) {
      cache = { lastUpdateId: 0, bids: new Map(), asks: new Map() };
      this.orderBookCache.set(pair, cache);
    }

    // Process bids
    if (data.b) {
      for (const [price, qty] of data.b) {
        const p = parseFloat(price);
        const q = parseFloat(qty);
        if (q === 0) {
          cache.bids.delete(p);
        } else {
          cache.bids.set(p, q);
        }
      }
    }

    // Process asks
    if (data.a) {
      for (const [price, qty] of data.a) {
        const p = parseFloat(price);
        const q = parseFloat(qty);
        if (q === 0) {
          cache.asks.delete(p);
        } else {
          cache.asks.set(p, q);
        }
      }
    }

    cache.lastUpdateId = data.lastUpdateId || data.u || cache.lastUpdateId;

    // Build order book
    const orderBook: OrderBook = {
      symbol: pair,
      bids: Array.from(cache.bids.entries())
        .sort(([a], [b]) => b - a)
        .slice(0, this.orderBookDepth)
        .map(([price, quantity]) => ({ price, quantity })),
      asks: Array.from(cache.asks.entries())
        .sort(([a], [b]) => a - b)
        .slice(0, this.orderBookDepth)
        .map(([price, quantity]) => ({ price, quantity })),
      timestamp: Date.now(),
      exchange: "binance",
    };

    this.emit("onOrderBook", orderBook);
  }

  async subscribeTicker(pair: string): Promise<void> {
    const normalized = this.normalizePair(pair);
    this.pairs.add(normalized);
    const symbol = normalized.replace("/", "").toLowerCase();
    const stream = `${symbol}@ticker`;
    this.streamIds.add(stream);

    if (this.ws?.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify({
        method: "SUBSCRIBE",
        params: [stream],
        id: Date.now(),
      }));
    }
  }

  async unsubscribeTicker(pair: string): Promise<void> {
    const normalized = this.normalizePair(pair);
    const symbol = normalized.replace("/", "").toLowerCase();
    this.streamIds.delete(`${symbol}@ticker`);

    if (this.ws?.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify({
        method: "UNSUBSCRIBE",
        params: [`${symbol}@ticker`],
        id: Date.now(),
      }));
    }
  }

  async subscribeOrderBook(pair: string, depth: number = 20): Promise<void> {
    const normalized = this.normalizePair(pair);
    this.pairs.add(normalized);
    this.orderBookDepth = depth;
    const symbol = normalized.replace("/", "").toLowerCase();

    // Get snapshot first
    try {
      const snapshot = await this.fetchOrderBook(normalized, depth);
      const cache = this.orderBookCache.get(normalized);
      if (cache && snapshot) {
        cache.lastUpdateId = 0;
        for (const bid of snapshot.bids) cache.bids.set(bid.price, bid.quantity);
        for (const ask of snapshot.asks) cache.asks.set(ask.price, ask.quantity);
      }
    } catch (error) {
      logger.warn(`Failed to fetch order book snapshot for ${normalized}`);
    }

    const stream = `${symbol}@depth${depth}@100ms`;
    this.streamIds.add(stream);

    if (this.ws?.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify({
        method: "SUBSCRIBE",
        params: [stream],
        id: Date.now(),
      }));
    }
  }

  async unsubscribeOrderBook(pair: string): Promise<void> {
    const normalized = this.normalizePair(pair);
    const symbol = normalized.replace("/", "").toLowerCase();
    this.streamIds.delete(`${symbol}@depth${this.orderBookDepth}@100ms`);
    this.orderBookCache.delete(normalized);

    if (this.ws?.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify({
        method: "UNSUBSCRIBE",
        params: [`${symbol}@depth${this.orderBookDepth}@100ms`],
        id: Date.now(),
      }));
    }
  }

  async subscribeTrades(pair: string): Promise<void> {
    const normalized = this.normalizePair(pair);
    this.pairs.add(normalized);
    const symbol = normalized.replace("/", "").toLowerCase();
    const stream = `${symbol}@trade`;
    this.streamIds.add(stream);

    if (this.ws?.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify({
        method: "SUBSCRIBE",
        params: [stream],
        id: Date.now(),
      }));
    }
  }

  async unsubscribeTrades(pair: string): Promise<void> {
    const normalized = this.normalizePair(pair);
    const symbol = normalized.replace("/", "").toLowerCase();
    this.streamIds.delete(`${symbol}@trade`);
  }

  async subscribeCandles(pair: string, timeframe: string): Promise<void> {
    const normalized = this.normalizePair(pair);
    this.pairs.add(normalized);
    const symbol = normalized.replace("/", "").toLowerCase();
    const stream = `${symbol}@kline_${timeframe}`;
    this.streamIds.add(stream);

    if (this.ws?.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify({
        method: "SUBSCRIBE",
        params: [stream],
        id: Date.now(),
      }));
    }
  }

  async unsubscribeCandles(pair: string, timeframe: string): Promise<void> {
    const normalized = this.normalizePair(pair);
    const symbol = normalized.replace("/", "").toLowerCase();
    this.streamIds.delete(`${symbol}@kline_${timeframe}`);
  }

  async fetchHistoricalOHLCV(pair: string, timeframe: string, since?: number, limit: number = 500): Promise<OHLCV[]> {
    try {
      const ohlcv = await this.rest.fetchOHLCV(pair, timeframe, since, limit);
      return ohlcv.map((candle: any) => ({
        timestamp: candle[0],
        open: candle[1],
        high: candle[2],
        low: candle[3],
        close: candle[4],
        volume: candle[5],
      }));
    } catch (error) {
      logger.error(`Failed to fetch OHLCV for ${pair}`, { error });
      throw error;
    }
  }

  async fetchTicker(pair: string): Promise<Ticker> {
    const ticker = await this.rest.fetchTicker(pair);
    return {
      symbol: pair,
      last: ticker.last || 0,
      bid: ticker.bid || 0,
      ask: ticker.ask || 0,
      high24h: ticker.high || 0,
      low24h: ticker.low || 0,
      volume24h: ticker.baseVolume || 0,
      quoteVolume24h: ticker.quoteVolume || 0,
      change24h: ticker.change || 0,
      changePercent24h: ticker.percentage || 0,
      timestamp: ticker.timestamp || Date.now(),
    };
  }

  async fetchOrderBook(pair: string, depth: number = 20): Promise<OrderBook> {
    const ob = await this.rest.fetchOrderBook(pair, depth);
    return {
      symbol: pair,
      bids: ob.bids.map(([price, quantity]: number[]) => ({ price, quantity })),
      asks: ob.asks.map(([price, quantity]: number[]) => ({ price, quantity })),
      timestamp: Date.now(),
      exchange: "binance",
    };
  }

  async fetchFundingRate(pair: string): Promise<FundingRate> {
    if (!this.useFutures) throw new Error("Funding rate only available for futures");

    const info = await this.rest.fetchFundingRate(pair);
    return {
      symbol: pair,
      rate: info.fundingRate || 0,
      nextFundingTimestamp: info.fundingTimestamp || 0,
      markPrice: info.markPrice || 0,
      indexPrice: info.indexPrice || 0,
    };
  }
}