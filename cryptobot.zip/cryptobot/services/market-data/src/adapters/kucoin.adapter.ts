import { ExchangeAdapter } from "./exchange.adapter";
import type { Ticker, OHLCV, OrderBook, TradeTick } from "./exchange.adapter";
import ccxt, { kucoin } from "ccxt";
import WebSocket from "ws";
import { logger } from "../utils/logger";
import { v4 as uuidv4 } from "uuid";

/**
 * KuCoin exchange adapter using WebSocket streams.
 * Requires token-based authentication for private channels,
 * but public channels are open.
 */
export class KucoinAdapter extends ExchangeAdapter {
  private ws: WebSocket | null = null;
  private rest: kucoin;
  private pingInterval: NodeJS.Timeout | null = null;
  private connectId: string = uuidv4();
  private wsEndpoint: string = "";
  private token: string = "";
  private tokenExpiry: number = 0;
  private orderBookCache: Map<string, { bids: Map<number, number>; asks: Map<number, number>; sequence: number; timestamp: number }> = new Map();

  constructor() {
    super("kucoin");
    this.rest = new ccxt.kucoin({
      enableRateLimit: true,
    }) as kucoin;
  }

  /**
   * Get public WebSocket token from KuCoin REST API.
   */
  private async getPublicToken(): Promise<{ token: string; endpoint: string; expireAt: number }> {
    if (this.token && Date.now() < this.tokenExpiry) {
      return { token: this.token, endpoint: this.wsEndpoint, expireAt: this.tokenExpiry };
    }

    try {
      const response = await this.rest.fetch("https://api.kucoin.com/api/v1/bullet-public", "POST");
      const data = (response as any)?.data;

      if (!data?.token || !data?.instanceServers?.[0]?.endpoint) {
        throw new Error("Failed to get KuCoin public token");
      }

      this.token = data.token;
      this.wsEndpoint = data.instanceServers[0].endpoint;
      this.tokenExpiry = Date.now() + 23 * 60 * 60 * 1000; // 23 hours

      logger.info(`KuCoin public token obtained, endpoint: ${this.wsEndpoint}`);
      return { token: this.token, endpoint: this.wsEndpoint, expireAt: this.tokenExpiry };
    } catch (error) {
      logger.error("Failed to get KuCoin public token", { error });
      throw error;
    }
  }

  async connect(): Promise<void> {
    if (this.isConnected) return;

    const { token, endpoint } = await this.getPublicToken();
    const url = `${endpoint}?token=${token}&connectId=${this.connectId}`;

    return new Promise((resolve, reject) => {
      this.ws = new WebSocket(url);

      this.ws.on("open", () => {
        this.isConnected = true;
        this.resetReconnect();
        this.startPing();
        logger.info("KuCoin WebSocket connected");
        this.emit("onConnected");
        this.resubscribeAll();
        resolve();
      });

      this.ws.on("message", (data: WebSocket.Data) => {
        try {
          const message = JSON.parse(data.toString());
          this.handleMessage(message);
        } catch (error) {
          logger.error("Failed to parse KuCoin WebSocket message", { error });
        }
      });

      this.ws.on("error", (error) => {
        logger.error("KuCoin WebSocket error", { error: error.message });
        this.emit("onError", error);
      });

      this.ws.on("close", (code) => {
        this.isConnected = false;
        this.stopPing();
        this.token = ""; // Force new token on reconnect
        logger.warn(`KuCoin WebSocket closed: ${code}`);
        this.scheduleReconnect();
      });

      setTimeout(() => {
        if (!this.isConnected) reject(new Error("KuCoin WebSocket connection timeout"));
      }, 15000);
    });
  }

  async disconnect(): Promise<void> {
    this.stopPing();
    if (this.ws) {
      this.ws.close(1000, "Client disconnect");
      this.ws = null;
    }
    this.isConnected = false;
    this.orderBookCache.clear();
  }

  private startPing(): void {
    this.stopPing();
    this.pingInterval = setInterval(() => {
      if (this.ws?.readyState === WebSocket.OPEN) {
        this.ws.send(JSON.stringify({ id: uuidv4(), type: "ping" }));
      }
    }, 18000);
  }

  private stopPing(): void {
    if (this.pingInterval) {
      clearInterval(this.pingInterval);
      this.pingInterval = null;
    }
  }

  private async resubscribeAll(): Promise<void> {
    for (const pair of this.pairs) {
      const symbol = pair.replace("/", "-").toUpperCase();
      await this.subscribeTicker(pair);
    }
  }

  private handleMessage(message: any): void {
    const type = message.type;

    switch (type) {
      case "pong":
        break;

      case "welcome":
        logger.debug("KuCoin welcome message received");
        break;

      case "message": {
        const topic = message.topic || "";
        const data = message.data || message;

        if (topic.includes("/market/ticker:")) {
          this.emit("onTicker", this.parseTickerFromTopic(topic, data));
        } else if (topic.includes("/market/snapshot:")) {
          const pair = this.topicToPair(topic);
          if (pair) this.handleOrderBookSnapshot(pair, data);
        } else if (topic.includes("/market/level2:")) {
          const pair = this.topicToPair(topic);
          if (pair) this.handleOrderBookUpdate(pair, data);
        } else if (topic.includes("/market/match:")) {
          const pair = this.topicToPair(topic);
          if (pair) {
            this.emit("onTrade", {
              id: data.tradeId || data.sequence || "",
              price: parseFloat(data.price || "0"),
              quantity: parseFloat(data.size || "0"),
              side: data.side || "buy",
              timestamp: parseInt(data.time || "0") || Date.now(),
            });
          }
        }
        break;
      }

      case "error":
        logger.error(`KuCoin WS error: ${message.code} - ${message.data}`, { message });
        break;
    }
  }

  private topicToPair(topic: string): string | null {
    // Topic format: /market/ticker:BTC-USDT
    const parts = topic.split(":");
    if (parts.length < 2) return null;
    return (parts[1] || "").replace("-", "/");
  }

  private parseTickerFromTopic(topic: string, data: any): Ticker {
    return {
      symbol: this.topicToPair(topic) || "unknown",
      last: parseFloat(data.price || "0"),
      bid: parseFloat(data.bestBid || "0"),
      ask: parseFloat(data.bestAsk || "0"),
      high24h: parseFloat(data.high || "0"),
      low24h: parseFloat(data.low || "0"),
      volume24h: parseFloat(data.vol || data.volume || "0"),
      quoteVolume24h: parseFloat(data.volValue || "0"),
      change24h: parseFloat(data.changePrice || "0"),
      changePercent24h: parseFloat(data.changeRate || "0") * 100,
      timestamp: parseInt(data.time || "0") || Date.now(),
    };
  }

  private handleOrderBookSnapshot(pair: string, data: any): void {
    const cache = { bids: new Map<number, number>(), asks: new Map<number, number>(), sequence: data.sequence || 0, timestamp: Date.now() };

    if (data.bids) for (const [price, qty] of data.bids) {
      const q = parseFloat(qty);
      if (q > 0) cache.bids.set(parseFloat(price), q);
    }
    if (data.asks) for (const [price, qty] of data.asks) {
      const q = parseFloat(qty);
      if (q > 0) cache.asks.set(parseFloat(price), q);
    }

    this.orderBookCache.set(pair, cache);

    this.emit("onOrderBook", {
      symbol: pair,
      bids: Array.from(cache.bids.entries()).sort(([a], [b]) => b - a).slice(0, 50).map(([p, q]) => ({ price: p, quantity: q })),
      asks: Array.from(cache.asks.entries()).sort(([a], [b]) => a - b).slice(0, 50).map(([p, q]) => ({ price: p, quantity: q })),
      timestamp: cache.timestamp,
      exchange: "kucoin",
    });
  }

  private handleOrderBookUpdate(pair: string, data: any): void {
    let cache = this.orderBookCache.get(pair);
    if (!cache) {
      cache = { bids: new Map(), asks: new Map(), sequence: 0, timestamp: Date.now() };
      this.orderBookCache.set(pair, cache);
    }

    const changes = data.changes || [];
    for (const [price, side, qty] of changes) {
      const p = parseFloat(price);
      const q = parseFloat(qty);
      if (side === "buy") {
        q === 0 ? cache.bids.delete(p) : cache.bids.set(p, q);
      } else if (side === "sell") {
        q === 0 ? cache.asks.delete(p) : cache.asks.set(p, q);
      }
    }

    cache.sequence = data.sequenceEnd || cache.sequence;
    cache.timestamp = Date.now();

    this.emit("onOrderBook", {
      symbol: pair,
      bids: Array.from(cache.bids.entries()).sort(([a], [b]) => b - a).slice(0, 50).map(([p, q]) => ({ price: p, quantity: q })),
      asks: Array.from(cache.asks.entries()).sort(([a], [b]) => a - b).slice(0, 50).map(([p, q]) => ({ price: p, quantity: q })),
      timestamp: cache.timestamp,
      exchange: "kucoin",
    });
  }

  async subscribeTicker(pair: string): Promise<void> {
    const normalized = this.normalizePair(pair);
    this.pairs.add(normalized);
    const symbol = normalized.replace("/", "-").toUpperCase();
    if (this.ws?.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify({
        id: uuidv4(),
        type: "subscribe",
        topic: `/market/ticker:${symbol}`,
        privateChannel: false,
        response: true,
      }));
    }
  }

  async unsubscribeTicker(pair: string): Promise<void> {
    const normalized = this.normalizePair(pair);
    const symbol = normalized.replace("/", "-").toUpperCase();
    if (this.ws?.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify({
        id: uuidv4(),
        type: "unsubscribe",
        topic: `/market/ticker:${symbol}`,
        privateChannel: false,
        response: true,
      }));
    }
  }

  async subscribeOrderBook(pair: string, _depth: number = 50): Promise<void> {
    const normalized = this.normalizePair(pair);
    this.pairs.add(normalized);
    const symbol = normalized.replace("/", "-").toUpperCase();
    if (this.ws?.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify({
        id: uuidv4(),
        type: "subscribe",
        topic: `/market/level2:${symbol}`,
        privateChannel: false,
        response: true,
      }));
    }
  }

  async unsubscribeOrderBook(pair: string): Promise<void> {
    const normalized = this.normalizePair(pair);
    const symbol = normalized.replace("/", "-").toUpperCase();
    if (this.ws?.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify({
        id: uuidv4(),
        type: "unsubscribe",
        topic: `/market/level2:${symbol}`,
        privateChannel: false,
        response: true,
      }));
    }
  }

  async subscribeTrades(pair: string): Promise<void> {
    const normalized = this.normalizePair(pair);
    this.pairs.add(normalized);
    const symbol = normalized.replace("/", "-").toUpperCase();
    if (this.ws?.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify({
        id: uuidv4(),
        type: "subscribe",
        topic: `/market/match:${symbol}`,
        privateChannel: false,
        response: true,
      }));
    }
  }

  async unsubscribeTrades(pair: string): Promise<void> {
    const normalized = this.normalizePair(pair);
    const symbol = normalized.replace("/", "-").toUpperCase();
    if (this.ws?.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify({
        id: uuidv4(),
        type: "unsubscribe",
        topic: `/market/match:${symbol}`,
        privateChannel: false,
        response: true,
      }));
    }
  }

  async subscribeCandles(pair: string, _timeframe: string): Promise<void> {
    this.pairs.add(this.normalizePair(pair));
    // KuCoin candles use different endpoint, added via REST polling
    logger.info(`KuCoin candles available via REST for ${pair}`);
  }

  async unsubscribeCandles(_pair: string, _timeframe: string): Promise<void> {
    // No-op
  }

  async fetchHistoricalOHLCV(pair: string, timeframe: string, since?: number, limit: number = 500): Promise<OHLCV[]> {
    try {
      const ohlcv = await this.rest.fetchOHLCV(pair, timeframe, since, limit);
      return ohlcv.map((candle: any) => ({
        timestamp: candle[0],
        open: candle[1],
        high: candle[2],
        low: candle[3],
        close: candle[4],
        volume: candle[5],
      }));
    } catch (error) {
      logger.error(`Failed to fetch OHLCV for ${pair} from KuCoin`, { error });
      throw error;
    }
  }

  async fetchTicker(pair: string): Promise<Ticker> {
    const ticker = await this.rest.fetchTicker(pair);
    return {
      symbol: pair,
      last: ticker.last || 0,
      bid: ticker.bid || 0,
      ask: ticker.ask || 0,
      high24h: ticker.high || 0,
      low24h: ticker.low || 0,
      volume24h: ticker.baseVolume || 0,
      quoteVolume24h: ticker.quoteVolume || 0,
      change24h: ticker.change || 0,
      changePercent24h: ticker.percentage || 0,
      timestamp: ticker.timestamp || Date.now(),
    };
  }

  async fetchOrderBook(pair: string, depth: number = 50): Promise<OrderBook> {
    const ob = await this.rest.fetchOrderBook(pair, depth);
    return {
      symbol: pair,
      bids: ob.bids.map(([p, q]: number[]) => ({ price: p, quantity: q })),
      asks: ob.asks.map(([p, q]: number[]) => ({ price: p, quantity: q })),
      timestamp: Date.now(),
      exchange: "kucoin",
    };
  }
}