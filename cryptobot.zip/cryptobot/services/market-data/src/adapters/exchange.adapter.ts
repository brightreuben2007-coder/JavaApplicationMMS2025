import { EventEmitter } from "node:events";

export interface Ticker {
  symbol: string;
  last: number;
  bid: number;
  ask: number;
  high24h: number;
  low24h: number;
  volume24h: number;
  quoteVolume24h: number;
  change24h: number;
  changePercent24h: number;
  timestamp: number;
}

export interface OHLCV {
  timestamp: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

export interface OrderBookLevel {
  price: number;
  quantity: number;
}

export interface OrderBook {
  symbol: string;
  bids: OrderBookLevel[];
  asks: OrderBookLevel[];
  timestamp: number;
  exchange: string;
}

export interface TradeTick {
  id: string;
  price: number;
  quantity: number;
  side: "buy" | "sell";
  timestamp: number;
}

export interface FundingRate {
  symbol: string;
  rate: number;
  nextFundingTimestamp: number;
  markPrice: number;
  indexPrice: number;
}

export interface Liquidation {
  symbol: string;
  side: "buy" | "sell";
  quantity: number;
  price: number;
  timestamp: number;
}

export interface ExchangeAdapterEvents {
  onTicker: (ticker: Ticker) => void;
  onCandle: (candle: OHLCV) => void;
  onOrderBook: (orderBook: OrderBook) => void;
  onTrade: (trade: TradeTick) => void;
  onFundingRate: (rate: FundingRate) => void;
  onLiquidation: (liquidation: Liquidation) => void;
  onError: (error: Error) => void;
  onConnected: () => void;
  onDisconnected: (reason: string) => void;
}

export abstract class ExchangeAdapter extends EventEmitter {
  protected exchangeId: string;
  protected pairs: Set<string> = new Set();
  protected isConnected: boolean = false;
  protected reconnectAttempts: number = 0;
  protected maxReconnectAttempts: number = 20;
  protected baseReconnectDelay: number = 1000;
  protected maxReconnectDelay: number = 60000;
  protected reconnectTimer: NodeJS.Timeout | null = null;

  constructor(exchangeId: string) {
    super();
    this.exchangeId = exchangeId;
  }

  abstract connect(): Promise<void>;
  abstract disconnect(): Promise<void>;
  abstract subscribeTicker(pair: string): Promise<void>;
  abstract unsubscribeTicker(pair: string): Promise<void>;
  abstract subscribeOrderBook(pair: string, depth?: number): Promise<void>;
  abstract unsubscribeOrderBook(pair: string): Promise<void>;
  abstract subscribeTrades(pair: string): Promise<void>;
  abstract unsubscribeTrades(pair: string): Promise<void>;
  abstract subscribeCandles(pair: string, timeframe: string): Promise<void>;
  abstract unsubscribeCandles(pair: string, timeframe: string): Promise<void>;
  abstract fetchHistoricalOHLCV(pair: string, timeframe: string, since?: number, limit?: number): Promise<OHLCV[]>;
  abstract fetchTicker(pair: string): Promise<Ticker>;
  abstract fetchOrderBook(pair: string, depth?: number): Promise<OrderBook>;
  abstract fetchFundingRate?(pair: string): Promise<FundingRate>;

  getExchangeId(): string {
    return this.exchangeId;
  }

  getSubscribedPairs(): string[] {
    return Array.from(this.pairs);
  }

  isExchangeConnected(): boolean {
    return this.isConnected;
  }

  protected resetReconnect(): void {
    this.reconnectAttempts = 0;
  }

  protected scheduleReconnect(): void {
    if (this.reconnectTimer) return;

    const delay = Math.min(
      this.baseReconnectDelay * Math.pow(2, this.reconnectAttempts),
      this.maxReconnectDelay
    );

    this.reconnectAttempts++;
    this.isConnected = false;

    this.emit("onDisconnected", `Reconnecting in ${delay}ms (attempt ${this.reconnectAttempts})`);

    this.reconnectTimer = setTimeout(async () => {
      this.reconnectTimer = null;
      try {
        await this.connect();
      } catch (error) {
        this.emit("onError", error as Error);
        if (this.reconnectAttempts < this.maxReconnectAttempts) {
          this.scheduleReconnect();
        }
      }
    }, delay);
  }

  /**
   * Normalize a pair symbol to standard format (e.g., BTC/USDT).
   */
  protected normalizePair(pair: string): string {
    return pair.replace("-", "/").toUpperCase();
  }
}