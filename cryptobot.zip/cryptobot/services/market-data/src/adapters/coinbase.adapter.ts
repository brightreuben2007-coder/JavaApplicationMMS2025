import { ExchangeAdapter } from "./exchange.adapter";
import type { Ticker, OHLCV, OrderBook, TradeTick } from "./exchange.adapter";
import ccxt, { coinbase } from "ccxt";
import WebSocket from "ws";
import { logger } from "../utils/logger";

/**
 * Coinbase exchange adapter using Advanced Trade WebSocket.
 */
export class CoinbaseAdapter extends ExchangeAdapter {
  private ws: WebSocket | null = null;
  private wsUrl: string = "wss://ws-feed.exchange.coinbase.com";
  private rest: coinbase;
  private pingInterval: NodeJS.Timeout | null = null;
  private orderBookCache: Map<string, { bids: Map<number, number>; asks: Map<number, number>; sequence: number; timestamp: number }> = new Map();

  constructor() {
    super("coinbase");
    this.rest = new ccxt.coinbase({
      enableRateLimit: true,
    }) as coinbase;
  }

  async connect(): Promise<void> {
    if (this.isConnected) return;

    return new Promise((resolve, reject) => {
      this.ws = new WebSocket(this.wsUrl);

      this.ws.on("open", () => {
        this.isConnected = true;
        this.resetReconnect();
        this.startPing();
        logger.info("Coinbase WebSocket connected");
        this.emit("onConnected");
        this.resubscribeAll();
        resolve();
      });

      this.ws.on("message", (data: WebSocket.Data) => {
        try {
          const message = JSON.parse(data.toString());
          this.handleMessage(message);
        } catch (error) {
          logger.error("Failed to parse Coinbase WebSocket message", { error });
        }
      });

      this.ws.on("error", (error) => {
        logger.error("Coinbase WebSocket error", { error: error.message });
        this.emit("onError", error);
      });

      this.ws.on("close", (code, reason) => {
        this.isConnected = false;
        this.stopPing();
        logger.warn(`Coinbase WebSocket closed: ${code}`);
        this.scheduleReconnect();
      });

      setTimeout(() => {
        if (!this.isConnected) reject(new Error("Coinbase WebSocket connection timeout"));
      }, 15000);
    });
  }

  async disconnect(): Promise<void> {
    this.stopPing();
    if (this.ws) {
      this.ws.close(1000, "Client disconnect");
      this.ws = null;
    }
    this.isConnected = false;
    this.orderBookCache.clear();
  }

  private startPing(): void {
    this.stopPing();
    this.pingInterval = setInterval(() => {
      if (this.ws?.readyState === WebSocket.OPEN) {
        this.ws.send(JSON.stringify({ type: "heartbeat", on: "heartbeat", time: new Date().toISOString() }));
      }
    }, 30000);
  }

  private stopPing(): void {
    if (this.pingInterval) {
      clearInterval(this.pingInterval);
      this.pingInterval = null;
    }
  }

  private async resubscribeAll(): Promise<void> {
    const productIds: string[] = [];
    const channels: string[] = [];

    for (const pair of this.pairs) {
      const productId = pair.replace("/", "-");
      productIds.push(productId);
    }

    if (productIds.length > 0 && this.ws?.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify({
        type: "subscribe",
        product_ids: productIds,
        channels: ["ticker", "level2_batch", "matches"],
      }));
    }
  }

  private handleMessage(message: any): void {
    const type = message.type;

    switch (type) {
      case "ticker": {
        const productId = (message.product_id || "").replace("-", "/");
        this.emit("onTicker", {
          symbol: productId,
          last: parseFloat(message.price || "0"),
          bid: parseFloat(message.best_bid || "0"),
          ask: parseFloat(message.best_ask || "0"),
          high24h: parseFloat(message.high_24h || "0"),
          low24h: parseFloat(message.low_24h || "0"),
          volume24h: parseFloat(message.volume_24h || "0"),
          quoteVolume24h: parseFloat(message.volume_24h || "0") * parseFloat(message.price || "0"),
          change24h: parseFloat(message.price || "0") - parseFloat(message.open_24h || "0"),
          changePercent24h: parseFloat(message.price || "0") > 0
            ? ((parseFloat(message.price) - parseFloat(message.open_24h)) / parseFloat(message.open_24h)) * 100
            : 0,
          timestamp: Date.now(),
        });
        break;
      }

      case "l2update": {
        const productId = (message.product_id || "").replace("-", "/");
        this.handleOrderBookUpdate(productId, message.changes || []);
        break;
      }

      case "snapshot": {
        const productId = (message.product_id || "").replace("-", "/");
        this.handleOrderBookSnapshot(productId, message);
        break;
      }

      case "match":
      case "last_match": {
        const productId = (message.product_id || "").replace("-", "/");
        this.emit("onTrade", {
          id: message.trade_id?.toString() || "",
          price: parseFloat(message.price || "0"),
          quantity: parseFloat(message.size || "0"),
          side: message.side || "buy",
          timestamp: Date.parse(message.time) || Date.now(),
        });
        break;
      }

      case "heartbeat":
        break;

      case "error":
        logger.error(`Coinbase WS error: ${message.message}`, { message });
        break;
    }
  }

  private handleOrderBookSnapshot(pair: string, data: any): void {
    const cache = { bids: new Map<number, number>(), asks: new Map<number, number>(), sequence: data.sequence || 0, timestamp: Date.now() };

    if (data.bids) for (const [price, qty] of data.bids) {
      const q = parseFloat(qty);
      if (q > 0) cache.bids.set(parseFloat(price), q);
    }
    if (data.asks) for (const [price, qty] of data.asks) {
      const q = parseFloat(qty);
      if (q > 0) cache.asks.set(parseFloat(price), q);
    }

    this.orderBookCache.set(pair, cache);

    this.emit("onOrderBook", {
      symbol: pair,
      bids: Array.from(cache.bids.entries()).sort(([a], [b]) => b - a).slice(0, 50).map(([p, q]) => ({ price: p, quantity: q })),
      asks: Array.from(cache.asks.entries()).sort(([a], [b]) => a - b).slice(0, 50).map(([p, q]) => ({ price: p, quantity: q })),
      timestamp: cache.timestamp,
      exchange: "coinbase",
    });
  }

  private handleOrderBookUpdate(pair: string, changes: [string, string, string][]): void {
    let cache = this.orderBookCache.get(pair);
    if (!cache) {
      cache = { bids: new Map(), asks: new Map(), sequence: 0, timestamp: Date.now() };
      this.orderBookCache.set(pair, cache);
    }

    for (const [side, priceStr, qtyStr] of changes) {
      const price = parseFloat(priceStr);
      const qty = parseFloat(qtyStr);

      if (side === "buy") {
        qty === 0 ? cache.bids.delete(price) : cache.bids.set(price, qty);
      } else if (side === "sell") {
        qty === 0 ? cache.asks.delete(price) : cache.asks.set(price, qty);
      }
    }

    cache.timestamp = Date.now();

    this.emit("onOrderBook", {
      symbol: pair,
      bids: Array.from(cache.bids.entries()).sort(([a], [b]) => b - a).slice(0, 50).map(([p, q]) => ({ price: p, quantity: q })),
      asks: Array.from(cache.asks.entries()).sort(([a], [b]) => a - b).slice(0, 50).map(([p, q]) => ({ price: p, quantity: q })),
      timestamp: cache.timestamp,
      exchange: "coinbase",
    });
  }

  async subscribeTicker(pair: string): Promise<void> {
    const normalized = this.normalizePair(pair);
    this.pairs.add(normalized);
    const productId = normalized.replace("/", "-");
    if (this.ws?.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify({ type: "subscribe", product_ids: [productId], channels: ["ticker"] }));
    }
  }

  async unsubscribeTicker(pair: string): Promise<void> {
    const normalized = this.normalizePair(pair);
    const productId = normalized.replace("/", "-");
    if (this.ws?.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify({ type: "unsubscribe", product_ids: [productId], channels: ["ticker"] }));
    }
  }

  async subscribeOrderBook(pair: string, _depth: number = 50): Promise<void> {
    const normalized = this.normalizePair(pair);
    this.pairs.add(normalized);
    const productId = normalized.replace("/", "-");
    if (this.ws?.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify({ type: "subscribe", product_ids: [productId], channels: ["level2_batch"] }));
    }
  }

  async unsubscribeOrderBook(pair: string): Promise<void> {
    const normalized = this.normalizePair(pair);
    const productId = normalized.replace("/", "-");
    if (this.ws?.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify({ type: "unsubscribe", product_ids: [productId], channels: ["level2_batch"] }));
    }
  }

  async subscribeTrades(pair: string): Promise<void> {
    const normalized = this.normalizePair(pair);
    this.pairs.add(normalized);
    const productId = normalized.replace("/", "-");
    if (this.ws?.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify({ type: "subscribe", product_ids: [productId], channels: ["matches"] }));
    }
  }

  async unsubscribeTrades(pair: string): Promise<void> {
    const normalized = this.normalizePair(pair);
    const productId = normalized.replace("/", "-");
    if (this.ws?.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify({ type: "unsubscribe", product_ids: [productId], channels: ["matches"] }));
    }
  }

  async subscribeCandles(pair: string, _timeframe: string): Promise<void> {
    // Coinbase doesn't have real-time candle WebSocket
    this.pairs.add(this.normalizePair(pair));
    logger.info(`Coinbase candles not available via WebSocket, use REST for ${pair}`);
  }

  async unsubscribeCandles(_pair: string, _timeframe: string): Promise<void> {
    // No-op
  }

  async fetchHistoricalOHLCV(pair: string, timeframe: string, since?: number, limit: number = 500): Promise<OHLCV[]> {
    try {
      const ohlcv = await this.rest.fetchOHLCV(pair, timeframe, since, limit);
      return ohlcv.map((candle: any) => ({
        timestamp: candle[0],
        open: candle[1],
        high: candle[2],
        low: candle[3],
        close: candle[4],
        volume: candle[5],
      }));
    } catch (error) {
      logger.error(`Failed to fetch OHLCV for ${pair} from Coinbase`, { error });
      throw error;
    }
  }

  async fetchTicker(pair: string): Promise<Ticker> {
    const ticker = await this.rest.fetchTicker(pair);
    return {
      symbol: pair,
      last: ticker.last || 0,
      bid: ticker.bid || 0,
      ask: ticker.ask || 0,
      high24h: ticker.high || 0,
      low24h: ticker.low || 0,
      volume24h: ticker.baseVolume || 0,
      quoteVolume24h: ticker.quoteVolume || 0,
      change24h: ticker.change || 0,
      changePercent24h: ticker.percentage || 0,
      timestamp: ticker.timestamp || Date.now(),
    };
  }

  async fetchOrderBook(pair: string, depth: number = 50): Promise<OrderBook> {
    const ob = await this.rest.fetchOrderBook(pair, depth);
    return {
      symbol: pair,
      bids: ob.bids.map(([p, q]: number[]) => ({ price: p, quantity: q })),
      asks: ob.asks.map(([p, q]: number[]) => ({ price: p, quantity: q })),
      timestamp: Date.now(),
      exchange: "coinbase",
    };
  }
}