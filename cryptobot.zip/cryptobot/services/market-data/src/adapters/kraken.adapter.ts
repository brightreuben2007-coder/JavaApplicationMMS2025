import { ExchangeAdapter } from "./exchange.adapter";
import type { Ticker, OHLCV, OrderBook, TradeTick } from "./exchange.adapter";
import ccxt, { kraken } from "ccxt";
import WebSocket from "ws";
import { logger } from "../utils/logger";

/**
 * Kraken exchange adapter using WebSocket streams.
 */
export class KrakenAdapter extends ExchangeAdapter {
  private ws: WebSocket | null = null;
  private wsUrl: string = "wss://ws.kraken.com/v2";
  private rest: kraken;
  private pingInterval: NodeJS.Timeout | null = null;
  private orderBookCache: Map<string, { bids: Map<number, number>; asks: Map<number, number>; timestamp: number }> = new Map();
  private symbolMap: Map<string, string> = new Map(); // pair -> Kraken symbol

  constructor() {
    super("kraken");
    this.rest = new ccxt.kraken({
      enableRateLimit: true,
    }) as kraken;
  }

  /**
   * Convert our pair format (BTC/USDT) to Kraken format (XBT/USDT).
   */
  private toKrakenSymbol(pair: string): string {
    const normalized = this.normalizePair(pair);
    const [base, quote] = normalized.split("/");
    // Kraken uses XBT for Bitcoin
    const krakenBase = base === "BTC" ? "XBT" : base;
    return `${krakenBase}/${quote}`;
  }

  async connect(): Promise<void> {
    if (this.isConnected) return;

    return new Promise((resolve, reject) => {
      this.ws = new WebSocket(this.wsUrl);

      this.ws.on("open", () => {
        this.isConnected = true;
        this.resetReconnect();
        this.startPing();
        logger.info("Kraken WebSocket connected");
        this.emit("onConnected");
        this.resubscribeAll();
        resolve();
      });

      this.ws.on("message", (data: WebSocket.Data) => {
        try {
          const message = JSON.parse(data.toString());
          this.handleMessage(message);
        } catch (error) {
          logger.error("Failed to parse Kraken WebSocket message", { error });
        }
      });

      this.ws.on("error", (error) => {
        logger.error("Kraken WebSocket error", { error: error.message });
        this.emit("onError", error);
      });

      this.ws.on("close", (code) => {
        this.isConnected = false;
        this.stopPing();
        logger.warn(`Kraken WebSocket closed: ${code}`);
        this.scheduleReconnect();
      });

      setTimeout(() => {
        if (!this.isConnected) reject(new Error("Kraken WebSocket connection timeout"));
      }, 15000);
    });
  }

  async disconnect(): Promise<void> {
    this.stopPing();
    if (this.ws) {
      this.ws.close(1000, "Client disconnect");
      this.ws = null;
    }
    this.isConnected = false;
    this.orderBookCache.clear();
  }

  private startPing(): void {
    this.stopPing();
    this.pingInterval = setInterval(() => {
      if (this.ws?.readyState === WebSocket.OPEN) {
        this.ws.send(JSON.stringify({ method: "ping" }));
      }
    }, 30000);
  }

  private stopPing(): void {
    if (this.pingInterval) {
      clearInterval(this.pingInterval);
      this.pingInterval = null;
    }
  }

  private async resubscribeAll(): Promise<void> {
    const subscriptions: any[] = [];
    for (const pair of this.pairs) {
      const symbol = this.toKrakenSymbol(pair).replace("/", "");
      subscriptions.push({ name: "ticker", token: symbol });
      subscriptions.push({ name: "book", token: symbol, depth: 25 });
      subscriptions.push({ name: "trade", token: symbol });
    }
    if (subscriptions.length > 0 && this.ws?.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify({ method: "subscribe", params: subscriptions }));
    }
  }

  private handleMessage(message: any): void {
    if (message.method === "pong") return;

    // Handle ticker
    if (message.channel === "ticker" && message.data) {
      for (const tickerData of message.data) {
        const pair = this.krakenSymbolToPair(tickerData.symbol || "");
        if (pair) {
          this.emit("onTicker", {
            symbol: pair,
            last: parseFloat(tickerData.last || "0"),
            bid: parseFloat(tickerData.bid || "0"),
            ask: parseFloat(tickerData.ask || "0"),
            high24h: parseFloat(tickerData.high || "0"),
            low24h: parseFloat(tickerData.low || "0"),
            volume24h: parseFloat(tickerData.volume || "0"),
            quoteVolume24h: parseFloat(tickerData.volume || "0") * parseFloat(tickerData.last || "0"),
            change24h: 0,
            changePercent24h: parseFloat((tickerData.change || "0")) * 100,
            timestamp: Date.now(),
          });
        }
      }
    }

    // Handle order book
    if (message.channel === "book" && message.data) {
      for (const bookData of message.data) {
        const pair = this.krakenSymbolToPair(bookData.symbol || "");
        if (pair) {
          this.handleOrderBookUpdate(pair, bookData);
        }
      }
    }

    // Handle trades
    if (message.channel === "trade" && message.data) {
      for (const tradeData of message.data) {
        const pair = this.krakenSymbolToPair(tradeData.symbol || "");
        if (pair) {
          this.emit("onTrade", {
            id: tradeData.ordertxid || tradeData.trade_id?.toString() || "",
            price: parseFloat(tradeData.price || "0"),
            quantity: parseFloat(tradeData.qty || tradeData.volume || "0"),
            side: tradeData.side === "sell" ? "sell" : "buy",
            timestamp: Date.now(),
          });
        }
      }
    }
  }

  private handleOrderBookUpdate(pair: string, data: any): void {
    let cache = this.orderBookCache.get(pair);
    if (!cache) {
      cache = { bids: new Map(), asks: new Map(), timestamp: Date.now() };
      this.orderBookCache.set(pair, cache);
    }

    // Snapshot
    if (data.bs) for (const [price, qty] of data.bs) {
      const q = parseFloat(qty);
      q === 0 ? cache.bids.delete(parseFloat(price)) : cache.bids.set(parseFloat(price), q);
    }
    if (data.as) for (const [price, qty] of data.as) {
      const q = parseFloat(qty);
      q === 0 ? cache.asks.delete(parseFloat(price)) : cache.asks.set(parseFloat(price), q);
    }

    // Delta (Kraken uses "b"/"a" for updates)
    if (data.b) for (const [price, qty] of data.b) {
      const q = parseFloat(qty);
      q === 0 ? cache.bids.delete(parseFloat(price)) : cache.bids.set(parseFloat(price), q);
    }
    if (data.a) for (const [price, qty] of data.a) {
      const q = parseFloat(qty);
      q === 0 ? cache.asks.delete(parseFloat(price)) : cache.asks.set(parseFloat(price), q);
    }

    cache.timestamp = Date.now();

    this.emit("onOrderBook", {
      symbol: pair,
      bids: Array.from(cache.bids.entries()).sort(([a], [b]) => b - a).slice(0, 25).map(([p, q]) => ({ price: p, quantity: q })),
      asks: Array.from(cache.asks.entries()).sort(([a], [b]) => a - b).slice(0, 25).map(([p, q]) => ({ price: p, quantity: q })),
      timestamp: cache.timestamp,
      exchange: "kraken",
    });
  }

  private krakenSymbolToPair(krakenSymbol: string): string | null {
    // Kraken uses XBT instead of BTC
    const normalized = krakenSymbol.replace("XBT", "BTC");
    // Kraken symbols like "BTC/USD" — need to split correctly
    if (!normalized.includes("/")) {
      // Try to infer from known quote currencies
      for (const quote of ["USD", "USDT", "USDC", "EUR"]) {
        if (normalized.endsWith(quote)) {
          const base = normalized.slice(0, -quote.length);
          return `${base}/${quote}`;
        }
      }
      return null;
    }
    return normalized;
  }

  async subscribeTicker(pair: string): Promise<void> {
    const normalized = this.normalizePair(pair);
    this.pairs.add(normalized);
    const symbol = this.toKrakenSymbol(normalized).replace("/", "");
    if (this.ws?.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify({ method: "subscribe", params: [{ name: "ticker", token: symbol }] }));
    }
  }

  async unsubscribeTicker(pair: string): Promise<void> {
    const normalized = this.normalizePair(pair);
    const symbol = this.toKrakenSymbol(normalized).replace("/", "");
    if (this.ws?.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify({ method: "unsubscribe", params: [{ name: "ticker", token: symbol }] }));
    }
  }

  async subscribeOrderBook(pair: string, depth: number = 25): Promise<void> {
    const normalized = this.normalizePair(pair);
    this.pairs.add(normalized);
    const symbol = this.toKrakenSymbol(normalized).replace("/", "");
    if (this.ws?.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify({ method: "subscribe", params: [{ name: "book", token: symbol, depth }] }));
    }
  }

  async unsubscribeOrderBook(pair: string): Promise<void> {
    const normalized = this.normalizePair(pair);
    this.pairs.add(normalized);
    const symbol = this.toKrakenSymbol(normalized).replace("/", "");
    if (this.ws?.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify({ method: "unsubscribe", params: [{ name: "book", token: symbol }] }));
    }
  }

  async subscribeTrades(pair: string): Promise<void> {
    const normalized = this.normalizePair(pair);
    this.pairs.add(normalized);
    const symbol = this.toKrakenSymbol(normalized).replace("/", "");
    if (this.ws?.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify({ method: "subscribe", params: [{ name: "trade", token: symbol }] }));
    }
  }

  async unsubscribeTrades(pair: string): Promise<void> {
    const normalized = this.normalizePair(pair);
    const symbol = this.toKrakenSymbol(normalized).replace("/", "");
    if (this.ws?.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify({ method: "unsubscribe", params: [{ name: "trade", token: symbol }] }));
    }
  }

  async subscribeCandles(pair: string, timeframe: string): Promise<void> {
    // Kraken doesn't have real-time candle WebSocket — use REST polling
    this.pairs.add(this.normalizePair(pair));
    logger.info(`Kraken candles not available via WebSocket, use REST for ${pair} ${timeframe}`);
  }

  async unsubscribeCandles(_pair: string, _timeframe: string): Promise<void> {
    // No-op for Kraken
  }

  async fetchHistoricalOHLCV(pair: string, timeframe: string, since?: number, limit: number = 500): Promise<OHLCV[]> {
    try {
      const krakenPair = this.toKrakenSymbol(pair);
      const ohlcv = await this.rest.fetchOHLCV(krakenPair, timeframe, since, limit);
      return ohlcv.map((candle: any) => ({
        timestamp: candle[0],
        open: candle[1],
        high: candle[2],
        low: candle[3],
        close: candle[4],
        volume: candle[5],
      }));
    } catch (error) {
      logger.error(`Failed to fetch OHLCV for ${pair} from Kraken`, { error });
      throw error;
    }
  }

  async fetchTicker(pair: string): Promise<Ticker> {
    const krakenPair = this.toKrakenSymbol(pair);
    const ticker = await this.rest.fetchTicker(krakenPair);
    return {
      symbol: pair,
      last: ticker.last || 0,
      bid: ticker.bid || 0,
      ask: ticker.ask || 0,
      high24h: ticker.high || 0,
      low24h: ticker.low || 0,
      volume24h: ticker.baseVolume || 0,
      quoteVolume24h: ticker.quoteVolume || 0,
      change24h: ticker.change || 0,
      changePercent24h: ticker.percentage || 0,
      timestamp: ticker.timestamp || Date.now(),
    };
  }

  async fetchOrderBook(pair: string, depth: number = 25): Promise<OrderBook> {
    const krakenPair = this.toKrakenSymbol(pair);
    const ob = await this.rest.fetchOrderBook(krakenPair, depth);
    return {
      symbol: pair,
      bids: ob.bids.map(([p, q]: number[]) => ({ price: p, quantity: q })),
      asks: ob.asks.map(([p, q]: number[]) => ({ price: p, quantity: q })),
      timestamp: Date.now(),
      exchange: "kraken",
    };
  }
}