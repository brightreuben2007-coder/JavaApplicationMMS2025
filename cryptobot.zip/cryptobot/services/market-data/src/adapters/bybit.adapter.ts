import { ExchangeAdapter } from "./exchange.adapter";
import type { Ticker, OHLCV, OrderBook, TradeTick, FundingRate } from "./exchange.adapter";
import ccxt, { bybit } from "ccxt";
import WebSocket from "ws";
import { logger } from "../utils/logger";

/**
 * Bybit exchange adapter using WebSocket streams.
 * Handles spot, USDT perpetuals, and inverse perpetuals.
 */
export class BybitAdapter extends ExchangeAdapter {
  private ws: WebSocket | null = null;
  private wsSpotUrl: string = "wss://stream.bybit.com/v5/public/spot";
  private wsLinearUrl: string = "wss://stream.bybit.com/v5/public/linear";
  private wsInverseUrl: string = "wss://stream.bybit.com/v5/public/inverse";
  private rest: bybit;
  private marketType: "spot" | "linear" | "inverse";
  private pingInterval: NodeJS.Timeout | null = null;
  private orderBookCache: Map<string, { bids: Map<number, number>; asks: Map<number, number>; timestamp: number }> = new Map();
  private requestId: number = 0;
  private pendingRequests: Map<string, { resolve: (value: any) => void; reject: (error: Error) => void; timeout: NodeJS.Timeout }> = new Map();

  constructor(marketType: "spot" | "linear" | "inverse" = "spot") {
    super("bybit");
    this.marketType = marketType;
    this.rest = new ccxt.bybit({
      enableRateLimit: true,
      options: {
        defaultType: marketType === "spot" ? "spot" : marketType === "linear" ? "linear" : "inverse",
      },
    }) as bybit;
  }

  private get wsUrl(): string {
    switch (this.marketType) {
      case "spot": return this.wsSpotUrl;
      case "linear": return this.wsLinearUrl;
      case "inverse": return this.wsInverseUrl;
      default: return this.wsSpotUrl;
    }
  }

  async connect(): Promise<void> {
    if (this.isConnected) return;

    return new Promise((resolve, reject) => {
      this.ws = new WebSocket(this.wsUrl);

      this.ws.on("open", () => {
        this.isConnected = true;
        this.resetReconnect();
        this.startPing();
        logger.info(`Bybit WebSocket connected (${this.marketType})`);
        this.emit("onConnected");
        this.resubscribeAll();
        resolve();
      });

      this.ws.on("message", (data: WebSocket.Data) => {
        try {
          const message = JSON.parse(data.toString());
          this.handleMessage(message);
        } catch (error) {
          logger.error("Failed to parse Bybit WebSocket message", { error });
        }
      });

      this.ws.on("error", (error) => {
        logger.error("Bybit WebSocket error", { error: error.message });
        this.emit("onError", error);
      });

      this.ws.on("close", (code, reason) => {
        this.isConnected = false;
        this.stopPing();
        logger.warn(`Bybit WebSocket closed: ${code}`);
        this.scheduleReconnect();
      });

      setTimeout(() => {
        if (!this.isConnected) reject(new Error("Bybit WebSocket connection timeout"));
      }, 15000);
    });
  }

  async disconnect(): Promise<void> {
    this.stopPing();
    if (this.ws) {
      this.ws.close(1000, "Client disconnect");
      this.ws = null;
    }
    this.isConnected = false;
    this.orderBookCache.clear();
  }

  private startPing(): void {
    this.stopPing();
    this.pingInterval = setInterval(() => {
      if (this.ws?.readyState === WebSocket.OPEN) {
        this.ws.send(JSON.stringify({ req_id: String(++this.requestId), op: "ping" }));
      }
    }, 20000);
  }

  private stopPing(): void {
    if (this.pingInterval) {
      clearInterval(this.pingInterval);
      this.pingInterval = null;
    }
  }

  private sendSubscribe(topics: string[]): void {
    if (this.ws?.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify({
        req_id: String(++this.requestId),
        op: "subscribe",
        args: topics,
      }));
    }
  }

  private sendUnsubscribe(topics: string[]): void {
    if (this.ws?.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify({
        req_id: String(++this.requestId),
        op: "unsubscribe",
        args: topics,
      }));
    }
  }

  private async resubscribeAll(): Promise<void> {
    // Bybit uses V5 format: {topic}.{interval?}.{symbol}
    const topics: string[] = [];
    for (const pair of this.pairs) {
      const symbol = pair.replace("/", "").toUpperCase();
      topics.push(`tickers.${symbol}`);
      topics.push(`orderbook.50.${symbol}`);
      topics.push(`publicTrade.${symbol}`);
    }
    if (topics.length > 0) this.sendSubscribe(topics);
  }

  private handleMessage(message: any): void {
    // Handle pong
    if (message.op === "pong") return;

    // Handle subscription response
    if (message.op === "subscribe" || message.op === "unsubscribe") {
      logger.debug(`Bybit ${message.op}: ${message.success ? "success" : "failed"}`);
      return;
    }

    // Handle data
    if (message.topic && message.data) {
      this.handleTopicMessage(message.topic, message.data, message.type);
    }
  }

  private handleTopicMessage(topic: string, data: any, type: string): void {
    const parts = topic.split(".");
    const topicType = parts[0] || "";
    const symbol = parts[1] || "";
    const pair = symbol
      ? `${symbol.slice(0, -4)}/${symbol.slice(-4)}`
      : "unknown";

    switch (topicType) {
      case "tickers": {
        const t = Array.isArray(data) ? data[0] : data;
        if (!t) return;
        this.emit("onTicker", this.parseTicker(pair, t));
        break;
      }

      case "orderbook": {
        this.handleOrderBookData(pair, data, type);
        break;
      }

      case "publicTrade": {
        const trades = Array.isArray(data) ? data : [data];
        for (const trade of trades) {
          this.emit("onTrade", {
            id: trade.i || trade.T?.toString() || "",
            price: parseFloat(trade.p || "0"),
            quantity: parseFloat(trade.v || "0"),
            side: trade.S === "Buy" ? "buy" : "sell",
            timestamp: parseInt(trade.T || "0") || Date.now(),
          });
        }
        break;
      }
    }
  }

  private parseTicker(pair: string, data: any): Ticker {
    return {
      symbol: pair,
      last: parseFloat(data.lastPrice || data.indexPrice || "0"),
      bid: parseFloat(data.bid1Price || data.bidPrice || "0"),
      ask: parseFloat(data.ask1Price || data.askPrice || "0"),
      high24h: parseFloat(data.highPrice24h || "0"),
      low24h: parseFloat(data.lowPrice24h || "0"),
      volume24h: parseFloat(data.volume24h || data.turnover24h || "0"),
      quoteVolume24h: parseFloat(data.turnover24h || "0"),
      change24h: parseFloat((data.price24hPcnt || "0")) * 100,
      changePercent24h: parseFloat((data.price24hPcnt || "0")) * 100,
      timestamp: parseInt(data.ts || "0") || Date.now(),
    };
  }

  private handleOrderBookData(pair: string, data: any, type: string): void {
    let cache = this.orderBookCache.get(pair);
    if (!cache) {
      cache = { bids: new Map(), asks: new Map(), timestamp: Date.now() };
      this.orderBookCache.set(pair, cache);
    }

    if (type === "snapshot") {
      cache.bids.clear();
      cache.asks.clear();

      if (data.b) for (const [price, qty] of data.b) {
        const q = parseFloat(qty);
        if (q > 0) cache.bids.set(parseFloat(price), q);
      }
      if (data.a) for (const [price, qty] of data.a) {
        const q = parseFloat(qty);
        if (q > 0) cache.asks.set(parseFloat(price), q);
      }
    } else {
      // Delta
      if (data.b) for (const [price, qty] of data.b) {
        const q = parseFloat(qty);
        q === 0 ? cache.bids.delete(parseFloat(price)) : cache.bids.set(parseFloat(price), q);
      }
      if (data.a) for (const [price, qty] of data.a) {
        const q = parseFloat(qty);
        q === 0 ? cache.asks.delete(parseFloat(price)) : cache.asks.set(parseFloat(price), q);
      }
    }

    cache.timestamp = Date.now();

    const orderBook: OrderBook = {
      symbol: pair,
      bids: Array.from(cache.bids.entries()).sort(([a], [b]) => b - a).slice(0, 50).map(([p, q]) => ({ price: p, quantity: q })),
      asks: Array.from(cache.asks.entries()).sort(([a], [b]) => a - b).slice(0, 50).map(([p, q]) => ({ price: p, quantity: q })),
      timestamp: cache.timestamp,
      exchange: "bybit",
    };

    this.emit("onOrderBook", orderBook);
  }

  async subscribeTicker(pair: string): Promise<void> {
    const normalized = this.normalizePair(pair);
    this.pairs.add(normalized);
    const symbol = normalized.replace("/", "").toUpperCase();
    this.sendSubscribe([`tickers.${symbol}`]);
  }

  async unsubscribeTicker(pair: string): Promise<void> {
    const normalized = this.normalizePair(pair);
    const symbol = normalized.replace("/", "").toUpperCase();
    this.sendUnsubscribe([`tickers.${symbol}`]);
  }

  async subscribeOrderBook(pair: string, depth: number = 50): Promise<void> {
    const normalized = this.normalizePair(pair);
    this.pairs.add(normalized);
    const symbol = normalized.replace("/", "").toUpperCase();
    this.sendSubscribe([`orderbook.${depth}.${symbol}`]);
  }

  async unsubscribeOrderBook(pair: string): Promise<void> {
    const normalized = this.normalizePair(pair);
    const symbol = normalized.replace("/", "").toUpperCase();
    this.sendUnsubscribe([`orderbook.50.${symbol}`]);
  }

  async subscribeTrades(pair: string): Promise<void> {
    const normalized = this.normalizePair(pair);
    this.pairs.add(normalized);
    const symbol = normalized.replace("/", "").toUpperCase();
    this.sendSubscribe([`publicTrade.${symbol}`]);
  }

  async unsubscribeTrades(pair: string): Promise<void> {
    const normalized = this.normalizePair(pair);
    const symbol = normalized.replace("/", "").toUpperCase();
    this.sendUnsubscribe([`publicTrade.${symbol}`]);
  }

  async subscribeCandles(pair: string, timeframe: string): Promise<void> {
    const normalized = this.normalizePair(pair);
    this.pairs.add(normalized);
    const symbol = normalized.replace("/", "").toUpperCase();
    // Bybit uses kline.{interval}.{symbol}
    this.sendSubscribe([`kline.${timeframe}.${symbol}`]);

    // Handle kline messages in handleTopicMessage
    const originalHandler = this.handleTopicMessage.bind(this);
    this.handleTopicMessage = (topic: string, data: any, type: string) => {
      const tParts = topic.split(".");
      if (tParts[0] === "kline") {
        const candles = Array.isArray(data) ? data : [data];
        for (const candle of candles) {
          this.emit("onCandle", {
            timestamp: parseInt(candle.start || candle.t || "0"),
            open: parseFloat(candle.open || candle.o || "0"),
            high: parseFloat(candle.high || candle.h || "0"),
            low: parseFloat(candle.low || candle.l || "0"),
            close: parseFloat(candle.close || candle.c || "0"),
            volume: parseFloat(candle.volume || candle.v || "0"),
          });
        }
        return;
      }
      originalHandler(topic, data, type);
    };
  }

  async unsubscribeCandles(pair: string, timeframe: string): Promise<void> {
    const normalized = this.normalizePair(pair);
    const symbol = normalized.replace("/", "").toUpperCase();
    this.sendUnsubscribe([`kline.${timeframe}.${symbol}`]);
  }

  async fetchHistoricalOHLCV(pair: string, timeframe: string, since?: number, limit: number = 500): Promise<OHLCV[]> {
    try {
      const ohlcv = await this.rest.fetchOHLCV(pair, timeframe, since, limit);
      return ohlcv.map((candle: any) => ({
        timestamp: candle[0],
        open: candle[1],
        high: candle[2],
        low: candle[3],
        close: candle[4],
        volume: candle[5],
      }));
    } catch (error) {
      logger.error(`Failed to fetch OHLCV for ${pair} from Bybit`, { error });
      throw error;
    }
  }

  async fetchTicker(pair: string): Promise<Ticker> {
    const ticker = await this.rest.fetchTicker(pair);
    return {
      symbol: pair,
      last: ticker.last || 0,
      bid: ticker.bid || 0,
      ask: ticker.ask || 0,
      high24h: ticker.high || 0,
      low24h: ticker.low || 0,
      volume24h: ticker.baseVolume || 0,
      quoteVolume24h: ticker.quoteVolume || 0,
      change24h: ticker.change || 0,
      changePercent24h: ticker.percentage || 0,
      timestamp: ticker.timestamp || Date.now(),
    };
  }

  async fetchOrderBook(pair: string, depth: number = 50): Promise<OrderBook> {
    const ob = await this.rest.fetchOrderBook(pair, depth);
    return {
      symbol: pair,
      bids: ob.bids.map(([p, q]: number[]) => ({ price: p, quantity: q })),
      asks: ob.asks.map(([p, q]: number[]) => ({ price: p, quantity: q })),
      timestamp: Date.now(),
      exchange: "bybit",
    };
  }

  async fetchFundingRate(pair: string): Promise<FundingRate> {
    if (this.marketType === "spot") throw new Error("Funding rate not available for spot");
    const info = await this.rest.fetchFundingRate(pair);
    return {
      symbol: pair,
      rate: info.fundingRate || 0,
      nextFundingTimestamp: info.fundingTimestamp || 0,
      markPrice: info.markPrice || 0,
      indexPrice: info.indexPrice || 0,
    };
  }
}