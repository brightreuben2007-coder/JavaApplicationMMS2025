import { PredictionService } from "../predictionService";
import { ModelRegistry } from "../modelRegistry";

describe("Prediction Service", () => {
  let predictionService: PredictionService;
  let modelRegistry: ModelRegistry;

  beforeEach(() => {
    modelRegistry = new ModelRegistry("/tmp/test-models");
    predictionService = new PredictionService(modelRegistry);
  });

  it("should update feature history", () => {
    const candle = {
      timestamp: Date.now(),
      open: 50000,
      high: 51000,
      low: 49000,
      close: 50500,
      volume: 100,
    };

    predictionService.updateFeatureHistory("BTC/USDT", candle);

    // Add more candles to build history
    for (let i = 0; i < 80; i++) {
      predictionService.updateFeatureHistory("BTC/USDT", {
        timestamp: Date.now() + i * 3600000,
        open: 50000 + i * 10,
        high: 51000 + i * 10,
        low: 49000 + i * 10,
        close: 50500 + i * 10,
        volume: 100 + i,
      });
    }

    expect(predictionService.hasEnoughHistory("BTC/USDT")).toBe(true);
  });

  it("should return null for untrained model", async () => {
    const result = await predictionService.predict("nonexistent-model", "BTC/USDT");
    expect(result).toBeNull();
  });

  it("should return features for a pair", () => {
    const candle = {
      timestamp: Date.now(),
      open: 50000,
      high: 51000,
      low: 49000,
      close: 50500,
      volume: 100,
    };

    for (let i = 0; i < 80; i++) {
      predictionService.updateFeatureHistory("ETH/USDT", {
        timestamp: Date.now() + i * 3600000,
        open: 3000 + i,
        high: 3100 + i,
        low: 2900 + i,
        close: 3050 + i,
        volume: 50 + i,
      });
    }

    const features = predictionService.getLatestFeatures("ETH/USDT");
    expect(features).not.toBeNull();
    expect(features?.features.length).toBeGreaterThan(0);
  });

  it("should return null for unknown pair", () => {
    const features = predictionService.getLatestFeatures("UNKNOWN/USDT");
    expect(features).toBeNull();
  });
});