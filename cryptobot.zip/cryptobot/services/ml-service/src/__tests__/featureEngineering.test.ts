import { FeatureEngineering } from "../featureEngineering";

describe("Feature Engineering", () => {
  let fe: FeatureEngineering;

  // Generate 100 synthetic candles
  const generateCandles = (count: number = 100) => {
    const candles: any[] = [];
    let price = 50000;
    const now = Date.now();

    for (let i = 0; i < count; i++) {
      const change = (Math.random() - 0.5) * 0.02;
      const open = price;
      const close = open * (1 + change);
      candles.push({
        timestamp: now + i * 3600000,
        open,
        high: Math.max(open, close) * (1 + Math.random() * 0.01),
        low: Math.min(open, close) * (1 - Math.random() * 0.01),
        close,
        volume: Math.random() * 100 + 10,
      });
      price = close;
    }

    return candles;
  };

  beforeEach(() => {
    fe = new FeatureEngineering();
  });

  it("should engineer features from candles", () => {
    const candles = generateCandles(100);
    const featureSets = fe.engineerFeatures(candles);

    expect(featureSets.length).toBeGreaterThan(0);
    expect(featureSets[0]?.features.length).toBeGreaterThan(5);
    expect(featureSets[0]?.featureNames.length).toBe(featureSets[0]?.features.length);
  });

  it("should have valid targets (0 or 1)", () => {
    const candles = generateCandles(100);
    const featureSets = fe.engineerFeatures(candles);

    for (const fs of featureSets) {
      expect([0, 1]).toContain(fs.target);
    }
  });

  it("should throw for insufficient candles", () => {
    const candles = generateCandles(30);
    expect(() => fe.engineerFeatures(candles)).toThrow("at least 60");
  });

  it("should normalize features to approximately zero mean", () => {
    const candles = generateCandles(100);
    const featureSets = fe.engineerFeatures(candles);
    const { normalized, means } = fe.normalize(featureSets);

    expect(normalized.length).toBe(featureSets.length);
    // Means should be close to 0 after normalization
    for (const mean of means) {
      expect(Math.abs(mean)).toBeLessThan(10);
    }
  });

  it("should normalize a single sample with pre-computed stats", () => {
    const candles = generateCandles(100);
    const featureSets = fe.engineerFeatures(candles);
    const { means, stds } = fe.normalize(featureSets);

    const sample = featureSets[0]?.features || [];
    const normalized = fe.normalizeSingle(sample, means, stds);

    expect(normalized.length).toBe(sample.length);
  });

  it("should return feature names", () => {
    const names = fe.getFeatureNames();
    expect(names.length).toBeGreaterThan(0);
    expect(names).toContain("rsi_14");
    expect(names).toContain("bb_position");
  });

  it("should handle custom feature list", () => {
    const customFe = new FeatureEngineering(["rsi_14", "volume_ratio"]);
    const names = customFe.getFeatureNames();
    expect(names).toEqual(["rsi_14", "volume_ratio"]);
  });
});