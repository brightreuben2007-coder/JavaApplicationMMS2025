import { ModelRegistry } from "../modelRegistry";

describe("Model Registry", () => {
  let registry: ModelRegistry;

  beforeEach(() => {
    registry = new ModelRegistry("/tmp/test-models");
  });

  it("should save and retrieve model metadata", () => {
    const metadata = {
      type: "random_forest" as const,
      pair: "BTC/USDT",
      metrics: { accuracy: 0.75, precision: 0.72, recall: 0.68 },
      features: ["rsi_14", "ema_9_distance", "volume_ratio"],
      normalizer: { means: [0.5, 0, 1], stds: [0.3, 0.02, 0.5] },
      createdAt: new Date(),
    };

    registry.saveModelMetadata("user-1", "model-123", metadata);
    const retrieved = registry.getModelMetadata("model-123");

    expect(retrieved).not.toBeNull();
    expect(retrieved?.type).toBe("random_forest");
    expect(retrieved?.pair).toBe("BTC/USDT");
    expect(retrieved?.metrics?.accuracy).toBe(0.75);
  });

  it("should return null for unknown model", () => {
    const meta = registry.getModelMetadata("nonexistent");
    expect(meta).toBeNull();
  });

  it("should store and retrieve model objects", () => {
    const model = { predict: () => "buy", isTrained: () => true };
    registry.storeModel("model:test-1", model);
    const retrieved = registry.getModel<typeof model>("model:test-1");
    expect(retrieved).toBe(model);
  });

  it("should list user models", () => {
    registry.saveModelMetadata("user-1", "model-a", {
      type: "xgboost",
      pair: "ETH/USDT",
      metrics: { accuracy: 0.8, precision: 0.78, recall: 0.75 },
      features: [],
      normalizer: { means: [], stds: [] },
      createdAt: new Date(),
    });

    registry.saveModelMetadata("user-1", "model-b", {
      type: "lstm",
      pair: "SOL/USDT",
      metrics: { accuracy: 0.72, precision: 0.70, recall: 0.65 },
      features: [],
      normalizer: { means: [], stds: [] },
      createdAt: new Date(),
    });

    const models = registry.listUserModels("user-1");
    expect(models.length).toBeGreaterThanOrEqual(2);
    expect(models.some((m) => m.type === "xgboost")).toBe(true);
    expect(models.some((m) => m.type === "lstm")).toBe(true);
  });

  it("should track predictions", () => {
    registry.saveModelMetadata("user-1", "model-track", {
      type: "random_forest",
      pair: "BTC/USDT",
      metrics: { accuracy: 0.75, precision: 0.72, recall: 0.68 },
      features: [],
      normalizer: { means: [], stds: [] },
      createdAt: new Date(),
    });

    registry.trackPrediction("model-track", true);
    registry.trackPrediction("model-track", true);
    registry.trackPrediction("model-track", false);

    const meta = registry.getModelMetadata("model-track");
    expect(meta?.totalPredictions).toBe(3);
    expect(meta?.correctPredictions).toBe(2);
  });
});