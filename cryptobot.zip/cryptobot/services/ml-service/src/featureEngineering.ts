import { logger } from "./utils/logger";

export interface OHLCV {
  timestamp: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

export interface FeatureSet {
  timestamp: number;
  features: number[];
  featureNames: string[];
  target: number | null; // 1 = price up, 0 = price down, null = no label
}

/**
 * Feature Engineering Pipeline.
 * Calculates technical indicators, creates lag features,
 * and normalizes all features for ML model consumption.
 */
export class FeatureEngineering {
  private selectedFeatures: string[];

  constructor(features?: string[]) {
    this.selectedFeatures = features || [
      "rsi_14",
      "ema_9_distance",
      "ema_21_distance",
      "ema_50_distance",
      "macd_histogram",
      "bb_position",
      "volume_ratio",
      "price_momentum_1",
      "price_momentum_3",
      "price_momentum_5",
      "candle_body_ratio",
      "high_low_ratio",
    ];
  }

  /**
   * Engineer features from OHLCV data.
   */
  engineerFeatures(candles: OHLCV[], predictionHorizon: number = 1): FeatureSet[] {
    if (candles.length < 60) {
      throw new Error(`Need at least 60 candles, got ${candles.length}`);
    }

    const closes = candles.map((c) => c.close);
    const highs = candles.map((c) => c.high);
    const lows = candles.map((c) => c.low);
    const volumes = candles.map((c) => c.volume);

    const featureSets: FeatureSet[] = [];

    // Calculate indicators
    const rsi14 = this.calculateRSI([...closes], 14);
    const ema9 = this.calculateEMA([...closes], 9);
    const ema21 = this.calculateEMA([...closes], 21);
    const ema50 = this.calculateEMA([...closes], 50);
    const bb = this.calculateBollingerBands([...closes], 20, 2);

    for (let i = 50; i < candles.length - predictionHorizon; i++) {
      const candle = candles[i]!;
      const features: number[] = [];
      const featureNames: string[] = [];

      // RSI
      const rsi = rsi14[i] ?? 50;
      features.push(rsi / 100);
      featureNames.push("rsi_14");

      // EMA distances (how far price is from EMA, normalized)
      const ema9Dist = ema9[i] ? (candle.close - ema9[i]) / ema9[i] : 0;
      const ema21Dist = ema21[i] ? (candle.close - ema21[i]) / ema21[i] : 0;
      const ema50Dist = ema50[i] ? (candle.close - ema50[i]) / ema50[i] : 0;
      features.push(ema9Dist, ema21Dist, ema50Dist);
      featureNames.push("ema_9_distance", "ema_21_distance", "ema_50_distance");

      // MACD histogram (simplified: EMA9 - EMA21)
      const macdHist = (ema9[i] ?? 0) - (ema21[i] ?? 0);
      const macdNorm = candle.close > 0 ? macdHist / candle.close : 0;
      features.push(macdNorm);
      featureNames.push("macd_histogram");

      // Bollinger Band position (0 = lower, 0.5 = middle, 1 = upper)
      const bbUpper = bb.upper[i] ?? candle.close;
      const bbLower = bb.lower[i] ?? candle.close;
      const bbRange = bbUpper - bbLower;
      const bbPosition = bbRange > 0 ? (candle.close - bbLower) / bbRange : 0.5;
      features.push(Math.max(0, Math.min(1, bbPosition)));
      featureNames.push("bb_position");

      // Volume ratio (current volume / 20-period average)
      const avgVolume = volumes.slice(Math.max(0, i - 20), i + 1).reduce((s, v) => s + v, 0) / Math.min(20, i + 1);
      const volRatio = avgVolume > 0 ? candle.volume / avgVolume : 1;
      features.push(Math.min(5, volRatio));
      featureNames.push("volume_ratio");

      // Price momentum (returns at different horizons)
      for (const horizon of [1, 3, 5]) {
        const pastIdx = i - horizon;
        const pastClose = pastIdx >= 0 ? (closes[pastIdx] ?? candle.close) : candle.close;
        const momentum = pastClose > 0 ? (candle.close - pastClose) / pastClose : 0;
        features.push(momentum);
        featureNames.push(`price_momentum_${horizon}`);
      }

      // Candle body ratio (body / high-low range)
      const body = Math.abs(candle.close - candle.open);
      const hlRange = candle.high - candle.low;
      const bodyRatio = hlRange > 0 ? body / hlRange : 0;
      features.push(bodyRatio);
      featureNames.push("candle_body_ratio");

      // High-Low ratio
      const hlRatio = candle.low > 0 ? (candle.high - candle.low) / candle.low : 0;
      features.push(hlRatio);
      featureNames.push("high_low_ratio");

      // Target: did price go up in the next `predictionHorizon` candles?
      const futureIdx = i + predictionHorizon;
      const futureClose = futureIdx < candles.length ? (closes[futureIdx] ?? candle.close) : candle.close;
      const target = futureClose > candle.close ? 1 : 0;

      featureSets.push({
        timestamp: candle.timestamp,
        features,
        featureNames,
        target,
      });
    }

    return featureSets;
  }

  /**
   * Normalize features to zero mean and unit variance.
   * Returns both normalized data and the scaler parameters.
   */
  normalize(featureSets: FeatureSet[]): { normalized: number[][]; means: number[]; stds: number[] } {
    if (featureSets.length === 0) {
      return { normalized: [], means: [], stds: [] };
    }

    const numFeatures = featureSets[0]?.features.length || 0;
    const means: number[] = new Array(numFeatures).fill(0);
    const stds: number[] = new Array(numFeatures).fill(0);

    // Calculate means
    for (const fs of featureSets) {
      for (let i = 0; i < numFeatures; i++) {
        means[i] += (fs.features[i] ?? 0);
      }
    }
    for (let i = 0; i < numFeatures; i++) {
      means[i] /= featureSets.length;
    }

    // Calculate standard deviations
    for (const fs of featureSets) {
      for (let i = 0; i < numFeatures; i++) {
        stds[i] += Math.pow((fs.features[i] ?? 0) - (means[i] ?? 0), 2);
      }
    }
    for (let i = 0; i < numFeatures; i++) {
      stds[i] = Math.sqrt((stds[i] ?? 0) / featureSets.length);
      if (stds[i] === 0) stds[i] = 1; // Avoid division by zero
    }

    // Apply normalization
    const normalized = featureSets.map((fs) =>
      fs.features.map((f, i) => (f - (means[i] ?? 0)) / (stds[i] ?? 1))
    );

    return { normalized, means, stds };
  }

  /**
   * Normalize a single feature vector using pre-computed means and stds.
   */
  normalizeSingle(features: number[], means: number[], stds: number[]): number[] {
    return features.map((f, i) => (f - (means[i] ?? 0)) / (stds[i] ?? 1));
  }

  // ============================================================
  // TECHNICAL INDICATORS
  // ============================================================

  private calculateRSI(closes: number[], period: number): (number | null)[] {
    const rsi: (number | null)[] = new Array(closes.length).fill(null);
    if (closes.length < period + 1) return rsi;

    let gains = 0;
    let losses = 0;

    for (let i = 1; i <= period; i++) {
      const diff = (closes[i] ?? 0) - (closes[i - 1] ?? 0);
      if (diff > 0) gains += diff;
      else losses -= diff;
    }

    let avgGain = gains / period;
    let avgLoss = losses / period;

    for (let i = period; i < closes.length; i++) {
      if (avgLoss === 0) {
        rsi[i] = 100;
      } else {
        const rs = avgGain / avgLoss;
        rsi[i] = 100 - 100 / (1 + rs);
      }

      const diff = (closes[i] ?? 0) - (closes[i - 1] ?? 0);
      if (diff > 0) {
        avgGain = (avgGain * (period - 1) + diff) / period;
        avgLoss = (avgLoss * (period - 1)) / period;
      } else {
        avgGain = (avgGain * (period - 1)) / period;
        avgLoss = (avgLoss * (period - 1) - diff) / period;
      }
    }

    return rsi;
  }

  private calculateEMA(values: number[], period: number): (number | null)[] {
    const ema: (number | null)[] = new Array(values.length).fill(null);
    if (values.length < period) return ema;

    const multiplier = 2 / (period + 1);

    // First EMA = SMA
    let sum = 0;
    for (let i = 0; i < period; i++) {
      sum += values[i] ?? 0;
    }
    ema[period - 1] = sum / period;

    for (let i = period; i < values.length; i++) {
      ema[i] = ((values[i] ?? 0) - (ema[i - 1] ?? 0)) * multiplier + (ema[i - 1] ?? 0);
    }

    return ema;
  }

  private calculateBollingerBands(
    closes: number[],
    period: number,
    stdDev: number
  ): { upper: (number | null)[]; middle: (number | null)[]; lower: (number | null)[] } {
    const upper: (number | null)[] = new Array(closes.length).fill(null);
    const middle: (number | null)[] = new Array(closes.length).fill(null);
    const lower: (number | null)[] = new Array(closes.length).fill(null);

    for (let i = period - 1; i < closes.length; i++) {
      const slice = closes.slice(i - period + 1, i + 1);
      const avg = slice.reduce((s, v) => s + v, 0) / period;
      const variance = slice.reduce((s, v) => s + (v - avg) ** 2, 0) / period;
      const std = Math.sqrt(variance);

      middle[i] = avg;
      upper[i] = avg + stdDev * std;
      lower[i] = avg - stdDev * std;
    }

    return { upper, middle, lower };
  }

  getFeatureNames(): string[] {
    return this.selectedFeatures;
  }

  getNumFeatures(): number {
    return this.selectedFeatures.length;
  }
}