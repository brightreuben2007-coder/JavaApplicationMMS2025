import fs from "node:fs";
import path from "node:path";
import { logger } from "./utils/logger";

export interface ModelMetadata {
  type: "random_forest" | "xgboost" | "lstm";
  pair: string;
  metrics: {
    accuracy: number;
    precision: number;
    recall: number;
    featureImportance?: number[];
  } | null;
  features: string[];
  normalizer: { means: number[]; stds: number[] };
  createdAt: Date;
  lastTrainedAt?: Date;
  totalPredictions?: number;
  correctPredictions?: number;
}

/**
 * Model Registry.
 * Manages model artifacts and metadata.
 * Stores models in memory for fast inference.
 */
export class ModelRegistry {
  private basePath: string;
  private metadata: Map<string, ModelMetadata> = new Map();
  private models: Map<string, any> = new Map();

  constructor(basePath: string = "/app/models") {
    this.basePath = basePath;
    this.ensureDirectory(basePath);
  }

  private ensureDirectory(dir: string): void {
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
      logger.info(`Created model directory: ${dir}`);
    }
  }

  /**
   * Get the file path for a model artifact.
   */
  getModelPath(userId: string, modelId: string, modelType: string): string {
    const dir = path.join(this.basePath, userId, modelId);
    this.ensureDirectory(dir);
    return dir;
  }

  /**
   * Save model metadata.
   */
  saveModelMetadata(userId: string, modelId: string, metadata: ModelMetadata): void {
    const key = `meta:${modelId}`;
    this.metadata.set(key, metadata);

    // Persist to disk
    const filePath = path.join(this.basePath, userId, modelId, "metadata.json");
    try {
      fs.writeFileSync(filePath, JSON.stringify(metadata, null, 2));
      logger.info(`Model metadata saved: ${modelId}`);
    } catch (error) {
      logger.error(`Failed to save model metadata: ${modelId}`, { error });
    }
  }

  /**
   * Get model metadata.
   */
  getModelMetadata(modelId: string): ModelMetadata | null {
    return this.metadata.get(`meta:${modelId}`) || null;
  }

  /**
   * Store a model object in memory.
   */
  storeModel(key: string, model: any): void {
    this.models.set(key, model);
    logger.debug(`Model stored in registry: ${key}`);
  }

  /**
   * Get a model object from memory.
   */
  getModel<T>(key: string): T | null {
    return (this.models.get(key) as T) || null;
  }

  /**
   * Remove a model.
   */
  removeModel(modelId: string): void {
    this.metadata.delete(`meta:${modelId}`);
    this.models.delete(`model:${modelId}`);
    logger.info(`Model removed: ${modelId}`);
  }

  /**
   * List all models for a user.
   */
  listUserModels(userId: string): Array<{
    modelId: string;
    type: string;
    pair: string;
    accuracy: number | null;
    createdAt: Date;
  }> {
    const models: Array<{
      modelId: string;
      type: string;
      pair: string;
      accuracy: number | null;
      createdAt: Date;
    }> = [];

    for (const [key, meta] of this.metadata.entries()) {
      const modelId = key.replace("meta:", "");
      if (modelId.startsWith(userId) || true) { // Simplified: all models
        models.push({
          modelId,
          type: meta.type,
          pair: meta.pair,
          accuracy: meta.metrics?.accuracy || null,
          createdAt: meta.createdAt,
        });
      }
    }

    return models.sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  /**
   * Update prediction tracking for a model.
   */
  trackPrediction(modelId: string, correct: boolean): void {
    const meta = this.metadata.get(`meta:${modelId}`);
    if (!meta) return;

    meta.totalPredictions = (meta.totalPredictions || 0) + 1;
    meta.correctPredictions = (meta.correctPredictions || 0) + (correct ? 1 : 0);
  }

  /**
   * Get the number of models in the registry.
   */
  getModelCount(): number {
    return this.metadata.size;
  }
}