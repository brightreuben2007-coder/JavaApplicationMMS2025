import dotenv from "dotenv";
dotenv.config();

import express from "express";
import helmet from "helmet";
import promClient from "prom-client";
import Redis from "ioredis";
import { v4 as uuidv4 } from "uuid";
import { FeatureEngineering, type OHLCV } from "./featureEngineering";
import { TrainingPipeline, type TrainingJob, type ModelType } from "./trainingPipeline";
import { PredictionService } from "./predictionService";
import { ModelRegistry } from "./modelRegistry";
import { logger } from "./utils/logger";
import { z } from "zod";

const app = express();
const PORT = parseInt(process.env.PORT || "3008", 10);
const REDIS_URL = process.env.REDIS_URL || "redis://localhost:6379";
const MODELS_DIR = process.env.MODELS_DIR || "/app/models";

// Metrics
const register = new promClient.Registry();
promClient.collectDefaultMetrics({ register, prefix: "ml_service_" });

const trainingCounter = new promClient.Counter({
  name: "ml_training_jobs_total",
  help: "Total training jobs",
  labelNames: ["modelType", "status"],
  registers: [register],
});

const predictionCounter = new promClient.Counter({
  name: "ml_predictions_total",
  help: "Total predictions made",
  labelNames: ["modelType", "signal"],
  registers: [register],
});

const activeModelsGauge = new promClient.Gauge({
  name: "ml_active_models",
  help: "Number of active models",
  registers: [register],
});

// Services
const modelRegistry = new ModelRegistry(MODELS_DIR);
const trainingPipeline = new TrainingPipeline(modelRegistry);
const predictionService = new PredictionService(modelRegistry);
const featureEngineering = new FeatureEngineering();

// Redis
const redis = new Redis(REDIS_URL, { maxRetriesPerRequest: 3 });
const subscriber = redis.duplicate();

// Express
app.use(helmet());
app.use(express.json({ limit: "5mb" }));

app.get("/health", (_req, res) => {
  res.json({
    status: "healthy",
    service: "ml-service",
    activeModels: modelRegistry.getModelCount(),
    uptime: process.uptime(),
  });
});

app.get("/metrics", async (_req, res) => {
  activeModelsGauge.set(modelRegistry.getModelCount());
  res.set("Content-Type", register.contentType);
  res.end(await register.metrics());
});

// Train a new model
app.post("/api/ml/train", async (req, res) => {
  try {
    const schema = z.object({
      userId: z.string(),
      name: z.string().min(1).max(255),
      pair: z.string(),
      exchange: z.string().default("binance"),
      timeframe: z.string().default("1h"),
      modelType: z.enum(["random_forest", "xgboost", "lstm"]),
      features: z.array(z.string()).min(2),
      predictionHorizon: z.number().int().min(1).max(100).default(1),
      lookbackPeriod: z.number().int().min(7).max(365).default(90),
    });

    const data = schema.parse(req.body);
    const modelId = uuidv4();

    const job: TrainingJob = {
      userId: data.userId,
      modelId,
      pair: data.pair,
      exchange: data.exchange,
      timeframe: data.timeframe,
      modelType: data.modelType,
      features: data.features,
      predictionHorizon: data.predictionHorizon,
      lookbackPeriod: data.lookbackPeriod,
      trainTestSplit: 0.8,
      status: "queued",
      progress: 0,
      metrics: null,
      error: null,
      startedAt: null,
      completedAt: null,
    };

    // Run training asynchronously
    trainingPipeline.runTraining(job).then(() => {
      trainingCounter.inc({ modelType: data.modelType, status: job.status });
      activeModelsGauge.set(modelRegistry.getModelCount());
    }).catch((err) => {
      logger.error(`Training failed for ${modelId}`, { error: err.message });
    });

    res.status(202).json({
      success: true,
      data: { modelId, name: data.name, status: "queued" },
    });
  } catch (error) {
    res.status(400).json({ success: false, error: { message: (error as Error).message } });
  }
});

// Get training job status
app.get("/api/ml/train/:modelId", (req, res) => {
  const job = trainingPipeline.getJobStatus(req.params.modelId);
  if (!job) {
    return res.status(404).json({ success: false, error: { message: "Job not found" } });
  }
  res.json({ success: true, data: job });
});

// Get prediction
app.post("/api/ml/predict", async (req, res) => {
  try {
    const { modelId, pair } = req.body;
    if (!modelId || !pair) {
      return res.status(400).json({ success: false, error: { message: "modelId and pair are required" } });
    }

    const prediction = await predictionService.predict(modelId, pair);

    if (prediction) {
      predictionCounter.inc({ modelType: prediction.modelType, signal: prediction.signal });

      // Publish to Redis for trading engine
      redis.publish("ml:prediction", JSON.stringify(prediction)).catch(() => {});
    }

    res.json({ success: true, data: prediction });
  } catch (error) {
    res.status(500).json({ success: false, error: { message: (error as Error).message } });
  }
});

// List user models
app.get("/api/ml/models/:userId", (_req, res) => {
  const models = modelRegistry.listUserModels(_req.params.userId);
  res.json({ success: true, data: models });
});

// Get model details
app.get("/api/ml/models/detail/:modelId", (req, res) => {
  const meta = modelRegistry.getModelMetadata(req.params.modelId);
  if (!meta) {
    return res.status(404).json({ success: false, error: { message: "Model not found" } });
  }
  res.json({ success: true, data: meta });
});

// Get feature names
app.get("/api/ml/features", (_req, res) => {
  res.json({ success: true, data: featureEngineering.getFeatureNames() });
});

// Redis listeners
async function setupRedisListeners(): Promise<void> {
  subscriber.subscribe("market:candles:*:*:*");

  subscriber.on("pmessage", async (_pattern, channel, message) => {
    try {
      const data = JSON.parse(message);
      const parts = channel.split(":");
      if (parts.length >= 5) {
        const pair = parts[3] || "";
        const timeframe = parts[4] || "";

        if (data.close) {
          const candle: OHLCV = {
            timestamp: data.timestamp || Date.now(),
            open: data.open,
            high: data.high,
            low: data.low,
            close: data.close,
            volume: data.volume || 0,
          };
          predictionService.updateFeatureHistory(pair, candle);
        }
      }
    } catch {
      // Ignore parse errors for non-JSON messages
    }
  });

  // Handle market data updates
  subscriber.subscribe("market:*:*:ticker");

  subscriber.on("pmessage", async (_pattern, channel, message) => {
    try {
      const data = JSON.parse(message);
      if (data.symbol) {
        // Update feature history with ticker data if available
        // This would be used for real-time feature updates
      }
    } catch {
      // Ignore
    }
  });

  logger.info("ML service Redis listeners active");
}

// Retraining scheduler (weekly)
function scheduleRetraining(): void {
  const WEEKLY = 7 * 24 * 60 * 60 * 1000;

  setInterval(async () => {
    logger.info("Starting weekly model retraining check...");
    // In production: iterate all active models and retrain with fresh data
    // This would be handled by the BullMQ scheduler or similar
  }, WEEKLY);

  logger.info("Weekly retraining scheduler active");
}

// Start
app.listen(PORT, async () => {
  await setupRedisListeners();
  scheduleRetraining();
  logger.info(`ML Service started on port ${PORT}`);
});

process.on("SIGTERM", async () => {
  logger.info("Shutting down ML service...");
  await redis.quit();
  await subscriber.quit();
  process.exit(0);
});