import { FeatureEngineering, type OHLCV } from "./featureEngineering";
import { RandomForestModel } from "./models/randomForest";
import { XGBoostModel } from "./models/xgboost";
import { LSTMModel } from "./models/lstm";
import { ModelRegistry } from "./modelRegistry";
import { logger } from "./utils/logger";
import ccxt from "ccxt";

export type ModelType = "random_forest" | "xgboost" | "lstm";

export interface TrainingJob {
  userId: string;
  modelId: string;
  pair: string;
  exchange: string;
  timeframe: string;
  modelType: ModelType;
  features: string[];
  predictionHorizon: number;
  lookbackPeriod: number;
  trainTestSplit: number;
  status: "queued" | "running" | "completed" | "failed";
  progress: number;
  metrics: Record<string, number> | null;
  error: string | null;
  startedAt: Date | null;
  completedAt: Date | null;
}

/**
 * Training Pipeline.
 * Orchestrates the full ML workflow:
 * 1. Fetch historical OHLCV data
 * 2. Engineer features
 * 3. Train model
 * 4. Evaluate on test set
 * 5. Save model artifact
 * 6. Record metadata
 */
export class TrainingPipeline {
  private featureEngineering: FeatureEngineering;
  private modelRegistry: ModelRegistry;
  private activeJobs: Map<string, TrainingJob> = new Map();
  private exchangeInstances: Map<string, any> = new Map();

  constructor(modelRegistry: ModelRegistry) {
    this.featureEngineering = new FeatureEngineering();
    this.modelRegistry = modelRegistry;
  }

  /**
   * Fetch historical OHLCV data from exchange.
   */
  async fetchData(
    exchangeId: string,
    pair: string,
    timeframe: string,
    since: number,
    limit: number = 1000
  ): Promise<OHLCV[]> {
    if (!this.exchangeInstances.has(exchangeId)) {
      const ExchangeClass = (ccxt as any)[exchangeId];
      if (!ExchangeClass) throw new Error(`Exchange ${exchangeId} not supported`);
      this.exchangeInstances.set(exchangeId, new ExchangeClass({ enableRateLimit: true }));
    }

    const exchange = this.exchangeInstances.get(exchangeId);

    try {
      const raw = await exchange.fetchOHLCV(pair, timeframe, since, limit);
      return raw.map((c: any) => ({
        timestamp: c[0],
        open: c[1],
        high: c[2],
        low: c[3],
        close: c[4],
        volume: c[5],
      }));
    } catch (error) {
      logger.error(`Failed to fetch OHLCV for ${pair} on ${exchangeId}`, { error });
      throw error;
    }
  }

  /**
   * Run a complete training job.
   */
  async runTraining(job: TrainingJob): Promise<void> {
    job.status = "running";
    job.startedAt = new Date();
    job.progress = 0;

    this.activeJobs.set(job.modelId, job);

    try {
      // Step 1: Fetch data
      logger.info(`Training job ${job.modelId}: Fetching data for ${job.pair}`);
      job.progress = 10;

      const since = Date.now() - job.lookbackPeriod * 24 * 3600000;
      const candles = await this.fetchData(job.exchange, job.pair, job.timeframe, since, 2000);

      if (candles.length < 100) {
        throw new Error(`Insufficient data: only ${candles.length} candles available`);
      }

      // Step 2: Engineer features
      logger.info(`Training job ${job.modelId}: Engineering features`);
      job.progress = 30;

      const featureSets = this.featureEngineering.engineerFeatures(candles, job.predictionHorizon);

      if (featureSets.length < 50) {
        throw new Error(`Only ${featureSets.length} feature sets created. Need at least 50.`);
      }

      // Normalize
      const { normalized, means, stds } = this.featureEngineering.normalize(featureSets);
      const labels = featureSets.map((fs) => fs.target).filter((t): t is number => t !== null);

      if (labels.length < 50) {
        throw new Error(`Only ${labels.length} valid labels after filtering`);
      }

      // Step 3: Train model
      logger.info(`Training job ${job.modelId}: Training ${job.modelType}`);
      job.progress = 50;

      const trainData = { features: normalized, labels };
      let metrics: {
        accuracy: number;
        precision: number;
        recall: number;
        featureImportance?: number[];
      } | null = null;

      switch (job.modelType) {
        case "random_forest": {
          const rf = new RandomForestModel({ nEstimators: 100, maxDepth: 10 });
          metrics = await rf.train(trainData);

          // Save model
          const modelPath = this.modelRegistry.getModelPath(job.userId, job.modelId, "random_forest");
          this.modelRegistry.saveModelMetadata(job.userId, job.modelId, {
            type: "random_forest",
            pair: job.pair,
            metrics,
            features: this.featureEngineering.getFeatureNames(),
            normalizer: { means, stds },
            createdAt: new Date(),
          });
          // Store model object for inference
          this.modelRegistry.storeModel(`model:${job.modelId}`, rf);
          break;
        }

        case "xgboost": {
          const xgb = new XGBoostModel({ nEstimators: 50, maxDepth: 6, learningRate: 0.1 });
          metrics = await xgb.train(trainData);

          const modelPath = this.modelRegistry.getModelPath(job.userId, job.modelId, "xgboost");
          this.modelRegistry.saveModelMetadata(job.userId, job.modelId, {
            type: "xgboost",
            pair: job.pair,
            metrics,
            features: this.featureEngineering.getFeatureNames(),
            normalizer: { means, stds },
            createdAt: new Date(),
          });
          this.modelRegistry.storeModel(`model:${job.modelId}`, xgb);
          break;
        }

        case "lstm": {
          const lstm = new LSTMModel({
            sequenceLength: 50,
            epochs: 50,
            batchSize: 32,
            lstmUnits: 64,
          });
          metrics = await lstm.train({
            features: normalized,
            labels,
            sequenceLength: 50,
          });

          const modelPath = this.modelRegistry.getModelPath(job.userId, job.modelId, "lstm");
          await lstm.save(modelPath);

          this.modelRegistry.saveModelMetadata(job.userId, job.modelId, {
            type: "lstm",
            pair: job.pair,
            metrics,
            features: this.featureEngineering.getFeatureNames(),
            normalizer: { means, stds },
            createdAt: new Date(),
          });
          this.modelRegistry.storeModel(`model:${job.modelId}`, lstm);
          break;
        }

        default:
          throw new Error(`Unknown model type: ${job.modelType}`);
      }

      // Step 4: Complete
      job.status = "completed";
      job.completedAt = new Date();
      job.progress = 100;
      job.metrics = metrics;

      logger.info(`Training job ${job.modelId} completed: accuracy=${((metrics?.accuracy || 0) * 100).toFixed(1)}%`);
    } catch (error) {
      job.status = "failed";
      job.error = (error as Error).message;
      logger.error(`Training job ${job.modelId} failed`, { error: (error as Error).message });
    }
  }

  /**
   * Get the status of a training job.
   */
  getJobStatus(modelId: string): TrainingJob | null {
    return this.activeJobs.get(modelId) || null;
  }

  /**
   * Get all active training jobs.
   */
  getActiveJobs(): TrainingJob[] {
    return Array.from(this.activeJobs.values());
  }
}