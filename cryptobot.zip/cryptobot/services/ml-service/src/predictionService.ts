import { FeatureEngineering, type OHLCV } from "./featureEngineering";
import { RandomForestModel } from "./models/randomForest";
import { XGBoostModel } from "./models/xgboost";
import { LSTMModel } from "./models/lstm";
import { ModelRegistry } from "./modelRegistry";
import { logger } from "./utils/logger";

export interface PredictionResult {
  signal: "buy" | "sell" | "hold";
  confidence: number;
  probabilities: { buy: number; sell: number };
  modelType: string;
  modelId: string;
  pair: string;
  featureNames: string[];
  timestamp: number;
}

export interface FeatureHistory {
  candles: OHLCV[];
  features: number[][];
  lastUpdated: number;
}

/**
 * Prediction Service.
 * Loads trained models and runs inference on live market data.
 * Maintains feature history for LSTM sequence prediction.
 */
export class PredictionService {
  private featureEngineering: FeatureEngineering;
  private modelRegistry: ModelRegistry;
  private featureHistories: Map<string, FeatureHistory> = new Map();
  private maxHistoryLength: number = 200;

  constructor(modelRegistry: ModelRegistry) {
    this.featureEngineering = new FeatureEngineering();
    this.modelRegistry = modelRegistry;
  }

  /**
   * Append new candle to feature history for a pair.
   */
  updateFeatureHistory(pair: string, candle: OHLCV): void {
    let history = this.featureHistories.get(pair);

    if (!history) {
      history = { candles: [], features: [], lastUpdated: 0 };
      this.featureHistories.set(pair, history);
    }

    history.candles.push(candle);
    if (history.candles.length > this.maxHistoryLength) {
      history.candles = history.candles.slice(-this.maxHistoryLength);
    }

    // Recalculate features if we have enough candles
    if (history.candles.length >= 60) {
      try {
        const featureSets = this.featureEngineering.engineerFeatures(history.candles, 1);
        history.features = featureSets.map((fs) => fs.features);
        history.lastUpdated = Date.now();
      } catch (error) {
        logger.warn(`Failed to engineer features for ${pair}`, { error });
      }
    }
  }

  /**
   * Generate a prediction using a trained model.
   */
  async predict(
    modelId: string,
    pair: string
  ): Promise<PredictionResult | null> {
    const metadata = this.modelRegistry.getModelMetadata(modelId);
    if (!metadata) {
      logger.warn(`Model metadata not found: ${modelId}`);
      return null;
    }

    const history = this.featureHistories.get(pair);
    if (!history || history.features.length === 0) {
      logger.warn(`No feature history for ${pair}`);
      return null;
    }

    const latestFeatures = history.features[history.features.length - 1];
    if (!latestFeatures || latestFeatures.length === 0) {
      return null;
    }

    // Normalize features
    let normalizedFeatures: number[];
    if (metadata.normalizer) {
      normalizedFeatures = this.featureEngineering.normalizeSingle(
        latestFeatures,
        metadata.normalizer.means,
        metadata.normalizer.stds
      );
    } else {
      normalizedFeatures = latestFeatures;
    }

    let result: PredictionResult | null = null;

    try {
      switch (metadata.type) {
        case "random_forest": {
          const model = this.modelRegistry.getModel<RandomForestModel>(`model:${modelId}`);
          if (!model || !model.isTrained()) break;
          const pred = model.predict(normalizedFeatures);
          result = { ...pred, modelType: "random_forest", modelId, pair, featureNames: metadata.features, timestamp: Date.now() };
          break;
        }

        case "xgboost": {
          const model = this.modelRegistry.getModel<XGBoostModel>(`model:${modelId}`);
          if (!model || !model.isTrained()) break;
          const pred = model.predict(normalizedFeatures);
          result = { ...pred, modelType: "xgboost", modelId, pair, featureNames: metadata.features, timestamp: Date.now() };
          break;
        }

        case "lstm": {
          const model = this.modelRegistry.getModel<LSTMModel>(`model:${modelId}`);
          if (!model || !model.isTrained()) break;
          const pred = model.predict(history.features);
          result = { ...pred, modelType: "lstm", modelId, pair, featureNames: metadata.features, timestamp: Date.now() };
          break;
        }
      }
    } catch (error) {
      logger.error(`Prediction failed for model ${modelId}`, { error: (error as Error).message });
    }

    if (result) {
      logger.debug(`Prediction: ${result.signal} (${(result.confidence * 100).toFixed(1)}%) for ${pair} via ${result.modelType}`);
    }

    return result;
  }

  /**
   * Get the latest features for a pair (for debugging/monitoring).
   */
  getLatestFeatures(pair: string): { features: number[]; featureNames: string[] } | null {
    const history = this.featureHistories.get(pair);
    if (!history || history.features.length === 0) return null;

    const latest = history.features[history.features.length - 1];
    return {
      features: latest || [],
      featureNames: this.featureEngineering.getFeatureNames(),
    };
  }

  /**
   * Check if enough history exists for prediction.
   */
  hasEnoughHistory(pair: string): boolean {
    const history = this.featureHistories.get(pair);
    return !!history && history.candles.length >= 60;
  }
}