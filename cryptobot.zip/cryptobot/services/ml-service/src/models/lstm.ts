import * as tf from "@tensorflow/tfjs-node";
import { logger } from "../utils/logger";

export interface LSTMConfig {
  sequenceLength: number;
  epochs: number;
  batchSize: number;
  learningRate: number;
  lstmUnits: number;
  dropoutRate: number;
}

/**
 * LSTM Model for time series prediction.
 * Uses TensorFlow.js for training and inference.
 * Predicts price direction based on sequence of features.
 */
export class LSTMModel {
  private model: tf.LayersModel | null = null;
  private config: LSTMConfig;
  private trained: boolean = false;
  private featureImportance: number[] = [];
  private normalizer: { means: number[]; stds: number[] } | null = null;

  constructor(config?: Partial<LSTMConfig>) {
    this.config = {
      sequenceLength: config?.sequenceLength || 50,
      epochs: config?.epochs || 50,
      batchSize: config?.batchSize || 32,
      learningRate: config?.learningRate || 0.001,
      lstmUnits: config?.lstmUnits || 64,
      dropoutRate: config?.dropoutRate || 0.2,
    };
  }

  /**
   * Train the LSTM model.
   */
  async train(data: {
    features: number[][];
    labels: number[];
    sequenceLength?: number;
  }): Promise<{
    accuracy: number;
    precision: number;
    recall: number;
  }> {
    const seqLen = data.sequenceLength || this.config.sequenceLength;

    if (data.features.length < seqLen + 10) {
      throw new Error(`Need at least ${seqLen + 10} samples, got ${data.features.length}`);
    }

    // Create sequences
    const { sequences, targets } = this.createSequences(data.features, data.labels, seqLen);

    if (sequences.length < 10) {
      throw new Error(`Only ${sequences.length} sequences created. Need more data.`);
    }

    // Split
    const splitIdx = Math.floor(sequences.length * 0.8);
    const trainX = tf.tensor3d(sequences.slice(0, splitIdx));
    const trainY = tf.tensor2d(targets.slice(0, splitIdx).map((t) => [1 - t, t]));
    const testX = tf.tensor3d(sequences.slice(splitIdx));
    const testY = targets.slice(splitIdx);

    const numFeatures = data.features[0]?.length || 1;

    logger.info(`Training LSTM: ${splitIdx} train, ${sequences.length - splitIdx} test sequences`);

    // Build model
    this.model = this.buildModel(numFeatures);

    // Train
    await this.model.fit(trainX, trainY, {
      epochs: this.config.epochs,
      batchSize: this.config.batchSize,
      validationSplit: 0.1,
      callbacks: {
        onEpochEnd: (epoch, logs) => {
          if (epoch % 10 === 0 && logs) {
            logger.debug(`LSTM epoch ${epoch + 1}/${this.config.epochs}: loss=${(logs.loss || 0).toFixed(4)}, acc=${((logs.acc || 0) * 100).toFixed(1)}%`);
          }
        },
      },
    });

    this.trained = true;

    // Evaluate
    const testPred = this.model.predict(testX) as tf.Tensor;
    const testPredArr = Array.from(testPred.dataSync());
    const testPredictions: number[] = [];

    for (let i = 0; i < testY.length; i++) {
      const buyProb = testPredArr[i * 2 + 1] || 0;
      testPredictions.push(buyProb >= 0.5 ? 1 : 0);
    }

    const metrics = this.evaluate(testY, testPredictions);

    logger.info(`LSTM trained: accuracy=${(metrics.accuracy * 100).toFixed(1)}%, precision=${(metrics.precision * 100).toFixed(1)}%`);

    // Cleanup
    trainX.dispose();
    trainY.dispose();
    testX.dispose();
    testPred.dispose();

    return metrics;
  }

  /**
   * Create sequences for LSTM input.
   */
  private createSequences(
    features: number[][],
    labels: number[],
    seqLen: number
  ): { sequences: number[][][]; targets: number[] } {
    const sequences: number[][][] = [];
    const targets: number[] = [];

    for (let i = seqLen; i < features.length; i++) {
      const seq = features.slice(i - seqLen, i);
      const target = labels[i - 1] ?? 0;

      if (seq.length === seqLen) {
        sequences.push(seq);
        targets.push(target);
      }
    }

    return { sequences, targets };
  }

  /**
   * Build the LSTM model architecture.
   */
  private buildModel(numFeatures: number): tf.LayersModel {
    const model = tf.sequential();

    model.add(tf.layers.lstm({
      units: this.config.lstmUnits,
      returnSequences: true,
      inputShape: [this.config.sequenceLength, numFeatures],
      dropout: this.config.dropoutRate,
    }));

    model.add(tf.layers.lstm({
      units: Math.floor(this.config.lstmUnits / 2),
      returnSequences: false,
      dropout: this.config.dropoutRate,
    }));

    model.add(tf.layers.dense({ units: 32, activation: "relu" }));
    model.add(tf.layers.dropout({ rate: this.config.dropoutRate }));
    model.add(tf.layers.dense({ units: 2, activation: "softmax" }));

    model.compile({
      optimizer: tf.train.adam(this.config.learningRate),
      loss: "categoricalCrossentropy",
      metrics: ["accuracy"],
    });

    return model;
  }

  /**
   * Predict for a single sample (using the last sequenceLength features).
   */
  predict(featureHistory: number[][]): {
    signal: "buy" | "sell" | "hold";
    confidence: number;
    probabilities: { buy: number; sell: number };
  } {
    if (!this.trained || !this.model) {
      throw new Error("LSTM model not trained");
    }

    if (featureHistory.length < this.config.sequenceLength) {
      throw new Error(`Need ${this.config.sequenceLength} historical features, got ${featureHistory.length}`);
    }

    const sequence = featureHistory.slice(-this.config.sequenceLength);
    const input = tf.tensor3d([sequence]);
    const prediction = this.model.predict(input) as tf.Tensor;
    const proba = Array.from(prediction.dataSync());

    input.dispose();
    prediction.dispose();

    const sellProb = proba[0] || 0;
    const buyProb = proba[1] || 0;

    let signal: "buy" | "sell" | "hold";
    let confidence: number;

    if (buyProb > 0.65) {
      signal = "buy";
      confidence = buyProb;
    } else if (sellProb > 0.65) {
      signal = "sell";
      confidence = sellProb;
    } else {
      signal = "hold";
      confidence = Math.max(buyProb, sellProb);
    }

    return { signal, confidence, probabilities: { buy: buyProb, sell: sellProb } };
  }

  private evaluate(actual: number[], predicted: number[]): {
    accuracy: number;
    precision: number;
    recall: number;
  } {
    let tp = 0, fp = 0, tn = 0, fn = 0;

    for (let i = 0; i < actual.length; i++) {
      const a = actual[i];
      const p = predicted[i];
      if (a === 1 && p === 1) tp++;
      else if (a === 0 && p === 1) fp++;
      else if (a === 0 && p === 0) tn++;
      else if (a === 1 && p === 0) fn++;
    }

    const total = actual.length || 1;
    return {
      accuracy: (tp + tn) / total,
      precision: tp + fp > 0 ? tp / (tp + fp) : 0,
      recall: tp + fn > 0 ? tp / (tp + fn) : 0,
    };
  }

  /**
   * Save the model to disk.
   */
  async save(path: string): Promise<void> {
    if (!this.model) throw new Error("No model to save");
    await this.model.save(`file://${path}`);
    logger.info(`LSTM model saved to ${path}`);
  }

  /**
   * Load the model from disk.
   */
  async load(path: string): Promise<void> {
    this.model = await tf.loadLayersModel(`file://${path}/model.json`);
    this.trained = true;
    logger.info(`LSTM model loaded from ${path}`);
  }

  isTrained(): boolean {
    return this.trained;
  }
}