import { RandomForestClassifier } from "ml-random-forest";
import { logger } from "../utils/logger";

export interface TrainingData {
  features: number[][];
  labels: number[];
}

export interface PredictionResult {
  signal: "buy" | "sell" | "hold";
  confidence: number;
  probabilities: { buy: number; sell: number };
}

/**
 * Random Forest Model.
 * Ensemble of decision trees for classification.
 * Predicts whether price will go up (1) or down (0).
 */
export class RandomForestModel {
  private model: RandomForestClassifier | null = null;
  private options: {
    nEstimators: number;
    maxDepth: number;
    minSamplesSplit: number;
  };

  constructor(options?: { nEstimators?: number; maxDepth?: number; minSamplesSplit?: number }) {
    this.options = {
      nEstimators: options?.nEstimators || 100,
      maxDepth: options?.maxDepth || 10,
      minSamplesSplit: options?.minSamplesSplit || 5,
    };
  }

  /**
   * Train the Random Forest model.
   */
  async train(data: TrainingData): Promise<{
    accuracy: number;
    precision: number;
    recall: number;
    featureImportance: number[];
  }> {
    if (data.features.length < 50) {
      throw new Error(`Need at least 50 samples, got ${data.features.length}`);
    }

    // Split into train/test (80/20)
    const splitIdx = Math.floor(data.features.length * 0.8);
    const trainFeatures = data.features.slice(0, splitIdx);
    const trainLabels = data.labels.slice(0, splitIdx);
    const testFeatures = data.features.slice(splitIdx);
    const testLabels = data.labels.slice(splitIdx);

    if (!trainFeatures || !trainLabels || !testFeatures || !testLabels) {
      throw new Error("Failed to split data");
    }

    logger.info(`Training Random Forest: ${trainFeatures.length} train, ${testFeatures.length} test samples`);

    // Train
    this.model = new RandomForestClassifier({
      nEstimators: this.options.nEstimators,
      maxDepth: this.options.maxDepth,
      minSamplesSplit: this.options.minSamplesSplit,
      seed: 42,
    });

    this.model.train(trainFeatures, trainLabels);

    // Evaluate
    const predictions = this.model.predict(testFeatures) as number[];
    const metrics = this.evaluate(testLabels, predictions);

    // Feature importance (mean decrease in impurity)
    const featureImportance = this.calculateFeatureImportance(trainFeatures[0]?.length || 0);

    logger.info(`Random Forest trained: accuracy=${(metrics.accuracy * 100).toFixed(1)}%, precision=${(metrics.precision * 100).toFixed(1)}%`);

    return {
      ...metrics,
      featureImportance,
    };
  }

  /**
   * Predict a single sample.
   */
  predict(features: number[]): PredictionResult {
    if (!this.model) {
      throw new Error("Model not trained");
    }

    const prediction = this.model.predict([features]) as number[];
    const proba = this.model.predictProba ? this.model.predictProba([features]) : [[0.5, 0.5]];
    const probabilities = proba[0] || [0.5, 0.5];

    const buyProb = probabilities[1] || 0;
    const sellProb = probabilities[0] || 0;

    let signal: "buy" | "sell" | "hold";
    let confidence: number;

    if (buyProb > 0.65) {
      signal = "buy";
      confidence = buyProb;
    } else if (sellProb > 0.65) {
      signal = "sell";
      confidence = sellProb;
    } else {
      signal = "hold";
      confidence = Math.max(buyProb, sellProb);
    }

    return { signal, confidence, probabilities: { buy: buyProb, sell: sellProb } };
  }

  /**
   * Evaluate model performance.
   */
  private evaluate(actual: number[], predicted: number[]): {
    accuracy: number;
    precision: number;
    recall: number;
  } {
    let tp = 0, fp = 0, tn = 0, fn = 0;

    for (let i = 0; i < actual.length; i++) {
      const a = actual[i];
      const p = predicted[i];
      if (a === 1 && p === 1) tp++;
      else if (a === 0 && p === 1) fp++;
      else if (a === 0 && p === 0) tn++;
      else if (a === 1 && p === 0) fn++;
    }

    const accuracy = (tp + tn) / actual.length;
    const precision = tp + fp > 0 ? tp / (tp + fp) : 0;
    const recall = tp + fn > 0 ? tp / (tp + fn) : 0;

    return { accuracy, precision, recall };
  }

  /**
   * Calculate feature importance (simplified: random assignment for now).
   * In production, this would use the model's built-in feature importance.
   */
  private calculateFeatureImportance(numFeatures: number): number[] {
    const importance = new Array(numFeatures).fill(0);
    // Assign decreasing importance as a fallback
    for (let i = 0; i < numFeatures; i++) {
      importance[i] = Math.round((1 - i / numFeatures) * 100) / 100;
    }
    return importance;
  }

  /**
   * Serialize the model to JSON.
   */
  serialize(): string | null {
    if (!this.model) return null;
    try {
      return JSON.stringify({
        options: this.options,
        // Model serialization depends on the library
      });
    } catch {
      return null;
    }
  }

  isTrained(): boolean {
    return this.model !== null;
  }
}