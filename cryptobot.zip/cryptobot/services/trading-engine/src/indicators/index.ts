import * as TI from "technicalindicators";

export interface IndicatorInput {
  values: number[];
  period?: number;
}

// ============================================================
// MOVING AVERAGES
// ============================================================

export function EMA(values: number[], period: number): number[] {
  return TI.ema({ values, period });
}

export function SMA(values: number[], period: number): number[] {
  return TI.sma({ values, period });
}

export function WMA(values: number[], period: number): number[] {
  return TI.wma({ values, period });
}

// ============================================================
// MOMENTUM
// ============================================================

export function RSI(values: number[], period: number = 14): number[] {
  return TI.rsi({ values, period });
}

export function MACD(values: number[], fastPeriod: number = 12, slowPeriod: number = 26, signalPeriod: number = 9) {
  const macdInput = {
    values,
    fastPeriod,
    slowPeriod,
    signalPeriod,
    SimpleMAOscillator: false,
    SimpleMASignal: false,
  };
  const macdResult = TI.macd(macdInput);

  return {
    macd: macdResult.MACD as number[],
    signal: macdResult.signal as number[],
    histogram: macdResult.histogram as number[],
  };
}

export function Stochastic(
  high: number[],
  low: number[],
  close: number[],
  period: number = 14,
  signalPeriod: number = 3
) {
  return TI.stochastic({ high, low, close, period, signalPeriod });
}

// ============================================================
// VOLATILITY
// ============================================================

export function BollingerBands(values: number[], period: number = 20, stdDev: number = 2) {
  return TI.bollingerbands({ values, period, stdDev });
}

export function ATR(high: number[], low: number[], close: number[], period: number = 14): number[] {
  return TI.atr({ high, low, close, period });
}

// ============================================================
// VOLUME
// ============================================================

export function OBV(close: number[], volume: number[]): number[] {
  return TI.obv({ close, volume });
}

export function VolumeProfile(
  high: number[],
  low: number[],
  close: number[],
  volume: number[],
  bins: number = 20
): { price: number; volume: number }[] {
  // Custom volume profile implementation
  const range = Math.max(...high) - Math.min(...low);
  const binSize = range / bins;

  const profile: Map<number, number> = new Map();

  for (let i = 0; i < close.length; i++) {
    const midPrice = (high[i]! + low[i]!) / 2;
    const bin = Math.floor((midPrice - Math.min(...low)) / binSize) * binSize + Math.min(...low) + binSize / 2;
    profile.set(bin, (profile.get(bin) || 0) + (volume[i] || 0));
  }

  return Array.from(profile.entries())
    .map(([price, volume]) => ({ price: Math.round(price * 100) / 100, volume }))
    .sort((a, b) => b.volume - a.volume);
}

// ============================================================
// TREND
// ============================================================

export function Ichimoku(
  high: number[],
  low: number[],
  tenkanPeriod: number = 9,
  kijunPeriod: number = 26,
  senkouBPeriod: number = 52
) {
  return TI.ichimokucloud({
    high,
    low,
    conversionPeriod: tenkanPeriod,
    basePeriod: kijunPeriod,
    spanPeriod: senkouBPeriod,
    displacement: kijunPeriod,
  });
}

export function ADX(high: number[], low: number[], close: number[], period: number = 14) {
  return TI.adx({ high, low, close, period });
}

// ============================================================
// SUPPORT / RESISTANCE
// ============================================================

export function PivotPoints(high: number, low: number, close: number) {
  const pp = (high + low + close) / 3;
  return {
    pivot: pp,
    r1: 2 * pp - low,
    r2: pp + (high - low),
    r3: high + 2 * (pp - low),
    s1: 2 * pp - high,
    s2: pp - (high - low),
    s3: low - 2 * (high - pp),
  };
}

export function FibonacciLevels(high: number, low: number, trend: "up" | "down" = "up") {
  const diff = high - low;
  const levels = [0, 0.236, 0.382, 0.5, 0.618, 0.786, 1];

  if (trend === "up") {
    return levels.map((level) => ({
      level,
      price: low + diff * level,
    }));
  } else {
    return levels.map((level) => ({
      level,
      price: high - diff * level,
    }));
  }
}

// ============================================================
// CUMULATIVE
// ============================================================

export function CVD(close: number[], volume: number[]): number[] {
  const cvd: number[] = [];
  let cumulative = 0;
  for (let i = 1; i < close.length; i++) {
    const delta = (close[i] || 0) > (close[i - 1] || 0) ? volume[i] || 0 : -(volume[i] || 0);
    cumulative += delta;
    cvd.push(cumulative);
  }
  return cvd;
}

// ============================================================
// UTILITY
// ============================================================
export function standardDeviation(values: number[]): number {
  const mean = values.reduce((sum, v) => sum + v, 0) / values.length;
  const variance = values.reduce((sum, v) => sum + (v - mean) ** 2, 0) / values.length;
  return Math.sqrt(variance);
}

export function average(values: number[]): number {
  return values.reduce((sum, v) => sum + v, 0) / values.length;
}

export function crossAbove(line1: number[], line2: number[]): boolean {
  if (line1.length < 2 || line2.length < 2) return false;
  const current = (line1[line1.length - 1] || 0) - (line2[line2.length - 1] || 0);
  const previous = (line1[line1.length - 2] || 0) - (line2[line2.length - 2] || 0);
  return previous <= 0 && current > 0;
}

export function crossBelow(line1: number[], line2: number[]): boolean {
  if (line1.length < 2 || line2.length < 2) return false;
  const current = (line1[line1.length - 1] || 0) - (line2[line2.length - 1] || 0);
  const previous = (line1[line1.length - 2] || 0) - (line2[line2.length - 2] || 0);
  return previous >= 0 && current < 0;
}