export class TradingError extends Error {
  public readonly code: string;
  public readonly statusCode: number;
  public readonly botId?: string;

  constructor(code: string, message: string, statusCode: number = 500, botId?: string) {
    super(message);
    this.name = "TradingError";
    this.code = code;
    this.statusCode = statusCode;
    this.botId = botId;
    Error.captureStackTrace(this, this.constructor);
  }
}

export class OrderExecutionError extends TradingError {
  constructor(message: string, botId?: string) {
    super("ORDER_EXECUTION_FAILED", message, 502, botId);
    this.name = "OrderExecutionError";
  }
}

export class InsufficientBalanceError extends TradingError {
  constructor(asset: string, required: number, available: number, botId?: string) {
    super(
      "INSUFFICIENT_BALANCE",
      `Insufficient ${asset} balance: required ${required}, available ${available}`,
      400,
      botId
    );
    this.name = "InsufficientBalanceError";
  }
}

export class ProtectionTriggeredError extends TradingError {
  constructor(reason: string, botId?: string) {
    super("PROTECTION_TRIGGERED", reason, 400, botId);
    this.name = "ProtectionTriggeredError";
  }
}

export class StrategyError extends TradingError {
  constructor(message: string, botId?: string) {
    super("STRATEGY_ERROR", message, 500, botId);
    this.name = "StrategyError";
  }
}