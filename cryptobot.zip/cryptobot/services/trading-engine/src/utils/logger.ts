import winston from "winston";

const SENSITIVE_FIELDS = [
  "apiKey", "apiSecret", "privateKey", "encryptedKey", "encryptedSecret",
  "password", "token", "secret",
];

const redactSensitive = winston.format((info) => {
  const masked = { ...info };
  for (const key of SENSITIVE_FIELDS) {
    if (typeof masked[key] === "string" && masked[key].length > 0) {
      masked[key] = "[REDACTED]";
    }
  }
  return masked;
});

export const logger = winston.createLogger({
  level: process.env.LOG_LEVEL || "info",
  format: winston.format.combine(
    redactSensitive(),
    winston.format.timestamp({ format: "ISO8601" }),
    winston.format.errors({ stack: true }),
    process.env.NODE_ENV === "production"
      ? winston.format.json()
      : winston.format.combine(
          winston.format.colorize(),
          winston.format.printf(({ timestamp, level, message, ...meta }) => {
            const metaStr = Object.keys(meta).length ? ` ${JSON.stringify(meta)}` : "";
            return `${timestamp} [${level}]: ${message}${metaStr}`;
          })
        )
  ),
  defaultMeta: { service: "trading-engine" },
  transports: [new winston.transports.Console()],
});