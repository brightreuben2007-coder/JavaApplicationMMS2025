import { logger } from "../utils/logger";
import type { OHLCV } from "../strategies/base.strategy";

/**
 * Detects abnormal volatility and can pause bots.
 */
export class VolatilityProtection {
  private thresholdPercent: number;
  private lookbackCandles: number;
  private recentCandles: OHLCV[] = [];

  constructor(thresholdPercent: number = 10, lookbackCandles: number = 10) {
    this.thresholdPercent = thresholdPercent;
    this.lookbackCandles = lookbackCandles;
  }

  /**
   * Feed a new candle and check if volatility exceeds threshold.
   */
  checkVolatility(candle: OHLCV): { triggered: boolean; bodyPercent: number; reason: string | null } {
    this.recentCandles.push(candle);
    if (this.recentCandles.length > this.lookbackCandles) {
      this.recentCandles.shift();
    }

    const bodyPercent = Math.abs(candle.close - candle.open) / candle.open * 100;

    // Check 1: Single candle body exceeds threshold
    if (bodyPercent > this.thresholdPercent * 1.5) {
      return {
        triggered: true,
        bodyPercent,
        reason: `Candle body ${bodyPercent.toFixed(2)}% exceeds ${(this.thresholdPercent * 1.5).toFixed(1)}%`,
      };
    }

    // Check 2: Current price is far from recent average
    if (this.recentCandles.length >= 5) {
      const recentCloses = this.recentCandles.map((c) => c.close);
      const avgClose = recentCloses.reduce((sum, c) => sum + c, 0) / recentCloses.length;
      const deviation = Math.abs(candle.close - avgClose) / avgClose * 100;

      if (deviation > this.thresholdPercent) {
        return {
          triggered: true,
          bodyPercent: deviation,
          reason: `Price deviation ${deviation.toFixed(2)}% from ${this.lookbackCandles}-candle average exceeds ${this.thresholdPercent}%`,
        };
      }
    }

    return { triggered: false, bodyPercent, reason: null };
  }

  /**
   * Update the threshold.
   */
  setThreshold(thresholdPercent: number): void {
    this.thresholdPercent = thresholdPercent;
  }

  /**
   * Reset the candle history.
   */
  reset(): void {
    this.recentCandles = [];
  }
}