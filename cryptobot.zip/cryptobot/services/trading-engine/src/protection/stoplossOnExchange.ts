import { OrderRouter } from "../orders/orderRouter";
import { logger } from "../utils/logger";
import type { Position } from "../strategies/base.strategy";

export interface StopLossConfig {
  stoplossPercent: number;
  exchangeId: string;
  credentialId: string;
  pair: string;
  paperTrading: boolean;
}

/**
 * Places actual stop-loss orders on the exchange so they survive
 * bot crashes or downtime. This is the Freqtrade-style approach.
 */
export class StopLossOnExchange {
  private orderRouter: OrderRouter;
  private activeStopLosses: Map<string, string> = new Map(); // positionId -> exchangeOrderId

  constructor(orderRouter: OrderRouter) {
    this.orderRouter = orderRouter;
  }

  /**
   * Place a stop-loss order for a position.
   */
  async placeStopLoss(position: Position, config: StopLossConfig): Promise<string | null> {
    // Remove any existing stop-loss for this position
    await this.cancelStopLoss(position.id, config);

    const stopPrice = position.entryPrice * (1 - config.stoplossPercent / 100);
    const stopSide = position.side === "buy" ? "sell" : "buy";

    const orderId = await this.orderRouter.placeStopLoss(
      config.pair,
      stopSide,
      position.quantity,
      stopPrice,
      config.credentialId,
      config.exchangeId,
      config.paperTrading
    );

    if (orderId) {
      this.activeStopLosses.set(position.id, orderId);
      logger.info(`Stop-loss placed for position ${position.id} at ${stopPrice}`, {
        positionId: position.id,
        orderId,
        stopPrice,
      });
    }

    return orderId;
  }

  /**
   * Cancel the stop-loss for a position.
   */
  async cancelStopLoss(positionId: string, config: StopLossConfig): Promise<void> {
    const existingOrderId = this.activeStopLosses.get(positionId);
    if (existingOrderId) {
      await this.orderRouter.cancelOrder(
        existingOrderId,
        config.pair,
        config.credentialId,
        config.exchangeId,
        config.paperTrading
      );
      this.activeStopLosses.delete(positionId);
      logger.info(`Stop-loss cancelled for position ${positionId}`);
    }
  }

  /**
   * Update stop-loss price (e.g., for trailing stops).
   * Cancels existing and places new.
   */
  async updateStopLoss(
    position: Position,
    newStopPrice: number,
    config: StopLossConfig
  ): Promise<string | null> {
    await this.cancelStopLoss(position.id, config);

    const stopSide = position.side === "buy" ? "sell" : "buy";

    const orderId = await this.orderRouter.placeStopLoss(
      config.pair,
      stopSide,
      position.quantity,
      newStopPrice,
      config.credentialId,
      config.exchangeId,
      config.paperTrading
    );

    if (orderId) {
      this.activeStopLosses.set(position.id, orderId);
    }

    return orderId;
  }

  /**
   * Get the active stop-loss order ID for a position.
   */
  getStopLossOrderId(positionId: string): string | null {
    return this.activeStopLosses.get(positionId) || null;
  }
}