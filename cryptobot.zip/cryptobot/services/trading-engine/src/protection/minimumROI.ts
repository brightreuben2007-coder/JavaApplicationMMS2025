/**
 * Evaluates minimum ROI rules for position closure.
 * Format: { "minutes": roiPercent }
 * Example: { "0": 3.0, "60": 2.0, "120": 1.0 }
 * Means: close at 3% immediately, or 2% after 60 minutes, or 1% after 120 minutes.
 */
export class MinimumROIChecker {
  private roiTable: Record<number, number>;

  constructor(roiTable: Record<string, number> = {}) {
    // Convert string keys to numbers and sort by time ascending
    this.roiTable = {};
    for (const [minutesStr, roi] of Object.entries(roiTable)) {
      this.roiTable[parseInt(minutesStr)] = roi;
    }
  }

  /**
   * Check if a position should be closed based on minimum ROI rules.
   * @param entryPrice - The entry price of the position
   * @param currentPrice - The current market price
   * @param openedAt - When the position was opened
   * @param side - "buy" (long) or "sell" (short)
   * @returns true if the position should be closed
   */
  shouldClose(
    entryPrice: number,
    currentPrice: number,
    openedAt: Date,
    side: "buy" | "sell" = "buy"
  ): { shouldClose: boolean; reason: string; currentROI: number } {
    const elapsedMinutes = (Date.now() - openedAt.getTime()) / 60000;
    const currentROI = side === "buy"
      ? ((currentPrice - entryPrice) / entryPrice) * 100
      : ((entryPrice - currentPrice) / entryPrice) * 100;

    // Get sorted time thresholds
    const thresholds = Object.entries(this.roiTable)
      .map(([min, roi]) => ({ minutes: parseInt(min), roi }))
      .sort((a, b) => a.minutes - b.minutes);

    if (thresholds.length === 0) {
      return { shouldClose: false, reason: "No ROI rules configured", currentROI };
    }

    // Find the applicable threshold based on elapsed time
    let applicableROI: number | null = null;
    let applicableMinutes: number = 0;

    for (let i = 0; i < thresholds.length; i++) {
      const threshold = thresholds[i]!;
      if (elapsedMinutes >= threshold.minutes) {
        applicableROI = threshold.roi;
        applicableMinutes = threshold.minutes;
      }
    }

    if (applicableROI === null) {
      return {
        shouldClose: false,
        reason: `Not enough time elapsed (${elapsedMinutes.toFixed(1)}m < ${thresholds[0]!.minutes}m)`,
        currentROI,
      };
    }

    if (currentROI >= applicableROI) {
      return {
        shouldClose: true,
        reason: `ROI ${currentROI.toFixed(2)}% >= ${applicableROI}% (after ${applicableMinutes}m, elapsed ${elapsedMinutes.toFixed(1)}m)`,
        currentROI,
      };
    }

    return {
      shouldClose: false,
      reason: `ROI ${currentROI.toFixed(2)}% < ${applicableROI}% target`,
      currentROI,
    };
  }

  /**
   * Get the current required ROI based on elapsed time.
   */
  getRequiredROI(elapsedMinutes: number): number {
    const thresholds = Object.entries(this.roiTable)
      .map(([min, roi]) => ({ minutes: parseInt(min), roi }))
      .sort((a, b) => a.minutes - b.minutes);

    let requiredROI = 0;

    for (const threshold of thresholds) {
      if (elapsedMinutes >= threshold.minutes) {
        requiredROI = threshold.roi;
      }
    }

    return requiredROI;
  }
}