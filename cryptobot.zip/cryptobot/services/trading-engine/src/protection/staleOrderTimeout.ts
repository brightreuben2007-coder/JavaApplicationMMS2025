import { OrderRouter } from "../orders/orderRouter";
import { logger } from "../utils/logger";
import type { OrderResult } from "../strategies/base.strategy";

interface OrderTrackingConfig {
  credentialId: string;
  exchangeId: string;
  paperTrading: boolean;
}

interface OrderTrackingEntry {
  order: OrderResult;
  createdAt: Date;
  config: OrderTrackingConfig;
}

/**
 * Cancels orders that have been open too long without filling.
 * Prevents capital from being locked in unfilled limit orders.
 */
export class StaleOrderTimeout {
  private orderRouter: OrderRouter;
  private defaultTimeoutMinutes: number;
  private orderTracking: Map<string, OrderTrackingEntry> = new Map();
  private checkInterval: NodeJS.Timeout | null = null;

  constructor(orderRouter: OrderRouter, defaultTimeoutMinutes: number = 60) {
    this.orderRouter = orderRouter;
    this.defaultTimeoutMinutes = defaultTimeoutMinutes;
  }

  /**
   * Start tracking an order for staleness.
   */
  trackOrder(order: OrderResult, config: OrderTrackingConfig): void {
    this.orderTracking.set(order.orderId, {
      order,
      createdAt: new Date(),
      config,
    });
    logger.debug(`Tracking order ${order.orderId} for staleness`, {
      symbol: order.symbol,
      timeoutMinutes: this.defaultTimeoutMinutes,
    });
  }

  /**
   * Stop tracking an order (when filled or cancelled manually).
   */
  untrackOrder(orderId: string): void {
    this.orderTracking.delete(orderId);
    logger.debug(`Stopped tracking order ${orderId}`);
  }

  /**
   * Start the periodic check for stale orders.
   */
  startChecking(intervalMs: number = 60000): void {
    if (this.checkInterval) {
      logger.warn("Stale order check already running");
      return;
    }

    this.checkInterval = setInterval(() => {
      this.checkStaleOrders();
    }, intervalMs);

    logger.info(`Stale order check started (interval: ${intervalMs}ms, timeout: ${this.defaultTimeoutMinutes}min)`);
  }

  /**
   * Stop the periodic check.
   */
  stopChecking(): void {
    if (this.checkInterval) {
      clearInterval(this.checkInterval);
      this.checkInterval = null;
      logger.info("Stale order check stopped");
    }
  }

  /**
   * Update the default timeout.
   */
  setTimeoutMinutes(minutes: number): void {
    this.defaultTimeoutMinutes = minutes;
  }

  /**
   * Get the number of orders being tracked.
   */
  getTrackedOrderCount(): number {
    return this.orderTracking.size;
  }

  /**
   * Check all tracked orders and cancel stale ones.
   */
  private async checkStaleOrders(): Promise<void> {
    const now = new Date();
    const staleThresholdMs = this.defaultTimeoutMinutes * 60000;
    const staleOrders: string[] = [];

    // Identify stale orders
    for (const [orderId, tracking] of this.orderTracking.entries()) {
      const age = now.getTime() - tracking.createdAt.getTime();

      if (age > staleThresholdMs) {
        staleOrders.push(orderId);
        logger.warn(`Stale order detected: ${orderId}`, {
          orderId,
          ageMinutes: Math.round(age / 60000),
          symbol: tracking.order.symbol,
          side: tracking.order.side,
          price: tracking.order.price,
        });
      }
    }

    // Cancel stale orders (async, don't block the loop)
    for (const orderId of staleOrders) {
      const tracking = this.orderTracking.get(orderId);
      if (!tracking) continue;

      try {
        const cancelled = await this.orderRouter.cancelOrder(
          tracking.order.exchangeOrderId,
          tracking.order.symbol,
          tracking.config.credentialId,
          tracking.config.exchangeId,
          tracking.config.paperTrading
        );

        if (cancelled) {
          logger.info(`Stale order ${orderId} cancelled successfully`);
        } else {
          logger.error(`Failed to cancel stale order ${orderId}`);
        }
      } catch (error) {
        logger.error(`Error cancelling stale order ${orderId}`, {
          error: (error as Error).message,
        });
      } finally {
        this.untrackOrder(orderId);
      }
    }

    if (staleOrders.length > 0) {
      logger.info(`Stale order check complete: ${staleOrders.length} orders cancelled`);
    }
  }
}