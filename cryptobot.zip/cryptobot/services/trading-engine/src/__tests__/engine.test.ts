import { TradingEngine } from "../engine";

describe("Trading Engine", () => {
  let engine: TradingEngine;

  beforeAll(() => {
    engine = new TradingEngine("redis://localhost:6379");
  });

  afterAll(async () => {
    await engine.shutdown();
  });

  it("should start with zero bots", () => {
    expect(engine.getBotCount()).toBe(0);
  });

  it("should return empty active bot IDs", () => {
    expect(engine.getActiveBotIds()).toEqual([]);
  });

  it("should have an order router", () => {
    expect(engine.getOrderRouter()).toBeDefined();
  });

  it("should emit bot:started event when bot starts", (done) => {
    engine.once("bot:started", (botId: string) => {
      expect(botId).toBe("test-bot-engine");
      done();
    });

    engine.startBot({
      botId: "test-bot-engine",
      userId: "test-user",
      exchange: "binance",
      pair: "BTC/USDT",
      strategyType: "dca",
      config: {
        baseOrderSize: 0.01,
        safetyOrderSize: 0.005,
        maxSafetyOrders: 3,
        priceDeviationPercent: 2,
        safetyOrderVolumeScale: 1.5,
        safetyOrderStepScale: 1.2,
        takeProfitPercent: 2,
        trailingTakeProfit: false,
        trailingDeviationPercent: 0.5,
        cooldownBetweenDealsMinutes: 30,
        minimumROI: {},
      },
      status: "active",
      paperTrading: true,
      protectionConfig: null,
      dealStartConditions: null,
    });
  });

  it("should stop a bot gracefully", async () => {
    await engine.stopBot("test-bot-engine");
    // Should not throw
  });

  it("should handle unknown strategy type", async () => {
    await expect(
      engine.startBot({
        botId: "bad-bot",
        userId: "test",
        exchange: "binance",
        pair: "BTC/USDT",
        strategyType: "invalid" as any,
        config: {},
        status: "active",
        paperTrading: true,
        protectionConfig: null,
        dealStartConditions: null,
      })
    ).rejects.toThrow("Unknown strategy type");
  });
});