import { DCAStrategy } from "../strategies/dca.strategy";
import type { BotContext, OHLCV, Ticker } from "../strategies/base.strategy";

const mockContext: BotContext = {
  botId: "test-bot-1",
  userId: "test-user",
  exchange: "binance",
  pair: "BTC/USDT",
  strategyType: "dca",
  config: {
    baseOrderSize: 0.01,
    safetyOrderSize: 0.005,
    maxSafetyOrders: 3,
    priceDeviationPercent: 2,
    safetyOrderVolumeScale: 1.5,
    safetyOrderStepScale: 1.2,
    takeProfitPercent: 2,
    trailingTakeProfit: false,
    trailingDeviationPercent: 0.5,
    cooldownBetweenDealsMinutes: 30,
    minimumROI: { "0": 3, "60": 2, "120": 1 },
  },
  status: "active",
  paperTrading: true,
  protectionConfig: {
    stoplossOnExchange: false,
    stoplossPercent: 10,
    cooldownMinutes: 30,
    maxOpenDeals: 5,
    minimumROI: { "0": 3, "60": 2 },
    volatilityProtectionEnabled: false,
    volatilityThreshold: 10,
    staleOrderTimeoutMinutes: 60,
  },
  dealStartConditions: [{ type: "manual", params: {} }],
};

const mockCandle: OHLCV = {
  timestamp: Date.now(),
  open: 50000,
  high: 51000,
  low: 49000,
  close: 50500,
  volume: 100,
};

const mockTicker: Ticker = {
  symbol: "BTC/USDT",
  last: 50500,
  bid: 50490,
  ask: 50510,
  high24h: 51000,
  low24h: 49000,
  volume24h: 1000,
  timestamp: Date.now(),
};

describe("DCA Strategy", () => {
  let strategy: DCAStrategy;

  beforeEach(() => {
    strategy = new DCAStrategy(mockContext);
  });

  it("should initialize without error", async () => {
    await strategy.onInit();
    expect(strategy.getPair()).toBe("BTC/USDT");
    expect(strategy.getStrategyType()).toBe("dca");
  });

  it("should not start deal if no conditions met", async () => {
    const ctx = { ...mockContext, dealStartConditions: [] };
    const s = new DCAStrategy({ ...ctx, config: { ...mockContext.config, dealStartConditions: [] } });
    await s.onTick(mockCandle, mockTicker);
    // Should not have any open positions
    const positions = s.getOpenPositions();
    expect(positions.length).toBe(0);
  });

  it("should emit log events during init", async () => {
    const logs: any[] = [];
    strategy.on("onLog", (level: string, msg: string) => logs.push({ level, msg }));
    await strategy.onInit();
    expect(logs.length).toBeGreaterThan(0);
  });

  it("should calculate stop loss correctly", () => {
    const sl = (strategy as any).calculateStopLossPrice(50000, "buy");
    expect(sl).toBe(45000); // 50000 * (1 - 10/100)
  });

  it("should calculate profit percent correctly", () => {
    const profit = (strategy as any).calculateProfitPercent(50000, 51000, "buy");
    expect(profit).toBe(2);
  });

  it("should handle emergency close when no active deal", async () => {
    await strategy.emergencyClose(50000);
    // Should not throw
  });
});