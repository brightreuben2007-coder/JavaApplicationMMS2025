import {
  EMA, SMA, RSI, MACD, BollingerBands, ATR,
  crossAbove, crossBelow, standardDeviation, PivotPoints, FibonacciLevels,
} from "../indicators";

describe("Indicators", () => {
  const closes = [10, 11, 12, 13, 14, 15, 14, 13, 12, 11, 10, 11, 12, 13, 14, 15, 16, 15, 14, 13];
  const highs = closes.map(c => c + 1);
  const lows = closes.map(c => c - 1);
  const volumes = closes.map(() => 100);

  describe("EMA", () => {
    it("should calculate EMA", () => {
      const result = EMA(closes, 5);
      expect(result.length).toBeGreaterThan(0);
      expect(result[result.length - 1]).toBeGreaterThan(0);
    });
  });

  describe("SMA", () => {
    it("should calculate SMA", () => {
      const result = SMA(closes, 5);
      expect(result.length).toBeGreaterThan(0);
    });
  });

  describe("RSI", () => {
    it("should calculate RSI between 0 and 100", () => {
      const result = RSI(closes, 14);
      expect(result.length).toBeGreaterThan(0);
      const last = result[result.length - 1] || 0;
      expect(last).toBeGreaterThanOrEqual(0);
      expect(last).toBeLessThanOrEqual(100);
    });
  });

  describe("MACD", () => {
    it("should calculate MACD with signal and histogram", () => {
      const result = MACD(closes, 12, 26, 9);
      expect(result.macd.length).toBeGreaterThan(0);
      expect(result.signal.length).toBeGreaterThan(0);
      expect(result.histogram.length).toBeGreaterThan(0);
    });
  });

  describe("BollingerBands", () => {
    it("should calculate upper, middle, and lower bands", () => {
      const result = BollingerBands(closes, 10, 2);
      expect(result.upper.length).toBeGreaterThan(0);
      expect(result.lower.length).toBeGreaterThan(0);
      const lastUpper = result.upper[result.upper.length - 1] || 0;
      const lastLower = result.lower[result.lower.length - 1] || 0;
      expect(lastUpper).toBeGreaterThan(lastLower);
    });
  });

  describe("ATR", () => {
    it("should calculate ATR", () => {
      const result = ATR(highs, lows, closes, 14);
      expect(result.length).toBeGreaterThan(0);
      expect(result[result.length - 1]).toBeGreaterThan(0);
    });
  });

  describe("crossAbove", () => {
    it("should detect bullish crossover", () => {
      const line1 = [5, 6, 7, 8];
      const line2 = [6, 6, 6, 7];
      expect(crossAbove(line1, line2)).toBe(true);
    });

    it("should not detect when already above", () => {
      const line1 = [10, 11, 12];
      const line2 = [5, 5, 5];
      expect(crossAbove(line1, line2)).toBe(false);
    });
  });

  describe("crossBelow", () => {
    it("should detect bearish crossover", () => {
      const line1 = [8, 7, 6, 5];
      const line2 = [6, 6, 6, 6];
      expect(crossBelow(line1, line2)).toBe(true);
    });
  });

  describe("PivotPoints", () => {
    it("should calculate pivot and support/resistance levels", () => {
      const result = PivotPoints(1500, 1400, 1450);
      expect(result.pivot).toBe(1450);
      expect(result.r1).toBeGreaterThan(result.pivot);
      expect(result.s1).toBeLessThan(result.pivot);
    });
  });

  describe("FibonacciLevels", () => {
    it("should calculate fib levels for uptrend", () => {
      const result = FibonacciLevels(100, 0, "up");
      expect(result.length).toBe(7);
      expect(result[0]?.level).toBe(0);
      expect(result[6]?.level).toBe(1);
      expect(result[3]?.price).toBe(50); // 0.5 level
    });
  });

  describe("standardDeviation", () => {
    it("should calculate standard deviation", () => {
      const result = standardDeviation([2, 4, 4, 4, 5, 5, 7, 9]);
      expect(result).toBeCloseTo(2, 0);
    });
  });
});