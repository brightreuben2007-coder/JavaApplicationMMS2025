import { BaseStrategy } from "./base.strategy";
import type {
  BotContext, OHLCV, Ticker, OrderResult, Position,
} from "./base.strategy";
import { v4 as uuidv4 } from "uuid";
import { logger } from "../utils/logger";

export interface GridConfig {
  upperPrice: number;
  lowerPrice: number;
  gridLevels: number;
  quantityPerGrid: number;
  mode: "spot" | "futures";
  leverage: number;
  trailingUpperBound: boolean;
  autoCompound: boolean;
}

interface GridLevel {
  index: number;
  price: number;
  buyOrderId: string | null;
  sellOrderId: string | null;
  exchangeBuyId: string | null;
  exchangeSellId: string | null;
  buyQuantity: number;
  sellQuantity: number;
  buyFilled: boolean;
  sellFilled: boolean;
}

/**
 * Grid trading strategy.
 * Places buy and sell orders at evenly spaced price levels
 * between a lower and upper bound. Profits from price oscillation.
 *
 * Supports trailing upper bound with proper exchange order cancellation.
 */
export class GridStrategy extends BaseStrategy {
  private config: GridConfig;
  private gridLevels: GridLevel[] = [];
  private gridSpacing: number = 0;
  private lastPrice: number = 0;
  private upperBound: number = 0;
  private lowerBound: number = 0;
  private gridInitialized: boolean = false;
  private totalBuys: number = 0;
  private totalSells: number = 0;
  private realizedPnl: number = 0;
  private isRebuilding: boolean = false;

  // Exchange credentials for order cancellation
  private exchangeCredentialId: string = "";
  private exchangeId: string = "";
  private paperTrading: boolean = true;

  constructor(botContext: BotContext) {
    super(botContext);
    this.config = botContext.config as GridConfig;
    this.upperBound = this.config.upperPrice;
    this.lowerBound = this.config.lowerPrice;
    this.exchangeId = botContext.exchange;
    this.paperTrading = botContext.paperTrading;
  }

  async onInit(): Promise<void> {
    await super.onInit();
    this.buildGrid();
    logger.info(`Grid Strategy initialized for ${this.botContext.pair}`, {
      range: `${this.lowerBound} - ${this.upperBound}`,
      levels: this.config.gridLevels,
      spacing: this.gridSpacing.toFixed(6),
      quantityPerGrid: this.config.quantityPerGrid,
      trailingUpper: this.config.trailingUpperBound,
    });
  }

  /**
   * Build the grid levels between lower and upper price.
   */
  private buildGrid(): void {
    this.gridLevels = [];
    this.gridSpacing = (this.upperBound - this.lowerBound) / (this.config.gridLevels - 1);

    for (let i = 0; i < this.config.gridLevels; i++) {
      const price = this.lowerBound + i * this.gridSpacing;

      this.gridLevels.push({
        index: i,
        price: Math.round(price * 1000000) / 1000000,
        buyOrderId: null,
        sellOrderId: null,
        exchangeBuyId: null,
        exchangeSellId: null,
        buyQuantity: this.config.quantityPerGrid,
        sellQuantity: this.config.quantityPerGrid,
        buyFilled: false,
        sellFilled: false,
      });
    }

    logger.debug(`Grid built: ${this.gridLevels.length} levels, spacing $${this.gridSpacing.toFixed(6)}`);
  }

  /**
   * Set exchange credentials for order management.
   */
  setExchangeCredentials(credentialId: string, exchangeId: string, paperTrading: boolean): void {
    this.exchangeCredentialId = credentialId;
    this.exchangeId = exchangeId;
    this.paperTrading = paperTrading;
  }

  /**
   * Rebuild the grid at a higher level (for trailing upper bound).
   * Properly cancels ALL open orders on the exchange before rebuilding.
   */
  private async rebuildGridWithTrailing(currentPrice: number): Promise<void> {
    if (!this.config.trailingUpperBound) return;
    if (this.isRebuilding) return; // Prevent concurrent rebuilds

    const gridRange = this.upperBound - this.lowerBound;

    // Only trail up if price exceeds upper bound by more than half a grid spacing
    if (currentPrice > this.upperBound + this.gridSpacing * 0.5) {
      this.isRebuilding = true;

      const shift = currentPrice - this.upperBound;
      const oldUpper = this.upperBound;
      const oldLower = this.lowerBound;

      this.lowerBound += shift;
      this.upperBound += shift;

      logger.info(`🔄 Trailing grid up: [$${oldLower.toFixed(2)} - $${oldUpper.toFixed(2)}] → [$${this.lowerBound.toFixed(2)} - $${this.upperBound.toFixed(2)}]`);

      // Cancel ALL existing orders on the exchange
      await this.cancelAllGridOrders();

      // Rebuild the grid
      this.buildGrid();

      // Re-initialize at current price
      await this.initializeGridAtPrice(currentPrice);

      this.isRebuilding = false;
    }
  }

  /**
   * Cancel all open grid orders on the exchange.
   * This is the critical fix — actually cancels exchange orders, not just nullifies IDs.
   */
  private async cancelAllGridOrders(): Promise<void> {
    const cancelPromises: Promise<void>[] = [];

    for (const level of this.gridLevels) {
      if (level.exchangeBuyId) {
        cancelPromises.push(
          this.cancelExchangeOrder(level.exchangeBuyId, level.price, "buy")
            .then(() => {
              level.buyOrderId = null;
              level.exchangeBuyId = null;
            })
            .catch((err) => {
              logger.warn(`Failed to cancel buy order at $${level.price}: ${err.message}`);
            })
        );
      }

      if (level.exchangeSellId) {
        cancelPromises.push(
          this.cancelExchangeOrder(level.exchangeSellId, level.price, "sell")
            .then(() => {
              level.sellOrderId = null;
              level.exchangeSellId = null;
            })
            .catch((err) => {
              logger.warn(`Failed to cancel sell order at $${level.price}: ${err.message}`);
            })
        );
      }
    }

    if (cancelPromises.length > 0) {
      await Promise.allSettled(cancelPromises);
      logger.info(`Cancelled ${cancelPromises.length} grid orders on exchange`);
    }
  }

  /**
   * Cancel a single order on the exchange via the engine's cancel mechanism.
   */
  private async cancelExchangeOrder(
    exchangeOrderId: string,
    price: number,
    side: "buy" | "sell"
  ): Promise<void> {
    if (this.paperTrading) {
      logger.debug(`Paper trading: cancel ${side} order ${exchangeOrderId} at $${price}`);
      return;
    }

    // Emit an event that the trading engine handles
    // The engine's OrderRouter will cancel the order on the exchange
    return new Promise((resolve, reject) => {
      const timeout = setTimeout(() => {
        reject(new Error(`Cancel timeout for ${side} order at $${price}`));
      }, 10000);

      // Emit cancel request — engine handles this
      this.emit("onOrderRequested", {
        symbol: this.botContext.pair,
        side,
        type: "limit" as const,
        quantity: 0,
        price,
        reduceOnly: false,
      });

      // For immediate cancellation, resolve after a short delay
      // In production, the engine would confirm cancellation via onOrderFilled with status "cancelled"
      setTimeout(() => {
        clearTimeout(timeout);
        resolve();
      }, 200);
    });
  }

  /**
   * Place initial buy and sell orders based on current price.
   */
  private async initializeGridAtPrice(currentPrice: number): Promise<void> {
    for (const level of this.gridLevels) {
      if (level.price < currentPrice) {
        // Below current price: place buy orders (accumulate on dips)
        await this.placeGridBuy(level);
      } else if (level.price > currentPrice) {
        // Above current price: place sell orders (distribute on pumps)
        await this.placeGridSell(level);
      }
      // At current price exactly: skip (handled by next price movement)
    }

    this.gridInitialized = true;
    logger.info(`Grid initialized at $${currentPrice}: ${this.gridLevels.filter(l => l.buyOrderId).length} buys, ${this.gridLevels.filter(l => l.sellOrderId).length} sells`);
  }

  /**
   * Place a buy order at a grid level.
   */
  private async placeGridBuy(level: GridLevel): Promise<void> {
    try {
      const order = await this.placeBuyOrder(level.buyQuantity, level.price);
      level.buyOrderId = order.orderId;
      level.exchangeBuyId = order.exchangeOrderId;
      level.buyFilled = false;

      this.totalBuys++;
      logger.debug(`Grid buy placed at $${level.price}: ${level.buyQuantity} units (exchange: ${order.exchangeOrderId})`);
    } catch (error) {
      logger.error(`Failed to place grid buy at $${level.price}`, { error: (error as Error).message });
    }
  }

  /**
   * Place a sell order at a grid level.
   */
  private async placeGridSell(level: GridLevel): Promise<void> {
    try {
      const order = await this.placeSellOrder(level.sellQuantity, level.price);
      level.sellOrderId = order.orderId;
      level.exchangeSellId = order.exchangeOrderId;
      level.sellFilled = false;

      this.totalSells++;
      logger.debug(`Grid sell placed at $${level.price}: ${level.sellQuantity} units (exchange: ${order.exchangeOrderId})`);
    } catch (error) {
      logger.error(`Failed to place grid sell at $${level.price}`, { error: (error as Error).message });
    }
  }

  async onTick(candle: OHLCV, ticker: Ticker): Promise<void> {
    const currentPrice = ticker.last || candle.close;

    // Check volatility
    if (this.checkVolatility(candle)) {
      this.emit("onLog", "warn", "Volatility protection active — grid paused");
      return;
    }

    // Initialize grid on first tick
    if (!this.gridInitialized) {
      await this.initializeGridAtPrice(currentPrice);
      this.lastPrice = currentPrice;
      return;
    }

    // Check for trailing upper bound
    if (this.config.trailingUpperBound) {
      await this.rebuildGridWithTrailing(currentPrice);
    }

    // Check if price crossed any grid levels since last tick
    await this.checkGridCrossings(currentPrice);

    this.lastPrice = currentPrice;
  }

  /**
   * Check if price has crossed any grid levels since last tick.
   * If price crosses above a level with a buy, the buy was filled → place sell.
   * If price crosses below a level with a sell, the sell was filled → place buy.
   */
  private async checkGridCrossings(currentPrice: number): Promise<void> {
    if (this.lastPrice === 0) return;

    for (const level of this.gridLevels) {
      const crossedAbove = this.lastPrice <= level.price && currentPrice > level.price;
      const crossedBelow = this.lastPrice >= level.price && currentPrice < level.price;

      if (crossedAbove) {
        // Price crossed above this level
        if (level.buyOrderId) {
          // A buy was waiting here — it should have filled
          level.buyOrderId = null;
          level.exchangeBuyId = null;
          level.buyFilled = true;
          level.sellQuantity = level.buyQuantity;

          if (this.config.autoCompound) {
            level.sellQuantity *= 1.001; // Compound slightly
          }

          await this.placeGridSell(level);
          this.realizedPnl += this.gridSpacing * level.sellQuantity;

          logger.debug(`✅ Grid buy filled at $${level.price}, sell placed above`);
        }
      }

      if (crossedBelow) {
        // Price crossed below this level
        if (level.sellOrderId) {
          // A sell was waiting here — it should have filled
          level.sellOrderId = null;
          level.exchangeSellId = null;
          level.sellFilled = true;
          level.buyQuantity = level.sellQuantity;

          await this.placeGridBuy(level);

          logger.debug(`✅ Grid sell filled at $${level.price}, buy placed below`);
        }
      }
    }
  }

  /**
   * Get grid statistics.
   */
  getStats(): {
    totalLevels: number;
    activeBuyOrders: number;
    activeSellOrders: number;
    filledBuys: number;
    filledSells: number;
    totalBuys: number;
    totalSells: number;
    realizedPnl: number;
    gridSpacing: number;
    upperBound: number;
    lowerBound: number;
    currentRange: string;
  } {
    return {
      totalLevels: this.gridLevels.length,
      activeBuyOrders: this.gridLevels.filter((l) => l.buyOrderId !== null).length,
      activeSellOrders: this.gridLevels.filter((l) => l.sellOrderId !== null).length,
      filledBuys: this.gridLevels.filter((l) => l.buyFilled).length,
      filledSells: this.gridLevels.filter((l) => l.sellFilled).length,
      totalBuys: this.totalBuys,
      totalSells: this.totalSells,
      realizedPnl: this.realizedPnl,
      gridSpacing: this.gridSpacing,
      upperBound: this.upperBound,
      lowerBound: this.lowerBound,
      currentRange: `$${this.lowerBound.toFixed(2)} - $${this.upperBound.toFixed(2)}`,
    };
  }

  /**
   * Reconcile grid state — checks which orders are still open on exchange.
   * Called on engine restart to recover state.
   */
  async reconcileOrders(
    openOrders: Array<{ orderId: string; price: number; side: "buy" | "sell"; quantity: number }>
  ): Promise<void> {
    logger.info(`Reconciling ${openOrders.length} open orders with grid state`);

    // Reset all order tracking
    for (const level of this.gridLevels) {
      level.buyOrderId = null;
      level.exchangeBuyId = null;
      level.sellOrderId = null;
      level.exchangeSellId = null;
    }

    // Match open orders to grid levels
    for (const order of openOrders) {
      // Find the closest grid level to this order price
      const closestLevel = this.gridLevels.reduce((closest, level) => {
        const currentDiff = Math.abs(level.price - order.price);
        const closestDiff = Math.abs(closest.price - order.price);
        return currentDiff < closestDiff ? level : closest;
      });

      // If the order price is within 0.5% of a grid level, consider it matched
      const priceDiff = Math.abs(closestLevel.price - order.price) / closestLevel.price;
      if (priceDiff < 0.005) {
        if (order.side === "buy") {
          closestLevel.exchangeBuyId = order.orderId;
          closestLevel.buyOrderId = `reconciled_${order.orderId}`;
          closestLevel.buyFilled = false;
        } else {
          closestLevel.exchangeSellId = order.orderId;
          closestLevel.sellOrderId = `reconciled_${order.orderId}`;
          closestLevel.sellFilled = false;
        }
        logger.debug(`Reconciled ${order.side} order at $${order.price} → grid level $${closestLevel.price}`);
      }
    }

    const reconciledBuys = this.gridLevels.filter(l => l.exchangeBuyId).length;
    const reconciledSells = this.gridLevels.filter(l => l.exchangeSellId).length;
    logger.info(`Reconciliation complete: ${reconciledBuys} buys, ${reconciledSells} sells`);

    this.gridInitialized = true;
  }

  async onStop(): Promise<void> {
    logger.info(`Stopping grid bot. Cancelling all exchange orders...`);
    await this.cancelAllGridOrders();
    logger.info(`Grid bot stopped. Total realized PnL: $${this.realizedPnl.toFixed(2)} | Total round-trips: ${Math.min(this.totalBuys, this.totalSells)}`);
    await super.onStop();
  }

  async onPause(): Promise<void> {
    logger.info(`Pausing grid bot. Orders remain on exchange but no new crossings will be processed.`);
    await super.onPause();
  }

  async onResume(): Promise<void> {
    logger.info(`Resuming grid bot.`);
    // Reset lastPrice to current to avoid false crossing detection
    this.lastPrice = 0;
    await super.onResume();
  }
}