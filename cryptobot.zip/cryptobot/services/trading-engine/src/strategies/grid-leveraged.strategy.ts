import { GridStrategy } from "./grid.strategy";
import type { BotContext, OHLCV, Ticker } from "./base.strategy";
import { logger } from "../utils/logger";

export interface LeveragedGridConfig {
  upperPrice: number;
  lowerPrice: number;
  gridLevels: number;
  quantityPerGrid: number;
  mode: "futures";
  leverage: number;
  trailingUpperBound: boolean;
  autoCompound: boolean;
  marginMode: "isolated" | "cross";
}

/**
 * Leveraged Grid strategy.
 * Extends the standard grid strategy with leverage support (1x-125x).
 * Shows estimated liquidation price prominently before activation.
 *
 * IMPORTANT: Liquidation price is an ESTIMATE for display purposes.
 * Actual liquidation depends on exchange-specific maintenance margin,
 * funding rates, and other open positions (in cross margin mode).
 */
export class LeveragedGridStrategy extends GridStrategy {
  private leveragedConfig: LeveragedGridConfig;
  private estimatedLiquidationPrice: number = 0;
  private marginUsed: number = 0;
  private maintenanceMarginRate: number = 0.005; // 0.5% default, varies by exchange

  constructor(botContext: BotContext) {
    super(botContext);
    this.leveragedConfig = botContext.config as LeveragedGridConfig;

    // Adjust maintenance margin based on leverage tier
    if (this.leveragedConfig.leverage <= 5) this.maintenanceMarginRate = 0.005;
    else if (this.leveragedConfig.leverage <= 20) this.maintenanceMarginRate = 0.01;
    else if (this.leveragedConfig.leverage <= 50) this.maintenanceMarginRate = 0.025;
    else this.maintenanceMarginRate = 0.05; // 50x-125x
  }

  async onInit(): Promise<void> {
    await super.onInit();
    this.calculateEstimatedLiquidation();

    logger.warn(
      `⚠️ Leveraged Grid active: ${this.leveragedConfig.leverage}x | ` +
      `Mode: ${this.leveragedConfig.marginMode} | ` +
      `Est. liquidation: $${this.estimatedLiquidationPrice.toFixed(2)} | ` +
      `Margin required: $${this.marginUsed.toFixed(2)}`
    );
  }

  /**
   * Calculate estimated liquidation price.
   *
   * Isolated margin formula (simplified):
   *   liquidationPrice = entryPrice * (1 - 1/leverage + maintenanceMarginRate)
   *
   * Cross margin formula (simplified, assumes only this position):
   *   Same as isolated, but uses total account balance
   *
   * This is an ESTIMATE. Actual liquidation depends on:
   *   - Exchange's exact maintenance margin schedule
   *   - Funding rate at time of liquidation
   *   - Other open positions (cross margin)
   *   - Exchange insurance fund policies
   */
  private calculateEstimatedLiquidation(): void {
    const midPrice = (this.leveragedConfig.upperPrice + this.leveragedConfig.lowerPrice) / 2;
    const positionSize = midPrice * this.leveragedConfig.quantityPerGrid * this.leveragedConfig.gridLevels;

    // Estimated liquidation for the average entry price
    this.estimatedLiquidationPrice =
      midPrice * (1 - 1 / this.leveragedConfig.leverage + this.maintenanceMarginRate);

    // Margin used (position value / leverage)
    this.marginUsed = positionSize / this.leveragedConfig.leverage;

    // Adjust for isolated vs cross margin
    if (this.leveragedConfig.marginMode === "cross") {
      // Cross margin: liquidation depends on total account equity
      // We estimate assuming this is the only position
      this.estimatedLiquidationPrice =
        midPrice * (1 - 1 / this.leveragedConfig.leverage + this.maintenanceMarginRate * 0.8);
    }
  }

  async onTick(candle: OHLCV, ticker: Ticker): Promise<void> {
    const currentPrice = ticker.last || candle.close;

    // Calculate distance to estimated liquidation
    const distancePercent = ((currentPrice - this.estimatedLiquidationPrice) / currentPrice) * 100;
    const distanceDollars = currentPrice - this.estimatedLiquidationPrice;

    // Multi-level warnings
    if (distancePercent < 2) {
      this.emit(
        "onLog",
        "error",
        `🚨 CRITICAL: ${distancePercent.toFixed(1)}% ($${distanceDollars.toFixed(2)}) from est. liquidation at $${this.estimatedLiquidationPrice.toFixed(2)}`
      );
    } else if (distancePercent < 5) {
      this.emit(
        "onLog",
        "warn",
        `⚠️ WARNING: ${distancePercent.toFixed(1)}% ($${distanceDollars.toFixed(2)}) from est. liquidation at $${this.estimatedLiquidationPrice.toFixed(2)}`
      );
    } else if (distancePercent < 10) {
      this.emit(
        "onLog",
        "info",
        `ℹ️ Price approaching liquidation zone: ${distancePercent.toFixed(1)}% buffer remaining`
      );
    }

    // Auto-deleveraging prevention: if within 1%, close positions
    if (distancePercent < 1) {
      logger.error(
        `🚨 AUTO-CLOSE TRIGGERED: ${distancePercent.toFixed(1)}% from liquidation. ` +
        `Closing grid positions to prevent forced liquidation.`
      );
      await this.emergencyClose(currentPrice);
      return;
    }

    // Standard grid logic from parent
    await super.onTick(candle, ticker);
  }

  /**
   * Emergency close all positions to prevent liquidation.
   */
  private async emergencyClose(currentPrice: number): Promise<void> {
    logger.warn(`Emergency close initiated at $${currentPrice}`);
    await this.onStop();
  }

  /**
   * Get detailed liquidation information for the UI.
   * This should be displayed prominently before bot activation.
   */
  getLiquidationInfo(currentPrice?: number): {
    estimatedLiquidationPrice: number;
    currentDistancePercent: number;
    currentDistanceDollars: number;
    leverage: number;
    marginMode: string;
    marginUsed: number;
    maintenanceMarginRate: number;
    riskLevel: "safe" | "warning" | "danger" | "critical";
    disclaimer: string;
  } {
    const price = currentPrice || 0;
    const distancePct = price > 0 ? ((price - this.estimatedLiquidationPrice) / price) * 100 : 100;
    const distanceUsd = price - this.estimatedLiquidationPrice;

    let riskLevel: "safe" | "warning" | "danger" | "critical" = "safe";
    if (distancePct < 2) riskLevel = "critical";
    else if (distancePct < 5) riskLevel = "danger";
    else if (distancePct < 10) riskLevel = "warning";

    return {
      estimatedLiquidationPrice: Math.round(this.estimatedLiquidationPrice * 100) / 100,
      currentDistancePercent: Math.round(distancePct * 100) / 100,
      currentDistanceDollars: Math.round(Math.abs(distanceUsd) * 100) / 100,
      leverage: this.leveragedConfig.leverage,
      marginMode: this.leveragedConfig.marginMode,
      marginUsed: Math.round(this.marginUsed * 100) / 100,
      maintenanceMarginRate: this.maintenanceMarginRate,
      riskLevel,
      disclaimer:
        "This is an ESTIMATED liquidation price. Actual liquidation depends on " +
        "exchange-specific maintenance margin schedules, funding rates, and other positions. " +
        "Always maintain adequate margin buffer.",
    };
  }

  /**
   * Update the maintenance margin rate based on actual exchange data.
   * Call this when exchange-specific rates are available.
   */
  setMaintenanceMarginRate(rate: number): void {
    this.maintenanceMarginRate = rate;
    this.calculateEstimatedLiquidation();
    logger.info(`Maintenance margin updated to ${(rate * 100).toFixed(2)}% | New est. liquidation: $${this.estimatedLiquidationPrice.toFixed(2)}`);
  }

  getStats(): any {
    const baseStats = super.getStats();
    const liqInfo = this.getLiquidationInfo();
    return {
      ...baseStats,
      leverage: liqInfo.leverage,
      marginMode: liqInfo.marginMode,
      estimatedLiquidationPrice: liqInfo.estimatedLiquidationPrice,
      currentDistancePercent: liqInfo.currentDistancePercent,
      riskLevel: liqInfo.riskLevel,
      marginUsed: liqInfo.marginUsed,
    };
  }
}