import { BaseStrategy } from "./base.strategy";
import type { BotContext, OHLCV, Ticker, Position } from "./base.strategy";
import { MACD, EMA, ADX, crossAbove, crossBelow } from "../indicators";
import { v4 as uuidv4 } from "uuid";
import { logger } from "../utils/logger";

export interface MACDConfig {
  fastPeriod: number;
  slowPeriod: number;
  signalPeriod: number;
  baseOrderSize: number;
  takeProfitPercent: number;
  stopLossPercent: number;
  trailingTakeProfit: boolean;
  trailingDeviationPercent: number;
  useTrendFilter: boolean;
  adxPeriod: number;
  adxMinThreshold: number;
  cooldownBetweenDealsMinutes: number;
  minimumROI: Record<string, number>;
}

/**
 * MACD crossover strategy with ADX trend filter.
 *
 * Buys when MACD crosses above signal line (bullish).
 * Optionally filters with ADX to avoid ranging markets.
 * Sells on bearish crossover, TP, or SL.
 */
export class MACDStrategy extends BaseStrategy {
  private config: MACDConfig;
  private activeDealId: string | null = null;
  private entryPrice: number = 0;
  private positionQuantity: number = 0;
  private highestPriceSinceEntry: number = 0;
  private candles: OHLCV[] = [];
  private maxCandles: number = 300;
  private lastMACD: { macdLine: number; signalLine: number; histogram: number } | null = null;
  private prevMACD: { macdLine: number; signalLine: number; histogram: number } | null = null;

  constructor(botContext: BotContext) {
    super(botContext);
    this.config = botContext.config as MACDConfig;
  }

  async onInit(): Promise<void> {
    await super.onInit();
    logger.info(`MACD Strategy initialized for ${this.botContext.pair}`, {
      fast: this.config.fastPeriod,
      slow: this.config.slowPeriod,
      signal: this.config.signalPeriod,
      takeProfit: `${this.config.takeProfitPercent}%`,
      stopLoss: `${this.config.stopLossPercent}%`,
      trendFilter: this.config.useTrendFilter ? `ADX(${this.config.adxPeriod}) > ${this.config.adxMinThreshold}` : "disabled",
    });
  }

  /**
   * Calculate current MACD values efficiently.
   */
  private calculateMACD(): { macdLine: number; signalLine: number; histogram: number } | null {
    const minCandles = this.config.slowPeriod + this.config.signalPeriod + 2;
    if (this.candles.length < minCandles) return null;

    const closes = this.candles.map((c) => c.close);
    const result = MACD(closes, this.config.fastPeriod, this.config.slowPeriod, this.config.signalPeriod);

    // Only check the last 2 values for crossover detection
    const macdArr = result.macd;
    const signalArr = result.signal;
    const histArr = result.histogram;

    if (macdArr.length < 2 || signalArr.length < 2) return null;

    return {
      macdLine: macdArr[macdArr.length - 1] || 0,
      signalLine: signalArr[signalArr.length - 1] || 0,
      histogram: histArr[histArr.length - 1] || 0,
    };
  }

  /**
   * Detect MACD crossover using only the last 2 values.
   */
  private detectCrossover(): "bullish" | "bearish" | null {
    if (!this.prevMACD || !this.lastMACD) return null;

    const prevDiff = this.prevMACD.macdLine - this.prevMACD.signalLine;
    const currDiff = this.lastMACD.macdLine - this.lastMACD.signalLine;

    if (prevDiff <= 0 && currDiff > 0) return "bullish";
    if (prevDiff >= 0 && currDiff < 0) return "bearish";

    return null;
  }

  /**
   * Check ADX trend strength.
   * ADX > 25 indicates trending market (good for MACD).
   * ADX < 20 indicates ranging market (bad for MACD).
   */
  private isTrending(): boolean {
    if (!this.config.useTrendFilter) return true;

    if (this.candles.length < this.config.adxPeriod + 1) return true; // Not enough data, allow by default

    const highs = this.candles.map((c) => c.high);
    const lows = this.candles.map((c) => c.low);
    const closes = this.candles.map((c) => c.close);

    const adxValues = ADX(highs, lows, closes, this.config.adxPeriod);
    const currentADX = adxValues[adxValues.length - 1] || 0;

    const isTrending = currentADX >= this.config.adxMinThreshold;

    if (!isTrending) {
      logger.debug(`ADX filter: ${currentADX.toFixed(1)} < ${this.config.adxMinThreshold} — signal suppressed`);
    }

    return isTrending;
  }

  private shouldStartDeal(candle: OHLCV): boolean {
    if (this.activeDealId) return false;
    if (this.isInCooldown(this.botContext.pair)) return false;
    if (this.checkVolatility(candle)) return false;

    const crossover = this.detectCrossover();
    if (crossover !== "bullish") return false;

    if (!this.isTrending()) return false;

    return true;
  }

  async onTick(candle: OHLCV, ticker: Ticker): Promise<void> {
    this.candles.push(candle);
    if (this.candles.length > this.maxCandles) {
      this.candles.shift();
    }

    // Update MACD state
    this.prevMACD = this.lastMACD;
    this.lastMACD = this.calculateMACD();

    const currentPrice = ticker.last || candle.close;

    if (!this.activeDealId && this.shouldStartDeal(candle)) {
      await this.startDeal(currentPrice);
      return;
    }

    if (!this.activeDealId) return;

    if (currentPrice > this.highestPriceSinceEntry) {
      this.highestPriceSinceEntry = currentPrice;
    }

    // Stop loss
    const slPrice = this.entryPrice * (1 - this.config.stopLossPercent / 100);
    if (currentPrice <= slPrice) {
      await this.closeDeal(currentPrice, `SL: -${this.config.stopLossPercent}%`);
      return;
    }

    // Trailing take profit
    if (this.config.trailingTakeProfit) {
      const trailPrice = this.highestPriceSinceEntry * (1 - this.config.trailingDeviationPercent / 100);
      const profitPercent = ((currentPrice - this.entryPrice) / this.entryPrice) * 100;
      if (currentPrice <= trailPrice && profitPercent > 0) {
        await this.closeDeal(currentPrice, `Trailing TP: ${profitPercent.toFixed(2)}%`);
        return;
      }
    }

    // Fixed take profit
    const profitPercent = ((currentPrice - this.entryPrice) / this.entryPrice) * 100;
    if (profitPercent >= this.config.takeProfitPercent) {
      await this.closeDeal(currentPrice, `TP: ${profitPercent.toFixed(2)}%`);
      return;
    }

    // MACD bearish crossover exit (only if in profit)
    const crossover = this.detectCrossover();
    if (crossover === "bearish" && profitPercent > 0) {
      await this.closeDeal(currentPrice, `MACD bearish crossover (+${profitPercent.toFixed(2)}%)`);
      return;
    }
  }

  private async startDeal(currentPrice: number): Promise<void> {
    this.activeDealId = uuidv4();
    this.entryPrice = currentPrice;
    this.highestPriceSinceEntry = currentPrice;

    try {
      const order = await this.placeBuyOrder(this.config.baseOrderSize);
      this.positionQuantity = order.quantity;

      const position: Position = {
        id: `macd_${this.activeDealId}`,
        botId: this.botContext.botId,
        pair: this.botContext.pair,
        entryPrice: currentPrice,
        currentPrice,
        quantity: this.positionQuantity,
        side: "buy",
        unrealizedPnl: 0,
        realizedPnl: 0,
        stopLoss: currentPrice * (1 - this.config.stopLossPercent / 100),
        takeProfit: [{ price: currentPrice * (1 + this.config.takeProfitPercent / 100), percentage: 100 }],
        safetyOrders: null,
        minimumROI: this.config.minimumROI,
        status: "open",
        openedAt: new Date(),
      };

      this.openPosition(position);

      const macdInfo = this.lastMACD
        ? ` | MACD: ${this.lastMACD.macdLine.toFixed(4)} / Signal: ${this.lastMACD.signalLine.toFixed(4)}`
        : "";

      this.emit("onLog", "info", `MACD bullish crossover — BUY ${order.quantity} @ $${currentPrice}${macdInfo}`);

      if (this.botContext.protectionConfig?.stoplossOnExchange) {
        this.emit("onSignal", { action: "sell", price: position.stopLoss!, reason: "stop_loss" });
      }
    } catch (error) {
      this.emit("onError", error as Error);
      this.activeDealId = null;
    }
  }

  private async closeDeal(currentPrice: number, reason: string): Promise<void> {
    if (!this.activeDealId) return;

    try {
      await this.placeSellOrder(this.positionQuantity);

      const pnl = (currentPrice - this.entryPrice) * this.positionQuantity;
      const pnlPercent = ((currentPrice - this.entryPrice) / this.entryPrice) * 100;
      this.closePosition(`macd_${this.activeDealId}`, pnl);

      this.emit("onLog", "info", `MACD deal closed: ${reason} | PnL: $${pnl.toFixed(2)} (${pnlPercent.toFixed(2)}%)`);

      this.setCooldown(this.botContext.pair);

      this.activeDealId = null;
      this.positionQuantity = 0;
      this.entryPrice = 0;
      this.highestPriceSinceEntry = 0;
    } catch (error) {
      this.emit("onError", error as Error);
    }
  }

  async onStop(): Promise<void> {
    if (this.activeDealId) {
      await this.closeDeal(this.entryPrice, "Bot stopped");
    }
    await super.onStop();
  }
}