import { EventEmitter } from "node:events";
import { logger } from "../utils/logger";

export type StrategyType =
  | "dca"
  | "grid"
  | "grid-infinity"
  | "grid-leveraged"
  | "martingale"
  | "macd"
  | "bollinger"
  | "arbitrage"
  | "marketmaking"
  | "avellaneda"
  | "rebalancing"
  | "twap"
  | "ml";

export type BotStatus = "active" | "paused" | "stopped" | "error";
export type TradeSide = "buy" | "sell";
export type OrderType = "market" | "limit";

export interface OHLCV {
  timestamp: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

export interface Ticker {
  symbol: string;
  last: number;
  bid: number;
  ask: number;
  high24h: number;
  low24h: number;
  volume24h: number;
  timestamp: number;
}

export interface OrderRequest {
  symbol: string;
  side: TradeSide;
  type: OrderType;
  quantity: number;
  price?: number;
  reduceOnly?: boolean;
  leverage?: number;
}

export interface OrderResult {
  orderId: string;
  exchangeOrderId: string;
  symbol: string;
  side: TradeSide;
  type: OrderType;
  quantity: number;
  price: number | null;
  filledPrice: number | null;
  status: "open" | "filled" | "cancelled" | "rejected";
  fee: number;
  feeCurrency: string | null;
  createdAt: Date;
  filledAt: Date | null;
}

export interface StrategyConfig {
  [key: string]: any;
}

export interface Position {
  id: string;
  botId: string;
  pair: string;
  entryPrice: number;
  currentPrice: number;
  quantity: number;
  side: TradeSide;
  unrealizedPnl: number;
  realizedPnl: number;
  stopLoss: number | null;
  takeProfit: { price: number; percentage: number }[] | null;
  safetyOrders: SafetyOrderState[] | null;
  minimumROI: Record<string, number> | null;
  status: "open" | "closed";
  openedAt: Date;
}

export interface SafetyOrderState {
  index: number;
  triggerPrice: number;
  quantity: number;
  filled: boolean;
  filledPrice: number | null;
}

export interface DealStartCondition {
  type: "webhook" | "rsi" | "price_breakout" | "bollinger" | "ema_cross" | "macd_cross" | "scheduled" | "manual";
  params: Record<string, any>;
}

export interface ProtectionConfig {
  stoplossOnExchange: boolean;
  stoplossPercent: number;
  cooldownMinutes: number;
  maxOpenDeals: number;
  minimumROI: Record<string, number>;
  volatilityProtectionEnabled: boolean;
  volatilityThreshold: number;
  staleOrderTimeoutMinutes: number;
}

export interface BotContext {
  botId: string;
  userId: string;
  exchange: string;
  pair: string;
  strategyType: StrategyType;
  config: StrategyConfig;
  status: BotStatus;
  paperTrading: boolean;
  protectionConfig: ProtectionConfig | null;
  dealStartConditions: DealStartCondition[] | null;
}

export interface StrategyEvents {
  onSignal: (signal: { action: TradeSide; price: number; reason: string }) => void;
  onOrderRequested: (order: OrderRequest) => Promise<OrderResult>;
  onOrderFilled: (order: OrderResult) => void;
  onPositionOpened: (position: Position) => void;
  onPositionClosed: (position: Position, pnl: number) => void;
  onError: (error: Error) => void;
  onLog: (level: string, message: string, data?: any) => void;
}

export abstract class BaseStrategy extends EventEmitter {
  protected botContext: BotContext;
  protected positions: Map<string, Position> = new Map();
  protected openOrders: Map<string, OrderResult> = new Map();
  protected lastSignalTime: Date | null = null;
  protected cooldowns: Map<string, Date> = new Map();

  constructor(botContext: BotContext) {
    super();
    this.botContext = botContext;
  }

  // ============================================================
  // LIFECYCLE HOOKS (overridden by each strategy)
  // ============================================================

  /** Called once when the strategy is initialized */
  async onInit(): Promise<void> {
    this.emit("onLog", "info", `Strategy initialized: ${this.botContext.strategyType}`);
  }

  /** Called on each new candle/tick */
  abstract onTick(candle: OHLCV, ticker: Ticker): Promise<void>;

  /** Called when a price update arrives (can be much faster than candles) */
  async onPrice(price: number, ticker: Ticker): Promise<void> {
    // Default: do nothing, override in strategies that need tick-level updates
  }

  /** Called when an order is filled */
  async onOrderFilled(order: OrderResult): Promise<void> {
    this.openOrders.delete(order.orderId);
    this.emit("onOrderFilled", order);
  }

  /** Called when the bot is paused */
  async onPause(): Promise<void> {
    logger.info(`Bot ${this.botContext.botId} paused`);
  }

  /** Called when the bot is resumed */
  async onResume(): Promise<void> {
    logger.info(`Bot ${this.botContext.botId} resumed`);
  }

  /** Called when the bot is stopped */
  async onStop(): Promise<void> {
    logger.info(`Bot ${this.botContext.botId} stopped`);
  }

  // ============================================================
  // ORDER METHODS
  // ============================================================
  protected async placeOrder(order: OrderRequest): Promise<OrderResult> {
    if (this.botContext.status !== "active") {
      throw new Error(`Bot ${this.botContext.botId} is not active`);
    }

    this.emit("onLog", "info", `Placing ${order.side} ${order.type} order: ${order.quantity} @ ${order.price || "market"}`);

    // The engine handles actual exchange communication
    return new Promise((resolve, reject) => {
      this.emit("onOrderRequested", order);
      // Engine will call onOrderFilled when complete
      // For now, assume it resolves via event
      const timeout = setTimeout(() => {
        reject(new Error(`Order timeout for ${order.symbol}`));
      }, 30000);

      this.once("onOrderFilled", (filled: OrderResult) => {
        clearTimeout(timeout);
        resolve(filled);
      });
    });
  }

  protected async placeBuyOrder(quantity: number, price?: number): Promise<OrderResult> {
    return this.placeOrder({
      symbol: this.botContext.pair,
      side: "buy",
      type: price ? "limit" : "market",
      quantity,
      price,
    });
  }

  protected async placeSellOrder(quantity: number, price?: number): Promise<OrderResult> {
    return this.placeOrder({
      symbol: this.botContext.pair,
      side: "sell",
      type: price ? "limit" : "market",
      quantity,
      price,
    });
  }

  // ============================================================
  // POSITION MANAGEMENT
  // ============================================================
  protected openPosition(position: Position): void {
    this.positions.set(position.id, position);
    this.emit("onPositionOpened", position);
  }

  protected closePosition(positionId: string, pnl: number): void {
    const position = this.positions.get(positionId);
    if (position) {
      position.status = "closed";
      position.realizedPnl = pnl;
      this.emit("onPositionClosed", position, pnl);
      this.positions.delete(positionId);
    }
  }

  protected getOpenPositions(): Position[] {
    return Array.from(this.positions.values()).filter((p) => p.status === "open");
  }

  protected getOpenPositionCount(): number {
    return this.getOpenPositions().length;
  }

  // ============================================================
  // PROTECTION CHECKS
  // ============================================================

  /** Check if minimum ROI time-based rules require closing */
  protected checkMinimumROI(position: Position, currentPrice: number): boolean {
    const minimumROI = this.botContext.protectionConfig?.minimumROI || {};
    if (Object.keys(minimumROI).length === 0) return false;

    const elapsedMinutes = (Date.now() - position.openedAt.getTime()) / 60000;
    const profitPercent = ((currentPrice - position.entryPrice) / position.entryPrice) * 100;

    // Sort ROI thresholds by time (ascending)
    const thresholds = Object.entries(minimumROI)
      .map(([minutes, roi]) => ({ minutes: parseInt(minutes), roi }))
      .sort((a, b) => a.minutes - b.minutes);

    for (let i = 0; i < thresholds.length; i++) {
      const threshold = thresholds[i]!;
      const nextThreshold = thresholds[i + 1];

      if (elapsedMinutes >= threshold.minutes) {
        // If there's a next threshold, check if we're between them
        if (nextThreshold && elapsedMinutes >= nextThreshold.minutes) {
          continue;
        }
        // We're in this threshold's time window
        if (profitPercent >= threshold.roi) {
          return true;
        }
      }
    }

    return false;
  }

  /** Check if volatility protection should pause the bot */
  protected checkVolatility(candle: OHLCV): boolean {
    if (!this.botContext.protectionConfig?.volatilityProtectionEnabled) return false;

    const bodyPercent = Math.abs(candle.close - candle.open) / candle.open * 100;
    const threshold = this.botContext.protectionConfig.volatilityThreshold;

    if (bodyPercent > threshold) {
      this.emit("onLog", "warn", `Volatility protection triggered: ${bodyPercent.toFixed(2)}% > ${threshold}%`);
      return true;
    }

    return false;
  }

  /** Check if bot is in cooldown for a specific pair */
  protected isInCooldown(pair: string): boolean {
    const cooldownUntil = this.cooldowns.get(pair);
    if (cooldownUntil && new Date() < cooldownUntil) {
      return true;
    }
    return false;
  }

  /** Set cooldown for a pair */
  protected setCooldown(pair: string): void {
    const minutes = this.botContext.protectionConfig?.cooldownMinutes || 30;
    const cooldownUntil = new Date(Date.now() + minutes * 60000);
    this.cooldowns.set(pair, cooldownUntil);
  }

  // ============================================================
  // SIGNAL GENERATION
  // ============================================================
  protected emitSignal(action: TradeSide, price: number, reason: string): void {
    // Check if max open deals reached
    const maxDeals = this.botContext.protectionConfig?.maxOpenDeals || 5;
    if (action === "buy" && this.getOpenPositionCount() >= maxDeals) {
      this.emit("onLog", "info", `Max open deals reached (${maxDeals}), skipping buy signal`);
      return;
    }

    this.lastSignalTime = new Date();
    this.emit("onSignal", { action, price, reason });
  }

  // ============================================================
  // UTILITY METHODS
  // ============================================================
  protected calculateProfitPercent(entryPrice: number, currentPrice: number, side: TradeSide): number {
    if (side === "buy") {
      return ((currentPrice - entryPrice) / entryPrice) * 100;
    } else {
      return ((entryPrice - currentPrice) / entryPrice) * 100;
    }
  }

  protected calculateStopLossPrice(entryPrice: number, side: TradeSide): number {
    const percent = this.botContext.protectionConfig?.stoplossPercent || 10;
    if (side === "buy") {
      return entryPrice * (1 - percent / 100);
    } else {
      return entryPrice * (1 + percent / 100);
    }
  }

  getBotContext(): BotContext {
    return this.botContext;
  }

  getStrategyType(): StrategyType {
    return this.botContext.strategyType;
  }

  getPair(): string {
    return this.botContext.pair;
  }
}