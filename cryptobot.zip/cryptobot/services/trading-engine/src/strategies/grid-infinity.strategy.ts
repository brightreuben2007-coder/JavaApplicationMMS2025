import { BaseStrategy } from "./base.strategy";
import type { BotContext, OHLCV, Ticker, OrderResult } from "./base.strategy";
import { v4 as uuidv4 } from "uuid";
import { logger } from "../utils/logger";

export interface InfinityGridConfig {
  lowerPrice: number;
  initialQuantity: number;
  gridSpacingPercent: number;
  autoCompound: boolean;
}

interface DynamicGridLevel {
  id: string;
  price: number;
  side: "buy" | "sell";
  quantity: number;
  orderId: string | null;
  filled: boolean;
  createdAt: Date;
}

/**
 * Infinity Grid strategy.
 * Has a lower bound but NO upper bound.
 * Creates new grid levels dynamically as price rises.
 * Captures unlimited upside in bull markets.
 *
 * This is Pionex's signature innovation.
 */
export class InfinityGridStrategy extends BaseStrategy {
  private config: InfinityGridConfig;
  private gridLevels: Map<string, DynamicGridLevel> = new Map();
  private activeOrders: Map<string, DynamicGridLevel> = new Map();
  private lastPrice: number = 0;
  private highestPriceSinceStart: number = 0;
  private lowestLevelPrice: number = 0;
  private highestLevelPlaced: number = 0;
  private realizedPnl: number = 0;
  private baseAssetHeld: number = 0;
  private quoteAssetHeld: number = 0;
  private initialized: boolean = false;

  constructor(botContext: BotContext) {
    super(botContext);
    this.config = botContext.config as InfinityGridConfig;
  }

  async onInit(): Promise<void> {
    await super.onInit();
    this.lowestLevelPrice = this.config.lowerPrice;
    logger.info(`Infinity Grid initialized for ${this.botContext.pair}`, {
      lowerPrice: this.config.lowerPrice,
      gridSpacing: `${this.config.gridSpacingPercent}%`,
      initialQuantity: this.config.initialQuantity,
    });
  }

  /**
   * Calculate the next grid level price based on a reference price and direction.
   */
  private nextLevelPrice(referencePrice: number, direction: "up" | "down"): number {
    const multiplier = direction === "up"
      ? 1 + this.config.gridSpacingPercent / 100
      : 1 - this.config.gridSpacingPercent / 100;
    return Math.round(referencePrice * multiplier * 100) / 100;
  }

  /**
   * Create a new grid level.
   */
  private createLevel(
    price: number,
    side: "buy" | "sell",
    quantity: number
  ): DynamicGridLevel {
    const level: DynamicGridLevel = {
      id: uuidv4(),
      price,
      side,
      quantity,
      orderId: null,
      filled: false,
      createdAt: new Date(),
    };

    this.gridLevels.set(level.id, level);
    return level;
  }

  async onTick(candle: OHLCV, ticker: Ticker): Promise<void> {
    const currentPrice = ticker.last || candle.close;

    if (currentPrice > this.highestPriceSinceStart) {
      this.highestPriceSinceStart = currentPrice;
    }

    // Initialize on first tick
    if (!this.initialized) {
      await this.initialize(currentPrice);
      this.lastPrice = currentPrice;
      this.initialized = true;
      return;
    }

    // Check volatility
    if (this.checkVolatility(candle)) {
      return;
    }

    // Expand grid upward if needed (the "infinity" part)
    await this.expandGridUpward(currentPrice);

    // Check for level crossings
    await this.checkLevelCrossings(currentPrice);

    this.lastPrice = currentPrice;
  }

  /**
   * Initialize the grid at the current price.
   * Places buy levels below current price and sell levels above.
   */
  private async initialize(currentPrice: number): Promise<void> {
    // Calculate initial number of levels downward to the floor
    let price = currentPrice;
    const initialBuyLevels: DynamicGridLevel[] = [];

    // Place buy levels going down to the floor
    while (price > this.config.lowerPrice) {
      price = this.nextLevelPrice(price, "down");
      if (price >= this.config.lowerPrice) {
        const level = this.createLevel(price, "buy", this.config.initialQuantity);
        initialBuyLevels.push(level);
      }
    }

    // Place the floor level
    const floorLevel = this.createLevel(this.config.lowerPrice, "buy", this.config.initialQuantity);
    initialBuyLevels.push(floorLevel);

    // Place buy orders for all initial buy levels
    for (const level of initialBuyLevels.reverse()) {
      await this.placeGridOrder(level);
    }

    // Place initial sell level above current price
    const sellPrice = this.nextLevelPrice(currentPrice, "up");
    const sellLevel = this.createLevel(sellPrice, "sell", this.config.initialQuantity);
    await this.placeGridOrder(sellLevel);
    this.highestLevelPlaced = sellPrice;

    logger.info(`Infinity Grid initialized at $${currentPrice}`, {
      buyLevels: initialBuyLevels.length,
      floorPrice: this.config.lowerPrice,
      firstSellPrice: sellPrice,
    });
  }

  /**
   * Expand the grid upward when price rises beyond existing sell levels.
   * This is the "infinity" mechanism — creates new levels forever.
   */
  private async expandGridUpward(currentPrice: number): Promise<void> {
    // Check if price is approaching the highest sell level
    const buffer = this.highestLevelPlaced * (1 - this.config.gridSpacingPercent / 200);

    if (currentPrice >= buffer && currentPrice > this.highestLevelPlaced * 0.99) {
      // Create new sell levels above current highest
      let nextPrice = this.nextLevelPrice(this.highestLevelPlaced, "up");

      // Create up to 3 new levels at a time to stay ahead of price
      for (let i = 0; i < 3; i++) {
        const level = this.createLevel(nextPrice, "sell", this.config.initialQuantity);
        await this.placeGridOrder(level, "sell");
        this.highestLevelPlaced = nextPrice;
        nextPrice = this.nextLevelPrice(nextPrice, "up");
      }

      logger.info(`Grid expanded upward: highest sell now at $${this.highestLevelPlaced}`);
    }
  }

  /**
   * Place a grid order (buy or sell).
   */
  private async placeGridOrder(
    level: DynamicGridLevel,
    overrideSide?: "buy" | "sell"
  ): Promise<void> {
    const side = overrideSide || level.side;

    try {
      const order = side === "buy"
        ? await this.placeBuyOrder(level.quantity, level.price)
        : await this.placeSellOrder(level.quantity, level.price);

      level.orderId = order.orderId;
      level.filled = false;
      this.activeOrders.set(order.orderId, level);

      logger.debug(`Infinity grid ${side} placed at $${level.price}`);
    } catch (error) {
      logger.error(`Failed to place infinity grid ${side} order at $${level.price}`, { error });
    }
  }

  /**
   * Check if price has crossed any active grid levels.
   */
  private async checkLevelCrossings(currentPrice: number): Promise<void> {
    for (const [orderId, level] of this.activeOrders.entries()) {
      if (level.side === "buy" && this.lastPrice <= level.price && currentPrice > level.price) {
        // Buy level crossed — order filled
        await this.onBuyFilled(level, orderId, currentPrice);
      } else if (level.side === "sell" && this.lastPrice >= level.price && currentPrice < level.price) {
        // Sell level crossed — order filled
        await this.onSellFilled(level, orderId, currentPrice);
      }
    }
  }

  /**
   * Handle a buy order fill: place a corresponding sell above.
   */
  private async onBuyFilled(
    buyLevel: DynamicGridLevel,
    orderId: string,
    currentPrice: number
  ): Promise<void> {
    this.activeOrders.delete(orderId);
    buyLevel.filled = true;

    this.baseAssetHeld += buyLevel.quantity;
    this.quoteAssetHeld -= buyLevel.price * buyLevel.quantity;

    // Place a sell order one level above
    const sellPrice = this.nextLevelPrice(buyLevel.price, "up");
    const sellQty = this.config.autoCompound
      ? buyLevel.quantity * 1.001
      : buyLevel.quantity;

    const sellLevel = this.createLevel(sellPrice, "sell", sellQty);
    await this.placeGridOrder(sellLevel);

    this.emit("onLog", "info", `Infinity grid: bought at $${buyLevel.price}, placed sell at $${sellPrice}`);
  }

  /**
   * Handle a sell order fill: place a corresponding buy below.
   */
  private async onSellFilled(
    sellLevel: DynamicGridLevel,
    orderId: string,
    currentPrice: number
  ): Promise<void> {
    this.activeOrders.delete(orderId);
    sellLevel.filled = true;

    const profit = sellLevel.price * sellLevel.quantity * (this.config.gridSpacingPercent / 100);
    this.realizedPnl += profit;

    this.baseAssetHeld -= sellLevel.quantity;
    this.quoteAssetHeld += sellLevel.price * sellLevel.quantity;

    // Place a buy order one level below
    const buyPrice = this.nextLevelPrice(sellLevel.price, "down");
    const buyQty = this.config.autoCompound
      ? sellLevel.quantity * 1.001
      : sellLevel.quantity;

    // Only place buy if above the floor
    if (buyPrice >= this.config.lowerPrice) {
      const buyLevel = this.createLevel(buyPrice, "buy", buyQty);
      await this.placeGridOrder(buyLevel);
    }

    this.emit("onLog", "info", `Infinity grid: sold at $${sellLevel.price}, placed buy at $${buyPrice} | PnL: $${profit.toFixed(2)}`);
  }

  /**
   * Get grid statistics.
   */
  getStats(): {
    totalLevels: number;
    activeOrders: number;
    buyLevels: number;
    sellLevels: number;
    realizedPnl: number;
    baseAssetHeld: number;
    quoteAssetHeld: number;
    floorPrice: number;
    highestSellLevel: number;
    highestPriceReached: number;
  } {
    const levels = Array.from(this.gridLevels.values());
    return {
      totalLevels: levels.length,
      activeOrders: this.activeOrders.size,
      buyLevels: levels.filter((l) => l.side === "buy").length,
      sellLevels: levels.filter((l) => l.side === "sell").length,
      realizedPnl: this.realizedPnl,
      baseAssetHeld: this.baseAssetHeld,
      quoteAssetHeld: this.quoteAssetHeld,
      floorPrice: this.config.lowerPrice,
      highestSellLevel: this.highestLevelPlaced,
      highestPriceReached: this.highestPriceSinceStart,
    };
  }

  async onStop(): Promise<void> {
    logger.info(`Infinity Grid stopped. Realized PnL: $${this.realizedPnl.toFixed(2)}`);
    await super.onStop();
  }
}