import { BaseStrategy } from "./base.strategy";
import type { BotContext, OHLCV, Ticker } from "./base.strategy";
import { logger } from "../utils/logger";

export interface RebalancingConfig {
  targetAllocations: { asset: string; percentage: number }[];
  rebalanceTriggerPercent: number;
  rebalanceIntervalMinutes: number;
  useLimitOrders: boolean;
}

interface AssetBalance {
  asset: string;
  free: number;
  locked: number;
  price: number;
  value: number;
  currentPercent: number;
  targetPercent: number;
  drift: number;
  action: "buy" | "sell" | "hold";
  amountToTrade: number;
}

/**
 * Portfolio Rebalancing Strategy.
 * Maintains target asset allocation by automatically buying/selling
 * when any asset drifts beyond the trigger threshold.
 *
 * Example: Target 50% BTC / 30% ETH / 20% USDT
 * If BTC rises to 58%, sell 8% worth of BTC and buy ETH/USDT.
 */
export class RebalancingStrategy extends BaseStrategy {
  private config: RebalancingConfig;
  private balances: Map<string, AssetBalance> = new Map();
  private prices: Map<string, number> = new Map();
  private lastRebalanceTime: number = 0;
  private totalPortfolioValue: number = 0;
  private isRebalancing: boolean = false;
  private rebalanceCount: number = 0;
  private totalFees: number = 0;

  constructor(botContext: BotContext) {
    super(botContext);
    this.config = botContext.config as RebalancingConfig;

    // Validate allocations sum to 100%
    const total = this.config.targetAllocations.reduce((sum, a) => sum + a.percentage, 0);
    if (Math.abs(total - 100) > 0.01) {
      logger.warn(`Target allocations sum to ${total}%, not 100%. Adjusting proportionally.`);
      const scale = 100 / total;
      this.config.targetAllocations = this.config.targetAllocations.map(a => ({
        ...a,
        percentage: Math.round(a.percentage * scale * 100) / 100,
      }));
    }
  }

  async onInit(): Promise<void> {
    await super.onInit();
    logger.info(`Rebalancing Strategy initialized`, {
      allocations: this.config.targetAllocations.map(a => `${a.asset}: ${a.percentage}%`).join(", "),
      triggerPercent: `${this.config.rebalanceTriggerPercent}%`,
      interval: `${this.config.rebalanceIntervalMinutes}min`,
    });
  }

  /**
   * Update balances and prices from external data.
   */
  updateMarketData(
    balanceData: { asset: string; free: number; locked: number }[],
    priceData: { asset: string; price: number }[]
  ): void {
    for (const b of balanceData) {
      this.balances.set(b.asset, {
        asset: b.asset,
        free: b.free,
        locked: b.locked,
        price: 0,
        value: 0,
        currentPercent: 0,
        targetPercent: 0,
        drift: 0,
        action: "hold",
        amountToTrade: 0,
      });
    }

    for (const p of priceData) {
      this.prices.set(p.asset, p.price);
    }
  }

  /**
   * Calculate current portfolio state and detect drift.
   */
  private analyzePortfolio(): {
    needsRebalance: boolean;
    totalValue: number;
    assets: AssetBalance[];
    maxDrift: number;
  } {
    // Update prices in balances
    for (const [asset, balance] of this.balances.entries()) {
      const price = this.prices.get(asset) || 0;
      balance.price = price;
      balance.value = (balance.free + balance.locked) * price;
    }

    // Calculate total portfolio value
    this.totalPortfolioValue = Array.from(this.balances.values())
      .reduce((sum, b) => sum + b.value, 0);

    if (this.totalPortfolioValue <= 0) {
      return { needsRebalance: false, totalValue: 0, assets: [], maxDrift: 0 };
    }

    let maxDrift = 0;
    const assets: AssetBalance[] = [];

    // Analyze each position against targets
    for (const target of this.config.targetAllocations) {
      const balance = this.balances.get(target.asset);
      const currentPercent = balance
        ? (balance.value / this.totalPortfolioValue) * 100
        : 0;

      const drift = currentPercent - target.percentage;
      const absDrift = Math.abs(drift);

      if (absDrift > maxDrift) maxDrift = absDrift;

      let action: "buy" | "sell" | "hold" = "hold";
      let amountToTrade = 0;

      if (absDrift >= this.config.rebalanceTriggerPercent) {
        const targetValue = this.totalPortfolioValue * (target.percentage / 100);
        const currentValue = balance?.value || 0;
        const difference = targetValue - currentValue;

        if (difference > 0) {
          action = "buy";
          amountToTrade = difference;
        } else if (difference < 0) {
          action = "sell";
          amountToTrade = Math.abs(difference);
        }
      }

      assets.push({
        asset: target.asset,
        free: balance?.free || 0,
        locked: balance?.locked || 0,
        price: balance?.price || 0,
        value: balance?.value || 0,
        currentPercent,
        targetPercent: target.percentage,
        drift,
        action,
        amountToTrade,
      });
    }

    return {
      needsRebalance: maxDrift >= this.config.rebalanceTriggerPercent,
      totalValue: this.totalPortfolioValue,
      assets,
      maxDrift,
    };
  }

  async onTick(candle: OHLCV, ticker: Ticker): Promise<void> {
    const now = Date.now();
    const intervalMs = this.config.rebalanceIntervalMinutes * 60000;

    // Only check at configured interval
    if (now - this.lastRebalanceTime < intervalMs) return;
    this.lastRebalanceTime = now;

    if (this.isRebalancing) {
      logger.debug("Rebalance already in progress, skipping");
      return;
    }

    const analysis = this.analyzePortfolio();

    if (!analysis.needsRebalance) {
      logger.debug(`No rebalance needed. Max drift: ${analysis.maxDrift.toFixed(2)}%`);
      return;
    }

    await this.executeRebalance(analysis.assets);
  }

  /**
   * Execute the rebalance by buying and selling to reach targets.
   */
  private async executeRebalance(assets: AssetBalance[]): Promise<void> {
    this.isRebalancing = true;
    this.rebalanceCount++;

    logger.info(`🔄 Rebalance #${this.rebalanceCount} triggered. Portfolio: $${this.totalPortfolioValue.toFixed(2)}`);

    // Sell first to raise funds, then buy
    const sells = assets.filter(a => a.action === "sell" && a.price > 0);
    const buys = assets.filter(a => a.action === "buy" && a.price > 0);

    let quoteRaised = 0;

    // Execute sells
    for (const sell of sells) {
      try {
        const quantity = sell.amountToTrade / sell.price;
        const order = this.config.useLimitOrders
          ? await this.placeSellOrder(quantity, sell.price * 0.999) // Limit slightly below market
          : await this.placeSellOrder(quantity);

        const filledPrice = order.filledPrice || sell.price;
        quoteRaised += filledPrice * order.quantity;
        this.totalFees += order.fee;

        logger.info(`  Sold ${order.quantity.toFixed(4)} ${sell.asset} @ $${filledPrice.toFixed(2)} (drift: ${sell.drift > 0 ? '+' : ''}${sell.drift.toFixed(1)}%)`);
      } catch (error) {
        logger.error(`  Failed to sell ${sell.asset}`, { error: (error as Error).message });
      }
    }

    // Execute buys with raised funds
    if (quoteRaised > 0 && buys.length > 0) {
      const quotePerBuy = quoteRaised / buys.length;

      for (const buy of buys) {
        try {
          const quantity = quotePerBuy / buy.price;
          const order = this.config.useLimitOrders
            ? await this.placeBuyOrder(quantity, buy.price * 1.001)
            : await this.placeBuyOrder(quantity);

          this.totalFees += order.fee;

          logger.info(`  Bought ${order.quantity.toFixed(4)} ${buy.asset} @ $${(order.filledPrice || buy.price).toFixed(2)} (drift: ${buy.drift.toFixed(1)}%)`);
        } catch (error) {
          logger.error(`  Failed to buy ${buy.asset}`, { error: (error as Error).message });
        }
      }
    }

    this.isRebalancing = false;

    logger.info(`✅ Rebalance complete. Fees: $${this.totalFees.toFixed(2)}`);
  }

  getStats(): {
    totalValue: number;
    rebalanceCount: number;
    totalFees: number;
    assets: { asset: string; currentPercent: number; targetPercent: number; drift: number; action: string }[];
    lastRebalance: string;
  } {
    const analysis = this.analyzePortfolio();

    return {
      totalValue: analysis.totalValue,
      rebalanceCount: this.rebalanceCount,
      totalFees: this.totalFees,
      assets: analysis.assets.map(a => ({
        asset: a.asset,
        currentPercent: Math.round(a.currentPercent * 100) / 100,
        targetPercent: a.targetPercent,
        drift: Math.round(a.drift * 100) / 100,
        action: a.action,
      })),
      lastRebalance: new Date(this.lastRebalanceTime).toISOString(),
    };
  }

  async onStop(): Promise<void> {
    logger.info(`Rebalancing stopped. Total rebalances: ${this.rebalanceCount}`);
    await super.onStop();
  }
}