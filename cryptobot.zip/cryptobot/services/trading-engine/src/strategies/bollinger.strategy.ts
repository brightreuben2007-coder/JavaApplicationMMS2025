import { BaseStrategy } from "./base.strategy";
import type { BotContext, OHLCV, Ticker, Position } from "./base.strategy";
import { BollingerBands, RSI } from "../indicators";
import { v4 as uuidv4 } from "uuid";
import { logger } from "../utils/logger";

export interface BollingerConfig {
  period: number;
  stdDev: number;
  rsiPeriod: number;
  rsiOversold: number;
  rsiOverbought: number;
  baseOrderSize: number;
  takeProfitPercent: number;
  stopLossPercent: number;
  cooldownBetweenDealsMinutes: number;
  minimumROI: Record<string, number>;
}

/**
 * Bollinger Bands mean reversion strategy.
 * Buys when price touches/crosses below lower band (oversold).
 * Sells when price touches/crosses above upper band (overbought) or TP/SL hit.
 *
 * Can combine with RSI filter for higher accuracy.
 */
export class BollingerStrategy extends BaseStrategy {
  private config: BollingerConfig;
  private activeDealId: string | null = null;
  private entryPrice: number = 0;
  private positionQuantity: number = 0;
  private highestPriceSinceEntry: number = 0;
  private candles: OHLCV[] = [];
  private maxCandles: number = 200;

  constructor(botContext: BotContext) {
    super(botContext);
    this.config = botContext.config as BollingerConfig;
  }

  async onInit(): Promise<void> {
    await super.onInit();
    logger.info(`Bollinger Strategy initialized for ${this.botContext.pair}`, {
      period: this.config.period,
      stdDev: this.config.stdDev,
      rsiPeriod: this.config.rsiPeriod,
      oversold: this.config.rsiOversold,
      overbought: this.config.rsiOverbought,
    });
  }

  private getBollingerValues(): { upper: number; middle: number; lower: number } | null {
    if (this.candles.length < this.config.period) return null;

    const closes = this.candles.map((c) => c.close);
    const bb = BollingerBands(closes, this.config.period, this.config.stdDev);

    if (bb.upper.length === 0) return null;

    return {
      upper: bb.upper[bb.upper.length - 1] || 0,
      middle: bb.middle?.[bb.middle.length - 1] || bb.pb?.[bb.pb.length - 1] || 0,
      lower: bb.lower[bb.lower.length - 1] || 0,
    };
  }

  private getRSIValue(): number | null {
    if (this.candles.length < this.config.rsiPeriod + 1) return null;

    const closes = this.candles.map((c) => c.close);
    const rsiValues = RSI(closes, this.config.rsiPeriod);

    if (rsiValues.length === 0) return null;
    return rsiValues[rsiValues.length - 1] || null;
  }

  private shouldStartDeal(candle: OHLCV, currentPrice: number): boolean {
    if (this.activeDealId) return false;
    if (this.isInCooldown(this.botContext.pair)) return false;
    if (this.checkVolatility(candle)) return false;

    const bb = this.getBollingerValues();
    if (!bb) return false;

    // Price at or below lower band
    const atLowerBand = currentPrice <= bb.lower * 1.01;

    // Optional RSI filter
    if (this.config.rsiOversold > 0) {
      const rsi = this.getRSIValue();
      if (rsi === null) return atLowerBand;
      return atLowerBand && rsi <= this.config.rsiOversold;
    }

    return atLowerBand;
  }

  private shouldExitDeal(currentPrice: number): boolean {
    const bb = this.getBollingerValues();
    if (!bb) return false;

    // Price at or above upper band
    const atUpperBand = currentPrice >= bb.upper * 0.99;

    if (this.config.rsiOverbought > 0) {
      const rsi = this.getRSIValue();
      if (rsi === null) return atUpperBand;
      return atUpperBand && rsi >= this.config.rsiOverbought;
    }

    return atUpperBand;
  }

  async onTick(candle: OHLCV, ticker: Ticker): Promise<void> {
    this.candles.push(candle);
    if (this.candles.length > this.maxCandles) {
      this.candles.shift();
    }

    const currentPrice = ticker.last || candle.close;

    if (!this.activeDealId && this.shouldStartDeal(candle, currentPrice)) {
      await this.startDeal(currentPrice);
      return;
    }

    if (!this.activeDealId) return;

    if (currentPrice > this.highestPriceSinceEntry) {
      this.highestPriceSinceEntry = currentPrice;
    }

    // Stop loss
    const slPrice = this.entryPrice * (1 - this.config.stopLossPercent / 100);
    if (currentPrice <= slPrice) {
      await this.closeDeal(currentPrice, `SL: ${this.config.stopLossPercent}%`);
      return;
    }

    // Take profit
    const profitPercent = ((currentPrice - this.entryPrice) / this.entryPrice) * 100;
    if (profitPercent >= this.config.takeProfitPercent) {
      await this.closeDeal(currentPrice, `TP: ${profitPercent.toFixed(2)}%`);
      return;
    }

    // Exit on upper band touch
    if (this.shouldExitDeal(currentPrice) && profitPercent > 0) {
      await this.closeDeal(currentPrice, "Upper band exit");
    }
  }

  private async startDeal(currentPrice: number): Promise<void> {
    this.activeDealId = uuidv4();
    this.entryPrice = currentPrice;
    this.highestPriceSinceEntry = currentPrice;

    try {
      const order = await this.placeBuyOrder(this.config.baseOrderSize);
      this.positionQuantity = order.quantity;

      const bb = this.getBollingerValues();

      const position: Position = {
        id: `bb_${this.activeDealId}`,
        botId: this.botContext.botId,
        pair: this.botContext.pair,
        entryPrice: currentPrice,
        currentPrice,
        quantity: this.positionQuantity,
        side: "buy",
        unrealizedPnl: 0,
        realizedPnl: 0,
        stopLoss: currentPrice * (1 - this.config.stopLossPercent / 100),
        takeProfit: [{ price: currentPrice * (1 + this.config.takeProfitPercent / 100), percentage: 100 }],
        safetyOrders: null,
        minimumROI: this.config.minimumROI,
        status: "open",
        openedAt: new Date(),
      };

      this.openPosition(position);
      this.emit("onLog", "info",
        `Bollinger buy at lower band: $${currentPrice}` +
        (bb ? ` (band: $${bb.lower.toFixed(2)} - $${bb.upper.toFixed(2)})` : "")
      );

      if (this.botContext.protectionConfig?.stoplossOnExchange) {
        this.emit("onSignal", { action: "sell", price: position.stopLoss!, reason: "stop_loss" });
      }
    } catch (error) {
      this.emit("onError", error as Error);
      this.activeDealId = null;
    }
  }

  private async closeDeal(currentPrice: number, reason: string): Promise<void> {
    if (!this.activeDealId) return;

    try {
      await this.placeSellOrder(this.positionQuantity);

      const pnl = (currentPrice - this.entryPrice) * this.positionQuantity;
      this.closePosition(`bb_${this.activeDealId}`, pnl);

      this.emit("onLog", "info", `Bollinger deal closed: ${reason} | PnL: $${pnl.toFixed(2)}`);

      this.setCooldown(this.botContext.pair);

      this.activeDealId = null;
      this.positionQuantity = 0;
      this.entryPrice = 0;
    } catch (error) {
      this.emit("onError", error as Error);
    }
  }

  async onStop(): Promise<void> {
    if (this.activeDealId) {
      await this.closeDeal(this.entryPrice, "Bot stopped");
    }
    await super.onStop();
  }
}