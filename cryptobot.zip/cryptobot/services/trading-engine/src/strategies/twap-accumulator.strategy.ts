import { BaseStrategy } from "./base.strategy";
import type { BotContext, OHLCV, Ticker } from "./base.strategy";
import { logger } from "../utils/logger";

export interface TWAPConfig {
  totalAmount: number;
  durationMinutes: number;
  intervalSeconds: number;
  side: "buy" | "sell";
}

/**
 * TWAP (Time-Weighted Average Price) Accumulator.
 * Breaks a large order into smaller pieces executed at regular intervals
 * to minimize market impact and achieve the time-weighted average price.
 *
 * Pionex-style: simple UI with total amount, duration, and interval.
 */
export class TWAPAccumulatorStrategy extends BaseStrategy {
  private config: TWAPConfig;
  private totalSlices: number = 0;
  private slicesExecuted: number = 0;
  private amountPerSlice: number = 0;
  private totalExecuted: number = 0;
  private averagePrice: number = 0;
  private totalCost: number = 0;
  private startTime: number = 0;
  private nextExecutionTime: number = 0;
  private isComplete: boolean = false;
  private isRunning: boolean = false;

  constructor(botContext: BotContext) {
    super(botContext);
    this.config = botContext.config as TWAPConfig;
  }

  async onInit(): Promise<void> {
    await super.onInit();

    this.totalSlices = Math.ceil((this.config.durationMinutes * 60) / this.config.intervalSeconds);
    this.amountPerSlice = this.config.totalAmount / this.totalSlices;

    logger.info(`TWAP Accumulator initialized for ${this.botContext.pair}`, {
      side: this.config.side,
      totalAmount: this.config.totalAmount,
      duration: `${this.config.durationMinutes}min`,
      interval: `${this.config.intervalSeconds}s`,
      slices: this.totalSlices,
      amountPerSlice: this.amountPerSlice.toFixed(6),
    });

    this.startTime = Date.now();
    this.nextExecutionTime = this.startTime;
    this.isRunning = true;
  }

  async onTick(candle: OHLCV, ticker: Ticker): Promise<void> {
    if (!this.isRunning || this.isComplete) return;

    const now = Date.now();
    const currentPrice = ticker.last || candle.close;

    if (now >= this.nextExecutionTime) {
      await this.executeSlice(currentPrice);

      // Schedule next slice
      this.nextExecutionTime = now + this.config.intervalSeconds * 1000;

      // Check if we've completed
      if (this.slicesExecuted >= this.totalSlices) {
        await this.finish();
      }
    }
  }

  /**
   * Execute a single slice of the TWAP order.
   */
  private async executeSlice(currentPrice: number): Promise<void> {
    const remaining = this.config.totalAmount - this.totalExecuted;
    let sliceAmount = Math.min(this.amountPerSlice, remaining);

    if (sliceAmount <= 0) {
      await this.finish();
      return;
    }

    try {
      const order = this.config.side === "buy"
        ? await this.placeBuyOrder(sliceAmount)
        : await this.placeSellOrder(sliceAmount);

      const fillPrice = order.filledPrice || currentPrice;
      const executedQty = order.quantity;

      this.slicesExecuted++;
      this.totalExecuted += executedQty;
      this.totalCost += fillPrice * executedQty;
      this.averagePrice = this.totalExecuted > 0 ? this.totalCost / this.totalExecuted : 0;

      const progress = (this.totalExecuted / this.config.totalAmount) * 100;

      logger.info(
        `TWAP slice ${this.slicesExecuted}/${this.totalSlices} | ` +
        `${this.config.side} ${executedQty.toFixed(4)} @ $${fillPrice.toFixed(2)} | ` +
        `Avg: $${this.averagePrice.toFixed(4)} | ` +
        `${progress.toFixed(1)}% complete`
      );
    } catch (error) {
      logger.error(`TWAP slice ${this.slicesExecuted + 1} failed`, { error: (error as Error).message });
    }
  }

  /**
   * Finish the TWAP execution.
   */
  private async finish(): Promise<void> {
    this.isComplete = true;
    this.isRunning = false;

    const elapsedMs = Date.now() - this.startTime;
    const elapsedMin = elapsedMs / 60000;

    logger.info(
      `✅ TWAP complete | ` +
      `${this.config.side} ${this.totalExecuted.toFixed(4)} total | ` +
      `Avg price: $${this.averagePrice.toFixed(4)} | ` +
      `Slices: ${this.slicesExecuted}/${this.totalSlices} | ` +
      `Duration: ${elapsedMin.toFixed(1)}min`
    );

    this.emit("onLog", "info",
      `TWAP finished: ${this.totalExecuted.toFixed(4)} @ avg $${this.averagePrice.toFixed(4)}`
    );
  }

  /**
   * Get TWAP progress.
   */
  getProgress(): {
    isComplete: boolean;
    isRunning: boolean;
    progressPercent: number;
    slicesExecuted: number;
    totalSlices: number;
    totalExecuted: number;
    totalAmount: number;
    averagePrice: number;
    side: string;
    nextExecutionIn: number;
  } {
    return {
      isComplete: this.isComplete,
      isRunning: this.isRunning,
      progressPercent: this.config.totalAmount > 0 ? (this.totalExecuted / this.config.totalAmount) * 100 : 0,
      slicesExecuted: this.slicesExecuted,
      totalSlices: this.totalSlices,
      totalExecuted: this.totalExecuted,
      totalAmount: this.config.totalAmount,
      averagePrice: this.averagePrice,
      side: this.config.side,
      nextExecutionIn: Math.max(0, Math.ceil((this.nextExecutionTime - Date.now()) / 1000)),
    };
  }

  async onStop(): Promise<void> {
    this.isRunning = false;
    if (!this.isComplete) {
      logger.warn(`TWAP stopped early: ${this.totalExecuted.toFixed(4)} of ${this.totalAmount} executed`);
    }
    await super.onStop();
  }
}