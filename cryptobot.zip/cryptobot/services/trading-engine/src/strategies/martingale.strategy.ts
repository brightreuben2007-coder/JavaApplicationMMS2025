import { BaseStrategy } from "./base.strategy";
import type { BotContext, OHLCV, Ticker, Position, SafetyOrderState } from "./base.strategy";
import { v4 as uuidv4 } from "uuid";
import { logger } from "../utils/logger";

export interface MartingaleConfig {
  baseOrderSize: number;
  safetyOrderSize: number;
  maxSafetyOrders: number;
  priceDeviationPercent: number;
  safetyOrderVolumeScale: number;
  safetyOrderStepScale: number;
  takeProfitPercent: number;
  maxTotalInvestment: number;
  cooldownBetweenDealsMinutes: number;
  minimumROI: Record<string, number>;
}

/**
 * Martingale strategy — exponentially increases position size on each safety order.
 * Extends DCA logic with exponential rather than linear safety order scaling.
 *
 * HIGH RISK: Can drain accounts without proper max investment limits.
 * The maxTotalInvestment config prevents runaway position building.
 */
export class MartingaleStrategy extends BaseStrategy {
  private config: MartingaleConfig;
  private activeDealId: string | null = null;
  private safetyOrders: SafetyOrderState[] = [];
  private baseOrderPlaced: boolean = false;
  private entryPrice: number = 0;
  private totalQuantity: number = 0;
  private totalInvestment: number = 0;
  private dealStartTime: Date | null = null;
  private highestPriceSinceEntry: number = 0;
  private safetyOrderVolumeScale: number;
  private safetyOrderStepScale: number;

  constructor(botContext: BotContext) {
    super(botContext);
    this.config = botContext.config as MartingaleConfig;
    this.safetyOrderVolumeScale = this.config.safetyOrderVolumeScale || 2.0;
    this.safetyOrderStepScale = this.config.safetyOrderStepScale || 1.5;
  }

  async onInit(): Promise<void> {
    await super.onInit();
    logger.info(`Martingale Strategy initialized for ${this.botContext.pair}`, {
      baseOrderSize: this.config.baseOrderSize,
      maxSafetyOrders: this.config.maxSafetyOrders,
      volumeScale: this.safetyOrderVolumeScale,
      stepScale: this.safetyOrderStepScale,
      takeProfit: `${this.config.takeProfitPercent}%`,
      maxInvestment: this.config.maxTotalInvestment || "unlimited",
    });
  }

  /**
   * Build safety order levels with exponential size increase.
   * Also calculates and validates total potential investment.
   */
  private buildSafetyOrderLevels(currentPrice: number): void {
    this.safetyOrders = [];
    let currentDeviation = this.config.priceDeviationPercent;
    let currentSize = this.config.safetyOrderSize;
    let cumulativeDeviation = 0;
    let projectedTotal = this.config.baseOrderSize * currentPrice;

    for (let i = 0; i < this.config.maxSafetyOrders; i++) {
      cumulativeDeviation += currentDeviation;

      const triggerPrice = currentPrice * (1 - cumulativeDeviation / 100);
      projectedTotal += currentSize * triggerPrice;

      this.safetyOrders.push({
        index: i,
        triggerPrice: Math.round(triggerPrice * 1000000) / 1000000,
        quantity: Math.round(currentSize * 100000000) / 100000000,
        filled: false,
        filledPrice: null,
      });

      // Exponential scaling
      currentDeviation *= this.safetyOrderStepScale;
      currentSize *= this.safetyOrderVolumeScale;
    }

    // Warn if total investment exceeds configured max
    if (this.config.maxTotalInvestment > 0 && projectedTotal > this.config.maxTotalInvestment) {
      logger.warn(
        `⚠️ Martingale projected investment ($${projectedTotal.toFixed(2)}) exceeds max ($${this.config.maxTotalInvestment}). ` +
        `All safety orders may not execute.`
      );
    }
  }

  /**
   * Check if placing the next order would exceed max total investment.
   */
  private wouldExceedMaxInvestment(additionalCost: number): boolean {
    if (this.config.maxTotalInvestment <= 0) return false;
    return (this.totalInvestment + additionalCost) > this.config.maxTotalInvestment;
  }

  private calculateAverageEntryPrice(): number {
    if (this.totalQuantity === 0) return 0;
    return this.totalInvestment / this.totalQuantity;
  }

  private shouldStartDeal(candle: OHLCV): boolean {
    if (this.activeDealId) return false;
    if (this.isInCooldown(this.botContext.pair)) return false;
    if (this.getOpenPositionCount() >= (this.botContext.protectionConfig?.maxOpenDeals || 5)) return false;
    if (this.checkVolatility(candle)) return false;

    return true;
  }

  async onTick(candle: OHLCV, ticker: Ticker): Promise<void> {
    const currentPrice = ticker.last || candle.close;

    if (!this.activeDealId && this.shouldStartDeal(candle)) {
      await this.startDeal(currentPrice);
      return;
    }

    if (!this.activeDealId) return;

    if (currentPrice > this.highestPriceSinceEntry) {
      this.highestPriceSinceEntry = currentPrice;
    }

    await this.checkSafetyOrders(currentPrice);
    await this.checkTakeProfit(currentPrice);
  }

  private async startDeal(currentPrice: number): Promise<void> {
    this.activeDealId = uuidv4();
    this.baseOrderPlaced = false;
    this.highestPriceSinceEntry = currentPrice;
    this.totalQuantity = 0;
    this.totalInvestment = 0;
    this.entryPrice = currentPrice;
    this.dealStartTime = new Date();

    this.buildSafetyOrderLevels(currentPrice);

    logger.info(`Martingale deal started: ${this.activeDealId}`, {
      pair: this.botContext.pair,
      entryPrice: currentPrice,
      baseOrderSize: this.config.baseOrderSize,
      maxInvestment: this.config.maxTotalInvestment || "unlimited",
      safetyOrders: this.safetyOrders.map(so => `$${so.triggerPrice.toFixed(2)} x ${so.quantity}`),
    });

    await this.placeBaseOrder(currentPrice);
  }

  private async placeBaseOrder(currentPrice: number): Promise<void> {
    try {
      const orderCost = this.config.baseOrderSize * currentPrice;

      if (this.wouldExceedMaxInvestment(orderCost)) {
        logger.warn(`Base order would exceed max investment. Deal cancelled.`);
        this.activeDealId = null;
        return;
      }

      const order = await this.placeBuyOrder(this.config.baseOrderSize);
      const fillPrice = order.filledPrice || currentPrice;

      this.totalQuantity += order.quantity;
      this.totalInvestment += fillPrice * order.quantity;
      this.baseOrderPlaced = true;

      const avgEntry = this.calculateAverageEntryPrice();
      const position: Position = {
        id: `mart_${this.activeDealId}`,
        botId: this.botContext.botId,
        pair: this.botContext.pair,
        entryPrice: avgEntry,
        currentPrice,
        quantity: this.totalQuantity,
        side: "buy",
        unrealizedPnl: 0,
        realizedPnl: 0,
        stopLoss: null,
        takeProfit: [{ price: avgEntry * (1 + this.config.takeProfitPercent / 100), percentage: 100 }],
        safetyOrders: this.safetyOrders,
        minimumROI: this.config.minimumROI,
        status: "open",
        openedAt: new Date(),
      };

      this.openPosition(position);
      this.emit("onLog", "info", `Base order filled: ${order.quantity} @ $${fillPrice}`);
    } catch (error) {
      this.emit("onError", error as Error);
      this.activeDealId = null;
    }
  }

  private async checkSafetyOrders(currentPrice: number): Promise<void> {
    if (!this.activeDealId) return;

    for (const so of this.safetyOrders) {
      if (so.filled) continue;

      if (currentPrice <= so.triggerPrice) {
        // Check max investment BEFORE placing order
        const estimatedCost = so.quantity * currentPrice;
        if (this.wouldExceedMaxInvestment(estimatedCost)) {
          logger.warn(
            `⚠️ Safety order #${so.index + 1} blocked: would exceed max investment ` +
            `($${this.totalInvestment.toFixed(2)} + $${estimatedCost.toFixed(2)} > $${this.config.maxTotalInvestment})`
          );
          continue; // Skip this safety order but don't cancel the deal
        }

        try {
          this.emit("onLog", "warn",
            `Martingale SO#${so.index + 1} triggered at $${currentPrice} ` +
            `(trigger: $${so.triggerPrice.toFixed(2)}, size: ${so.quantity})`
          );

          const order = await this.placeBuyOrder(so.quantity);
          so.filled = true;
          so.filledPrice = order.filledPrice || currentPrice;
          this.totalQuantity += order.quantity;
          this.totalInvestment += so.filledPrice * order.quantity;

          const avgEntry = this.calculateAverageEntryPrice();
          const position = this.getOpenPositions().find(p => p.id === `mart_${this.activeDealId}`);
          if (position) {
            position.entryPrice = avgEntry;
            position.quantity = this.totalQuantity;
            position.currentPrice = currentPrice;
            position.safetyOrders = this.safetyOrders;
            position.takeProfit = [{ price: avgEntry * (1 + this.config.takeProfitPercent / 100), percentage: 100 }];
          }

          this.emit("onLog", "info",
            `✅ Martingale SO#${so.index + 1} filled: ${so.quantity} @ $${so.filledPrice.toFixed(2)} | ` +
            `Total invested: $${this.totalInvestment.toFixed(2)} | Avg entry: $${avgEntry.toFixed(4)} | ` +
            `Remaining allowed: $${this.config.maxTotalInvestment > 0 ? (this.config.maxTotalInvestment - this.totalInvestment).toFixed(2) : 'unlimited'}`
          );
        } catch (error) {
          this.emit("onError", error as Error);
        }
      }
    }
  }

  private async checkTakeProfit(currentPrice: number): Promise<void> {
    if (!this.activeDealId) return;

    const avgEntry = this.calculateAverageEntryPrice();
    const profitPercent = ((currentPrice - avgEntry) / avgEntry) * 100;

    if (profitPercent >= this.config.takeProfitPercent) {
      await this.closeDeal(currentPrice, `TP: ${profitPercent.toFixed(2)}%`);
    }
  }

  private async closeDeal(currentPrice: number, reason: string): Promise<void> {
    if (!this.activeDealId) return;

    try {
      await this.placeSellOrder(this.totalQuantity);

      const avgEntry = this.calculateAverageEntryPrice();
      const pnl = (currentPrice - avgEntry) * this.totalQuantity;
      const returnPercent = ((currentPrice - avgEntry) / avgEntry) * 100;

      this.closePosition(`mart_${this.activeDealId}`, pnl);

      this.emit("onLog", "info",
        `Martingale deal closed: ${reason} | ` +
        `PnL: $${pnl.toFixed(2)} (${returnPercent.toFixed(2)}%) | ` +
        `Total invested: $${this.totalInvestment.toFixed(2)} | ` +
        `Safety orders used: ${this.safetyOrders.filter(so => so.filled).length}/${this.safetyOrders.length}`
      );

      this.setCooldown(this.botContext.pair);

      this.resetDealState();
    } catch (error) {
      this.emit("onError", error as Error);
    }
  }

  private resetDealState(): void {
    this.activeDealId = null;
    this.baseOrderPlaced = false;
    this.totalQuantity = 0;
    this.totalInvestment = 0;
    this.highestPriceSinceEntry = 0;
    this.dealStartTime = null;
    this.safetyOrders = [];
  }

  async emergencyClose(currentPrice: number): Promise<void> {
    if (this.activeDealId) {
      await this.closeDeal(currentPrice, "Emergency close");
    }
  }

  async onStop(): Promise<void> {
    if (this.activeDealId) {
      const avgEntry = this.calculateAverageEntryPrice();
      await this.closeDeal(avgEntry, "Bot stopped");
    }
    await super.onStop();
  }
}