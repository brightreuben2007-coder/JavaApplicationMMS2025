import { BaseStrategy } from "./base.strategy";
import type {
  BotContext, OHLCV, Ticker, OrderResult, Position,
  SafetyOrderState, OrderRequest,
} from "./base.strategy";
import { MinimumROIChecker } from "../protection/minimumROI";
import { v4 as uuidv4 } from "uuid";
import { logger } from "../utils/logger";

export interface DCAConfig {
  baseOrderSize: number;
  safetyOrderSize: number;
  maxSafetyOrders: number;
  priceDeviationPercent: number;
  safetyOrderVolumeScale: number;
  safetyOrderStepScale: number;
  takeProfitPercent: number;
  trailingTakeProfit: boolean;
  trailingDeviationPercent: number;
  cooldownBetweenDealsMinutes: number;
  minimumROI: Record<string, number>;
}

/**
 * Dollar Cost Averaging strategy with safety orders.
 * Places a base buy order, then additional safety orders at
 * progressively lower prices. Takes profit on the average entry.
 */
export class DCAStrategy extends BaseStrategy {
  private config: DCAConfig;
  private activeDealId: string | null = null;
  private safetyOrders: SafetyOrderState[] = [];
  private baseOrderPlaced: boolean = false;
  private highestPriceSinceEntry: number = 0;
  private minimumROIChecker: MinimumROIChecker;
  private entryPrice: number = 0;
  private totalQuantity: number = 0;
  private totalInvestment: number = 0;
  private dealStartTime: Date | null = null;

  constructor(botContext: BotContext) {
    super(botContext);
    this.config = botContext.config as DCAConfig;
    this.minimumROIChecker = new MinimumROIChecker(this.config.minimumROI);

    // Build safety order trigger prices
    this.buildSafetyOrderLevels();
  }

  async onInit(): Promise<void> {
    await super.onInit();
    logger.info(`DCA Strategy initialized for ${this.botContext.pair}`, {
      baseOrderSize: this.config.baseOrderSize,
      maxSafetyOrders: this.config.maxSafetyOrders,
      takeProfit: this.config.takeProfitPercent,
    });
  }

  /**
   * Build the safety order levels based on configuration.
   * Each safety order triggers at a lower price with a larger size.
   */
  private buildSafetyOrderLevels(): void {
    this.safetyOrders = [];
    let currentDeviation = this.config.priceDeviationPercent;
    let currentSize = this.config.safetyOrderSize;
    const currentPrice = 0; // Will be set on first tick

    for (let i = 0; i < this.config.maxSafetyOrders; i++) {
      this.safetyOrders.push({
        index: i,
        triggerPrice: 0, // Calculated when deal starts
        quantity: currentSize,
        filled: false,
        filledPrice: null,
      });

      // Scale for next safety order
      currentDeviation *= this.config.safetyOrderStepScale;
      currentSize *= this.config.safetyOrderVolumeScale;
    }
  }

  /**
   * Calculate the average entry price considering all filled orders.
   */
  private calculateAverageEntryPrice(): number {
    if (this.totalQuantity === 0) return 0;
    return this.totalInvestment / this.totalQuantity;
  }

  /**
   * Check if deal start conditions are met.
   */
  private shouldStartDeal(candle: OHLCV, ticker: Ticker): boolean {
    if (this.activeDealId) return false; // Already in a deal
    if (this.isInCooldown(this.botContext.pair)) return false;
    if (this.getOpenPositionCount() >= (this.botContext.protectionConfig?.maxOpenDeals || 5)) return false;

    // Check volatility
    if (this.checkVolatility(candle)) {
      this.emit("onLog", "warn", "Volatility protection active — skipping deal start");
      return false;
    }

    const conditions = this.botContext.dealStartConditions;

    // If no conditions or manual/webhook, allow via external trigger
    if (!conditions || conditions.length === 0) return true;

    for (const condition of conditions) {
      switch (condition.type) {
        case "manual":
          return true;
        case "webhook":
          return true; // Webhook triggers are handled externally
        case "scheduled":
          return true; // Scheduled by external cron
        default:
          // Indicator-based conditions handled by signal evaluation
          return true;
      }
    }

    return false;
  }

  async onTick(candle: OHLCV, ticker: Ticker): Promise<void> {
    const currentPrice = ticker.last || candle.close;

    // Check if we should start a new deal
    if (!this.activeDealId && this.shouldStartDeal(candle, ticker)) {
      await this.startDeal(currentPrice);
      return;
    }

    // If no active deal, nothing to do
    if (!this.activeDealId) return;

    // Update highest price for trailing take profit
    if (currentPrice > this.highestPriceSinceEntry) {
      this.highestPriceSinceEntry = currentPrice;
    }

    // Check safety orders
    await this.checkSafetyOrders(currentPrice);

    // Check take profit
    await this.checkTakeProfit(currentPrice);

    // Check minimum ROI
    this.checkMinimumROIForDeal(currentPrice);
  }

  /**
   * Start a new DCA deal.
   */
  private async startDeal(currentPrice: number): Promise<void> {
    this.activeDealId = uuidv4();
    this.baseOrderPlaced = false;
    this.highestPriceSinceEntry = currentPrice;
    this.totalQuantity = 0;
    this.totalInvestment = 0;
    this.entryPrice = currentPrice;
    this.dealStartTime = new Date();

    // Calculate safety order trigger prices
    for (let i = 0; i < this.safetyOrders.length; i++) {
      let deviation = this.config.priceDeviationPercent;
      for (let j = 0; j <= i; j++) {
        if (j > 0) deviation *= this.config.safetyOrderStepScale;
      }
      const so = this.safetyOrders[i]!;
      so.triggerPrice = currentPrice * (1 - deviation / 100);
      so.filled = false;
      so.filledPrice = null;
    }

    logger.info(`Starting DCA deal ${this.activeDealId}`, {
      pair: this.botContext.pair,
      entryPrice: currentPrice,
      baseOrderSize: this.config.baseOrderSize,
    });

    // Place base order
    await this.placeBaseOrder(currentPrice);
  }

  /**
   * Place the initial base buy order.
   */
  private async placeBaseOrder(currentPrice: number): Promise<void> {
    try {
      const order = await this.placeBuyOrder(this.config.baseOrderSize);

      this.totalQuantity += order.quantity;
      this.totalInvestment += (order.filledPrice || currentPrice) * order.quantity;
      this.baseOrderPlaced = true;

      // Create position
      const position: Position = {
        id: `pos_${this.activeDealId}`,
        botId: this.botContext.botId,
        pair: this.botContext.pair,
        entryPrice: this.calculateAverageEntryPrice(),
        currentPrice,
        quantity: this.totalQuantity,
        side: "buy",
        unrealizedPnl: 0,
        realizedPnl: 0,
        stopLoss: this.calculateStopLossPrice(this.entryPrice, "buy"),
        takeProfit: [{ price: this.entryPrice * (1 + this.config.takeProfitPercent / 100), percentage: 100 }],
        safetyOrders: this.safetyOrders,
        minimumROI: this.config.minimumROI,
        status: "open",
        openedAt: new Date(),
      };

      this.openPosition(position);

      this.emit("onLog", "info", `Base order filled: ${order.quantity} @ ${order.filledPrice || currentPrice}`);

      // Place stop-loss on exchange if configured
      if (this.botContext.protectionConfig?.stoplossOnExchange) {
        this.emit("onSignal", { action: "sell", price: position.stopLoss!, reason: "stoploss_on_exchange" });
      }
    } catch (error) {
      this.emit("onError", error as Error);
      this.activeDealId = null;
    }
  }

  /**
   * Check if any safety orders should trigger.
   */
  private async checkSafetyOrders(currentPrice: number): Promise<void> {
    if (!this.activeDealId) return;

    for (const so of this.safetyOrders) {
      if (so.filled) continue;

      if (currentPrice <= so.triggerPrice) {
        try {
          const order = await this.placeBuyOrder(so.quantity);

          so.filled = true;
          so.filledPrice = order.filledPrice || currentPrice;
          this.totalQuantity += order.quantity;
          this.totalInvestment += so.filledPrice * order.quantity;

          // Update position
          const position = this.getOpenPositions().find(
            (p) => p.id === `pos_${this.activeDealId}`
          );
          if (position) {
            position.entryPrice = this.calculateAverageEntryPrice();
            position.quantity = this.totalQuantity;
            position.currentPrice = currentPrice;
            position.safetyOrders = this.safetyOrders;

            const newTP = position.entryPrice * (1 + this.config.takeProfitPercent / 100);
            position.takeProfit = [{ price: newTP, percentage: 100 }];
          }

          this.emit("onLog", "info", `Safety order #${so.index + 1} filled: ${so.quantity} @ ${so.filledPrice}`);

          // Place stop-loss on exchange for the new position
          if (this.botContext.protectionConfig?.stoplossOnExchange) {
            const newStopPrice = this.calculateStopLossPrice(
              this.calculateAverageEntryPrice(),
              "buy"
            );
            this.emit("onSignal", { action: "sell", price: newStopPrice, reason: "stoploss_update" });
          }
        } catch (error) {
          this.emit("onError", error as Error);
        }
      }
    }
  }

  /**
   * Check if take profit conditions are met.
   */
  private async checkTakeProfit(currentPrice: number): Promise<void> {
    if (!this.activeDealId) return;

    const avgEntry = this.calculateAverageEntryPrice();
    const profitPercent = ((currentPrice - avgEntry) / avgEntry) * 100;

    // Trailing take profit
    if (this.config.trailingTakeProfit) {
      const trailPrice = this.highestPriceSinceEntry * (1 - this.config.trailingDeviationPercent / 100);
      if (currentPrice <= trailPrice && profitPercent > 0) {
        await this.closeDeal(currentPrice, `Trailing TP triggered: ${profitPercent.toFixed(2)}%`);
        return;
      }
      return;
    }

    // Fixed take profit
    if (profitPercent >= this.config.takeProfitPercent) {
      await this.closeDeal(currentPrice, `TP hit: ${profitPercent.toFixed(2)}%`);
    }
  }

  /**
   * Check minimum ROI time-based exit rules.
   */
  private checkMinimumROIForDeal(currentPrice: number): void {
    if (!this.activeDealId || !this.dealStartTime) return;

    const avgEntry = this.calculateAverageEntryPrice();
    const result = this.minimumROIChecker.shouldClose(avgEntry, currentPrice, this.dealStartTime, "buy");

    if (result.shouldClose) {
      this.closeDeal(currentPrice, result.reason);
    }
  }

  /**
   * Close the current deal by selling the entire position.
   */
  private async closeDeal(currentPrice: number, reason: string): Promise<void> {
    if (!this.activeDealId) return;

    try {
      const order = await this.placeSellOrder(this.totalQuantity);

      const avgEntry = this.calculateAverageEntryPrice();
      const pnl = (currentPrice - avgEntry) * this.totalQuantity;

      const positionId = `pos_${this.activeDealId}`;
      this.closePosition(positionId, pnl);

      this.emit("onLog", "info", `Deal closed: ${reason} | PnL: ${pnl.toFixed(2)}`);

      // Set cooldown
      this.setCooldown(this.botContext.pair);

      // Reset deal state
      this.activeDealId = null;
      this.baseOrderPlaced = false;
      this.totalQuantity = 0;
      this.totalInvestment = 0;
      this.highestPriceSinceEntry = 0;
      this.dealStartTime = null;

      // Rebuild safety orders
      this.buildSafetyOrderLevels();
    } catch (error) {
      this.emit("onError", error as Error);
    }
  }

  /**
   * External webhook/manual signal to start a deal.
   */
  async forceStartDeal(price: number): Promise<void> {
    if (this.activeDealId) {
      logger.warn("Cannot force start — deal already active");
      return;
    }
    await this.startDeal(price);
  }

  /**
   * Emergency close — sell everything at market.
   */
  async emergencyClose(currentPrice: number): Promise<void> {
    if (this.activeDealId) {
      await this.closeDeal(currentPrice, "Emergency close");
    }
  }

  async onStop(): Promise<void> {
    // Get current price from last tick
    const avgEntry = this.calculateAverageEntryPrice();
    if (this.activeDealId && avgEntry > 0) {
      await this.closeDeal(avgEntry, "Bot stopped");
    }
    await super.onStop();
  }
}