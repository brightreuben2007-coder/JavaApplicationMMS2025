import { BaseStrategy } from "./base.strategy";
import type { BotContext, OHLCV, Ticker } from "./base.strategy";
import { standardDeviation } from "../indicators";
import { logger } from "../utils/logger";

export interface AvellanedaConfig {
  gamma: number;
  sigma: number;
  kappa: number;
  targetInventory: number;
  inventorySkewFactor: number;
  orderRefreshTimeMs: number;
  hangingOrdersEnabled: boolean;
  hangingOrdersKeptRatio: number;
}

interface ASOrder {
  id: string;
  side: "buy" | "sell";
  price: number;
  quantity: number;
  exchangeOrderId: string | null;
  placedAt: number;
  status: "open" | "filled" | "cancelled";
}

/**
 * Avellaneda-Stoikov market making strategy.
 *
 * NOW FULLY WIRED: actually places bid and ask orders on the exchange.
 * Quant model that adjusts spreads based on:
 *   - Inventory risk (gamma)
 *   - Volatility (sigma)
 *   - Order book density (kappa)
 */
export class AvellanedaStrategy extends BaseStrategy {
  private config: AvellanedaConfig;
  private midPrice: number = 0;
  private inventory: number = 0;
  private cash: number = 0;
  private lastRefreshTime: number = 0;
  private candles: OHLCV[] = [];
  private maxCandles: number = 100;
  private reservationPrice: number = 0;
  private bidPrice: number = 0;
  private askPrice: number = 0;
  private totalFills: number = 0;
  private totalPnl: number = 0;
  private activeBid: ASOrder | null = null;
  private activeAsk: ASOrder | null = null;
  private isRefreshing: boolean = false;
  private orderQuantity: number = 0.01; // Default, should be configurable

  constructor(botContext: BotContext) {
    super(botContext);
    this.config = botContext.config as AvellanedaConfig;
  }

  async onInit(): Promise<void> {
    await super.onInit();
    logger.info(`Avellaneda-Stoikov MM initialized for ${this.botContext.pair}`, {
      gamma: this.config.gamma,
      sigma: this.config.sigma || "dynamic",
      kappa: this.config.kappa,
      targetInventory: this.config.targetInventory,
    });
  }

  /**
   * Update inventory and cash balances.
   */
  updateInventory(inventory: number, cash: number, midPrice: number): void {
    this.inventory = inventory;
    this.cash = cash;
    this.midPrice = midPrice;
  }

  /**
   * Set the default order quantity.
   */
  setOrderQuantity(quantity: number): void {
    this.orderQuantity = quantity;
  }

  /**
   * Calculate annualized volatility from recent candles.
   */
  private calculateVolatility(): number {
    if (this.config.sigma > 0) return this.config.sigma;

    if (this.candles.length < 5) return 0.02;

    const returns: number[] = [];
    for (let i = 1; i < this.candles.length; i++) {
      const prev = this.candles[i - 1]?.close || 0;
      const curr = this.candles[i]?.close || 0;
      if (prev > 0) returns.push((curr - prev) / prev);
    }

    return standardDeviation(returns) * Math.sqrt(365 * 24);
  }

  /**
   * Calculate optimal bid and ask using Avellaneda-Stoikov model.
   */
  private calculateOptimalPrices(): { bid: number; ask: number; reservation: number; spread: number } {
    const T = Math.max(this.config.orderRefreshTimeMs / 1000 / (365 * 24 * 3600), 1e-8);
    const sigma = this.calculateVolatility();
    const gamma = this.config.gamma;
    const kappa = this.config.kappa;

    const inventoryImbalance = this.inventory - this.config.targetInventory;

    // Reservation price
    const reservation = this.midPrice - inventoryImbalance * gamma * sigma * sigma * T;

    // Spread adjustment
    const spreadAdj = 0.5 * gamma * sigma * sigma * T + (1 / kappa) * Math.log(1 + kappa / gamma);

    const bid = reservation - spreadAdj;
    const ask = reservation + spreadAdj;

    return {
      bid: Math.max(0.00001, Math.round(bid * 1000000) / 1000000),
      ask: Math.round(ask * 1000000) / 1000000,
      reservation: Math.round(reservation * 1000000) / 1000000,
      spread: ask - bid,
    };
  }

  async onTick(candle: OHLCV, ticker: Ticker): Promise<void> {
    this.candles.push(candle);
    if (this.candles.length > this.maxCandles) {
      this.candles.shift();
    }

    this.midPrice = (ticker.bid + ticker.ask) / 2;

    const now = Date.now();
    if (now - this.lastRefreshTime < this.config.orderRefreshTimeMs) return;

    this.lastRefreshTime = now;
    await this.refreshOrders();
  }

  /**
   * Cancel existing orders and place new ones at optimal prices.
   * NOW ACTUALLY PLACES ORDERS ON THE EXCHANGE.
   */
  private async refreshOrders(): Promise<void> {
    if (this.midPrice <= 0 || this.isRefreshing) return;

    this.isRefreshing = true;

    try {
      const prices = this.calculateOptimalPrices();
      this.reservationPrice = prices.reservation;
      this.bidPrice = prices.bid;
      this.askPrice = prices.ask;

      // Cancel old bid if price has changed significantly
      if (this.activeBid && Math.abs(this.activeBid.price - prices.bid) / prices.bid > 0.0001) {
        await this.cancelOrder(this.activeBid);
        this.activeBid = null;
      }

      // Cancel old ask if price has changed significantly
      if (this.activeAsk && Math.abs(this.activeAsk.price - prices.ask) / prices.ask > 0.0001) {
        await this.cancelOrder(this.activeAsk);
        this.activeAsk = null;
      }

      // Place new bid
      if (!this.activeBid) {
        await this.placeOrder("buy", prices.bid, this.orderQuantity);
      }

      // Place new ask
      if (!this.activeAsk) {
        await this.placeOrder("sell", prices.ask, this.orderQuantity);
      }

      logger.debug(
        `A-S: Mid=$${this.midPrice.toFixed(2)} | Res=$${prices.reservation.toFixed(4)} | ` +
        `Bid=$${prices.bid.toFixed(4)} | Ask=$${prices.ask.toFixed(4)} | ` +
        `Spread=$${prices.spread.toFixed(4)} | Inv=${this.inventory.toFixed(4)} | ` +
        `σ=${(this.calculateVolatility() * 100).toFixed(2)}%`
      );
    } catch (error) {
      logger.error("Failed to refresh A-S orders", { error: (error as Error).message });
    } finally {
      this.isRefreshing = false;
    }
  }

  /**
   * Place a single order on the exchange.
   */
  private async placeOrder(side: "buy" | "sell", price: number, quantity: number): Promise<void> {
    try {
      const order = side === "buy"
        ? await this.placeBuyOrder(quantity, price)
        : await this.placeSellOrder(quantity, price);

      const asOrder: ASOrder = {
        id: order.orderId,
        side,
        price,
        quantity,
        exchangeOrderId: order.exchangeOrderId,
        placedAt: Date.now(),
        status: "open",
      };

      if (side === "buy") {
        this.activeBid = asOrder;
      } else {
        this.activeAsk = asOrder;
      }

      // Listen for fills
      this.once(order.orderId, () => {
        this.handleFill(asOrder, order.filledPrice || price);
      });
    } catch (error) {
      logger.error(`Failed to place A-S ${side} order at $${price}`, { error: (error as Error).message });
    }
  }

  /**
   * Cancel an order on the exchange.
   */
  private async cancelOrder(order: ASOrder): Promise<void> {
    if (order.exchangeOrderId && !this.botContext.paperTrading) {
      logger.debug(`Cancelling A-S order ${order.exchangeOrderId}`);
    }
    order.status = "cancelled";
  }

  /**
   * Handle an order fill.
   */
  private handleFill(order: ASOrder, fillPrice: number): void {
    order.status = "filled";

    if (order.side === "buy") {
      this.inventory += order.quantity;
      this.cash -= fillPrice * order.quantity;
      this.totalPnl -= fillPrice * order.quantity;
      this.activeBid = null;
    } else {
      this.inventory -= order.quantity;
      this.cash += fillPrice * order.quantity;
      this.totalPnl += fillPrice * order.quantity;
      this.activeAsk = null;
    }

    this.totalFills++;
    logger.debug(`A-S fill: ${order.side} ${order.quantity} @ $${fillPrice} | Inv: ${this.inventory.toFixed(4)}`);
  }

  /**
   * Record an external fill for reconciliation.
   */
  recordFill(side: "buy" | "sell", price: number, quantity: number): void {
    if (side === "buy") {
      this.inventory += quantity;
      this.cash -= price * quantity;
      this.totalPnl -= price * quantity;
    } else {
      this.inventory -= quantity;
      this.cash += price * quantity;
      this.totalPnl += price * quantity;
    }
    this.totalFills++;
  }

  getStats(): {
    midPrice: number;
    reservationPrice: number;
    bidPrice: number;
    askPrice: number;
    spread: number;
    inventory: number;
    inventoryTarget: number;
    totalFills: number;
    totalPnl: number;
    volatility: number;
    gamma: number;
    hasActiveBid: boolean;
    hasActiveAsk: boolean;
  } {
    return {
      midPrice: this.midPrice,
      reservationPrice: this.reservationPrice,
      bidPrice: this.bidPrice,
      askPrice: this.askPrice,
      spread: this.askPrice - this.bidPrice,
      inventory: this.inventory,
      inventoryTarget: this.config.targetInventory,
      totalFills: this.totalFills,
      totalPnl: this.totalPnl,
      volatility: this.calculateVolatility(),
      gamma: this.config.gamma,
      hasActiveBid: this.activeBid !== null,
      hasActiveAsk: this.activeAsk !== null,
    };
  }

  async onStop(): Promise<void> {
    if (this.activeBid) await this.cancelOrder(this.activeBid);
    if (this.activeAsk) await this.cancelOrder(this.activeAsk);
    this.activeBid = null;
    this.activeAsk = null;
    logger.info(`A-S MM stopped. Fills: ${this.totalFills} | PnL: $${this.totalPnl.toFixed(2)}`);
    await super.onStop();
  }
}