import { BaseStrategy } from "./base.strategy";
import type { BotContext, OHLCV, Ticker } from "./base.strategy";
import { logger } from "../utils/logger";

export interface MarketMakingConfig {
  spreadPercent: number;
  orderAmount: number;
  orderRefreshIntervalMs: number;
  maxOpenOrders: number;
  inventoryTargetPercent: number;
  inventorySkewFactor: number;
  hangingOrdersEnabled: boolean;
  hangingOrdersKeptRatio: number;
}

interface MMOrder {
  side: "buy" | "sell";
  price: number;
  quantity: number;
  placedAt: number;
}

/**
 * Pure market making strategy.
 * Places simultaneous bid and ask orders around the mid price
 * to capture the spread. Adjusts pricing based on inventory skew.
 *
 * Based on Hummingbot's pure market making approach.
 */
export class MarketMakingStrategy extends BaseStrategy {
  private config: MarketMakingConfig;
  private activeOrders: MMOrder[] = [];
  private lastRefreshTime: number = 0;
  private midPrice: number = 0;
  private baseAssetBalance: number = 0;
  private quoteAssetBalance: number = 0;
  private realizedSpread: number = 0;
  private totalTrades: number = 0;

  constructor(botContext: BotContext) {
    super(botContext);
    this.config = botContext.config as MarketMakingConfig;
  }

  async onInit(): Promise<void> {
    await super.onInit();
    logger.info(`Market Making Strategy initialized for ${this.botContext.pair}`, {
      spread: `${this.config.spreadPercent}%`,
      orderAmount: this.config.orderAmount,
      refreshInterval: `${this.config.orderRefreshIntervalMs}ms`,
      inventoryTarget: `${this.config.inventoryTargetPercent}%`,
    });
  }

  /**
   * Set current balances for inventory management.
   */
  updateBalances(baseAsset: number, quoteAsset: number, midPrice: number): void {
    this.baseAssetBalance = baseAsset;
    this.quoteAssetBalance = quoteAsset;
    this.midPrice = midPrice;
  }

  /**
   * Calculate optimal bid and ask prices considering inventory skew.
   *
   * If holding too much base (e.g., 70% BTC), skew orders to sell more aggressively.
   * If holding too much quote (e.g., 70% USDT), skew orders to buy more aggressively.
   */
  private calculatePrices(): { bidPrice: number; askPrice: number } {
    const halfSpread = this.config.spreadPercent / 100 / 2;

    // Calculate inventory ratio
    const totalValue = this.baseAssetBalance * this.midPrice + this.quoteAssetBalance;
    const baseRatio = totalValue > 0 ? (this.baseAssetBalance * this.midPrice) / totalValue : 0.5;
    const targetRatio = this.config.inventoryTargetPercent / 100;

    // Skew factor: negative = more base than target (sell leaning), positive = less base (buy leaning)
    const skew = (targetRatio - baseRatio) * this.config.inventorySkewFactor;

    // Adjust spread based on inventory
    const bidSkew = skew * halfSpread;
    const askSkew = -skew * halfSpread;

    const bidPrice = this.midPrice * (1 - halfSpread + bidSkew);
    const askPrice = this.midPrice * (1 + halfSpread + askSkew);

    return {
      bidPrice: Math.round(bidPrice * 100) / 100,
      askPrice: Math.round(askPrice * 100) / 100,
    };
  }

  async onTick(candle: OHLCV, ticker: Ticker): Promise<void> {
    this.midPrice = (ticker.bid + ticker.ask) / 2;

    // Should we refresh orders?
    const now = Date.now();
    if (now - this.lastRefreshTime < this.config.orderRefreshIntervalMs) return;

    this.lastRefreshTime = now;

    await this.refreshOrders();
  }

  async onPrice(price: number, ticker: Ticker): Promise<void> {
    this.midPrice = (ticker.bid + ticker.ask) / 2;

    // On each price update, check if we need to refresh
    // Only refresh if enough time has passed
    const now = Date.now();
    if (now - this.lastRefreshTime < this.config.orderRefreshIntervalMs) return;

    this.lastRefreshTime = now;
    await this.refreshOrders();
  }

  /**
   * Cancel existing orders and place new ones at revised prices.
   */
  private async refreshOrders(): Promise<void> {
    if (this.midPrice <= 0) return;

    // Cancel existing orders (unless hanging orders are enabled)
    if (!this.config.hangingOrdersEnabled) {
      this.activeOrders = [];
    } else {
      // Keep a ratio of unfilled orders
      const maxToKeep = Math.floor(this.config.maxOpenOrders * this.config.hangingOrdersKeptRatio);
      if (this.activeOrders.length > maxToKeep) {
        this.activeOrders = this.activeOrders.slice(-maxToKeep);
      }
    }

    const { bidPrice, askPrice } = this.calculatePrices();
    const orderAmount = this.config.orderAmount;

    // Place new bid
    this.activeOrders.push({
      side: "buy",
      price: bidPrice,
      quantity: orderAmount,
      placedAt: Date.now(),
    });

    // Place new ask
    this.activeOrders.push({
      side: "sell",
      price: askPrice,
      quantity: orderAmount,
      placedAt: Date.now(),
    });

    logger.debug(`Market making orders refreshed: Bid $${bidPrice} | Ask $${askPrice} | Spread $${(askPrice - bidPrice).toFixed(2)}`);
  }

  /**
   * Record a filled order and track spread capture.
   */
  recordFill(side: "buy" | "sell", price: number, quantity: number): void {
    this.realizedSpread += quantity * price * (this.config.spreadPercent / 100);
    this.totalTrades++;

    // Update inventory tracking
    if (side === "buy") {
      this.baseAssetBalance += quantity;
      this.quoteAssetBalance -= price * quantity;
    } else {
      this.baseAssetBalance -= quantity;
      this.quoteAssetBalance += price * quantity;
    }
  }

  getStats(): {
    midPrice: number;
    activeOrders: number;
    totalTrades: number;
    realizedSpread: number;
    baseAssetBalance: number;
    quoteAssetBalance: number;
    inventoryRatio: number;
    currentBidAsk: { bid: number; ask: number } | null;
  } {
    const prices = this.calculatePrices();
    const totalValue = this.baseAssetBalance * this.midPrice + this.quoteAssetBalance;

    return {
      midPrice: this.midPrice,
      activeOrders: this.activeOrders.length,
      totalTrades: this.totalTrades,
      realizedSpread: this.realizedSpread,
      baseAssetBalance: this.baseAssetBalance,
      quoteAssetBalance: this.quoteAssetBalance,
      inventoryRatio: totalValue > 0 ? (this.baseAssetBalance * this.midPrice) / totalValue : 0.5,
      currentBidAsk: prices,
    };
  }

  async onStop(): Promise<void> {
    logger.info(`Market making stopped. Total trades: ${this.totalTrades} | Spread captured: $${this.realizedSpread.toFixed(2)}`);
    this.activeOrders = [];
    await super.onStop();
  }
}