import { BaseStrategy } from "./base.strategy";
import type { BotContext, OHLCV, Ticker, Position } from "./base.strategy";
import { v4 as uuidv4 } from "uuid";
import { logger } from "../utils/logger";

export interface MLConfig {
  baseOrderSize: number;
  takeProfitPercent: number;
  stopLossPercent: number;
  modelConfidenceThreshold: number;
  cooldownBetweenDealsMinutes: number;
  minimumROI: Record<string, number>;
}

/**
 * Machine Learning strategy.
 * Uses trained ML models to generate buy/sell/hold signals.
 * The actual model inference happens in the ML service.
 * This strategy receives predictions and executes based on them.
 *
 * FreqAI-style: users configure feature engineering elsewhere,
 * this strategy consumes the predictions.
 */
export class MLStrategy extends BaseStrategy {
  private config: MLConfig;
  private activeDealId: string | null = null;
  private entryPrice: number = 0;
  private positionQuantity: number = 0;
  private highestPriceSinceEntry: number = 0;
  private candles: OHLCV[] = [];
  private maxCandles: number = 200;
  private lastPredictions: Array<{ signal: "buy" | "sell" | "hold"; confidence: number; timestamp: number }> = [];
  private signalWindow: number = 3; // Number of recent signals to consider
  private modelId: string | null = null;

  constructor(botContext: BotContext) {
    super(botContext);
    this.config = botContext.config as MLConfig;
  }

  async onInit(): Promise<void> {
    await super.onInit();
    logger.info(`ML Strategy initialized for ${this.botContext.pair}`, {
      confidenceThreshold: this.config.modelConfidenceThreshold,
      takeProfit: `${this.config.takeProfitPercent}%`,
      stopLoss: `${this.config.stopLossPercent}%`,
    });
  }

  /**
   * Set the model ID being used.
   */
  setModelId(modelId: string): void {
    this.modelId = modelId;
  }

  /**
   * Receive a prediction from the ML service.
   * Called externally by the engine when ML service produces a prediction.
   */
  receivePrediction(signal: "buy" | "sell" | "hold", confidence: number): void {
    this.lastPredictions.push({
      signal,
      confidence,
      timestamp: Date.now(),
    });

    // Keep only recent predictions
    if (this.lastPredictions.length > this.signalWindow * 2) {
      this.lastPredictions = this.lastPredictions.slice(-this.signalWindow);
    }

    logger.debug(`ML prediction received: ${signal} (${(confidence * 100).toFixed(1)}% confidence)`);
  }

  /**
   * Determine the consensus signal from recent predictions.
   */
  private getConsensusSignal(): { signal: "buy" | "sell" | "hold"; confidence: number } | null {
    if (this.lastPredictions.length < this.signalWindow) return null;

    const recent = this.lastPredictions.slice(-this.signalWindow);

    const buyCount = recent.filter(p => p.signal === "buy").length;
    const sellCount = recent.filter(p => p.signal === "sell").length;
    const avgConfidence = recent.reduce((sum, p) => sum + p.confidence, 0) / recent.length;

    if (buyCount >= this.signalWindow) {
      return { signal: "buy", confidence: avgConfidence };
    } else if (sellCount >= this.signalWindow) {
      return { signal: "sell", confidence: avgConfidence };
    }

    return null;
  }

  private shouldStartDeal(): boolean {
    if (this.activeDealId) return false;
    if (this.isInCooldown(this.botContext.pair)) return false;

    const consensus = this.getConsensusSignal();
    if (!consensus) return false;
    if (consensus.signal !== "buy") return false;
    if (consensus.confidence < this.config.modelConfidenceThreshold) {
      logger.debug(`ML buy signal suppressed: confidence ${(consensus.confidence * 100).toFixed(1)}% < ${(this.config.modelConfidenceThreshold * 100).toFixed(0)}%`);
      return false;
    }

    return true;
  }

  async onTick(candle: OHLCV, ticker: Ticker): Promise<void> {
    this.candles.push(candle);
    if (this.candles.length > this.maxCandles) {
      this.candles.shift();
    }

    const currentPrice = ticker.last || candle.close;

    if (!this.activeDealId && this.shouldStartDeal()) {
      await this.startDeal(currentPrice);
      return;
    }

    if (!this.activeDealId) return;

    if (currentPrice > this.highestPriceSinceEntry) {
      this.highestPriceSinceEntry = currentPrice;
    }

    // Stop loss
    const slPrice = this.entryPrice * (1 - this.config.stopLossPercent / 100);
    if (currentPrice <= slPrice) {
      await this.closeDeal(currentPrice, `SL: -${this.config.stopLossPercent}%`);
      return;
    }

    // Take profit
    const profitPercent = ((currentPrice - this.entryPrice) / this.entryPrice) * 100;
    if (profitPercent >= this.config.takeProfitPercent) {
      await this.closeDeal(currentPrice, `TP: ${profitPercent.toFixed(2)}%`);
      return;
    }

    // ML sell signal
    const consensus = this.getConsensusSignal();
    if (consensus && consensus.signal === "sell" && consensus.confidence >= this.config.modelConfidenceThreshold) {
      await this.closeDeal(currentPrice, `ML sell signal (${(consensus.confidence * 100).toFixed(0)}% confidence)`);
    }
  }

  private async startDeal(currentPrice: number): Promise<void> {
    this.activeDealId = uuidv4();
    this.entryPrice = currentPrice;
    this.highestPriceSinceEntry = currentPrice;

    try {
      const order = await this.placeBuyOrder(this.config.baseOrderSize);
      this.positionQuantity = order.quantity;

      const consensus = this.getConsensusSignal();

      const position: Position = {
        id: `ml_${this.activeDealId}`,
        botId: this.botContext.botId,
        pair: this.botContext.pair,
        entryPrice: currentPrice,
        currentPrice,
        quantity: this.positionQuantity,
        side: "buy",
        unrealizedPnl: 0,
        realizedPnl: 0,
        stopLoss: currentPrice * (1 - this.config.stopLossPercent / 100),
        takeProfit: [{ price: currentPrice * (1 + this.config.takeProfitPercent / 100), percentage: 100 }],
        safetyOrders: null,
        minimumROI: this.config.minimumROI,
        status: "open",
        openedAt: new Date(),
      };

      this.openPosition(position);

      this.emit("onLog", "info",
        `🤖 ML buy signal: ${order.quantity} @ $${currentPrice}` +
        (consensus ? ` (confidence: ${(consensus.confidence * 100).toFixed(0)}%)` : "")
      );

      // Clear predictions after acting
      this.lastPredictions = [];

      if (this.botContext.protectionConfig?.stoplossOnExchange) {
        this.emit("onSignal", { action: "sell", price: position.stopLoss!, reason: "stop_loss" });
      }
    } catch (error) {
      this.emit("onError", error as Error);
      this.activeDealId = null;
    }
  }

  private async closeDeal(currentPrice: number, reason: string): Promise<void> {
    if (!this.activeDealId) return;

    try {
      await this.placeSellOrder(this.positionQuantity);

      const pnl = (currentPrice - this.entryPrice) * this.positionQuantity;
      const pnlPercent = ((currentPrice - this.entryPrice) / this.entryPrice) * 100;
      this.closePosition(`ml_${this.activeDealId}`, pnl);

      this.emit("onLog", "info", `ML deal closed: ${reason} | PnL: $${pnl.toFixed(2)} (${pnlPercent.toFixed(2)}%)`);

      this.setCooldown(this.botContext.pair);

      this.activeDealId = null;
      this.positionQuantity = 0;
      this.entryPrice = 0;
      this.highestPriceSinceEntry = 0;
    } catch (error) {
      this.emit("onError", error as Error);
    }
  }

  getModelInfo(): { modelId: string | null; recentPredictions: number } {
    return {
      modelId: this.modelId,
      recentPredictions: this.lastPredictions.length,
    };
  }

  async onStop(): Promise<void> {
    if (this.activeDealId) {
      await this.closeDeal(this.entryPrice, "Bot stopped");
    }
    await super.onStop();
  }
}