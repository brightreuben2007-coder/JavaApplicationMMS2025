import { logger } from "../utils/logger";

export type PairListMode = "static" | "volume" | "performance" | "volatility";

export interface PairListConfig {
  mode: PairListMode;
  pairs?: string[];
  maxPairs?: number;
  topVolumeCount?: number;
  momentumDays?: number;
  volatilityRange?: { min: number; max: number };
  blacklist: string[];
}

interface TickerData {
  symbol: string;
  last: number;
  quoteVolume: number;
  changePercent: number;
}

/**
 * Pair List Manager.
 * Dynamically selects trading pairs based on filters.
 * Freqtrade-style: volume, performance, volatility filters.
 */
export class PairListManager {
  private config: PairListConfig;
  private activePairs: string[] = [];
  private lastRefreshTime: number = 0;
  private refreshIntervalMs: number = 4 * 60 * 60 * 1000; // 4 hours

  constructor(config: PairListConfig) {
    this.config = config;
  }

  /**
   * Refresh the pair list based on current market data.
   */
  async refreshPairs(tickers: TickerData[]): Promise<string[]> {
    const now = Date.now();
    if (now - this.lastRefreshTime < this.refreshIntervalMs && this.activePairs.length > 0) {
      return this.activePairs;
    }

    this.lastRefreshTime = now;

    let selected: string[] = [];

    switch (this.config.mode) {
      case "static":
        selected = this.config.pairs || [];
        break;

      case "volume":
        selected = this.filterByVolume(tickers);
        break;

      case "performance":
        selected = this.filterByPerformance(tickers);
        break;

      case "volatility":
        selected = this.filterByVolatility(tickers);
        break;
    }

    // Remove blacklisted pairs
    selected = selected.filter(p => !this.config.blacklist.includes(p));

    // Limit to max pairs
    const maxPairs = this.config.maxPairs || 10;
    if (selected.length > maxPairs) {
      selected = selected.slice(0, maxPairs);
    }

    const oldPairs = [...this.activePairs];
    this.activePairs = selected;

    const added = selected.filter(p => !oldPairs.includes(p));
    const removed = oldPairs.filter(p => !selected.includes(p));

    if (added.length > 0 || removed.length > 0) {
      logger.info(`Pair list updated`, {
        mode: this.config.mode,
        count: selected.length,
        added,
        removed,
      });
    }

    return this.activePairs;
  }

  /**
   * Filter by 24h trading volume.
   */
  private filterByVolume(tickers: TickerData[]): string[] {
    const count = this.config.topVolumeCount || 10;

    return tickers
      .filter(t => t.quoteVolume > 0)
      .sort((a, b) => b.quoteVolume - a.quoteVolume)
      .slice(0, count)
      .map(t => t.symbol);
  }

  /**
   * Filter by price momentum (change %).
   */
  private filterByPerformance(tickers: TickerData[]): string[] {
    const count = this.config.topVolumeCount || 10;

    return tickers
      .filter(t => t.quoteVolume > 0)
      .sort((a, b) => b.changePercent - a.changePercent)
      .slice(0, count)
      .map(t => t.symbol);
  }

  /**
   * Filter by volatility range.
   */
  private filterByVolatility(tickers: TickerData[]): string[] {
    const range = this.config.volatilityRange || { min: 1, max: 20 };

    return tickers
      .filter(t => {
        const absChange = Math.abs(t.changePercent);
        return absChange >= range.min && absChange <= range.max;
      })
      .sort((a, b) => b.quoteVolume - a.quoteVolume)
      .map(t => t.symbol);
  }

  getActivePairs(): string[] {
    return this.activePairs;
  }
}