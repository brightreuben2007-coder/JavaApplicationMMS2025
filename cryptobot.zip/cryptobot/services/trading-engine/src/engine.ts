import { EventEmitter } from "node:events";
import { Redis } from "ioredis";
import { BaseStrategy } from "./strategies/base.strategy";
import { DCAStrategy } from "./strategies/dca.strategy";
import { GridStrategy } from "./strategies/grid.strategy";
import { InfinityGridStrategy } from "./strategies/grid-infinity.strategy";
import { LeveragedGridStrategy } from "./strategies/grid-leveraged.strategy";
import { MartingaleStrategy } from "./strategies/martingale.strategy";
import { MACDStrategy } from "./strategies/macd.strategy";
import { BollingerStrategy } from "./strategies/bollinger.strategy";
import { ArbitrageStrategy } from "./strategies/arbitrage.strategy";
import { MarketMakingStrategy } from "./strategies/marketmaking.strategy";
import { AvellanedaStrategy } from "./strategies/avellaneda.strategy";
import { RebalancingStrategy } from "./strategies/rebalancing.strategy";
import { TWAPAccumulatorStrategy } from "./strategies/twap-accumulator.strategy";
import { MLStrategy } from "./strategies/ml.strategy";
import { OrderRouter } from "./orders/orderRouter";
import { StopLossOnExchange } from "./protection/stoplossOnExchange";
import { CooldownManager } from "./protection/cooldown";
import { VolatilityProtection } from "./protection/volatilityProtection";
import { StaleOrderTimeout } from "./protection/staleOrderTimeout";
import { PairListManager } from "./pairlist/pairlistManager";
import { logger } from "./utils/logger";
import type { BotContext, StrategyType, OHLCV, Ticker, OrderRequest, OrderResult } from "./strategies/base.strategy";

interface BotInstance {
  strategy: BaseStrategy;
  context: BotContext;
}

/**
 * Trading Engine.
 * Manages all strategy instances, routes orders, and coordinates
 * between strategies, market data, and the exchange.
 */
export class TradingEngine extends EventEmitter {
  private bots: Map<string, BotInstance> = new Map();
  private orderRouter: OrderRouter;
  private stopLossManager: StopLossOnExchange;
  private cooldownManager: CooldownManager;
  private volatilityProtection: VolatilityProtection;
  private staleOrderTimeout: StaleOrderTimeout;
  private pairListManagers: Map<string, PairListManager> = new Map();
  private redis: Redis;

  constructor(redisUrl: string) {
    super();
    this.redis = new Redis(redisUrl, { maxRetriesPerRequest: 3 });
    this.orderRouter = new OrderRouter();
    this.stopLossManager = new StopLossOnExchange(this.orderRouter);
    this.cooldownManager = new CooldownManager();
    this.volatilityProtection = new VolatilityProtection();
    this.staleOrderTimeout = new StaleOrderTimeout(this.orderRouter);

    this.staleOrderTimeout.startChecking(60000);
    this.setupRedisListeners();
  }

  /**
   * Create a strategy instance based on type.
   */
  private createStrategy(context: BotContext): BaseStrategy {
    switch (context.strategyType) {
      case "dca": return new DCAStrategy(context);
      case "grid": return new GridStrategy(context);
      case "grid-infinity": return new InfinityGridStrategy(context);
      case "grid-leveraged": return new LeveragedGridStrategy(context);
      case "martingale": return new MartingaleStrategy(context);
      case "macd": return new MACDStrategy(context);
      case "bollinger": return new BollingerStrategy(context);
      case "arbitrage": return new ArbitrageStrategy(context);
      case "marketmaking": return new MarketMakingStrategy(context);
      case "avellaneda": return new AvellanedaStrategy(context);
      case "rebalancing": return new RebalancingStrategy(context);
      case "twap": return new TWAPAccumulatorStrategy(context);
      case "ml": return new MLStrategy(context);
      default:
        throw new Error(`Unknown strategy type: ${context.strategyType}`);
    }
  }

  /**
   * Register and start a bot.
   */
  async startBot(context: BotContext): Promise<void> {
    if (this.bots.has(context.botId)) {
      logger.warn(`Bot ${context.botId} is already running`);
      return;
    }

    const strategy = this.createStrategy(context);
    this.setupStrategyHandlers(strategy, context);
    await strategy.onInit();

    this.bots.set(context.botId, { strategy, context });

    // Setup pair list manager if configured
    if (context.pairlistConfig) {
      const manager = new PairListManager(context.pairlistConfig as any);
      this.pairListManagers.set(context.botId, manager);
    }

    logger.info(`Bot started: ${context.botId} (${context.strategyType})`);
    this.emit("bot:started", context.botId);
  }

  /**
   * Stop a bot.
   */
  async stopBot(botId: string): Promise<void> {
    const instance = this.bots.get(botId);
    if (!instance) {
      logger.warn(`Bot ${botId} not found`);
      return;
    }

    await instance.strategy.onStop();
    this.bots.delete(botId);
    this.pairListManagers.delete(botId);
    this.cooldownManager.clearAllCooldowns(botId);

    logger.info(`Bot stopped: ${botId}`);
    this.emit("bot:stopped", botId);
  }

  /**
   * Pause a bot.
   */
  async pauseBot(botId: string): Promise<void> {
    const instance = this.bots.get(botId);
    if (!instance) return;
    instance.context.status = "paused";
    await instance.strategy.onPause();
    this.emit("bot:paused", botId);
  }

  /**
   * Resume a bot.
   */
  async resumeBot(botId: string): Promise<void> {
    const instance = this.bots.get(botId);
    if (!instance) return;
    instance.context.status = "active";
    await instance.strategy.onResume();
    this.emit("bot:resumed", botId);
  }

  /**
   * Feed market data to relevant bots.
   */
  async onMarketData(exchange: string, pair: string, candle: OHLCV, ticker: Ticker): Promise<void> {
    for (const [botId, instance] of this.bots.entries()) {
      if (instance.context.exchange === exchange && instance.context.pair === pair) {
        if (instance.context.status !== "active") continue;

        try {
          await instance.strategy.onTick(candle, ticker);
        } catch (error) {
          logger.error(`Error in bot ${botId} onTick`, { error: (error as Error).message });
          this.emit("bot:error", botId, error);
        }
      }
    }
  }

  /**
   * Feed price update to relevant bots.
   */
  async onPriceUpdate(exchange: string, pair: string, price: number, ticker: Ticker): Promise<void> {
    for (const [botId, instance] of this.bots.entries()) {
      if (instance.context.exchange === exchange && instance.context.pair === pair) {
        if (instance.context.status !== "active") continue;

        await instance.strategy.onPrice(price, ticker).catch(err => {
          logger.error(`Error in bot ${botId} onPrice`, { error: err.message });
        });
      }
    }
  }

  /**
   * Setup event handlers for a strategy instance.
   */
  private setupStrategyHandlers(strategy: BaseStrategy, context: BotContext): void {
    strategy.on("onOrderRequested", async (order: OrderRequest) => {
      try {
        const result = await this.orderRouter.executeOrder(
          order,
          context.credentialId || "",
          context.exchange,
          context.paperTrading
        );

        await strategy.onOrderFilled(result);

        // Track for stale order detection
        if (result.status === "open") {
          this.staleOrderTimeout.trackOrder(result, {
            credentialId: context.credentialId || "",
            exchangeId: context.exchange,
            paperTrading: context.paperTrading,
          });
        }
      } catch (error) {
        strategy.emit("onError", error);
      }
    });

    strategy.on("onSignal", (signal) => {
      this.emit("bot:signal", context.botId, signal);
    });

    strategy.on("onPositionOpened", (position) => {
      this.emit("bot:position:opened", context.botId, position);
      this.publishBotEvent(context.botId, "position_opened", position);
    });

    strategy.on("onPositionClosed", (position, pnl) => {
      this.emit("bot:position:closed", context.botId, position, pnl);
      this.publishBotEvent(context.botId, "position_closed", { position, pnl });
    });

    strategy.on("onLog", (level, message, data) => {
      logger.log(level, `[Bot ${context.botId}] ${message}`, data);
    });

    strategy.on("onError", (error) => {
      logger.error(`[Bot ${context.botId}] Error: ${error.message}`);
      this.emit("bot:error", context.botId, error);
    });
  }

  /**
   * Setup Redis pub/sub listeners for external commands.
   */
  private setupRedisListeners(): void {
    const subscriber = this.redis.duplicate();

    subscriber.subscribe("bot:command:start", "bot:command:stop", "bot:command:pause",
      "bot:webhook", "market:candles", "market:ticker");

    subscriber.on("message", async (channel, message) => {
      try {
        const data = JSON.parse(message);

        switch (channel) {
          case "bot:command:start":
            if (data.botId) await this.resumeBot(data.botId);
            break;
          case "bot:command:stop":
            if (data.botId) await this.stopBot(data.botId);
            break;
          case "bot:command:pause":
            if (data.botId) await this.pauseBot(data.botId);
            break;
          case "bot:webhook":
            // Handle webhook signals
            this.emit("webhook:received", data);
            break;
          case "market:candles":
          case "market:ticker":
            // Market data is handled by onMarketData
            break;
        }
      } catch (error) {
        logger.error("Redis message processing error", { channel, error });
      }
    });
  }

  /**
   * Publish bot event to Redis for API gateway consumption.
   */
  private publishBotEvent(botId: string, event: string, data: any): void {
    this.redis.publish("bot:status", JSON.stringify({
      botId,
      event,
      data,
      timestamp: Date.now(),
    })).catch(err => logger.error("Failed to publish bot event", { error: err.message }));
  }

  getActiveBotIds(): string[] {
    return Array.from(this.bots.keys());
  }

  getBotCount(): number {
    return this.bots.size;
  }

  getOrderRouter(): OrderRouter {
    return this.orderRouter;
  }

  async shutdown(): Promise<void> {
    this.staleOrderTimeout.stopChecking();
    for (const botId of this.getActiveBotIds()) {
      await this.stopBot(botId);
    }
    await this.redis.quit();
    logger.info("Trading engine shut down");
  }
}