import dotenv from "dotenv";
dotenv.config();

import express from "express";
import helmet from "helmet";
import promClient from "prom-client";
import { TradingEngine } from "./engine";
import { logger } from "./utils/logger";

const app = express();
const PORT = parseInt(process.env.PORT || "3002", 10);
const REDIS_URL = process.env.REDIS_URL || "redis://localhost:6379";

// Metrics
const register = new promClient.Registry();
promClient.collectDefaultMetrics({ register, prefix: "trading_engine_" });

const activeBotsGauge = new promClient.Gauge({
  name: "trading_engine_active_bots",
  help: "Number of active trading bots",
  registers: [register],
});

const orderCounter = new promClient.Counter({
  name: "trading_engine_orders_total",
  help: "Total number of orders executed",
  labelNames: ["side", "status"],
  registers: [register],
});

// Engine instance
const engine = new TradingEngine(REDIS_URL);

// Express setup
app.use(helmet());
app.use(express.json());

app.get("/health", (_req, res) => {
  res.json({
    status: "healthy",
    service: "trading-engine",
    activeBots: engine.getBotCount(),
    uptime: process.uptime(),
  });
});

app.get("/metrics", async (_req, res) => {
  activeBotsGauge.set(engine.getBotCount());
  res.set("Content-Type", register.contentType);
  res.end(await register.metrics());
});

// Engine events
engine.on("bot:started", () => activeBotsGauge.inc());
engine.on("bot:stopped", () => activeBotsGauge.dec());

// Start server
app.listen(PORT, () => {
  logger.info(`Trading Engine started on port ${PORT}`);
});

// Graceful shutdown
const shutdown = async (signal: string) => {
  logger.info(`Received ${signal}. Shutting down...`);
  await engine.shutdown();
  process.exit(0);
};

process.on("SIGTERM", () => shutdown("SIGTERM"));
process.on("SIGINT", () => shutdown("SIGINT"));

export { engine, app };