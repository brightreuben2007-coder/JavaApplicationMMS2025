import { EventEmitter } from "node:events";
import { v4 as uuidv4 } from "uuid";
import ccxt, { Exchange } from "ccxt";
import { logger } from "../utils/logger";
import { OrderExecutionError, InsufficientBalanceError } from "../utils/errors";
import type { OrderRequest, OrderResult, TradeSide, OrderType } from "../strategies/base.strategy";

interface ExchangeConnection {
  exchange: Exchange;
  credentialId: string;
}

export class OrderRouter extends EventEmitter {
  private exchangeConnections: Map<string, ExchangeConnection> = new Map();
  private pendingOrders: Map<string, OrderRequest> = new Map();

  constructor() {
    super();
  }

  /**
   * Register an exchange connection for order execution.
   */
  registerExchange(
    key: string,
    exchange: Exchange,
    credentialId: string
  ): void {
    this.exchangeConnections.set(key, { exchange, credentialId });
    logger.info(`Exchange registered: ${key}`);
  }

  /**
   * Remove an exchange connection.
   */
  unregisterExchange(key: string): void {
    this.exchangeConnections.delete(key);
  }

  /**
   * Get exchange instance for a given key.
   */
  private getExchange(credentialId: string, exchangeId: string): Exchange {
    const key = `${exchangeId}:${credentialId}`;
    const connection = this.exchangeConnections.get(key);
    if (!connection) {
      throw new OrderExecutionError(`Exchange not registered: ${key}`);
    }
    return connection.exchange;
  }

  /**
   * Execute an order on the exchange.
   */
  async executeOrder(
    request: OrderRequest,
    credentialId: string,
    exchangeId: string,
    paperTrading: boolean = false
  ): Promise<OrderResult> {
    const orderId = uuidv4();

    if (paperTrading) {
      return this.simulateOrder(orderId, request, exchangeId);
    }

    const exchange = this.getExchange(credentialId, exchangeId);

    try {
      logger.info(`Executing ${request.side} ${request.type} order on ${exchangeId}`, {
        symbol: request.symbol,
        quantity: request.quantity,
        price: request.price,
      });

      let exchangeOrder: any;

      if (request.type === "market") {
        exchangeOrder = await exchange.createMarketOrder(
          request.symbol,
          request.side,
          request.quantity
        );
      } else if (request.type === "limit" && request.price) {
        exchangeOrder = await exchange.createLimitOrder(
          request.symbol,
          request.side,
          request.quantity,
          request.price
        );
      } else {
        throw new OrderExecutionError(`Invalid order type or missing price: ${request.type}`);
      }

      const result: OrderResult = {
        orderId,
        exchangeOrderId: exchangeOrder.id,
        symbol: request.symbol,
        side: request.side,
        type: request.type,
        quantity: exchangeOrder.amount,
        price: exchangeOrder.price || request.price || null,
        filledPrice: exchangeOrder.price || null,
        status: exchangeOrder.status === "closed" ? "filled" : "open",
        fee: exchangeOrder.fee?.cost || 0,
        feeCurrency: exchangeOrder.fee?.currency || null,
        createdAt: new Date(),
        filledAt: exchangeOrder.status === "closed" ? new Date() : null,
      };

      this.emit("order:executed", result);
      return result;
    } catch (error: any) {
      logger.error(`Order execution failed on ${exchangeId}`, {
        error: error.message,
        symbol: request.symbol,
      });

      const result: OrderResult = {
        orderId,
        exchangeOrderId: "",
        symbol: request.symbol,
        side: request.side,
        type: request.type,
        quantity: request.quantity,
        price: request.price || null,
        filledPrice: null,
        status: "rejected",
        fee: 0,
        feeCurrency: null,
        createdAt: new Date(),
        filledAt: null,
      };

      this.emit("order:rejected", result, error.message);
      throw new OrderExecutionError(error.message);
    }
  }

  /**
   * Simulate order for paper trading.
   */
  private async simulateOrder(
    orderId: string,
    request: OrderRequest,
    exchangeId: string
  ): Promise<OrderResult> {
    // Simulate a small delay
    await new Promise((resolve) => setTimeout(resolve, 50 + Math.random() * 200));

    const fillPrice = request.price || request.price || 0;

    const result: OrderResult = {
      orderId,
      exchangeOrderId: `paper_${uuidv4().slice(0, 12)}`,
      symbol: request.symbol,
      side: request.side,
      type: request.type,
      quantity: request.quantity,
      price: request.price || null,
      filledPrice: fillPrice,
      status: "filled",
      fee: request.quantity * fillPrice * 0.001,
      feeCurrency: request.symbol.split("/")[1] || "USDT",
      createdAt: new Date(),
      filledAt: new Date(),
    };

    this.emit("order:executed", result);
    return result;
  }

  /**
   * Cancel an order on the exchange.
   */
  async cancelOrder(
    exchangeOrderId: string,
    symbol: string,
    credentialId: string,
    exchangeId: string,
    paperTrading: boolean = false
  ): Promise<boolean> {
    if (paperTrading) {
      logger.info(`Paper trading: cancel order ${exchangeOrderId}`);
      return true;
    }

    const exchange = this.getExchange(credentialId, exchangeId);

    try {
      await exchange.cancelOrder(exchangeOrderId, symbol);
      logger.info(`Order cancelled: ${exchangeOrderId}`);
      return true;
    } catch (error: any) {
      logger.error(`Failed to cancel order ${exchangeOrderId}`, { error: error.message });
      return false;
    }
  }

  /**
   * Place a stop-loss order on the exchange.
   */
  async placeStopLoss(
    symbol: string,
    side: TradeSide,
    quantity: number,
    stopPrice: number,
    credentialId: string,
    exchangeId: string,
    paperTrading: boolean = false
  ): Promise<string | null> {
    if (paperTrading) {
      const id = `paper_sl_${uuidv4().slice(0, 12)}`;
      logger.info(`Paper trading: stop-loss placed at ${stopPrice}`, { id });
      return id;
    }

    const exchange = this.getExchange(credentialId, exchangeId);

    try {
      // Place stop-limit order
      const order = await exchange.createOrder(
        symbol,
        "stop_limit",
        side,
        quantity,
        stopPrice * (side === "sell" ? 0.99 : 1.01), // Limit slightly beyond stop
        { stopPrice }
      );

      logger.info(`Stop-loss placed: ${order.id} at ${stopPrice}`);
      return order.id;
    } catch (error: any) {
      logger.error(`Failed to place stop-loss`, { error: error.message });
      return null;
    }
  }
}