import PDFDocument from "pdfkit";
import type { BacktestResult } from "../engine";

/**
 * PDF Report Generator.
 * Creates formatted backtest reports with metrics, charts, and trade log.
 */
export function generatePDFReport(result: BacktestResult): PDFDocument {
  const doc = new PDFDocument({ margin: 50 });
  const m = result.metrics;

  // Title
  doc.fontSize(24).font("Helvetica-Bold").text("Backtest Report", { align: "center" });
  doc.moveDown();
  doc.fontSize(12).font("Helvetica").text(`Pair: ${result.config.pair}`, { align: "center" });
  doc.text(`${result.config.startDate.toISOString()} → ${result.config.endDate.toISOString()}`, { align: "center" });
  doc.text(`Timeframe: ${result.config.timeframe}`, { align: "center" });
  doc.moveDown(2);

  // Performance Summary
  doc.fontSize(16).font("Helvetica-Bold").text("Performance Summary");
  doc.moveDown();
  doc.fontSize(11).font("Helvetica");

  const summaryData = [
    ["Total Return", `${m.totalReturnPercent.toFixed(2)}%`],
    ["Sharpe Ratio", m.sharpeRatio.toFixed(2)],
    ["Sortino Ratio", m.sortinoRatio.toFixed(2)],
    ["Max Drawdown", `${m.maxDrawdownPercent.toFixed(2)}%`],
    ["Win Rate", `${m.winRate.toFixed(2)}%`],
    ["Profit Factor", m.profitFactor === Infinity ? "∞" : m.profitFactor.toFixed(2)],
    ["Total Trades", m.totalTrades.toString()],
    ["Winning Trades", m.winningTrades.toString()],
    ["Losing Trades", m.losingTrades.toString()],
    ["Avg Win", `$${m.avgWin.toFixed(2)}`],
    ["Avg Loss", `$${Math.abs(m.avgLoss).toFixed(2)}`],
    ["Largest Win", `$${m.largestWin.toFixed(2)}`],
    ["Largest Loss", `$${Math.abs(m.largestLoss).toFixed(2)}`],
    ["Expectancy", `$${m.expectancy.toFixed(2)}`],
    ["Avg Trade Duration", formatDuration(m.avgTradeDurationMs)],
  ];

  const col1X = 50;
  const col2X = 300;
  let y = doc.y;

  for (const [label, value] of summaryData) {
    doc.font("Helvetica-Bold").text(label, col1X, y);
    doc.font("Helvetica").text(value, col2X, y, { align: "left" });
    y += 18;
  }

  // Monthly Returns
  doc.addPage();
  doc.fontSize(16).font("Helvetica-Bold").text("Monthly Returns");
  doc.moveDown();
  doc.fontSize(10).font("Helvetica");

  const months = Object.entries(result.monthlyReturns);
  if (months.length > 0) {
    y = doc.y;
    for (const [month, returnPct] of months.slice(0, 36)) {
      const color = returnPct >= 0 ? "green" : "red";
      doc.fillColor(color).text(`${month}: ${returnPct >= 0 ? "+" : ""}${returnPct.toFixed(2)}%`, col1X, y);
      y += 16;
    }
  }

  // Trade Log
  doc.addPage();
  doc.fontSize(16).font("Helvetica-Bold").text("Trade Log");
  doc.moveDown();
  doc.fontSize(8).font("Helvetica");
  doc.fillColor("black");

  // Header
  const headers = ["Entry", "Exit", "Side", "Qty", "Entry $", "Exit $", "PnL $", "PnL %", "Reason"];
  const colWidths = [100, 100, 40, 50, 65, 65, 65, 55, 80];
  let xPos = 50;
  y = doc.y;

  for (let i = 0; i < headers.length; i++) {
    doc.font("Helvetica-Bold").text(headers[i]!, xPos, y, { width: colWidths[i] });
    xPos += colWidths[i]!;
  }

  doc.moveDown();
  y = doc.y;

  for (const trade of result.trades.slice(0, 100)) {
    xPos = 50;
    const rowData = [
      new Date(trade.entryTimestamp).toISOString().split("T")[0] || "",
      new Date(trade.exitTimestamp).toISOString().split("T")[0] || "",
      trade.side,
      trade.quantity.toFixed(4),
      trade.entryPrice.toFixed(2),
      trade.exitPrice.toFixed(2),
      trade.pnl >= 0 ? `+${trade.pnl.toFixed(2)}` : trade.pnl.toFixed(2),
      `${trade.pnlPercent >= 0 ? "+" : ""}${trade.pnlPercent.toFixed(2)}%`,
      trade.exitReason.slice(0, 15),
    ];

    const color = trade.pnl >= 0 ? "green" : "red";

    for (let i = 0; i < rowData.length; i++) {
      doc.fillColor(color).text(rowData[i]!, xPos, y, { width: colWidths[i] });
      xPos += colWidths[i]!;
    }

    y += 14;

    if (y > 700) {
      doc.addPage();
      y = 50;
    }
  }

  // Disclaimer
  doc.fillColor("gray");
  doc.fontSize(8);
  doc.moveDown(2);
  doc.text("This report is for informational purposes only. Past performance does not guarantee future results.");

  return doc;
}

function formatDuration(ms: number): string {
  if (ms <= 0) return "N/A";
  const hours = Math.floor(ms / 3600000);
  const minutes = Math.floor((ms % 3600000) / 60000);
  if (hours > 24) {
    const days = Math.floor(hours / 24);
    return `${days}d ${hours % 24}h`;
  }
  return `${hours}h ${minutes}m`;
}