import { BacktestEngine, type BacktestConfig, type BacktestResult } from "../engine";
import { DataLoader } from "../dataLoader";
import { logger } from "../utils/logger";

export interface ParameterSpace {
  [key: string]: { min: number; max: number; step: number };
}

export interface OptimizationResult {
  params: Record<string, number>;
  metrics: BacktestResult["metrics"];
  rank: number;
}

const MAX_COMBINATIONS = 10000;

/**
 * Grid Search Optimization.
 * Iterates through all parameter combinations exhaustively.
 * Now with combination count validation to prevent runaway searches.
 */
export async function gridSearch(
  engine: BacktestEngine,
  baseConfig: BacktestConfig,
  paramSpace: ParameterSpace,
  target: "sharpe" | "profit" | "drawdown" = "sharpe",
  onProgress?: (completed: number, total: number) => void
): Promise<OptimizationResult[]> {
  // Count combinations before generating
  const combinationCount = countCombinations(paramSpace);

  if (combinationCount > MAX_COMBINATIONS) {
    throw new Error(
      `Too many combinations: ${combinationCount.toLocaleString()}. ` +
      `Max allowed: ${MAX_COMBINATIONS.toLocaleString()}. ` +
      `Increase step sizes or narrow ranges.`
    );
  }

  if (combinationCount === 0) {
    throw new Error("No parameter combinations to test. Check your search space.");
  }

  const combinations = generateCombinations(paramSpace);
  const results: OptimizationResult[] = [];
  let completed = 0;
  let failed = 0;

  logger.info(`Grid search: ${combinations.length} combinations over ${Object.keys(paramSpace).length} parameters`);

  for (const params of combinations) {
    try {
      const config = applyParameters(baseConfig, params);
      const result = await engine.run(config);

      results.push({
        params: { ...params },
        metrics: result.metrics,
        rank: 0,
      });
    } catch (error) {
      failed++;
      logger.warn(`Combination failed: ${JSON.stringify(params)}`, { error: (error as Error).message });
    }

    completed++;
    if (completed % 10 === 0 || completed === combinations.length) {
      onProgress?.(completed, combinations.length);
      logger.debug(`Grid search progress: ${completed}/${combinations.length} (${failed} failed)`);
    }
  }

  if (results.length === 0) {
    throw new Error("All parameter combinations failed. Check your strategy and data.");
  }

  // Rank results
  results.sort((a, b) => {
    switch (target) {
      case "sharpe": return b.metrics.sharpeRatio - a.metrics.sharpeRatio;
      case "profit": return b.metrics.totalReturnPercent - a.metrics.totalReturnPercent;
      case "drawdown": return a.metrics.maxDrawdownPercent - b.metrics.maxDrawdownPercent;
      default: return 0;
    }
  });

  results.forEach((r, i) => (r.rank = i + 1));

  logger.info(`Grid search complete: best ${target} = ${results[0]?.metrics.sharpeRatio.toFixed(4)}`);

  return results;
}

/**
 * Count total combinations without generating them (fast).
 */
export function countCombinations(paramSpace: ParameterSpace): number {
  let count = 1;
  for (const key of Object.keys(paramSpace)) {
    const param = paramSpace[key]!;
    if (param.step <= 0) return 0;
    const steps = Math.floor((param.max - param.min) / param.step) + 1;
    if (steps <= 0) return 0;
    count *= steps;
    if (count > MAX_COMBINATIONS * 10) return count; // Early exit for huge spaces
  }
  return count;
}

function generateCombinations(paramSpace: ParameterSpace): Record<string, number>[] {
  const keys = Object.keys(paramSpace);
  if (keys.length === 0) return [{}];

  const combinations: Record<string, number>[] = [];
  const firstKey = keys[0]!;
  const firstParam = paramSpace[firstKey]!;

  for (let value = firstParam.min; value <= firstParam.max + firstParam.step * 0.001; value += firstParam.step) {
    const valueRounded = Math.round(Math.min(value, firstParam.max) * 10000) / 10000;

    if (keys.length === 1) {
      combinations.push({ [firstKey]: valueRounded });
    } else {
      const restSpace: ParameterSpace = {};
      for (let i = 1; i < keys.length; i++) {
        restSpace[keys[i]!] = paramSpace[keys[i]!]!;
      }
      const restCombinations = generateCombinations(restSpace);
      for (const restComb of restCombinations) {
        combinations.push({ [firstKey]: valueRounded, ...restComb });
      }
    }
  }

  return combinations;
}

function applyParameters(config: BacktestConfig, params: Record<string, number>): BacktestConfig {
  return {
    ...config,
    strategy: {
      ...config.strategy,
      config: { ...(config.strategy as any)?.config, ...params },
    } as any,
  };
}