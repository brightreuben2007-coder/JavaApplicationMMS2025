import { BacktestEngine, type BacktestConfig, type BacktestResult } from "../engine";
import type { ParameterSpace, OptimizationResult } from "./gridSearch";
import { logger } from "../utils/logger";

interface Individual {
  params: Record<string, number>;
  fitness: number;
}

/**
 * Genetic Algorithm Optimization.
 * Tournament selection, single-point crossover, mutation.
 */
export async function geneticOptimization(
  engine: BacktestEngine,
  baseConfig: BacktestConfig,
  paramSpace: ParameterSpace,
  target: "sharpe" | "profit" | "drawdown" = "sharpe",
  options?: {
    populationSize?: number;
    generations?: number;
    mutationRate?: number;
    elitismCount?: number;
  }
): Promise<OptimizationResult[]> {
  const popSize = options?.populationSize || 50;
  const generations = options?.generations || 20;
  const mutationRate = options?.mutationRate || 0.1;
  const elitismCount = options?.elitismCount || 3;

  // Generate initial population
  let population: Individual[] = [];
  const keys = Object.keys(paramSpace);

  for (let i = 0; i < popSize; i++) {
    const params: Record<string, number> = {};
    for (const key of keys) {
      const param = paramSpace[key]!;
      params[key] = param.min + Math.random() * (param.max - param.min);
    }
    population.push({ params, fitness: 0 });
  }

  // Evaluate initial population
  population = await evaluatePopulation(engine, baseConfig, population, target);

  logger.info(`Genetic optimization: ${generations} generations, ${popSize} population`);

  for (let gen = 0; gen < generations; gen++) {
    const newPopulation: Individual[] = [];

    // Elitism: keep best individuals
    const sorted = [...population].sort((a, b) => b.fitness - a.fitness);
    newPopulation.push(...sorted.slice(0, elitismCount));

    // Create rest via crossover + mutation
    while (newPopulation.length < popSize) {
      const parent1 = tournamentSelect(population, 3);
      const parent2 = tournamentSelect(population, 3);
      let child = singlePointCrossover(parent1, parent2);
      child = mutate(child, paramSpace, mutationRate);
      newPopulation.push(child);
    }

    // Evaluate new population
    population = await evaluatePopulation(engine, baseConfig, newPopulation, target);

    logger.debug(`Generation ${gen + 1}/${generations}: best fitness ${sorted[0]?.fitness.toFixed(4)}`);
  }

  // Return results sorted by fitness
  const results = await evaluatePopulation(engine, baseConfig, population, target);
  const finalResults: OptimizationResult[] = [];

  for (const indiv of results.sort((a, b) => b.fitness - a.fitness)) {
    finalResults.push({
      params: indiv.params,
      metrics: {} as any, // Would need to run full backtest
      rank: finalResults.length + 1,
    });
  }

  return finalResults;
}

async function evaluatePopulation(
  engine: BacktestEngine,
  baseConfig: BacktestConfig,
  population: Individual[],
  target: string
): Promise<Individual[]> {
  const evaluated: Individual[] = [];

  for (const indiv of population) {
    try {
      const config = {
        ...baseConfig,
        strategy: { ...baseConfig.strategy, config: indiv.params } as any,
      };
      const result = await engine.run(config);

      indiv.fitness = target === "sharpe"
        ? result.metrics.sharpeRatio
        : target === "profit"
        ? result.metrics.totalReturnPercent
        : -result.metrics.maxDrawdownPercent;

      evaluated.push(indiv);
    } catch {
      evaluated.push({ ...indiv, fitness: -Infinity });
    }
  }

  return evaluated;
}

function tournamentSelect(population: Individual[], tournamentSize: number): Individual {
  let best: Individual | null = null;
  for (let i = 0; i < tournamentSize; i++) {
    const candidate = population[Math.floor(Math.random() * population.length)]!;
    if (!best || candidate.fitness > best.fitness) {
      best = candidate;
    }
  }
  return best!;
}

function singlePointCrossover(parent1: Individual, parent2: Individual): Individual {
  const keys = Object.keys(parent1.params);
  if (keys.length === 0) return { ...parent1 };

  const crossPoint = Math.floor(Math.random() * keys.length);
  const params: Record<string, number> = {};

  for (let i = 0; i < keys.length; i++) {
    const key = keys[i]!;
    params[key] = i < crossPoint ? parent1.params[key]! : parent2.params[key]!;
  }

  return { params, fitness: 0 };
}

function mutate(individual: Individual, paramSpace: ParameterSpace, rate: number): Individual {
  const params = { ...individual.params };

  for (const key of Object.keys(params)) {
    if (Math.random() < rate) {
      const param = paramSpace[key]!;
      const range = param.max - param.min;
      params[key] = param.min + Math.random() * range;
    }
  }

  return { params, fitness: 0 };
}