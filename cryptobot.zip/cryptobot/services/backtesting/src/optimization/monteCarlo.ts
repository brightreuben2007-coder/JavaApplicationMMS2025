import type { BacktestTrade } from "../engine";

interface MonteCarloResult {
  percentile5: number;
  percentile50: number;
  percentile95: number;
  mean: number;
  stdDev: number;
  min: number;
  max: number;
  maxDrawdown: { percentile5: number; percentile50: number; percentile95: number };
  equityCurves: number[][];
}

/**
 * Calculate max drawdown from an equity curve.
 */
function calculateDrawdown(equityCurve: number[]): { maxDrawdown: number; maxDrawdownPercent: number } {
  let peak = equityCurve[0] || 0;
  let maxDd = 0;
  let maxDdPercent = 0;

  for (const equity of equityCurve) {
    if (equity > peak) peak = equity;
    const dd = peak - equity;
    const ddPercent = peak > 0 ? (dd / peak) * 100 : 0;
    if (dd > maxDd) maxDd = dd;
    if (ddPercent > maxDdPercent) maxDdPercent = ddPercent;
  }

  return { maxDrawdown: maxDd, maxDrawdownPercent: maxDdPercent };
}

/**
 * Monte Carlo Simulation.
 * Randomizes trade sequences using Fisher-Yates shuffle
 * to estimate the distribution of possible outcomes.
 */
export function monteCarloSimulation(
  trades: BacktestTrade[],
  iterations: number = 1000
): MonteCarloResult {
  if (trades.length < 2) {
    return {
      percentile5: 0,
      percentile50: 0,
      percentile95: 0,
      mean: 0,
      stdDev: 0,
      min: 0,
      max: 0,
      maxDrawdown: { percentile5: 0, percentile50: 0, percentile95: 0 },
      equityCurves: [],
    };
  }

  const finalEquities: number[] = [];
  const maxDrawdowns: number[] = [];
  const equityCurves: number[][] = [];

  // Validate all trades have required fields
  const validTrades = trades.filter(
    (t) => typeof t.pnl === "number" && !isNaN(t.pnl)
  );

  if (validTrades.length < 2) {
    throw new Error("Not enough valid trades for Monte Carlo simulation");
  }

  for (let i = 0; i < iterations; i++) {
    // Fisher-Yates shuffle
    const shuffled = [...validTrades];
    for (let j = shuffled.length - 1; j > 0; j--) {
      const k = Math.floor(Math.random() * (j + 1));
      [shuffled[j], shuffled[k]] = [shuffled[k]!, shuffled[j]!];
    }

    // Calculate equity curve from shuffled trades
    const curve: number[] = [10000];
    for (const trade of shuffled) {
      const lastEquity = curve[curve.length - 1] || 10000;
      const newEquity = Math.max(0, lastEquity + trade.pnl); // Floor at 0
      curve.push(newEquity);
    }

    const finalEquity = curve[curve.length - 1] || 10000;
    finalEquities.push(finalEquity);
    const { maxDrawdownPercent } = calculateDrawdown(curve);
    maxDrawdowns.push(maxDrawdownPercent);
    equityCurves.push(curve);
  }

  // Sort for percentiles
  finalEquities.sort((a, b) => a - b);
  maxDrawdowns.sort((a, b) => a - b);

  const n = iterations;
  const idx5 = Math.max(0, Math.floor(n * 0.05));
  const idx50 = Math.floor(n * 0.5);
  const idx95 = Math.min(n - 1, Math.floor(n * 0.95));

  const mean = finalEquities.reduce((s, e) => s + e, 0) / n;
  const variance = finalEquities.reduce((s, e) => s + (e - mean) ** 2, 0) / n;
  const stdDev = Math.sqrt(variance);

  return {
    percentile5: finalEquities[idx5] || 0,
    percentile50: finalEquities[idx50] || 0,
    percentile95: finalEquities[idx95] || 0,
    mean,
    stdDev,
    min: finalEquities[0] || 0,
    max: finalEquities[n - 1] || 0,
    maxDrawdown: {
      percentile5: maxDrawdowns[idx5] || 0,
      percentile50: maxDrawdowns[idx50] || 0,
      percentile95: maxDrawdowns[idx95] || 0,
    },
    equityCurves,
  };
}