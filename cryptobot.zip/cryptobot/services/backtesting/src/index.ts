import dotenv from "dotenv";
dotenv.config();

import express from "express";
import helmet from "helmet";
import promClient from "prom-client";
import Redis from "ioredis";
import { BacktestEngine, type BacktestConfig, type BacktestStrategy } from "./engine";
import { DataLoader } from "./dataLoader";
import { gridSearch } from "./optimization/gridSearch";
import { geneticOptimization } from "./optimization/genetic";
import { monteCarloSimulation } from "./optimization/monteCarlo";
import { generatePDFReport } from "./report/pdfExport";
import { logger } from "./utils/logger";

const app = express();
const PORT = parseInt(process.env.PORT || "3005", 10);
const REDIS_URL = process.env.REDIS_URL || "redis://localhost:6379";

const register = new promClient.Registry();
promClient.collectDefaultMetrics({ register, prefix: "backtesting_" });

const backtestCounter = new promClient.Counter({
  name: "backtesting_runs_total",
  help: "Total number of backtests run",
  registers: [register],
});

const engine = new BacktestEngine();
const dataLoader = new DataLoader();
const redis = new Redis(REDIS_URL, { maxRetriesPerRequest: 3 });

app.use(helmet());
app.use(express.json({ limit: "10mb" }));

app.get("/health", (_req, res) => {
  res.json({ status: "healthy", service: "backtesting", uptime: process.uptime() });
});

app.get("/metrics", async (_req, res) => {
  res.set("Content-Type", register.contentType);
  res.end(await register.metrics());
});

// Process backtest jobs from Redis queue
async function processBacktestJob(jobData: any): Promise<void> {
  try {
    const { jobId, userId, strategy, config } = jobData;

    logger.info(`Processing backtest job ${jobId}`);

    const backtestConfig: BacktestConfig = {
      pair: config.pair,
      exchange: config.exchange,
      timeframe: config.timeframe,
      startDate: new Date(config.dateStart),
      endDate: new Date(config.dateEnd),
      initialBalance: config.initialBalance || 10000,
      strategy: strategy as BacktestStrategy,
    };

    const result = await engine.run(backtestConfig);
    backtestCounter.inc();

    await redis.setex(
      `backtest:job:${jobId}`,
      3600,
      JSON.stringify({ ...result, status: "completed" })
    );

    logger.info(`Backtest job ${jobId} completed: ${result.metrics.totalReturnPercent.toFixed(2)}%`);
  } catch (error) {
    logger.error(`Backtest job failed`, { jobId: jobData.jobId, error });
    await redis.setex(
      `backtest:job:${jobData.jobId}`,
      3600,
      JSON.stringify({ status: "failed", error: (error as Error).message })
    );
  }
}

// Poll for backtest jobs
async function pollJobs(): Promise<void> {
  while (true) {
    try {
      const job = await redis.rpop("backtest:queue");
      if (job) {
        await processBacktestJob(JSON.parse(job));
      }
    } catch (error) {
      logger.error("Job polling error", { error });
    }
    await new Promise((resolve) => setTimeout(resolve, 1000));
  }
}

// Start
app.listen(PORT, () => {
  logger.info(`Backtesting Engine started on port ${PORT}`);
  pollJobs().catch((err) => logger.error("Job polling failed", { error: err }));
});

process.on("SIGTERM", async () => {
  await redis.quit();
  process.exit(0);
});