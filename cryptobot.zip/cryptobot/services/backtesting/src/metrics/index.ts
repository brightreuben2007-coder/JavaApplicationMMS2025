import type { BacktestTrade, BacktestMetrics } from "../engine";

export function calculateSharpeRatio(returns: number[], riskFreeRate: number = 0): number {
  if (returns.length < 2) return 0;
  const avgReturn = returns.reduce((s, r) => s + r, 0) / returns.length;
  const excessReturns = returns.map((r) => r - riskFreeRate);
  const stdDev = Math.sqrt(
    excessReturns.reduce((s, r) => s + r * r, 0) / excessReturns.length
  );
  return stdDev > 0 ? (avgReturn / stdDev) * Math.sqrt(365) : 0;
}

export function calculateSortinoRatio(returns: number[], riskFreeRate: number = 0): number {
  if (returns.length < 2) return 0;
  const avgReturn = returns.reduce((s, r) => s + r, 0) / returns.length;
  const downside = returns.filter((r) => r < 0);
  if (downside.length === 0) return avgReturn > 0 ? Infinity : 0;
  const downsideStd = Math.sqrt(
    downside.reduce((s, r) => s + r * r, 0) / downside.length
  );
  return downsideStd > 0 ? (avgReturn / downsideStd) * Math.sqrt(365) : 0;
}

export function calculateMaxDrawdown(equityCurve: number[]): { maxDrawdown: number; maxDrawdownPercent: number } {
  let peak = equityCurve[0] || 0;
  let maxDd = 0;
  let maxDdPercent = 0;

  for (const equity of equityCurve) {
    if (equity > peak) peak = equity;
    const dd = peak - equity;
    const ddPercent = peak > 0 ? (dd / peak) * 100 : 0;
    if (dd > maxDd) maxDd = dd;
    if (ddPercent > maxDdPercent) maxDdPercent = ddPercent;
  }

  return { maxDrawdown: maxDd, maxDrawdownPercent: maxDdPercent };
}

export function calculateProfitFactor(trades: BacktestTrade[]): number {
  const grossProfit = trades.filter((t) => t.pnl > 0).reduce((s, t) => s + t.pnl, 0);
  const grossLoss = Math.abs(trades.filter((t) => t.pnl < 0).reduce((s, t) => s + t.pnl, 0));
  return grossLoss > 0 ? grossProfit / grossLoss : grossProfit > 0 ? Infinity : 0;
}

export function calculateWinRate(trades: BacktestTrade[]): number {
  if (trades.length === 0) return 0;
  return (trades.filter((t) => t.pnl > 0).length / trades.length) * 100;
}

export function calculateCalmarRatio(totalReturn: number, maxDrawdown: number): number {
  return maxDrawdown > 0 ? totalReturn / maxDrawdown : totalReturn > 0 ? Infinity : 0;
}

export function calculateMAE(trades: BacktestTrade[], equityCurve: number[]): number {
  // Maximum Adverse Excursion — max unrealized loss during each trade
  // Simplified: max drawdown during the backtest
  const { maxDrawdown } = calculateMaxDrawdown(equityCurve);
  return maxDrawdown;
}

export function calculateMFE(trades: BacktestTrade[], equityCurve: number[]): number {
  // Maximum Favorable Excursion — max unrealized profit during each trade
  let peak = equityCurve[0] || 0;
  let maxMfe = 0;

  for (const equity of equityCurve) {
    if (equity > peak) {
      const mfe = equity - peak;
      if (mfe > maxMfe) maxMfe = mfe;
    }
    if (equity < peak * 0.9) {
      peak = equity;
    }
  }

  return maxMfe;
}

export function calculateOmegaRatio(returns: number[], threshold: number = 0): number {
  if (returns.length === 0) return 1;
  const gains = returns.filter((r) => r > threshold).reduce((s, r) => s + (r - threshold), 0);
  const losses = Math.abs(
    returns.filter((r) => r < threshold).reduce((s, r) => s + (r - threshold), 0)
  );
  return losses > 0 ? gains / losses : gains > 0 ? Infinity : 1;
}