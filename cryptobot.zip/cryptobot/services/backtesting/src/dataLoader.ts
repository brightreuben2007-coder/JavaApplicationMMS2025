import ccxt from "ccxt";
import { logger } from "./utils/logger";

export interface OHLCV {
  timestamp: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

interface CacheEntry {
  data: OHLCV[];
  expiresAt: number;
}

/**
 * Data Loader for backtesting.
 * Fetches historical OHLCV data from exchanges or imports from CSV.
 * Uses TTL-based cache to prevent memory leaks.
 */
export class DataLoader {
  private cache: Map<string, CacheEntry> = new Map();
  private exchangeInstances: Map<string, any> = new Map();
  private defaultTTL: number = 30 * 60 * 1000; // 30 minutes
  private maxCacheSize: number = 100;

  /**
   * Get or create an exchange instance.
   */
  private getExchange(exchangeId: string): any {
    if (this.exchangeInstances.has(exchangeId)) {
      return this.exchangeInstances.get(exchangeId);
    }

    const ExchangeClass = (ccxt as any)[exchangeId];
    if (!ExchangeClass) {
      throw new Error(`Exchange ${exchangeId} not supported by ccxt. Available: ${ccxt.exchanges.slice(0, 20).join(", ")}...`);
    }

    const exchange = new ExchangeClass({
      enableRateLimit: true,
      timeout: 30000,
    });

    this.exchangeInstances.set(exchangeId, exchange);
    return exchange;
  }

  /**
   * Fetch historical OHLCV data from an exchange.
   * Uses pagination to handle large requests.
   */
  async fetchOHLCV(
    exchangeId: string,
    pair: string,
    timeframe: string,
    since: number,
    limit: number = 1000
  ): Promise<OHLCV[]> {
    const cacheKey = `${exchangeId}:${pair}:${timeframe}:${since}:${limit}`;

    // Check cache
    const cached = this.cache.get(cacheKey);
    if (cached && Date.now() < cached.expiresAt) {
      logger.debug(`Cache hit for ${cacheKey}`);
      return cached.data;
    }

    const exchange = this.getExchange(exchangeId);

    try {
      let allCandles: any[] = [];
      let fetchSince = since;
      let remaining = Math.min(limit, 10000); // Hard cap at 10k candles
      let fetchLimit = Math.min(remaining, 1000);
      let retries = 0;
      const maxRetries = 3;

      while (remaining > 0) {
        try {
          const candles = await exchange.fetchOHLCV(pair, timeframe, fetchSince, fetchLimit);

          if (candles.length === 0) break;

          allCandles = allCandles.concat(candles);

          if (candles.length < fetchLimit) break;

          fetchSince = candles[candles.length - 1][0] + 1;
          remaining -= candles.length;
          fetchLimit = Math.min(remaining, 1000);
          retries = 0;

          // Respect exchange rate limits
          await new Promise((resolve) => setTimeout(resolve, exchange.rateLimit || 1000));
        } catch (error) {
          retries++;
          if (retries >= maxRetries) {
            logger.error(`Failed to fetch OHLCV after ${maxRetries} retries`);
            throw error;
          }
          logger.warn(`Retry ${retries}/${maxRetries} for OHLCV fetch`);
          await new Promise((resolve) => setTimeout(resolve, 2000 * retries));
        }
      }

      const ohlcv: OHLCV[] = allCandles.map((c: any) => ({
        timestamp: c[0],
        open: c[1],
        high: c[2],
        low: c[3],
        close: c[4],
        volume: c[5],
      }));

      // Evict oldest entries if cache is full
      if (this.cache.size >= this.maxCacheSize) {
        const oldestKey = Array.from(this.cache.entries())
          .sort(([, a], [, b]) => a.expiresAt - b.expiresAt)[0]?.[0];
        if (oldestKey) this.cache.delete(oldestKey);
        logger.debug(`Cache eviction: removed ${oldestKey}`);
      }

      // Store with TTL
      this.cache.set(cacheKey, {
        data: ohlcv,
        expiresAt: Date.now() + this.defaultTTL,
      });

      logger.info(`Fetched ${ohlcv.length} candles for ${pair} on ${exchangeId}`);
      return ohlcv;
    } catch (error) {
      logger.error(`Failed to fetch OHLCV for ${pair} on ${exchangeId}`, { error });
      throw error;
    }
  }

  /**
   * Parse OHLCV data from CSV string.
   * Expected format: timestamp,open,high,low,close,volume
   * Accepts Unix ms timestamps or ISO 8601 dates.
   */
  parseCSV(csv: string): OHLCV[] {
    const lines = csv.trim().split("\n");
    const candles: OHLCV[] = [];

    for (let i = 0; i < lines.length; i++) {
      const line = lines[i]?.trim();
      if (!line || line.startsWith("#") || line.toLowerCase().startsWith("timestamp")) continue;

      const parts = line.split(",");
      if (parts.length < 6) continue;

      const timestamp = parts[0]?.trim() || "0";
      const ts = isNaN(Number(timestamp)) ? Date.parse(timestamp) : parseInt(timestamp);

      if (isNaN(ts)) continue;

      candles.push({
        timestamp: ts,
        open: parseFloat(parts[1]?.trim() || "0"),
        high: parseFloat(parts[2]?.trim() || "0"),
        low: parseFloat(parts[3]?.trim() || "0"),
        close: parseFloat(parts[4]?.trim() || "0"),
        volume: parseFloat(parts[5]?.trim() || "0"),
      });
    }

    if (candles.length === 0) {
      throw new Error("No valid candles found in CSV data");
    }

    return candles.sort((a, b) => a.timestamp - b.timestamp);
  }

  /**
   * Generate synthetic OHLCV data for testing.
   * Uses geometric Brownian motion with configurable parameters.
   */
  generateSynthetic(
    count: number = 1000,
    startPrice: number = 100,
    volatility: number = 0.02,
    trend: number = 0.0001
  ): OHLCV[] {
    if (count <= 0) throw new Error("Count must be positive");
    if (startPrice <= 0) throw new Error("Start price must be positive");

    const candles: OHLCV[] = [];
    let price = startPrice;
    const now = Date.now();
    const interval = 3600000; // 1h

    for (let i = 0; i < count; i++) {
      // Geometric Brownian motion
      const drift = trend - 0.5 * volatility * volatility;
      const shock = volatility * (Math.random() * 2 - 1) * Math.sqrt(1 / 365);
      const change = drift + shock;
      const open = price;
      const close = open * Math.exp(change);
      const high = Math.max(open, close) * (1 + Math.random() * volatility * 0.5);
      const low = Math.min(open, close) * (1 - Math.random() * volatility * 0.5);
      const volume = Math.exp(Math.random() * 5) * 10; // Log-normal volume

      candles.push({
        timestamp: now + i * interval,
        open: Math.round(open * 100) / 100,
        high: Math.round(high * 100) / 100,
        low: Math.round(low * 100) / 100,
        close: Math.round(close * 100) / 100,
        volume: Math.round(volume * 100) / 100,
      });

      price = close;
    }

    return candles;
  }

  /**
   * Clear all cached data.
   */
  clearCache(): void {
    const size = this.cache.size;
    this.cache.clear();
    logger.info(`Cache cleared: ${size} entries removed`);
  }

  /**
   * Get cache statistics.
   */
  getCacheStats(): { size: number; maxSize: number; entries: { key: string; age: number }[] } {
    const now = Date.now();
    return {
      size: this.cache.size,
      maxSize: this.maxCacheSize,
      entries: Array.from(this.cache.entries()).map(([key, entry]) => ({
        key,
        age: Math.round((now - (entry.expiresAt - this.defaultTTL)) / 1000),
      })),
    };
  }

  /**
   * Set cache TTL in milliseconds.
   */
  setCacheTTL(ttlMs: number): void {
    this.defaultTTL = ttlMs;
  }
}