import type { OHLCV } from "./dataLoader";

export interface OrderRequest {
  side: "buy" | "sell";
  type: "market" | "limit";
  quantity: number;
  price?: number;
}

export interface FillResult {
  filled: boolean;
  quantity: number;
  price: number;
  fee: number;
  slippage: number;
  timestamp: number;
}

/**
 * Fill Model for backtesting.
 * Simulates order execution against historical OHLCV data.
 */
export class FillModel {
  private makerFee: number;
  private takerFee: number;
  private slippageModel: "fixed" | "volume" | "spread";
  private slippagePercent: number;
  private latencyMs: number;

  constructor(config?: {
    makerFee?: number;
    takerFee?: number;
    slippageModel?: "fixed" | "volume" | "spread";
    slippagePercent?: number;
    latencyMs?: number;
  }) {
    this.makerFee = config?.makerFee ?? 0.001;
    this.takerFee = config?.takerFee ?? 0.001;
    this.slippageModel = config?.slippageModel ?? "fixed";
    this.slippagePercent = config?.slippagePercent ?? 0.1;
    this.latencyMs = config?.latencyMs ?? 0;
  }

  /**
   * Simulate order fill against a candle.
   */
  simulateFill(order: OrderRequest, candle: OHLCV): FillResult {
    const executionPrice = this.getExecutionPrice(order, candle);
    const slipPrice = this.applySlippage(executionPrice, order.side, candle);
    const isMaker = this.isMakerOrder(order, executionPrice, candle);

    const fee = order.quantity * slipPrice * (isMaker ? this.makerFee : this.takerFee);

    return {
      filled: true,
      quantity: order.quantity,
      price: slipPrice,
      fee,
      slippage: Math.abs(slipPrice - executionPrice) / executionPrice * 100,
      timestamp: candle.timestamp + this.latencyMs,
    };
  }

  /**
   * Check if the order would have filled based on candle OHLCV.
   */
  wouldFill(order: OrderRequest, candle: OHLCV): boolean {
    if (order.type === "market") {
      return candle.volume > 0;
    }

    if (!order.price) return false;

    if (order.side === "buy") {
      // Buy limit: fills if price dropped to or below our limit
      return candle.low <= order.price;
    } else {
      // Sell limit: fills if price rose to or above our limit
      return candle.high >= order.price;
    }
  }

  /**
   * Get the execution price for an order.
   * Market orders fill at open (simplified).
   * Limit orders fill at the limit price or better.
   */
  private getExecutionPrice(order: OrderRequest, candle: OHLCV): number {
    if (order.type === "market") {
      return candle.open;
    }

    return order.price || candle.open;
  }

  /**
   * Apply slippage to the execution price.
   */
  private applySlippage(price: number, side: "buy" | "sell", candle: OHLCV): number {
    switch (this.slippageModel) {
      case "fixed":
        return side === "buy"
          ? price * (1 + this.slippagePercent / 100)
          : price * (1 - this.slippagePercent / 100);

      case "volume": {
        // More volume = less slippage
        const volumeFactor = Math.max(0.1, Math.min(1, 1000000 / (candle.volume * price)));
        const volSlippage = this.slippagePercent * volumeFactor / 100;
        return side === "buy"
          ? price * (1 + volSlippage)
          : price * (1 - volSlippage);
      }

      case "spread": {
        // Simulated spread
        const spread = (candle.high - candle.low) / candle.open * 0.1;
        return side === "buy"
          ? price * (1 + spread)
          : price * (1 - spread);
      }

      default:
        return price;
    }
  }

  /**
   * Determine if the order is a maker order.
   * Limit orders that don't cross the spread are maker orders.
   */
  private isMakerOrder(order: OrderRequest, executionPrice: number, candle: OHLCV): boolean {
    if (order.type === "market") return false;

    // Simplified: if the order price is not immediately marketable
    const midPrice = (candle.high + candle.low) / 2;

    if (order.side === "buy") {
      return (order.price || 0) < candle.open;
    } else {
      return (order.price || 0) > candle.open;
    }
  }
}