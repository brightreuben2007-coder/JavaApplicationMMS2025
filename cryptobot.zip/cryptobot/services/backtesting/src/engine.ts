import { EventEmitter } from "node:events";
import { DataLoader, type OHLCV } from "./dataLoader";
import { FillModel, type OrderRequest, type FillResult } from "./fillModel";
import { logger } from "./utils/logger";

export interface BacktestConfig {
  pair: string;
  exchange: string;
  timeframe: string;
  startDate: Date;
  endDate: Date;
  initialBalance: number;
  strategy: BacktestStrategy;
  makerFee?: number;
  takerFee?: number;
  slippagePercent?: number;
}

export interface BacktestResult {
  config: BacktestConfig;
  metrics: BacktestMetrics;
  equityCurve: { timestamp: number; equity: number }[];
  trades: BacktestTrade[];
  monthlyReturns: Record<string, number>;
  pairBreakdown: Record<string, { trades: number; pnl: number }>;
}

export interface BacktestMetrics {
  totalReturn: number;
  totalReturnPercent: number;
  sharpeRatio: number;
  sortinoRatio: number;
  calmarRatio: number;
  maxDrawdown: number;
  maxDrawdownPercent: number;
  winRate: number;
  profitFactor: number;
  totalTrades: number;
  winningTrades: number;
  losingTrades: number;
  avgWin: number;
  avgLoss: number;
  largestWin: number;
  largestLoss: number;
  avgTradeDurationMs: number;
  expectancy: number;
}

export interface BacktestTrade {
  entryTimestamp: number;
  exitTimestamp: number;
  entryPrice: number;
  exitPrice: number;
  quantity: number;
  side: "buy" | "sell";
  pnl: number;
  pnlPercent: number;
  exitReason: string;
}

export interface BacktestStrategy {
  name: string;
  onCandle: (candle: OHLCV, state: StrategyState) => StrategyAction[];
}

export interface StrategyState {
  balance: number;
  position: number;
  entryPrice: number;
  entryTimestamp: number;
  trades: BacktestTrade[];
  currentCandle: number;
  metadata?: Record<string, any>; // Strategy can store arbitrary state
}

export type StrategyAction =
  | { type: "buy"; quantity: number; price?: number; reason?: string }
  | { type: "sell"; quantity: number; price?: number; reason?: string }
  | { type: "hold" };

/**
 * Backtesting Engine.
 * Runs strategies against historical OHLCV data and calculates performance metrics.
 */
export class BacktestEngine extends EventEmitter {
  private dataLoader: DataLoader;
  private fillModel: FillModel;

  constructor() {
    super();
    this.dataLoader = new DataLoader();
    this.fillModel = new FillModel();
  }

  /**
   * Run a backtest.
   */
  async run(config: BacktestConfig): Promise<BacktestResult> {
    logger.info(`Starting backtest for ${config.pair} on ${config.exchange}`);

    // Configure fill model with fee/slippage from config
    this.fillModel = new FillModel({
      makerFee: config.makerFee ?? 0.001,
      takerFee: config.takerFee ?? 0.001,
      slippagePercent: config.slippagePercent ?? 0.1,
    });

    // Load data
    const candles = await this.loadData(config);
    if (candles.length < 10) {
      throw new Error(`Insufficient data: only ${candles.length} candles available for ${config.pair}`);
    }

    logger.info(`Loaded ${candles.length} candles for ${config.pair} (${config.timeframe})`);

    // Initialize state — this is the MUTABLE state passed to the strategy
    const state: StrategyState = {
      balance: config.initialBalance,
      position: 0,
      entryPrice: 0,
      entryTimestamp: 0,
      trades: [],
      currentCandle: 0,
      metadata: {},
    };

    const equityCurve: { timestamp: number; equity: number }[] = [];
    let peakEquity = config.initialBalance;
    let maxDrawdown = 0;

    // Run simulation
    for (let i = 0; i < candles.length; i++) {
      const candle = candles[i]!;
      state.currentCandle = i;

      // Call strategy — passes mutable state by reference now
      const actions = config.strategy.onCandle(candle, state);

      if (!Array.isArray(actions)) {
        logger.warn(`Strategy returned non-array actions at candle ${i}, skipping`);
        continue;
      }

      for (const action of actions) {
        if (!action || action.type === "hold") continue;

        if (action.type !== "buy" && action.type !== "sell") {
          logger.warn(`Unknown action type: ${(action as any)?.type}`);
          continue;
        }

        if (!action.quantity || action.quantity <= 0) {
          logger.warn(`Invalid quantity: ${action.quantity}`);
          continue;
        }

        const order: OrderRequest = {
          side: action.type,
          type: action.price ? "limit" : "market",
          quantity: action.quantity,
          price: action.price,
        };

        // Check if order would fill
        if (!this.fillModel.wouldFill(order, candle)) continue;

        const fill = this.fillModel.simulateFill(order, candle);

        if (action.type === "buy") {
          const cost = fill.price * fill.quantity + fill.fee;

          if (state.balance >= cost) {
            const prevPosition = state.position;
            state.balance -= cost;
            state.position += fill.quantity;

            // Weighted average entry price
            if (prevPosition === 0) {
              state.entryPrice = fill.price;
              state.entryTimestamp = candle.timestamp;
            } else {
              const totalCost = state.entryPrice * prevPosition + fill.price * fill.quantity;
              state.entryPrice = totalCost / state.position;
            }
          }
        } else {
          // Sell
          const sellQuantity = Math.min(fill.quantity, state.position);

          if (sellQuantity <= 0) continue;

          const proceeds = fill.price * sellQuantity - fill.fee;
          const costBasis = state.entryPrice * sellQuantity;
          const pnl = proceeds - costBasis;
          const pnlPercent = costBasis > 0 ? (pnl / costBasis) * 100 : 0;

          state.balance += proceeds;
          state.position -= sellQuantity;

          // Record trade
          state.trades.push({
            entryTimestamp: state.entryTimestamp,
            exitTimestamp: candle.timestamp,
            entryPrice: state.entryPrice,
            exitPrice: fill.price,
            quantity: sellQuantity,
            side: "sell",
            pnl: Math.round(pnl * 100) / 100,
            pnlPercent: Math.round(pnlPercent * 100) / 100,
            exitReason: action.reason || "Signal",
          });

          // Reset entry if position fully closed
          if (state.position <= 0) {
            state.position = 0;
            state.entryPrice = 0;
            state.entryTimestamp = 0;
          }
        }
      }

      // Calculate current equity
      const currentPrice = candle.close;
      const unrealizedPnl = state.position > 0
        ? (currentPrice - state.entryPrice) * state.position
        : 0;
      const equity = state.balance + state.position * currentPrice;

      equityCurve.push({
        timestamp: candle.timestamp,
        equity: Math.round(equity * 100) / 100,
      });

      // Track drawdown
      if (equity > peakEquity) peakEquity = equity;
      const drawdown = peakEquity > 0 ? (peakEquity - equity) / peakEquity : 0;
      if (drawdown > maxDrawdown) maxDrawdown = drawdown;
    }

    // Close any open position at the last price
    const lastCandle = candles[candles.length - 1]!;
    if (state.position > 0) {
      const closeProceeds = lastCandle.close * state.position;
      const costBasis = state.entryPrice * state.position;
      const closePnl = closeProceeds - costBasis;

      state.balance += closeProceeds;
      state.trades.push({
        entryTimestamp: state.entryTimestamp,
        exitTimestamp: lastCandle.timestamp,
        entryPrice: state.entryPrice,
        exitPrice: lastCandle.close,
        quantity: state.position,
        side: "sell",
        pnl: Math.round(closePnl * 100) / 100,
        pnlPercent: state.entryPrice > 0 ? ((lastCandle.close - state.entryPrice) / state.entryPrice) * 100 : 0,
        exitReason: "End of backtest",
      });
      state.position = 0;
    }

    // Calculate metrics
    const metrics = this.calculateMetrics(state, config.initialBalance, maxDrawdown);
    const monthlyReturns = this.calculateMonthlyReturns(equityCurve);
    const pairBreakdown = this.calculatePairBreakdown(state.trades, config.pair);

    const result: BacktestResult = {
      config,
      metrics,
      equityCurve,
      trades: state.trades,
      monthlyReturns,
      pairBreakdown,
    };

    const returnStr = metrics.totalReturnPercent >= 0 ? "+" : "";
    logger.info(`Backtest complete: ${returnStr}${metrics.totalReturnPercent.toFixed(2)}% | Sharpe: ${metrics.sharpeRatio.toFixed(2)} | Trades: ${metrics.totalTrades}`);

    return result;
  }

  /**
   * Load historical OHLCV data.
   */
  private async loadData(config: BacktestConfig): Promise<OHLCV[]> {
    const since = config.startDate.getTime();
    const until = config.endDate.getTime();
    const estimatedCandles = Math.ceil((until - since) / this.timeframeMs(config.timeframe));

    return this.dataLoader.fetchOHLCV(
      config.exchange,
      config.pair,
      config.timeframe,
      since,
      Math.min(estimatedCandles, 10000)
    );
  }

  private timeframeMs(timeframe: string): number {
    const map: Record<string, number> = {
      "1m": 60000, "5m": 300000, "15m": 900000,
      "1h": 3600000, "4h": 14400000, "1d": 86400000, "1w": 604800000,
    };
    return map[timeframe] || 3600000;
  }

  /**
   * Calculate all backtest metrics.
   */
  private calculateMetrics(state: StrategyState, initialBalance: number, maxDrawdown: number): BacktestMetrics {
    const trades = state.trades;
    const winningTrades = trades.filter((t) => t.pnl > 0);
    const losingTrades = trades.filter((t) => t.pnl < 0);
    const breakEvenTrades = trades.filter((t) => t.pnl === 0);

    const totalReturn = state.balance - initialBalance;
    const totalReturnPercent = (totalReturn / initialBalance) * 100;

    // Returns for ratio calculations
    const returns = trades
      .filter((t) => t.exitTimestamp > 0 && t.entryTimestamp > 0)
      .map((t) => t.pnlPercent);

    // Sharpe
    const avgReturn = returns.length > 0 ? returns.reduce((s, r) => s + r, 0) / returns.length : 0;
    const stdDevReturn = Math.sqrt(
      returns.length > 0 ? returns.reduce((s, r) => s + (r - avgReturn) ** 2, 0) / returns.length : 0
    );
    const sharpeRatio = stdDevReturn > 0 ? (avgReturn / stdDevReturn) * Math.sqrt(Math.max(trades.length, 1)) : 0;

    // Sortino
    const downsideReturns = returns.filter((r) => r < 0);
    const avgDownsideReturn = downsideReturns.length > 0
      ? Math.sqrt(downsideReturns.reduce((s, r) => s + r * r, 0) / downsideReturns.length)
      : 0;
    const sortinoRatio = avgDownsideReturn > 0 ? (avgReturn / avgDownsideReturn) * Math.sqrt(Math.max(trades.length, 1)) : 0;

    // Calmar
    const maxDrawdownPercent = maxDrawdown * 100;
    const calmarRatio = maxDrawdownPercent > 0 ? (totalReturnPercent / maxDrawdownPercent) * Math.sqrt(12) : 0;

    // Win rate (count break-even as half-win)
    const winRate = trades.length > 0
      ? ((winningTrades.length + breakEvenTrades.length * 0.5) / trades.length) * 100
      : 0;

    // Profit factor
    const grossProfit = winningTrades.reduce((s, t) => s + t.pnl, 0);
    const grossLoss = Math.abs(losingTrades.reduce((s, t) => s + t.pnl, 0));
    const profitFactor = grossLoss > 0 ? grossProfit / grossLoss : grossProfit > 0 ? Infinity : 0;

    // Averages
    const avgWin = winningTrades.length > 0 ? grossProfit / winningTrades.length : 0;
    const avgLoss = losingTrades.length > 0 ? grossLoss / losingTrades.length : 0;
    const largestWin = winningTrades.length > 0 ? Math.max(...winningTrades.map((t) => t.pnl)) : 0;
    const largestLoss = losingTrades.length > 0 ? Math.min(...losingTrades.map((t) => t.pnl)) : 0;

    // Average trade duration
    const durations = trades
      .filter((t) => t.exitTimestamp > t.entryTimestamp)
      .map((t) => t.exitTimestamp - t.entryTimestamp);
    const avgTradeDurationMs = durations.length > 0
      ? durations.reduce((s, d) => s + d, 0) / durations.length
      : 0;

    // Expectancy = (winRate * avgWin) - ((1 - winRate) * avgLoss)
    const expectancy = trades.length > 0
      ? (winRate / 100) * avgWin - (1 - winRate / 100) * avgLoss
      : 0;

    return {
      totalReturn: Math.round(totalReturn * 100) / 100,
      totalReturnPercent: Math.round(totalReturnPercent * 100) / 100,
      sharpeRatio: Math.round(sharpeRatio * 100) / 100,
      sortinoRatio: Math.round(sortinoRatio * 100) / 100,
      calmarRatio: Math.round(calmarRatio * 100) / 100,
      maxDrawdown: Math.round(maxDrawdown * initialBalance * 100) / 100,
      maxDrawdownPercent: Math.round(maxDrawdownPercent * 100) / 100,
      winRate: Math.round(winRate * 100) / 100,
      profitFactor: profitFactor === Infinity ? 999 : Math.round(profitFactor * 100) / 100,
      totalTrades: trades.length,
      winningTrades: winningTrades.length,
      losingTrades: losingTrades.length,
      avgWin: Math.round(avgWin * 100) / 100,
      avgLoss: Math.round(avgLoss * 100) / 100,
      largestWin: Math.round(largestWin * 100) / 100,
      largestLoss: Math.round(largestLoss * 100) / 100,
      avgTradeDurationMs,
      expectancy: Math.round(expectancy * 100) / 100,
    };
  }

  private calculateMonthlyReturns(equityCurve: { timestamp: number; equity: number }[]): Record<string, number> {
    const monthly: Record<string, number> = {};
    let monthStartEquity = equityCurve[0]?.equity || 0;
    let currentMonth = "";

    for (const point of equityCurve) {
      const date = new Date(point.timestamp);
      const monthKey = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}`;

      if (monthKey !== currentMonth) {
        if (currentMonth && monthStartEquity > 0) {
          const prevPoint = equityCurve[equityCurve.indexOf(point) - 1];
          const endEquity = prevPoint?.equity || monthStartEquity;
          monthly[currentMonth] = ((endEquity - monthStartEquity) / monthStartEquity) * 100;
        }
        currentMonth = monthKey;
        monthStartEquity = point.equity;
      }
    }

    // Last month
    if (currentMonth && monthStartEquity > 0) {
      const lastPoint = equityCurve[equityCurve.length - 1];
      if (lastPoint) {
        monthly[currentMonth] = ((lastPoint.equity - monthStartEquity) / monthStartEquity) * 100;
      }
    }

    return monthly;
  }

  private calculatePairBreakdown(
    trades: BacktestTrade[],
    pair: string
  ): Record<string, { trades: number; pnl: number }> {
    return {
      [pair]: {
        trades: trades.length,
        pnl: Math.round(trades.reduce((s, t) => s + t.pnl, 0) * 100) / 100,
      },
    };
  }

  /**
   * Run a quick backtest using synthetic data.
   */
  async runQuickBacktest(config: BacktestConfig & { candleCount?: number }): Promise<BacktestResult> {
    const candles = this.dataLoader.generateSynthetic(
      config.candleCount || 500,
      config.initialBalance * 0.01,
      0.02,
      0
    );

    const originalLoad = this.loadData.bind(this);
    this.loadData = async () => candles;

    const result = await this.run(config);
    this.loadData = originalLoad;
    return result;
  }
}