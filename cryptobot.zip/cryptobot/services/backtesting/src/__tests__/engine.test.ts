import { BacktestEngine, type BacktestStrategy } from "../engine";

const simpleMACrossover: BacktestStrategy = {
  name: "Simple MA Crossover",
  onCandle: (candle, state) => {
    // Buy if no position, sell if position exists
    if (state.position === 0) {
      return [{ type: "buy", quantity: 0.01, reason: "Signal" }];
    } else {
      const profit = state.entryPrice > 0
        ? ((candle.close - state.entryPrice) / state.entryPrice) * 100
        : 0;
      if (profit > 2 || profit < -5) {
        return [{ type: "sell", quantity: state.position, reason: "TP/SL" }];
      }
    }
    return [{ type: "hold" }];
  },
};

describe("Backtest Engine", () => {
  let engine: BacktestEngine;

  beforeEach(() => {
    engine = new BacktestEngine();
  });

  it("should run a backtest with synthetic data", async () => {
    const result = await engine.runQuickBacktest({
      pair: "BTC/USDT",
      exchange: "binance",
      timeframe: "1h",
      startDate: new Date(Date.now() - 30 * 24 * 3600000),
      endDate: new Date(),
      initialBalance: 10000,
      strategy: simpleMACrossover,
      candleCount: 200,
    });

    expect(result.trades.length).toBeGreaterThan(0);
    expect(result.metrics.totalReturnPercent).toBeDefined();
    expect(result.metrics.sharpeRatio).toBeDefined();
    expect(result.equityCurve.length).toBe(200);
  });

  it("should calculate valid metrics", async () => {
    const result = await engine.runQuickBacktest({
      pair: "ETH/USDT",
      exchange: "binance",
      timeframe: "4h",
      startDate: new Date(Date.now() - 90 * 24 * 3600000),
      endDate: new Date(),
      initialBalance: 5000,
      strategy: simpleMACrossover,
      candleCount: 100,
    });

    expect(result.metrics.totalTrades).toBeGreaterThan(0);
    expect(result.metrics.winRate).toBeGreaterThanOrEqual(0);
    expect(result.metrics.winRate).toBeLessThanOrEqual(100);
    expect(result.metrics.maxDrawdownPercent).toBeGreaterThanOrEqual(0);
    expect(result.metrics.profitFactor).toBeGreaterThan(0);
  });

  it("should generate monthly returns", async () => {
    const result = await engine.runQuickBacktest({
      pair: "BTC/USDT",
      exchange: "binance",
      timeframe: "1d",
      startDate: new Date("2024-01-01"),
      endDate: new Date("2024-06-01"),
      initialBalance: 10000,
      strategy: simpleMACrossover,
      candleCount: 150,
    });

    expect(Object.keys(result.monthlyReturns).length).toBeGreaterThan(0);
  });
});