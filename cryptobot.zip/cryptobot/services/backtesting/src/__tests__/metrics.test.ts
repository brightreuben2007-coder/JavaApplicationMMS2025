import {
  calculateSharpeRatio,
  calculateSortinoRatio,
  calculateMaxDrawdown,
  calculateProfitFactor,
  calculateWinRate,
} from "../metrics";

describe("Backtest Metrics", () => {
  describe("Sharpe Ratio", () => {
    it("should calculate positive Sharpe for profitable returns", () => {
      const returns = [0.01, 0.02, 0.015, 0.03, 0.01];
      const sharpe = calculateSharpeRatio(returns);
      expect(sharpe).toBeGreaterThan(0);
    });

    it("should return 0 for insufficient data", () => {
      expect(calculateSharpeRatio([])).toBe(0);
      expect(calculateSharpeRatio([0.01])).toBe(0);
    });
  });

  describe("Maximum Drawdown", () => {
    it("should calculate max drawdown", () => {
      const equity = [100, 110, 105, 95, 100, 120, 115];
      const { maxDrawdown, maxDrawdownPercent } = calculateMaxDrawdown(equity);
      expect(maxDrawdown).toBeGreaterThan(0);
      expect(maxDrawdownPercent).toBeGreaterThan(0);
    });

    it("should return 0 for rising equity", () => {
      const equity = [100, 110, 120, 130, 140];
      const { maxDrawdown } = calculateMaxDrawdown(equity);
      expect(maxDrawdown).toBe(0);
    });
  });

  describe("Profit Factor", () => {
    it("should be >1 for profitable strategy", () => {
      const trades = [
        { pnl: 100, pnlPercent: 1 } as any,
        { pnl: -50, pnlPercent: -0.5 } as any,
        { pnl: 200, pnlPercent: 2 } as any,
        { pnl: -30, pnlPercent: -0.3 } as any,
      ];
      expect(calculateProfitFactor(trades)).toBeGreaterThan(1);
    });

    it("should be Infinity for no losing trades", () => {
      const trades = [
        { pnl: 100, pnlPercent: 1 } as any,
        { pnl: 50, pnlPercent: 0.5 } as any,
      ];
      expect(calculateProfitFactor(trades)).toBe(Infinity);
    });
  });

  describe("Win Rate", () => {
    it("should calculate correctly", () => {
      const trades = [
        { pnl: 100, pnlPercent: 1 } as any,
        { pnl: -50, pnlPercent: -0.5 } as any,
        { pnl: 200, pnlPercent: 2 } as any,
        { pnl: -30, pnlPercent: -0.3 } as any,
      ];
      expect(calculateWinRate(trades)).toBe(50);
    });
  });
});