import { FillModel } from "../fillModel";

describe("Fill Model", () => {
  const fillModel = new FillModel({
    makerFee: 0.001,
    takerFee: 0.001,
    slippagePercent: 0.1,
  });

  const candle = {
    timestamp: 1700000000000,
    open: 50000,
    high: 51000,
    low: 49000,
    close: 50500,
    volume: 100,
  };

  it("should fill market buy order", () => {
    const fill = fillModel.simulateFill(
      { side: "buy", type: "market", quantity: 0.01 },
      candle
    );
    expect(fill.filled).toBe(true);
    expect(fill.quantity).toBe(0.01);
    expect(fill.price).toBeGreaterThan(0);
    expect(fill.fee).toBeGreaterThan(0);
  });

  it("should fill limit buy order if price touches", () => {
    const wouldFill = fillModel.wouldFill(
      { side: "buy", type: "limit", quantity: 0.01, price: 49500 },
      candle
    );
    expect(wouldFill).toBe(true);
  });

  it("should not fill limit buy if price too low", () => {
    const wouldFill = fillModel.wouldFill(
      { side: "buy", type: "limit", quantity: 0.01, price: 48000 },
      candle
    );
    expect(wouldFill).toBe(false);
  });

  it("should fill limit sell order if price touches", () => {
    const wouldFill = fillModel.wouldFill(
      { side: "sell", type: "limit", quantity: 0.01, price: 50500 },
      candle
    );
    expect(wouldFill).toBe(true);
  });

  it("should apply slippage to market orders", () => {
    const fill1 = fillModel.simulateFill(
      { side: "buy", type: "market", quantity: 0.01 },
      candle
    );
    // Buy slippage should make price higher than open
    expect(fill1.price).toBeGreaterThanOrEqual(candle.open);
  });

  it("should charge taker fees for market orders", () => {
    const fill = fillModel.simulateFill(
      { side: "buy", type: "market", quantity: 1 },
      candle
    );
    // Fee should be ~0.1% of trade value
    const expectedFee = 1 * fill.price * 0.001;
    expect(fill.fee).toBeCloseTo(expectedFee, 0);
  });
});