import webpush from "web-push";
import { logger } from "./utils/logger";

interface PushSubscription {
  endpoint: string;
  keys: {
    p256dh: string;
    auth: string;
  };
}

/**
 * Web Push Notification Service.
 * Sends browser push notifications via VAPID.
 */
export class WebPushService {
  private subscriptions: Map<string, PushSubscription[]> = new Map(); // userId -> subscriptions
  private initialized: boolean = false;

  /**
   * Initialize VAPID keys.
   */
  initialize(publicKey: string, privateKey: string, email: string = "noreply@cryptobot.com"): void {
    webpush.setVapidDetails(
      `mailto:${email}`,
      publicKey,
      privateKey
    );
    this.initialized = true;
    logger.info("Web Push service initialized");
  }

  /**
   * Store a push subscription for a user.
   */
  subscribe(userId: string, subscription: PushSubscription): void {
    if (!this.subscriptions.has(userId)) {
      this.subscriptions.set(userId, []);
    }

    const subs = this.subscriptions.get(userId)!;

    // Avoid duplicates
    const exists = subs.some((s) => s.endpoint === subscription.endpoint);
    if (!exists) {
      subs.push(subscription);
      logger.info(`Web push subscription added for user ${userId}`);
    }
  }

  /**
   * Remove a push subscription.
   */
  unsubscribe(userId: string, endpoint: string): void {
    const subs = this.subscriptions.get(userId);
    if (!subs) return;

    this.subscriptions.set(
      userId,
      subs.filter((s) => s.endpoint !== endpoint)
    );

    logger.info(`Web push subscription removed for user ${userId}`);
  }

  /**
   * Send a push notification to a user.
   */
  async sendNotification(
    userId: string,
    title: string,
    body: string,
    data?: Record<string, any>
  ): Promise<{ success: number; failed: number }> {
    if (!this.initialized) {
      logger.warn("Web Push not initialized");
      return { success: 0, failed: 0 };
    }

    const subs = this.subscriptions.get(userId);
    if (!subs || subs.length === 0) {
      return { success: 0, failed: 0 };
    }

    let success = 0;
    let failed = 0;

    const payload = JSON.stringify({
      title,
      body,
      icon: "/icon-192.png",
      badge: "/badge-72.png",
      data: data || {},
      timestamp: Date.now(),
    });

    for (const sub of subs) {
      try {
        await webpush.sendNotification(sub as any, payload);
        success++;
      } catch (error: any) {
        failed++;

        // Remove invalid subscriptions
        if (error.statusCode === 410 || error.statusCode === 404) {
          this.unsubscribe(userId, sub.endpoint);
        }

        logger.warn(`Web push failed for ${userId}`, { statusCode: error.statusCode });
      }
    }

    return { success, failed };
  }

  /**
   * Send a push notification to multiple users.
   */
  async sendBroadcast(
    userIds: string[],
    title: string,
    body: string,
    data?: Record<string, any>
  ): Promise<{ totalSuccess: number; totalFailed: number }> {
    let totalSuccess = 0;
    let totalFailed = 0;

    for (const userId of userIds) {
      const result = await this.sendNotification(userId, title, body, data);
      totalSuccess += result.success;
      totalFailed += result.failed;
    }

    return { totalSuccess, totalFailed };
  }

  /**
   * Get subscription count for a user.
   */
  getSubscriptionCount(userId: string): number {
    return this.subscriptions.get(userId)?.length || 0;
  }

  /**
   * Get total subscription count.
   */
  getTotalSubscriptions(): number {
    let total = 0;
    for (const subs of this.subscriptions.values()) {
      total += subs.length;
    }
    return total;
  }

  /**
   * Get the VAPID public key (for frontend).
   */
  getPublicKey(): string | null {
    return process.env.WEBPUSH_VAPID_PUBLIC || null;
  }
}