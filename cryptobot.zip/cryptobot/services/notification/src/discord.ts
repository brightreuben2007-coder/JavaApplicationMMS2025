import fetch from "node-fetch";
import { logger } from "./utils/logger";

interface DiscordEmbed {
  title?: string;
  description?: string;
  color?: number;
  fields?: Array<{ name: string; value: string; inline?: boolean }>;
  timestamp?: string;
  footer?: { text: string };
}

/**
 * Discord Webhook Service.
 * Sends notifications to Discord channels via webhooks.
 */
export class DiscordService {
  private webhookUrls: Map<string, string> = new Map();

  /**
   * Register a Discord webhook URL for a user or channel.
   */
  registerWebhook(key: string, webhookUrl: string): void {
    this.webhookUrls.set(key, webhookUrl);
    logger.info(`Discord webhook registered: ${key}`);
  }

  /**
   * Remove a webhook registration.
   */
  unregisterWebhook(key: string): void {
    this.webhookUrls.delete(key);
  }

  /**
   * Send a simple text message to Discord.
   */
  async sendMessage(key: string, content: string): Promise<boolean> {
    const webhookUrl = this.webhookUrls.get(key);
    if (!webhookUrl) {
      logger.warn(`Discord webhook not found: ${key}`);
      return false;
    }

    try {
      const response = await fetch(webhookUrl, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ content }),
      });

      if (!response.ok) {
        logger.error(`Discord send failed: ${response.status} ${response.statusText}`);
        return false;
      }

      return true;
    } catch (error) {
      logger.error("Discord send error", { error });
      return false;
    }
  }

  /**
   * Send a rich embed message to Discord.
   */
  async sendEmbed(key: string, embed: DiscordEmbed): Promise<boolean> {
    const webhookUrl = this.webhookUrls.get(key);
    if (!webhookUrl) {
      logger.warn(`Discord webhook not found: ${key}`);
      return false;
    }

    try {
      const response = await fetch(webhookUrl, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          embeds: [{
            ...embed,
            timestamp: embed.timestamp || new Date().toISOString(),
            footer: embed.footer || { text: "CryptoBot" },
          }],
        }),
      });

      if (!response.ok) {
        logger.error(`Discord embed failed: ${response.status}`);
        return false;
      }

      return true;
    } catch (error) {
      logger.error("Discord embed error", { error });
      return false;
    }
  }

  /**
   * Send a deal notification.
   */
  async notifyDeal(
    key: string,
    type: "opened" | "closed" | "tp_hit" | "sl_hit" | "so_filled",
    pair: string,
    details: Record<string, any>
  ): Promise<void> {
    const colors: Record<string, number> = {
      opened: 3447003,   // Blue
      closed: 10181046,  // Purple
      tp_hit: 3066993,   // Green
      sl_hit: 15158332,  // Red
      so_filled: 15844367, // Gold
    };

    const emojis: Record<string, string> = {
      opened: "🆕",
      closed: "🔒",
      tp_hit: "✅",
      sl_hit: "🛑",
      so_filled: "📉",
    };

    await this.sendEmbed(key, {
      title: `${emojis[type] || ""} Deal ${type.replace("_", " ")}: ${pair}`,
      color: colors[type] || 0,
      fields: Object.entries(details).map(([name, value]) => ({
        name: name.replace(/_/g, " ").replace(/\b\w/g, (c) => c.toUpperCase()),
        value: typeof value === "number" ? value.toFixed(4) : String(value),
        inline: true,
      })),
    });
  }

  /**
   * Send a risk alert to Discord.
   */
  async notifyRisk(key: string, level: string, message: string, details: Record<string, any>): Promise<void> {
    const colors: Record<string, number> = {
      normal: 3066993,
      warning: 15844367,
      danger: 15158332,
      critical: 10038562,
      halted: 0,
    };

    await this.sendEmbed(key, {
      title: `⚠️ Risk Alert [${level.toUpperCase()}]`,
      description: message,
      color: colors[level] || 0,
      fields: Object.entries(details).slice(0, 5).map(([name, value]) => ({
        name,
        value: typeof value === "number" ? value.toFixed(2) : String(value),
        inline: true,
      })),
    });
  }
}