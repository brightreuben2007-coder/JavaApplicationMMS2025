import fetch from "node-fetch";
import { logger } from "./utils/logger";

interface TelegramMessage {
  chatId: string;
  text: string;
  parseMode?: "HTML" | "Markdown";
  replyMarkup?: any;
}

interface TelegramUpdate {
  update_id: number;
  message?: {
    message_id: number;
    chat: { id: number; type: string; username?: string };
    text?: string;
    entities?: Array<{ type: string; offset: number; length: number }>;
  };
  callback_query?: {
    id: string;
    from: { id: number };
    data: string;
    message: { chat: { id: number }; message_id: number };
  };
}

/**
 * Telegram Bot Service.
 * Handles all Telegram Bot API interactions.
 * Supports commands: /status, /profit, /deals, /stop, /stopall,
 * /forcebuy, /forcesell, /balance, /link, /help
 */
export class TelegramService {
  private botToken: string;
  private apiBase: string;
  private commandHandlers: Map<string, (chatId: string, args: string[], userId: string | null) => Promise<string>> = new Map();
  private linkedUsers: Map<string, string> = new Map(); // chatId -> userId
  private pendingLinks: Map<string, string> = new Map(); // code -> userId
  private updateOffset: number = 0;
  private pollingActive: boolean = false;
  private pollingInterval: NodeJS.Timeout | null = null;

  constructor(botToken: string) {
    this.botToken = botToken;
    this.apiBase = `https://api.telegram.org/bot${botToken}`;
    this.registerDefaultCommands();
  }

  /**
   * Register all default bot commands.
   */
  private registerDefaultCommands(): void {
    this.commandHandlers.set("start", this.handleStart.bind(this));
    this.commandHandlers.set("help", this.handleHelp.bind(this));
    this.commandHandlers.set("status", this.handleStatus.bind(this));
    this.commandHandlers.set("profit", this.handleProfit.bind(this));
    this.commandHandlers.set("deals", this.handleDeals.bind(this));
    this.commandHandlers.set("stop", this.handleStop.bind(this));
    this.commandHandlers.set("stopall", this.handleStopAll.bind(this));
    this.commandHandlers.set("forcebuy", this.handleForceBuy.bind(this));
    this.commandHandlers.set("forcesell", this.handleForceSell.bind(this));
    this.commandHandlers.set("balance", this.handleBalance.bind(this));
    this.commandHandlers.set("link", this.handleLink.bind(this));
    this.commandHandlers.set("settings", this.handleSettings.bind(this));
  }

  /**
   * Register a pending link between a code and userId.
   */
  registerLinkCode(code: string, userId: string): void {
    this.pendingLinks.set(code, userId);
    // Expire after 10 minutes
    setTimeout(() => this.pendingLinks.delete(code), 600000);
  }

  /**
   * Get the link code for a user (to display in UI).
   */
  getLinkCodeForUser(userId: string): string | null {
    for (const [code, uid] of this.pendingLinks.entries()) {
      if (uid === userId) return code;
    }
    return null;
  }

  /**
   * Send a message to a Telegram chat.
   */
  async sendMessage(message: TelegramMessage): Promise<boolean> {
    try {
      const body: any = {
        chat_id: message.chatId,
        text: message.text,
        parse_mode: message.parseMode || "HTML",
      };

      if (message.replyMarkup) {
        body.reply_markup = message.replyMarkup;
      }

      const response = await fetch(`${this.apiBase}/sendMessage`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });

      const data = await response.json() as any;

      if (!data.ok) {
        logger.error(`Telegram send failed: ${data.description}`);
        return false;
      }

      return true;
    } catch (error) {
      logger.error("Telegram send error", { error });
      return false;
    }
  }

  /**
   * Send a notification to a user via Telegram (if linked).
   */
  async notifyUser(userId: string, message: string, chatId?: string): Promise<boolean> {
    const targetChatId = chatId || this.getChatIdForUser(userId);
    if (!targetChatId) return false;

    return this.sendMessage({
      chatId: targetChatId,
      text: message,
      parseMode: "HTML",
    });
  }

  /**
   * Get the linked chat ID for a user.
   */
  private getChatIdForUser(userId: string): string | null {
    for (const [chatId, uid] of this.linkedUsers.entries()) {
      if (uid === userId) return chatId;
    }
    return null;
  }

  /**
   * Get the linked user ID for a chat.
   */
  getUserIdForChat(chatId: string): string | null {
    return this.linkedUsers.get(chatId) || null;
  }

  // ============================================================
  // COMMAND HANDLERS
  // ============================================================

  private async handleStart(chatId: string, _args: string[]): Promise<string> {
    return [
      "🤖 <b>Welcome to CryptoBot!</b>",
      "",
      "Connect your exchange accounts and let automated trading work for you.",
      "",
      "🔗 <b>Quick Start:</b>",
      "1. Go to Settings → Notifications",
      "2. Copy the /link command shown there",
      "3. Send it here to link your account",
      "",
      "Type /help for all commands.",
    ].join("\n");
  }

  private async handleHelp(): Promise<string> {
    return [
      "📋 <b>Available Commands:</b>",
      "",
      "/status — View active bots",
      "/profit — View today's and all-time PnL",
      "/deals — View open deals",
      "/balance — View portfolio balances",
      "/stop &lt;bot_name&gt; — Stop a specific bot",
      "/stopall — Emergency stop all bots",
      "/forcebuy &lt;pair&gt; &lt;amount&gt; — Manual buy",
      "/forcesell &lt;deal_id&gt; — Close a deal",
      "/link &lt;code&gt; — Link your account",
      "/settings — Notification preferences",
      "/help — Show this message",
    ].join("\n");
  }

  private async handleStatus(chatId: string, _args: string[], userId: string | null): Promise<string> {
    if (!userId) return "⚠️ Please link your account first: /link [code]";
    return `🔍 <i>Fetching bot status for your account...</i>\n(This would query your active bots in production)`;
  }

  private async handleProfit(chatId: string, _args: string[], userId: string | null): Promise<string> {
    if (!userId) return "⚠️ Please link your account first: /link [code]";
    return `💰 <i>Fetching profit data...</i>`;
  }

  private async handleDeals(chatId: string, _args: string[], userId: string | null): Promise<string> {
    if (!userId) return "⚠️ Please link your account first: /link [code]";
    return `📊 <i>Fetching open deals...</i>`;
  }

  private async handleStop(chatId: string, args: string[], userId: string | null): Promise<string> {
    if (!userId) return "⚠️ Please link your account first: /link [code]";
    const botName = args.join(" ");
    if (!botName) return "⚠️ Usage: /stop [bot_name]";
    return `⏹ <b>Stop signal sent for:</b> ${botName}`;
  }

  private async handleStopAll(chatId: string, _args: string[], userId: string | null): Promise<string> {
    if (!userId) return "⚠️ Please link your account first: /link [code]";
    return [
      "🚨 <b>EMERGENCY STOP ALL</b>",
      "",
      "This will stop ALL your active bots immediately.",
      "Are you sure? Reply: /stopall confirm",
    ].join("\n");
  }

  private async handleForceBuy(chatId: string, args: string[], userId: string | null): Promise<string> {
    if (!userId) return "⚠️ Please link your account first: /link [code]";
    if (args.length < 2) return "⚠️ Usage: /forcebuy [pair] [amount]";
    const [pair, amount] = args;
    return `✅ <b>Force Buy:</b> ${amount} ${pair}`;
  }

  private async handleForceSell(chatId: string, args: string[], userId: string | null): Promise<string> {
    if (!userId) return "⚠️ Please link your account first: /link [code]";
    if (args.length < 1) return "⚠️ Usage: /forcesell [deal_id]";
    return `✅ <b>Force Sell:</b> Deal ${args[0]}`;
  }

  private async handleBalance(chatId: string, _args: string[], userId: string | null): Promise<string> {
    if (!userId) return "⚠️ Please link your account first: /link [code]";
    return `💎 <i>Fetching balances...</i>`;
  }

  private async handleLink(chatId: string, args: string[], userId: string | null): Promise<string> {
    if (args.length < 1) return "⚠️ Usage: /link [code]\nGet your code from Settings → Notifications in the web app.";

    const code = args[0] || "";
    const linkedUserId = this.pendingLinks.get(code);

    if (!linkedUserId) {
      return "❌ Invalid or expired link code. Please generate a new one from Settings → Notifications.";
    }

    this.linkedUsers.set(chatId, linkedUserId);
    this.pendingLinks.delete(code);

    logger.info(`Telegram linked: chat ${chatId} -> user ${linkedUserId}`);

    return [
      "✅ <b>Account linked successfully!</b>",
      "",
      "You'll now receive trading notifications here.",
      "Use /status to see your bots or /help for all commands.",
    ].join("\n");
  }

  private async handleSettings(chatId: string, _args: string[], userId: string | null): Promise<string> {
    if (!userId) return "⚠️ Please link your account first: /link [code]";
    return [
      "⚙️ <b>Notification Settings</b>",
      "",
      "Manage your preferences in the web app:",
      "Settings → Notifications",
    ].join("\n");
  }

  // ============================================================
  // POLLING & UPDATES
  // ============================================================

  /**
   * Start polling for updates from Telegram.
   */
  startPolling(pollInterval: number = 2000): void {
    if (this.pollingActive) return;
    this.pollingActive = true;

    this.poll();
    this.pollingInterval = setInterval(() => this.poll(), pollInterval);

    logger.info("Telegram polling started");
  }

  /**
   * Stop polling.
   */
  stopPolling(): void {
    this.pollingActive = false;
    if (this.pollingInterval) {
      clearInterval(this.pollingInterval);
      this.pollingInterval = null;
    }
    logger.info("Telegram polling stopped");
  }

  /**
   * Poll for updates and process commands.
   */
  private async poll(): Promise<void> {
    try {
      const url = `${this.apiBase}/getUpdates?offset=${this.updateOffset + 1}&timeout=10`;
      const response = await fetch(url);
      const data = await response.json() as { ok: boolean; result: TelegramUpdate[] };

      if (!data.ok || !Array.isArray(data.result)) return;

      for (const update of data.result) {
        this.updateOffset = update.update_id;
        await this.processUpdate(update);
      }
    } catch (error) {
      logger.error("Telegram polling error", { error });
    }
  }

  /**
   * Process a single update.
   */
  private async processUpdate(update: TelegramUpdate): Promise<void> {
    // Handle callback queries (inline keyboard buttons)
    if (update.callback_query) {
      const callback = update.callback_query;
      const chatId = callback.message.chat.id.toString();
      const userId = this.linkedUsers.get(chatId) || null;
      await this.handleCallback(chatId, callback.data, userId);
      return;
    }

    // Handle messages
    if (!update.message?.text) return;

    const chatId = update.message.chat.id.toString();
    const text = update.message.text.trim();
    const userId = this.linkedUsers.get(chatId) || null;

    // Check if it's a command
    if (text.startsWith("/")) {
      const parts = text.split(/\s+/);
      const command = (parts[0] || "").replace("/", "").toLowerCase().split("@")[0]; // Remove bot mention
      const args = parts.slice(1);

      const handler = this.commandHandlers.get(command || "");
      if (handler) {
        try {
          const reply = await handler(chatId, args, userId);
          await this.sendMessage({ chatId, text: reply, parseMode: "HTML" });
        } catch (error) {
          logger.error(`Command handler error: ${command}`, { error });
          await this.sendMessage({
            chatId,
            text: "⚠️ Something went wrong. Please try again.",
          });
        }
      } else {
        await this.sendMessage({
          chatId,
          text: `Unknown command: /${command}\nType /help for available commands.`,
        });
      }
    }
  }

  /**
   * Handle inline keyboard callbacks.
   */
  private async handleCallback(chatId: string, data: string, userId: string | null): Promise<void> {
    switch (data) {
      case "stopall_confirm":
        await this.sendMessage({
          chatId,
          text: "🚨 All bots stopped. Use /status to verify.",
        });
        break;
      case "cancel":
        await this.sendMessage({ chatId, text: "Cancelled." });
        break;
      default:
        logger.debug(`Unknown callback: ${data}`);
    }
  }

  /**
   * Build inline keyboard markup.
   */
  buildInlineKeyboard(buttons: Array<Array<{ text: string; callback_data: string }>>): any {
    return {
      inline_keyboard: buttons,
    };
  }

  /**
   * Send a message with inline keyboard buttons.
   */
  async sendWithKeyboard(
    chatId: string,
    text: string,
    buttons: Array<Array<{ text: string; callback_data: string }>>
  ): Promise<boolean> {
    return this.sendMessage({
      chatId,
      text,
      replyMarkup: this.buildInlineKeyboard(buttons),
    });
  }
}