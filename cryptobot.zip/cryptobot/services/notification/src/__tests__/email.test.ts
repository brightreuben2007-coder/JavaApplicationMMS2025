import { EmailService } from "../email";

describe("Email Service", () => {
  let emailService: EmailService;

  beforeEach(() => {
    emailService = new EmailService();
  });

  it("should initialize without error", () => {
    expect(emailService).toBeDefined();
  });

  it("should return false when sending without initialization", async () => {
    const result = await emailService.sendEmail({
      to: "test@example.com",
      subject: "Test",
      html: "<p>Test</p>",
    });
    expect(result).toBe(false);
  });

  it("should generate deal notification email without error", async () => {
    // Should not throw even without SMTP config
    await emailService.notifyDeal("test@example.com", "tp_hit", {
      pair: "BTC/USDT",
      entryPrice: 50000,
      exitPrice: 51000,
      profit: 100,
    });
  });

  it("should generate daily summary email without error", async () => {
    await emailService.sendDailySummary("test@example.com", {
      date: "2024-01-15",
      dailyPnl: 250.50,
      totalTrades: 12,
      winRate: 66.7,
      topPerformers: [{ pair: "BTC/USDT", pnl: 200 }, { pair: "ETH/USDT", pnl: 50.50 }],
    });
  });
});