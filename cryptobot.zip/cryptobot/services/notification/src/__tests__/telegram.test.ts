import { TelegramService } from "../telegram";

describe("Telegram Service", () => {
  let telegram: TelegramService;

  beforeEach(() => {
    telegram = new TelegramService("test-bot-token");
  });

  it("should register a link code", () => {
    telegram.registerLinkCode("abc123", "user-1");
    const code = telegram.getLinkCodeForUser("user-1");
    expect(code).toBe("abc123");
  });

  it("should return null for unlinked user", () => {
    const code = telegram.getLinkCodeForUser("nonexistent");
    expect(code).toBeNull();
  });

  it("should handle link command with valid code", async () => {
    telegram.registerLinkCode("xyz789", "user-2");

    // Access private method via any cast
    const result = await (telegram as any).handleLink("chat-1", ["xyz789"], null);
    expect(result).toContain("linked successfully");
    expect(telegram.getUserIdForChat("chat-1")).toBe("user-2");
  });

  it("should reject invalid link code", async () => {
    const result = await (telegram as any).handleLink("chat-1", ["invalid"], null);
    expect(result).toContain("Invalid or expired");
  });

  it("should return help text", async () => {
    const help = await (telegram as any).handleHelp();
    expect(help).toContain("Available Commands");
    expect(help).toContain("/status");
    expect(help).toContain("/stopall");
  });

  it("should require link for authenticated commands", async () => {
    const status = await (telegram as any).handleStatus("chat-1", [], null);
    expect(status).toContain("link your account");
  });

  it("should build inline keyboard", () => {
    const keyboard = telegram.buildInlineKeyboard([
      [{ text: "Confirm", callback_data: "stopall_confirm" }],
      [{ text: "Cancel", callback_data: "cancel" }],
    ]);
    expect(keyboard.inline_keyboard).toHaveLength(2);
    expect(keyboard.inline_keyboard[0][0].text).toBe("Confirm");
  });
});