import nodemailer from "nodemailer";
import { logger } from "./utils/logger";

interface EmailOptions {
  to: string;
  subject: string;
  html: string;
  text?: string;
}

/**
 * Email Notification Service.
 * Sends transactional emails via SMTP or SendGrid.
 * All user-provided data is HTML-escaped to prevent XSS.
 */
export class EmailService {
  private transporter: nodemailer.Transporter | null = null;
  private fromAddress: string;

  constructor(fromAddress: string = "noreply@cryptobot.com") {
    this.fromAddress = fromAddress;
  }

  /**
   * Escape HTML special characters to prevent XSS injection.
   */
  private escapeHtml(text: string): string {
    return text
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#039;");
  }

  /**
   * Safely format a value for HTML display.
   * Numbers are formatted, strings are escaped, other types are stringified and escaped.
   */
  private formatValue(value: unknown): string {
    if (typeof value === "number") {
      return value.toFixed(4);
    }
    if (typeof value === "string") {
      return this.escapeHtml(value);
    }
    if (value === null || value === undefined) {
      return "—";
    }
    if (typeof value === "boolean") {
      return value ? "Yes" : "No";
    }
    return this.escapeHtml(String(value));
  }

  /**
   * Format a key name for display (snake_case → Title Case).
   */
  private formatKey(key: string): string {
    return this.escapeHtml(
      key
        .replace(/_/g, " ")
        .replace(/\b\w/g, (c) => c.toUpperCase())
    );
  }

  /**
   * Initialize with SMTP credentials.
   */
  async initializeSMTP(host: string, user: string, pass: string, port: number = 587): Promise<void> {
    this.transporter = nodemailer.createTransport({
      host,
      port,
      secure: port === 465,
      auth: { user, pass },
    });

    try {
      await this.transporter.verify();
      logger.info("Email service initialized (SMTP)");
    } catch (error) {
      logger.error("Email service initialization failed", { error });
      this.transporter = null;
    }
  }

  /**
   * Initialize with SendGrid API key.
   */
  async initializeSendGrid(apiKey: string): Promise<void> {
    this.transporter = nodemailer.createTransport({
      host: "smtp.sendgrid.net",
      port: 587,
      auth: {
        user: "apikey",
        pass: apiKey,
      },
    });

    try {
      await this.transporter.verify();
      logger.info("Email service initialized (SendGrid)");
    } catch (error) {
      logger.error("SendGrid initialization failed", { error });
      this.transporter = null;
    }
  }

  /**
   * Send an email.
   */
  async sendEmail(options: EmailOptions): Promise<boolean> {
    if (!this.transporter) {
      logger.warn("Email service not initialized");
      return false;
    }

    try {
      const info = await this.transporter.sendMail({
        from: this.fromAddress,
        to: options.to,
        subject: options.subject,
        html: options.html,
        text: options.text,
      });

      logger.info(`Email sent: ${info.messageId} to ${options.to}`);
      return true;
    } catch (error) {
      logger.error("Email send failed", { error, to: options.to });
      return false;
    }
  }

  /**
   * Send a deal notification email.
   * All data values are HTML-escaped.
   */
  async notifyDeal(
    email: string,
    type: "deal_opened" | "deal_closed" | "tp_hit" | "sl_hit" | "so_filled",
    data: Record<string, any>
  ): Promise<void> {
    const subjects: Record<string, string> = {
      deal_opened: `🆕 New Deal Opened: ${this.escapeHtml(data.pair || "")}`,
      deal_closed: `🔒 Deal Closed: ${this.escapeHtml(data.pair || "")}`,
      tp_hit: `✅ Take Profit Hit: ${this.escapeHtml(data.pair || "")}`,
      sl_hit: `🛑 Stop Loss Hit: ${this.escapeHtml(data.pair || "")}`,
      so_filled: `📉 Safety Order Filled: ${this.escapeHtml(data.pair || "")}`,
    };

    const colors: Record<string, string> = {
      deal_opened: "#3498db",
      deal_closed: "#9b59b6",
      tp_hit: "#2ecc71",
      sl_hit: "#e74c3c",
      so_filled: "#f39c12",
    };

    const color = colors[type] || "#333333";

    // Build table rows with escaped values
    const tableRows = Object.entries(data)
      .map(
        ([key, value]) => `
          <tr>
            <td style="padding: 8px; border-bottom: 1px solid #eee; font-weight: bold; color: #555;">
              ${this.formatKey(key)}
            </td>
            <td style="padding: 8px; border-bottom: 1px solid #eee; text-align: right;">
              ${this.formatValue(value)}
            </td>
          </tr>
        `
      )
      .join("");

    await this.sendEmail({
      to: email,
      subject: subjects[type] || "CryptoBot Notification",
      html: `
        <div style="font-family: Arial, Helvetica, sans-serif; max-width: 600px; margin: 0 auto;">
          <div style="background: ${color}; padding: 20px; border-radius: 10px 10px 0 0;">
            <h2 style="color: white; margin: 0; font-size: 18px;">${subjects[type]}</h2>
          </div>
          <div style="background: #ffffff; padding: 20px; border-radius: 0 0 10px 10px; border: 1px solid #ddd; border-top: none;">
            <table style="width: 100%; border-collapse: collapse;">
              ${tableRows}
            </table>
          </div>
          <p style="color: #999; font-size: 12px; text-align: center; margin-top: 15px;">
            Sent by CryptoBot — 
            <a href="${process.env.FRONTEND_URL || "#"}" style="color: #999;">Manage notification settings</a>
          </p>
        </div>
      `,
    });
  }

  /**
   * Send a daily summary email.
   */
  async sendDailySummary(
    email: string,
    data: {
      date: string;
      dailyPnl: number;
      totalTrades: number;
      winRate: number;
      topPerformers: Array<{ pair: string; pnl: number }>;
    }
  ): Promise<void> {
    const pnlColor = data.dailyPnl >= 0 ? "#2ecc71" : "#e74c3c";
    const pnlSign = data.dailyPnl >= 0 ? "+" : "";
    const formattedPnl = `${pnlSign}$${Math.abs(data.dailyPnl).toFixed(2)}`;

    // Build top performers list with escaped values
    const performersHtml =
      data.topPerformers.length > 0
        ? `
          <h3 style="color: #333; margin-top: 20px;">Top Performers</h3>
          <table style="width: 100%; border-collapse: collapse;">
            ${data.topPerformers
              .map(
                (p) => `
              <tr>
                <td style="padding: 6px 8px; border-bottom: 1px solid #eee;">${this.escapeHtml(p.pair)}</td>
                <td style="padding: 6px 8px; border-bottom: 1px solid #eee; text-align: right; color: ${p.pnl >= 0 ? "#2ecc71" : "#e74c3c"};">
                  ${p.pnl >= 0 ? "+" : ""}$${p.pnl.toFixed(2)}
                </td>
              </tr>
            `
              )
              .join("")}
          </table>
        `
        : `<p style="color: #999;">No trades today.</p>`;

    await this.sendEmail({
      to: email,
      subject: `📊 Daily Trading Summary — ${this.escapeHtml(data.date)}`,
      html: `
        <div style="font-family: Arial, Helvetica, sans-serif; max-width: 600px; margin: 0 auto;">
          <div style="background: #2c3e50; padding: 20px; border-radius: 10px 10px 0 0;">
            <h2 style="color: white; margin: 0; font-size: 18px;">📊 Daily Trading Summary</h2>
            <p style="color: #bdc3c7; margin: 5px 0 0;">${this.escapeHtml(data.date)}</p>
          </div>
          <div style="background: #ffffff; padding: 20px; border-radius: 0 0 10px 10px; border: 1px solid #ddd; border-top: none;">
            <div style="text-align: center; padding: 15px 0;">
              <p style="font-size: 32px; color: ${pnlColor}; font-weight: bold; margin: 0;">
                ${formattedPnl}
              </p>
              <p style="color: #777; margin: 5px 0 0;">Daily P&amp;L</p>
            </div>
            
            <table style="width: 100%; border-collapse: collapse; margin-top: 10px;">
              <tr>
                <td style="padding: 8px; border-bottom: 1px solid #eee; font-weight: bold; color: #555;">Total Trades</td>
                <td style="padding: 8px; border-bottom: 1px solid #eee; text-align: right;">${data.totalTrades}</td>
              </tr>
              <tr>
                <td style="padding: 8px; border-bottom: 1px solid #eee; font-weight: bold; color: #555;">Win Rate</td>
                <td style="padding: 8px; border-bottom: 1px solid #eee; text-align: right;">${data.winRate.toFixed(1)}%</td>
              </tr>
            </table>
            
            ${performersHtml}
          </div>
          <p style="color: #999; font-size: 12px; text-align: center; margin-top: 15px;">
            Sent by CryptoBot — 
            <a href="${process.env.FRONTEND_URL || "#"}" style="color: #999;">Manage notification settings</a>
          </p>
        </div>
      `,
    });
  }

  /**
   * Send a risk alert email.
   */
  async notifyRisk(
    email: string,
    level: "warning" | "danger" | "critical" | "halted",
    message: string,
    details: Record<string, any>
  ): Promise<void> {
    const colors: Record<string, string> = {
      warning: "#f39c12",
      danger: "#e74c3c",
      critical: "#c0392b",
      halted: "#000000",
    };

    const emojis: Record<string, string> = {
      warning: "⚠️",
      danger: "🔴",
      critical: "🚨",
      halted: "⛔",
    };

    const color = colors[level] || "#e74c3c";
    const emoji = emojis[level] || "⚠️";

    const tableRows = Object.entries(details)
      .slice(0, 8)
      .map(
        ([key, value]) => `
          <tr>
            <td style="padding: 6px 8px; border-bottom: 1px solid #fdd;">${this.formatKey(key)}</td>
            <td style="padding: 6px 8px; border-bottom: 1px solid #fdd; text-align: right;">${this.formatValue(value)}</td>
          </tr>
        `
      )
      .join("");

    await this.sendEmail({
      to: email,
      subject: `${emoji} Risk Alert [${level.toUpperCase()}] — CryptoBot`,
      html: `
        <div style="font-family: Arial, Helvetica, sans-serif; max-width: 600px; margin: 0 auto;">
          <div style="background: ${color}; padding: 20px; border-radius: 10px 10px 0 0;">
            <h2 style="color: white; margin: 0; font-size: 18px;">${emoji} Risk Alert — ${this.escapeHtml(level.toUpperCase())}</h2>
          </div>
          <div style="background: #fff5f5; padding: 20px; border-radius: 0 0 10px 10px; border: 1px solid #fcc; border-top: none;">
            <p style="font-size: 16px; color: #333; margin: 0 0 15px;">${this.escapeHtml(message)}</p>
            
            <table style="width: 100%; border-collapse: collapse;">
              ${tableRows}
            </table>
          </div>
          <p style="color: #999; font-size: 12px; text-align: center; margin-top: 15px;">
            Sent by CryptoBot Risk Manager — 
            <a href="${process.env.FRONTEND_URL || "#"}" style="color: #999;">View dashboard</a>
          </p>
        </div>
      `,
    });
  }
}