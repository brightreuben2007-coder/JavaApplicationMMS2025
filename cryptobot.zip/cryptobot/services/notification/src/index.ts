import dotenv from "dotenv";
dotenv.config();

import express from "express";
import helmet from "helmet";
import promClient from "prom-client";
import Redis from "ioredis";
import { v4 as uuidv4 } from "uuid";
import { TelegramService } from "./telegram";
import { DiscordService } from "./discord";
import { EmailService } from "./email";
import { WebPushService } from "./webpush";
import { logger } from "./utils/logger";

const app = express();
const PORT = parseInt(process.env.PORT || "3007", 10);
const REDIS_URL = process.env.REDIS_URL || "redis://localhost:6379";

// Metrics
const register = new promClient.Registry();
promClient.collectDefaultMetrics({ register, prefix: "notification_" });

const notificationCounter = new promClient.Counter({
  name: "notification_sent_total",
  help: "Total notifications sent",
  labelNames: ["channel", "type"],
  registers: [register],
});

const notificationFailureCounter = new promClient.Counter({
  name: "notification_failed_total",
  help: "Total notification failures",
  labelNames: ["channel"],
  registers: [register],
});

// Services
const telegram = new TelegramService(process.env.TELEGRAM_BOT_TOKEN || "");
const discord = new DiscordService();
const email = new EmailService();
const webpush = new WebPushService();

// Initialize services
async function initializeServices(): Promise<void> {
  // Telegram
  if (process.env.TELEGRAM_BOT_TOKEN) {
    telegram.startPolling(3000);
    logger.info("Telegram bot started");
  }

  // Email
  if (process.env.SENDGRID_API_KEY) {
    await email.initializeSendGrid(process.env.SENDGRID_API_KEY);
  } else if (process.env.SMTP_HOST) {
    await email.initializeSMTP(
      process.env.SMTP_HOST,
      process.env.SMTP_USER || "",
      process.env.SMTP_PASS || "",
      parseInt(process.env.SMTP_PORT || "587")
    );
  }

  // Web Push
  if (process.env.WEBPUSH_VAPID_PUBLIC && process.env.WEBPUSH_VAPID_PRIVATE) {
    webpush.initialize(
      process.env.WEBPUSH_VAPID_PUBLIC,
      process.env.WEBPUSH_VAPID_PRIVATE
    );
  }
}

// Redis
const redis = new Redis(REDIS_URL, { maxRetriesPerRequest: 3 });

// Express
app.use(helmet());
app.use(express.json());

app.get("/health", (_req, res) => {
  res.json({
    status: "healthy",
    service: "notification",
    channels: {
      telegram: !!process.env.TELEGRAM_BOT_TOKEN,
      email: !!(process.env.SENDGRID_API_KEY || process.env.SMTP_HOST),
      webpush: !!(process.env.WEBPUSH_VAPID_PUBLIC),
      discord: true,
    },
    uptime: process.uptime(),
  });
});

app.get("/metrics", async (_req, res) => {
  res.set("Content-Type", register.contentType);
  res.end(await register.metrics());
});

// REST API
app.post("/api/notify/send", async (req, res) => {
  try {
    const { userId, channels, title, body, data, chatId } = req.body;
    let success = 0;
    let failed = 0;

    const message = body;

    if (channels.includes("telegram") && chatId) {
      const ok = await telegram.sendMessage({ chatId, text: message });
      ok ? success++ : failed++;
      notificationCounter.inc({ channel: "telegram", type: data?.type || "general" });
    }

    if (channels.includes("email") && data?.email) {
      const ok = await email.sendEmail({
        to: data.email,
        subject: title,
        html: `<p>${body}</p>`,
      });
      ok ? success++ : failed++;
      notificationCounter.inc({ channel: "email", type: data?.type || "general" });
    }

    if (channels.includes("push") && userId) {
      const result = await webpush.sendNotification(userId, title, body, data);
      success += result.success;
      failed += result.failed;
      notificationCounter.inc({ channel: "push", type: data?.type || "general" });
    }

    if (channels.includes("discord") && data?.discordKey) {
      const ok = await discord.sendMessage(data.discordKey, message);
      ok ? success++ : failed++;
      notificationCounter.inc({ channel: "discord", type: data?.type || "general" });
    }

    res.json({ success: true, data: { sent: success, failed } });
  } catch (error) {
    res.status(500).json({ success: false, error: { message: (error as Error).message } });
  }
});

// Deal notification
app.post("/api/notify/deal", async (req, res) => {
  try {
    const { userId, type, pair, details, channels, chatId, email: userEmail, discordKey } = req.body;

    if (channels.includes("telegram") && chatId) {
      const emoji = { opened: "🆕", closed: "🔒", tp_hit: "✅", sl_hit: "🛑", so_filled: "📉" }[type] || "ℹ️";
      await telegram.sendMessage({
        chatId,
        text: `${emoji} <b>${type.replace(/_/g, " ").toUpperCase()}</b>: ${pair}\n\n${JSON.stringify(details, null, 2)}`,
      });
      notificationCounter.inc({ channel: "telegram", type: `deal_${type}` });
    }

    if (channels.includes("discord") && discordKey) {
      await discord.notifyDeal(discordKey, type, pair, details);
      notificationCounter.inc({ channel: "discord", type: `deal_${type}` });
    }

    if (channels.includes("email") && userEmail) {
      await email.notifyDeal(userEmail, type, { pair, ...details });
      notificationCounter.inc({ channel: "email", type: `deal_${type}` });
    }

    if (channels.includes("push") && userId) {
      await webpush.sendNotification(userId, `${type.replace(/_/g, " ").toUpperCase()}: ${pair}`, JSON.stringify(details), { type, pair });
      notificationCounter.inc({ channel: "push", type: `deal_${type}` });
    }

    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ success: false, error: { message: (error as Error).message } });
  }
});

// Telegram link
app.post("/api/telegram/link", (req, res) => {
  const { userId } = req.body;
  const code = uuidv4().slice(0, 8);
  telegram.registerLinkCode(code, userId);
  res.json({ success: true, data: { code, command: `/link ${code}` } });
});

// Push subscription
app.post("/api/push/subscribe", (req, res) => {
  const { userId, subscription } = req.body;
  webpush.subscribe(userId, subscription);
  res.json({ success: true, vapidPublicKey: webpush.getPublicKey() });
});

app.post("/api/push/unsubscribe", (req, res) => {
  const { userId, endpoint } = req.body;
  webpush.unsubscribe(userId, endpoint);
  res.json({ success: true });
});

// Discord webhook registration
app.post("/api/discord/register", (req, res) => {
  const { userId, webhookUrl } = req.body;
  discord.registerWebhook(userId, webhookUrl);
  res.json({ success: true });
});

// Redis listener for alert events
async function setupRedisListeners(): Promise<void> {
  const subscriber = redis.duplicate();
  subscriber.subscribe("alert:user:*");

  subscriber.on("pmessage", async (pattern, channel, message) => {
    try {
      const data = JSON.parse(message);
      const parts = channel.split(":");
      const userId = parts[2];

      if (!userId || userId === "*") return;

      // Send to all user's channels
      const chatId = telegram.getUserIdForChat(userId) ? 
        Array.from((telegram as any).linkedUsers.entries())
          .find(([, uid]: [string, string]) => uid === userId)?.[0] : null;

      if (data.type === "risk_alert") {
        const levelEmoji = { critical: "🚨", danger: "🔴", warning: "⚠️", normal: "ℹ️" }[data.level] || "ℹ️";
        if (chatId) {
          await telegram.sendMessage({
            chatId,
            text: `${levelEmoji} <b>${data.level.toUpperCase()}</b>: ${data.message}`,
          });
        }
        await webpush.sendNotification(userId, `Risk Alert: ${data.level}`, data.message, data);
      }

      if (data.type === "deal_notification") {
        if (chatId) {
          await telegram.sendMessage({ chatId, text: data.message });
        }
        await webpush.sendNotification(userId, "Deal Update", data.message, data);
      }
    } catch (error) {
      logger.error("Redis message processing error", { channel, error });
    }
  });

  logger.info("Redis alert listeners active");
}

// Start
app.listen(PORT, async () => {
  await initializeServices();
  await setupRedisListeners();
  logger.info(`Notification Service started on port ${PORT}`);
});

process.on("SIGTERM", async () => {
  telegram.stopPolling();
  await redis.quit();
  process.exit(0);
});