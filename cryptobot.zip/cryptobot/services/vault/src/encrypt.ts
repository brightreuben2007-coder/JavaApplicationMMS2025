import crypto from "node:crypto";
import { EncryptionError, DecryptionError } from "./utils/errors";
import { logger } from "./utils/logger";

const ALGORITHM = "aes-256-gcm";
const IV_LENGTH = 16;
const AUTH_TAG_LENGTH = 16;
const KEY_LENGTH = 32;
const SALT_LENGTH = 64;
const SCRYPT_N = 16384;
const SCRYPT_R = 8;
const SCRYPT_P = 1;

interface EncryptedData {
  encrypted: string;
  iv: string;
  authTag: string;
}

function deriveKey(masterKey: string, salt: Buffer): Buffer {
  return crypto.scryptSync(masterKey, salt, KEY_LENGTH, {
    N: SCRYPT_N,
    r: SCRYPT_R,
    p: SCRYPT_P,
  });
}

function getMasterKey(): string {
  const keyFile = process.env.ENCRYPTION_MASTER_KEY_FILE;
  let masterKey: string | undefined;

  if (keyFile) {
    try {
      const fs = require("node:fs");
      masterKey = fs.readFileSync(keyFile, "utf-8").trim();
    } catch {
      throw new EncryptionError(
        "Failed to read encryption master key from file. Ensure ENCRYPTION_MASTER_KEY_FILE points to a valid file."
      );
    }
  } else {
    masterKey = process.env.ENCRYPTION_MASTER_KEY;
  }

  if (!masterKey || masterKey.length < 32) {
    throw new EncryptionError(
      "ENCRYPTION_MASTER_KEY must be at least 32 characters long. Set it as an environment variable or file."
    );
  }

  return masterKey;
}

export function encrypt(plaintext: string): EncryptedData {
  if (!plaintext || plaintext.length === 0) {
    throw new EncryptionError("Cannot encrypt empty string");
  }

  try {
    const masterKey = getMasterKey();
    const iv = crypto.randomBytes(IV_LENGTH);
    const salt = crypto.randomBytes(SALT_LENGTH);
    const derivedKey = deriveKey(masterKey, salt);

    const cipher = crypto.createCipheriv(ALGORITHM, derivedKey, iv, {
      authTagLength: AUTH_TAG_LENGTH,
    });

    const encrypted = Buffer.concat([
      cipher.update(plaintext, "utf-8"),
      cipher.final(),
    ]);

    const authTag = cipher.getAuthTag();

    // Prepend salt to encrypted data so decryption can derive the key
    const combined = Buffer.concat([salt, encrypted]);

    return {
      encrypted: combined.toString("base64"),
      iv: iv.toString("base64"),
      authTag: authTag.toString("base64"),
    };
  } catch (error) {
    logger.error("Encryption operation failed", { error });
    throw new EncryptionError(
      error instanceof Error ? error.message : "Unknown encryption error"
    );
  }
}

export function decrypt(encrypted: string, iv: string, authTag: string): string {
  if (!encrypted || encrypted.length === 0) {
    throw new DecryptionError("Cannot decrypt empty string");
  }
  if (!iv || iv.length === 0) {
    throw new DecryptionError("IV is required for decryption");
  }
  if (!authTag || authTag.length === 0) {
    throw new DecryptionError("Auth tag is required for decryption");
  }

  try {
    const masterKey = getMasterKey();

    const combined = Buffer.from(encrypted, "base64");
    const ivBuffer = Buffer.from(iv, "base64");
    const authTagBuffer = Buffer.from(authTag, "base64");

    // Extract salt from beginning of combined data
    const salt = combined.subarray(0, SALT_LENGTH);
    const ciphertext = combined.subarray(SALT_LENGTH);

    const derivedKey = deriveKey(masterKey, salt);

    const decipher = crypto.createDecipheriv(ALGORITHM, derivedKey, ivBuffer, {
      authTagLength: AUTH_TAG_LENGTH,
    });

    decipher.setAuthTag(authTagBuffer);

    const decrypted = Buffer.concat([
      decipher.update(ciphertext),
      decipher.final(),
    ]);

    return decrypted.toString("utf-8");
  } catch (error) {
    logger.error("Decryption operation failed", { error });
    throw new DecryptionError(
      error instanceof Error ? error.message : "Unknown decryption error"
    );
  }
}

export function encryptCredential(
  apiKey: string,
  apiSecret: string
): {
  encryptedKey: string;
  encryptedSecret: string;
  iv: string;
  authTag: string;
} {
  const keyResult = encrypt(apiKey);
  const secretResult = encrypt(apiSecret);

  // Use the same IV but different auth tags per field
  if (keyResult.iv !== secretResult.iv) {
    logger.warn(
      "IV mismatch between key and secret encryption. Using key IV for both for consistency."
    );
  }

  return {
    encryptedKey: keyResult.encrypted,
    encryptedSecret: secretResult.encrypted,
    iv: keyResult.iv,
    authTag: keyResult.authTag,
  };
}

export function decryptCredential(
  encryptedKey: string,
  encryptedSecret: string,
  iv: string,
  authTag: string
): { apiKey: string; apiSecret: string } {
  const apiKey = decrypt(encryptedKey, iv, authTag);
  const apiSecret = decrypt(encryptedSecret, iv, authTag);

  return { apiKey, apiSecret };
}