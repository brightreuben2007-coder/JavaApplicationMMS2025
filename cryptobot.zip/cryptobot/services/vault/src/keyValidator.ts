import ccxt, { Exchange } from "ccxt";
import { logger } from "./utils/logger";
import { ValidationError, WithdrawalEnabledError } from "./utils/errors";

export interface ValidationResult {
  isValid: boolean;
  exchange: string;
  permissions: {
    canTrade: boolean;
    canWithdraw: boolean;
    canDeposit: boolean;
    canRead: boolean;
    canTradeFutures: boolean;
    canTradeMargin: boolean;
  };
  balances: Record<string, { free: number; used: number; total: number }> | null;
  accountType: string | null;
  errorMessage: string | null;
  verifiedAt: string;
}

interface ExchangeConfig {
  apiKey: string;
  secret: string;
  password?: string;
  enableRateLimit: boolean;
  timeout: number;
}

function createExchangeInstance(
  exchangeId: string,
  apiKey: string,
  apiSecret: string,
  passphrase?: string
): Exchange {
  const config: ExchangeConfig = {
    apiKey,
    secret: apiSecret,
    enableRateLimit: true,
    timeout: 30000,
  };

  if (passphrase) {
    config.password = passphrase;
  }

  const exchangeClass = (ccxt as any)[exchangeId];
  if (!exchangeClass) {
    throw new ValidationError(
      `Unsupported exchange: "${exchangeId}". Supported exchanges: ${ccxt.exchanges.join(", ")}`
    );
  }

  const exchange = new exchangeClass(config) as Exchange;
  exchange.options = {
    ...exchange.options,
    warnOnFetchOpenOrdersWithoutSymbol: false,
  };

  return exchange;
}

function determinePermissions(
  exchangeId: string,
  response: any
): ValidationResult["permissions"] {
  const permissions: ValidationResult["permissions"] = {
    canTrade: false,
    canWithdraw: false,
    canDeposit: false,
    canRead: false,
    canTradeFutures: false,
    canTradeMargin: false,
  };

  if (exchangeId === "binance" || exchangeId === "binanceusdm") {
    const perms = response?.permissions || {};
    permissions.canRead = perms?.enableReading || perms?.canRead || false;
    permissions.canTrade = !!(perms?.enableSpotAndMarginTrading || perms?.enableFutures || perms?.canTrade);
    permissions.canWithdraw = !!(perms?.enableWithdrawals || perms?.canWithdraw);
    permissions.canTradeFutures = !!(perms?.enableFutures || response?.futuresType);
    permissions.canTradeMargin = !!(perms?.enableMargin || perms?.enableSpotAndMarginTrading);
    permissions.canDeposit = perms?.canDeposit ?? true;
  } else if (exchangeId === "bybit") {
    permissions.canRead = response?.readOnly !== false;
    permissions.canTrade = response?.readOnly !== true;
    permissions.canWithdraw = response?.permissions?.withdraw ?? false;
    permissions.canTradeFutures = response?.unifiedMarginStatus !== undefined;
  } else if (exchangeId === "kraken") {
    permissions.canRead = true;
    permissions.canTrade = response?.keyType !== "Query";
    permissions.canWithdraw = response?.keyType === "Trade" || (response?.permissions?.includes?.("withdraw") ?? false);
  } else if (exchangeId === "coinbase") {
    permissions.canRead = true;
    permissions.canTrade = response?.scopes?.includes?.("wallet:trades:create") ?? false;
    permissions.canWithdraw = response?.scopes?.includes?.("wallet:transfers:send") ?? false;
  } else if (exchangeId === "kucoin") {
    permissions.canRead = response?.permissions?.includes?.("General") ?? false;
    permissions.canTrade = response?.permissions?.includes?.("Trade") ?? false;
    permissions.canWithdraw = response?.permissions?.includes?.("Withdrawal") ?? false;
  }

  return permissions;
}

export async function validateExchangeCredentials(
  exchangeId: string,
  apiKey: string,
  apiSecret: string,
  passphrase?: string
): Promise<ValidationResult> {
  logger.info(`Validating credentials for ${exchangeId}`, { exchange: exchangeId });

  const exchange = createExchangeInstance(exchangeId, apiKey, apiSecret, passphrase);

  try {
    // Attempt to fetch balance and account info
    const [balance, markets] = await Promise.all([
      exchange.fetchBalance().catch((err: Error) => {
        logger.warn(`Could not fetch balance for ${exchangeId}`, { error: err.message });
        return null;
      }),
      exchange.fetchMarkets().catch((err: Error) => {
        logger.warn(`Could not fetch markets for ${exchangeId}`, { error: err.message });
        return null;
      }),
    ]);

    const permissions = determinePermissions(exchangeId, {
      ...(balance?.info || {}),
      ...(exchange as any).options,
      marketsCount: markets?.length ?? 0,
    });

    // CRITICAL: Reject if withdrawal is enabled
    if (permissions.canWithdraw) {
      throw new WithdrawalEnabledError(exchangeId);
    }

    // Filter only non-zero balances
    const nonZeroBalances: Record<string, { free: number; used: number; total: number }> = {};
    if (balance?.total) {
      for (const [asset, amount] of Object.entries(balance.total)) {
        if (typeof amount === "number" && amount > 0) {
          nonZeroBalances[asset] = {
            free: (balance.free as any)?.[asset] ?? 0,
            used: (balance.used as any)?.[asset] ?? 0,
            total: amount,
          };
        }
      }
    }

    logger.info(`Credentials validated successfully for ${exchangeId}`, {
      exchange: exchangeId,
      canTrade: permissions.canTrade,
      balanceAssets: Object.keys(nonZeroBalances).length,
    });

    return {
      isValid: true,
      exchange: exchangeId,
      permissions,
      balances: nonZeroBalances,
      accountType: (balance as any)?.type ?? (balance as any)?.accountType ?? "spot",
      errorMessage: null,
      verifiedAt: new Date().toISOString(),
    };
  } catch (error) {
    if (error instanceof WithdrawalEnabledError) {
      throw error;
    }

    const errorMessage =
      error instanceof Error ? error.message : "Unknown exchange error";

    logger.error(`Credential validation failed for ${exchangeId}`, {
      exchange: exchangeId,
      error: errorMessage,
    });

    return {
      isValid: false,
      exchange: exchangeId,
      permissions: {
        canTrade: false,
        canWithdraw: false,
        canDeposit: false,
        canRead: false,
        canTradeFutures: false,
        canTradeMargin: false,
      },
      balances: null,
      accountType: null,
      errorMessage,
      verifiedAt: new Date().toISOString(),
    };
  }
}

export async function quickValidateCredentials(
  exchangeId: string,
  apiKey: string,
  apiSecret: string,
  passphrase?: string
): Promise<boolean> {
  const result = await validateExchangeCredentials(exchangeId, apiKey, apiSecret, passphrase);
  return result.isValid && result.permissions.canTrade;
}