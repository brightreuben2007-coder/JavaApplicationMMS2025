import { ErrorCode } from "../../../shared/types/api.types";

export class AppError extends Error {
  public readonly code: ErrorCode;
  public readonly statusCode: number;
  public readonly details?: unknown;
  public readonly isOperational: boolean;

  constructor(
    code: ErrorCode,
    message: string,
    statusCode: number = 500,
    details?: unknown,
    isOperational: boolean = true
  ) {
    super(message);
    this.name = "AppError";
    this.code = code;
    this.statusCode = statusCode;
    this.details = details;
    this.isOperational = isOperational;
    Error.captureStackTrace(this, this.constructor);
  }
}

export class EncryptionError extends AppError {
  constructor(message: string, details?: unknown) {
    super(ErrorCode.SRV_INTERNAL_ERROR, `Encryption failed: ${message}`, 500, details);
    this.name = "EncryptionError";
  }
}

export class DecryptionError extends AppError {
  constructor(message: string, details?: unknown) {
    super(ErrorCode.SRV_INTERNAL_ERROR, `Decryption failed: ${message}`, 500, details);
    this.name = "DecryptionError";
  }
}

export class ValidationError extends AppError {
  constructor(message: string, details?: unknown) {
    super(ErrorCode.EXCH_INVALID_CREDENTIALS, message, 400, details);
    this.name = "ValidationError";
  }
}

export class WithdrawalEnabledError extends AppError {
  constructor(exchange: string) {
    super(
      ErrorCode.EXCH_WITHDRAWAL_ENABLED,
      `Exchange "${exchange}" API key has withdrawal permissions enabled. This is not allowed for security reasons.`,
      400
    );
    this.name = "WithdrawalEnabledError";
  }
}