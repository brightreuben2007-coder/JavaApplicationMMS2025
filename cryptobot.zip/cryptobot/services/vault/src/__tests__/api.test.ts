import request from "supertest";
import { app } from "../index";

// Set env vars before tests
beforeAll(() => {
  process.env.ENCRYPTION_MASTER_KEY =
    "this-is-a-very-long-master-key-for-testing-purposes-minimum-32-chars!!";
  process.env.VAULT_AUTH_TOKEN = "test-token";
});

afterAll(() => {
  delete process.env.ENCRYPTION_MASTER_KEY;
  delete process.env.VAULT_AUTH_TOKEN;
});

const authHeader = { Authorization: "Bearer test-token" };

describe("Vault API", () => {
  describe("GET /health", () => {
    it("should return healthy status", async () => {
      const res = await request(app).get("/health");
      expect(res.status).toBe(200);
      expect(res.body.status).toBe("healthy");
    });

    it("should not require auth", async () => {
      const res = await request(app).get("/health");
      expect(res.status).toBe(200);
    });
  });

  describe("GET /metrics", () => {
    it("should return prometheus metrics", async () => {
      const res = await request(app).get("/metrics");
      expect(res.status).toBe(200);
      expect(res.text).toContain("vault_");
    });
  });

  describe("Authentication middleware", () => {
    it("should reject requests without auth token", async () => {
      const res = await request(app)
        .post("/encrypt")
        .send({ plaintext: "test" });
      expect(res.status).toBe(401);
      expect(res.body.success).toBe(false);
    });

    it("should reject requests with invalid auth token", async () => {
      const res = await request(app)
        .post("/encrypt")
        .set("Authorization", "Bearer wrong-token")
        .send({ plaintext: "test" });
      expect(res.status).toBe(403);
    });
  });

  describe("POST /encrypt", () => {
    it("should encrypt a value", async () => {
      const res = await request(app)
        .post("/encrypt")
        .set(authHeader)
        .send({ plaintext: "my-secret-value" });

      expect(res.status).toBe(200);
      expect(res.body.success).toBe(true);
      expect(res.body.data.encrypted).toBeTruthy();
      expect(res.body.data.iv).toBeTruthy();
      expect(res.body.data.authTag).toBeTruthy();
    });

    it("should return different results for same input", async () => {
      const res1 = await request(app)
        .post("/encrypt")
        .set(authHeader)
        .send({ plaintext: "same-value" });

      const res2 = await request(app)
        .post("/encrypt")
        .set(authHeader)
        .send({ plaintext: "same-value" });

      expect(res1.body.data.encrypted).not.toBe(res2.body.data.encrypted);
    });

    it("should reject missing plaintext", async () => {
      const res = await request(app)
        .post("/encrypt")
        .set(authHeader)
        .send({});
      expect(res.status).toBe(400);
      expect(res.body.success).toBe(false);
    });
  });

  describe("POST /decrypt", () => {
    it("should decrypt a previously encrypted value", async () => {
      const encRes = await request(app)
        .post("/encrypt")
        .set(authHeader)
        .send({ plaintext: "original-message" });

      const decRes = await request(app)
        .post("/decrypt")
        .set(authHeader)
        .send(encRes.body.data);

      expect(decRes.status).toBe(200);
      expect(decRes.body.data.plaintext).toBe("original-message");
    });

    it("should fail with corrupted data", async () => {
      const encRes = await request(app)
        .post("/encrypt")
        .set(authHeader)
        .send({ plaintext: "test" });

      const res = await request(app)
        .post("/decrypt")
        .set(authHeader)
        .send({
          encrypted: "corrupted" + encRes.body.data.encrypted,
          iv: encRes.body.data.iv,
          authTag: encRes.body.data.authTag,
        });

      expect(res.status).toBe(500);
      expect(res.body.success).toBe(false);
    });

    it("should reject missing fields", async () => {
      const res = await request(app)
        .post("/decrypt")
        .set(authHeader)
        .send({ encrypted: "test" });
      expect(res.status).toBe(400);
    });
  });

  describe("POST /encrypt-credential", () => {
    it("should encrypt both key and secret", async () => {
      const res = await request(app)
        .post("/encrypt-credential")
        .set(authHeader)
        .send({ apiKey: "key123", apiSecret: "secret456" });

      expect(res.status).toBe(200);
      expect(res.body.data.encryptedKey).toBeTruthy();
      expect(res.body.data.encryptedSecret).toBeTruthy();
      expect(res.body.data.iv).toBeTruthy();
      expect(res.body.data.authTag).toBeTruthy();
    });

    it("should reject missing fields", async () => {
      const res = await request(app)
        .post("/encrypt-credential")
        .set(authHeader)
        .send({ apiKey: "only-key" });
      expect(res.status).toBe(400);
    });
  });

  describe("POST /decrypt-credential", () => {
    it("should round-trip credentials", async () => {
      const encRes = await request(app)
        .post("/encrypt-credential")
        .set(authHeader)
        .send({ apiKey: "myKey", apiSecret: "mySecret" });

      const decRes = await request(app)
        .post("/decrypt-credential")
        .set(authHeader)
        .send(encRes.body.data);

      expect(decRes.status).toBe(200);
      expect(decRes.body.data.apiKey).toBe("myKey");
      expect(decRes.body.data.apiSecret).toBe("mySecret");
    });

    it("should reject missing fields", async () => {
      const res = await request(app)
        .post("/decrypt-credential")
        .set(authHeader)
        .send({ encryptedKey: "test" });
      expect(res.status).toBe(400);
    });
  });

  describe("POST /validate", () => {
    it("should reject missing exchange field", async () => {
      const res = await request(app)
        .post("/validate")
        .set(authHeader)
        .send({ apiKey: "k", apiSecret: "s" });
      expect(res.status).toBe(400);
    });

    it("should reject unsupported exchange", async () => {
      const res = await request(app)
        .post("/validate")
        .set(authHeader)
        .send({ exchange: "invalid", apiKey: "k", apiSecret: "s" });
      expect(res.body.success).toBe(false);
    });
  });
});