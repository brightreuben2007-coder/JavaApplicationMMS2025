import { encrypt, decrypt, encryptCredential, decryptCredential } from "../encrypt";
import crypto from "node:crypto";

// Set env var before tests
beforeAll(() => {
  process.env.ENCRYPTION_MASTER_KEY =
    "this-is-a-very-long-master-key-for-testing-purposes-minimum-32-chars!!";
});

afterAll(() => {
  delete process.env.ENCRYPTION_MASTER_KEY;
});

describe("Encryption", () => {
  describe("encrypt", () => {
    it("should encrypt a plaintext string and return encrypted, iv, and authTag", () => {
      const plaintext = "my-secret-api-key-12345";
      const result = encrypt(plaintext);

      expect(result).toHaveProperty("encrypted");
      expect(result).toHaveProperty("iv");
      expect(result).toHaveProperty("authTag");
      expect(typeof result.encrypted).toBe("string");
      expect(typeof result.iv).toBe("string");
      expect(typeof result.authTag).toBe("string");

      // Encrypted should be different from plaintext
      expect(result.encrypted).not.toBe(plaintext);

      // base64 regex
      expect(result.encrypted).toMatch(/^[A-Za-z0-9+/]+=*$/);
      expect(result.iv).toMatch(/^[A-Za-z0-9+/]+=*$/);
      expect(result.authTag).toMatch(/^[A-Za-z0-9+/]+=*$/);
    });

    it("should produce different ciphertexts for the same plaintext (different IVs)", () => {
      const plaintext = "test-data";
      const result1 = encrypt(plaintext);
      const result2 = encrypt(plaintext);

      expect(result1.encrypted).not.toBe(result2.encrypted);
      expect(result1.iv).not.toBe(result2.iv);
    });

    it("should handle long strings", () => {
      const longString = "a".repeat(5000);
      const result = encrypt(longString);
      expect(result.encrypted.length).toBeGreaterThan(0);
    });

    it("should handle special characters", () => {
      const special = "!@#$%^&*()_+-=[]{}|;':\",./<>?`~\\§±€\n\t\r";
      const result = encrypt(special);
      expect(result.encrypted.length).toBeGreaterThan(0);
    });

    it("should handle unicode", () => {
      const unicode = "こんにちは世界 🌍 💰 ₿";
      const result = encrypt(unicode);
      expect(result.encrypted.length).toBeGreaterThan(0);
    });

    it("should throw on empty string", () => {
      expect(() => encrypt("")).toThrow("Cannot encrypt empty string");
    });
  });

  describe("decrypt", () => {
    it("should decrypt an encrypted value back to the original", () => {
      const original = "my-super-secret-key";
      const encrypted = encrypt(original);
      const decrypted = decrypt(encrypted.encrypted, encrypted.iv, encrypted.authTag);

      expect(decrypted).toBe(original);
    });

    it("should decrypt special characters correctly", () => {
      const original = "key!with@special#chars$%^&*()_+";
      const encrypted = encrypt(original);
      const decrypted = decrypt(encrypted.encrypted, encrypted.iv, encrypted.authTag);

      expect(decrypted).toBe(original);
    });

    it("should decrypt unicode correctly", () => {
      const original = "₿ ₿ ₿ bitcoin key 🌍";
      const encrypted = encrypt(original);
      const decrypted = decrypt(encrypted.encrypted, encrypted.iv, encrypted.authTag);

      expect(decrypted).toBe(original);
    });

    it("should throw on corrupted encrypted data", () => {
      const encrypted = encrypt("test");
      const corrupted = encrypted.encrypted.slice(0, -5) + "XXXXX";

      expect(() => decrypt(corrupted, encrypted.iv, encrypted.authTag)).toThrow(
        "Decryption failed"
      );
    });

    it("should throw on wrong auth tag", () => {
      const encrypted = encrypt("test");
      const wrongTag = Buffer.from("a".repeat(16)).toString("base64");

      expect(() => decrypt(encrypted.encrypted, encrypted.iv, wrongTag)).toThrow(
        "Decryption failed"
      );
    });

    it("should throw on wrong IV", () => {
      const encrypted = encrypt("test");
      const wrongIv = Buffer.from("b".repeat(16)).toString("base64");

      expect(() => decrypt(encrypted.encrypted, wrongIv, encrypted.authTag)).toThrow(
        "Decryption failed"
      );
    });

    it("should throw on empty encrypted string", () => {
      expect(() => decrypt("", "validiv", "validtag")).toThrow(
        "Cannot decrypt empty string"
      );
    });

    it("should throw on empty IV", () => {
      const encrypted = encrypt("test");
      expect(() => decrypt(encrypted.encrypted, "", encrypted.authTag)).toThrow(
        "IV is required"
      );
    });

    it("should throw on empty auth tag", () => {
      const encrypted = encrypt("test");
      expect(() => decrypt(encrypted.encrypted, encrypted.iv, "")).toThrow(
        "Auth tag is required"
      );
    });
  });

  describe("encryptCredential", () => {
    it("should encrypt both apiKey and apiSecret", () => {
      const result = encryptCredential("key123", "secret456");

      expect(result).toHaveProperty("encryptedKey");
      expect(result).toHaveProperty("encryptedSecret");
      expect(result).toHaveProperty("iv");
      expect(result).toHaveProperty("authTag");
    });
  });

  describe("decryptCredential", () => {
    it("should decrypt back to original keys", () => {
      const apiKey = "my-api-key-12345";
      const apiSecret = "my-api-secret-67890";

      const encrypted = encryptCredential(apiKey, apiSecret);
      const decrypted = decryptCredential(
        encrypted.encryptedKey,
        encrypted.encryptedSecret,
        encrypted.iv,
        encrypted.authTag
      );

      expect(decrypted.apiKey).toBe(apiKey);
      expect(decrypted.apiSecret).toBe(apiSecret);
    });
  });

  describe("round-trip consistency", () => {
    it("should survive 100 round-trips", () => {
      for (let i = 0; i < 100; i++) {
        const original = `key-${i}-${crypto.randomBytes(16).toString("hex")}`;
        const encrypted = encrypt(original);
        const decrypted = decrypt(encrypted.encrypted, encrypted.iv, encrypted.authTag);
        expect(decrypted).toBe(original);
      }
    });

    it("should survive credential round-trips", () => {
      for (let i = 0; i < 100; i++) {
        const key = crypto.randomBytes(32).toString("hex");
        const secret = crypto.randomBytes(32).toString("hex");
        const enc = encryptCredential(key, secret);
        const dec = decryptCredential(enc.encryptedKey, enc.encryptedSecret, enc.iv, enc.authTag);
        expect(dec.apiKey).toBe(key);
        expect(dec.apiSecret).toBe(secret);
      }
    });
  });
});