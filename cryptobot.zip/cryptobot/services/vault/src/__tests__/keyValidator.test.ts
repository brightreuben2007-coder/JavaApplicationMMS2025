import { validateExchangeCredentials, quickValidateCredentials } from "../keyValidator";
import { WithdrawalEnabledError, ValidationError } from "../utils/errors";

// Skip tests that require real API keys in CI
const SHOULD_RUN_LIVE_TESTS = process.env.RUN_LIVE_TESTS === "true";

describe("Key Validator", () => {
  describe("validateExchangeCredentials - input validation", () => {
    it("should throw ValidationError for unsupported exchange", async () => {
      await expect(
        validateExchangeCredentials("unsupported_exchange", "key", "secret")
      ).rejects.toThrow(ValidationError);
    });

    it("should throw ValidationError with helpful message listing supported exchanges", async () => {
      await expect(
        validateExchangeCredentials("nonexistent", "key", "secret")
      ).rejects.toThrow("Unsupported exchange");
    });
  });

  describe("validateExchangeCredentials - invalid credentials", () => {
    (SHOULD_RUN_LIVE_TESTS ? it : it.skip)(
      "should return isValid=false for invalid binance credentials",
      async () => {
        const result = await validateExchangeCredentials(
          "binance",
          "invalid_key_12345",
          "invalid_secret_67890"
        );

        expect(result.isValid).toBe(false);
        expect(result.errorMessage).toBeTruthy();
        expect(result.permissions.canTrade).toBe(false);
        expect(result.balances).toBeNull();
      },
      15000
    );
  });

  describe("permissions detection", () => {
    it("should correctly parse binance permissions structure", () => {
      // Test the internal logic via a mockable path
      // The actual test mocks ccxt
      jest.mock("ccxt", () => ({
        binance: class {
          fetchBalance = jest.fn();
          fetchMarkets = jest.fn();
        },
      }));
    });
  });

  describe("quickValidateCredentials", () => {
    it("should return false for invalid exchange", async () => {
      const result = await quickValidateCredentials("nonexistent", "k", "s");
      expect(result).toBe(false);
    });
  });

  describe("withdrawal permission rejection", () => {
    it("should have WithdrawalEnabledError defined with correct error code", () => {
      const error = new WithdrawalEnabledError("binance");
      expect(error.code).toBe("EXCH_WITHDRAWAL_ENABLED");
      expect(error.message).toContain("binance");
      expect(error.message).toContain("withdrawal");
      expect(error.statusCode).toBe(400);
    });
  });
});