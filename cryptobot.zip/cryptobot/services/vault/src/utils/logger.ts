import winston from "winston";

const redactKeys = ["apiKey", "apiSecret", "encryptedKey", "encryptedSecret", "iv", "authTag", "password"];

const redactSensitive = winston.format((info) => {
  const masked = { ...info };

  for (const key of redactKeys) {
    if (typeof masked[key] === "string" && masked[key].length > 0) {
      masked[key] = `[REDACTED:${masked[key].length}chars]`;
    }
  }

  if (typeof masked.message === "string") {
    for (const key of redactKeys) {
      masked.message = masked.message.replace(
        new RegExp(`"${key}":"[^"]*"`, "g"),
        `"${key}":"[REDACTED]"`
      );
    }
  }

  return masked;
});

export const logger = winston.createLogger({
  level: process.env.LOG_LEVEL || "info",
  format: winston.format.combine(
    redactSensitive(),
    winston.format.timestamp({ format: "ISO8601" }),
    winston.format.errors({ stack: true }),
    process.env.NODE_ENV === "production"
      ? winston.format.json()
      : winston.format.combine(
          winston.format.colorize(),
          winston.format.printf(({ timestamp, level, message, ...meta }) => {
            const metaStr = Object.keys(meta).length ? ` ${JSON.stringify(meta)}` : "";
            return `${timestamp} [${level}]: ${message}${metaStr}`;
          })
        )
  ),
  defaultMeta: { service: "vault" },
  transports: [new winston.transports.Console()],
});