import express from "express";
import helmet from "helmet";
import cors from "cors";
import promClient from "prom-client";
import dotenv from "dotenv";
import { logger } from "./utils/logger";
import { encrypt, decrypt, encryptCredential, decryptCredential } from "./encrypt";
import { validateExchangeCredentials } from "./keyValidator";
import { AppError } from "./utils/errors";
import { ErrorCode } from "../../shared/types/api.types";

dotenv.config();

const app = express();
const PORT = parseInt(process.env.PORT || "3003", 10);

// ============================================================
// METRICS
// ============================================================
const register = new promClient.Registry();
promClient.collectDefaultMetrics({ register, prefix: "vault_" });

const encryptCounter = new promClient.Counter({
  name: "vault_encrypt_total",
  help: "Total encryption operations",
  registers: [register],
});

const decryptCounter = new promClient.Counter({
  name: "vault_decrypt_total",
  help: "Total decryption operations",
  registers: [register],
});

const validationCounter = new promClient.Counter({
  name: "vault_validation_total",
  help: "Total credential validations",
  labelNames: ["exchange", "result"],
  registers: [register],
});

const validationDuration = new promClient.Histogram({
  name: "vault_validation_duration_seconds",
  help: "Credential validation duration in seconds",
  labelNames: ["exchange"],
  buckets: [0.1, 0.5, 1, 2, 5, 10, 15, 30],
  registers: [register],
});

// ============================================================
// MIDDLEWARE
// ============================================================
app.use(helmet());
app.use(cors());
app.use(express.json({ limit: "1mb" }));

// Request logging
app.use((req, _res, next) => {
  logger.info(`${req.method} ${req.path}`, {
    method: req.method,
    path: req.path,
    ip: req.ip,
  });
  next();
});

// Service auth middleware (internal service-to-service)
const SERVICE_AUTH_TOKEN = process.env.VAULT_AUTH_TOKEN || "internal-vault-token-change-me";

app.use((req, _res, next) => {
  // Health check is public
  if (req.path === "/health" || req.path === "/metrics") {
    return next();
  }

  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return next(new AppError(ErrorCode.AUTH_UNAUTHORIZED, "Missing or invalid authorization header", 401));
  }

  const token = authHeader.substring(7);
  if (token !== SERVICE_AUTH_TOKEN) {
    return next(new AppError(ErrorCode.AUTH_FORBIDDEN, "Invalid service token", 403));
  }

  next();
});

// ============================================================
// ROUTES
// ============================================================

// Health check
app.get("/health", (_req, res) => {
  res.json({
    status: "healthy",
    service: "vault",
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
  });
});

// Metrics
app.get("/metrics", async (_req, res) => {
  res.set("Content-Type", register.contentType);
  res.end(await register.metrics());
});

// Encrypt single value
app.post("/encrypt", (req, res, next) => {
  try {
    const { plaintext } = req.body;
    if (!plaintext || typeof plaintext !== "string") {
      throw new AppError(ErrorCode.VAL_INVALID_INPUT, "Field 'plaintext' (string) is required", 400);
    }

    encryptCounter.inc();
    const result = encrypt(plaintext);

    logger.info("Encryption operation completed");
    res.json({ success: true, data: result });
  } catch (error) {
    next(error);
  }
});

// Decrypt single value
app.post("/decrypt", (req, res, next) => {
  try {
    const { encrypted, iv, authTag } = req.body;
    if (!encrypted || !iv || !authTag) {
      throw new AppError(
        ErrorCode.VAL_MISSING_FIELD,
        "Fields 'encrypted', 'iv', and 'authTag' are required",
        400
      );
    }

    decryptCounter.inc();
    const result = decrypt(encrypted, iv, authTag);

    logger.info("Decryption operation completed");
    res.json({ success: true, data: { plaintext: result } });
  } catch (error) {
    next(error);
  }
});

// Encrypt exchange credentials (both key + secret)
app.post("/encrypt-credential", (req, res, next) => {
  try {
    const { apiKey, apiSecret } = req.body;
    if (!apiKey || !apiSecret) {
      throw new AppError(
        ErrorCode.VAL_MISSING_FIELD,
        "Fields 'apiKey' and 'apiSecret' are required",
        400
      );
    }

    encryptCounter.inc(2);
    const result = encryptCredential(apiKey, apiSecret);

    logger.info("Credential encryption completed");
    res.json({ success: true, data: result });
  } catch (error) {
    next(error);
  }
});

// Decrypt exchange credentials
app.post("/decrypt-credential", (req, res, next) => {
  try {
    const { encryptedKey, encryptedSecret, iv, authTag } = req.body;
    if (!encryptedKey || !encryptedSecret || !iv || !authTag) {
      throw new AppError(
        ErrorCode.VAL_MISSING_FIELD,
        "Fields 'encryptedKey', 'encryptedSecret', 'iv', and 'authTag' are required",
        400
      );
    }

    decryptCounter.inc(2);
    const result = decryptCredential(encryptedKey, encryptedSecret, iv, authTag);

    logger.info("Credential decryption completed");
    // Never log the decrypted keys
    res.json({ success: true, data: result });
  } catch (error) {
    next(error);
  }
});

// Validate exchange credentials
app.post("/validate", async (req, res, next) => {
  const startTime = Date.now();

  try {
    const { exchange, apiKey, apiSecret, passphrase } = req.body;
    if (!exchange || !apiKey || !apiSecret) {
      throw new AppError(
        ErrorCode.VAL_MISSING_FIELD,
        "Fields 'exchange', 'apiKey', and 'apiSecret' are required",
        400
      );
    }

    const result = await validateExchangeCredentials(exchange, apiKey, apiSecret, passphrase);

    const duration = (Date.now() - startTime) / 1000;
    validationCounter.inc({ exchange, result: result.isValid ? "success" : "failure" });
    validationDuration.observe({ exchange }, duration);

    logger.info(`Credential validation ${result.isValid ? "succeeded" : "failed"} for ${exchange}`, {
      exchange,
      isValid: result.isValid,
      duration,
    });

    res.json({ success: true, data: result });
  } catch (error) {
    const duration = (Date.now() - startTime) / 1000;
    validationCounter.inc({ exchange: req.body?.exchange || "unknown", result: "error" });
    validationDuration.observe({ exchange: req.body?.exchange || "unknown" }, duration);
    next(error);
  }
});

// ============================================================
// ERROR HANDLER
// ============================================================
app.use(
  (
    err: Error,
    _req: express.Request,
    res: express.Response,
    _next: express.NextFunction
  ) => {
    if (err instanceof AppError) {
      logger.warn(`AppError: ${err.message}`, {
        code: err.code,
        statusCode: err.statusCode,
      });

      res.status(err.statusCode).json({
        success: false,
        error: {
          code: err.code,
          message: err.message,
          details: err.details,
          timestamp: new Date().toISOString(),
        },
      });
      return;
    }

    logger.error("Unhandled error", { error: err.message, stack: err.stack });

    res.status(500).json({
      success: false,
      error: {
        code: ErrorCode.SRV_INTERNAL_ERROR,
        message: "An unexpected error occurred",
        timestamp: new Date().toISOString(),
      },
    });
  }
);

// ============================================================
// START SERVER
// ============================================================
const server = app.listen(PORT, () => {
  logger.info(`Vault service started on port ${PORT}`);
});

// Graceful shutdown
const shutdown = async (signal: string) => {
  logger.info(`Received ${signal}. Shutting down gracefully...`);
  server.close(() => {
    logger.info("HTTP server closed");
    process.exit(0);
  });

  // Force shutdown after 10s
  setTimeout(() => {
    logger.error("Forced shutdown after timeout");
    process.exit(1);
  }, 10000);
};

process.on("SIGTERM", () => shutdown("SIGTERM"));
process.on("SIGINT", () => shutdown("SIGINT"));
process.on("unhandledRejection", (reason) => {
  logger.error("Unhandled rejection", { reason });
});
process.on("uncaughtException", (error) => {
  logger.error("Uncaught exception", { error: error.message, stack: error.stack });
  process.exit(1);
});

export { app, server };