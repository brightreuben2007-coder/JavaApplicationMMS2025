import { Request, Response, NextFunction } from "express";
import { prisma } from "../prisma/client";
import { NotFoundError } from "../utils/errors";
import { logger } from "../utils/logger";

export async function createStrategy(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const { name, description, strategyType, config, conditionBlocks, isPublic, tags } = req.body;

    const strategy = await prisma.strategy.create({
      data: {
        userId: req.userId,
        name,
        description,
        strategyJson: config as any,
        conditionBlocks: conditionBlocks as any,
        isPublic: isPublic ?? false,
        tags: tags ?? [],
      },
    });

    logger.info(`Strategy created: ${strategy.id}`, { userId: req.userId });

    res.status(201).json({
      success: true,
      data: strategy,
    });
  } catch (error) {
    next(error);
  }
}

export async function getStrategies(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const page = parseInt(req.query.page as string) || 1;
    const limit = Math.min(parseInt(req.query.limit as string) || 20, 100);

    const where: any = {
      OR: [
        { userId: req.userId },
        { isPublic: true },
      ],
    };

    const [strategies, total] = await Promise.all([
      prisma.strategy.findMany({
        where,
        orderBy: { updatedAt: "desc" },
        skip: (page - 1) * limit,
        take: limit,
      }),
      prisma.strategy.count({ where }),
    ]);

    res.json({
      success: true,
      data: strategies,
      meta: {
        pagination: {
          page,
          limit,
          total,
          totalPages: Math.ceil(total / limit),
          hasNext: page * limit < total,
          hasPrev: page > 1,
        },
      },
    });
  } catch (error) {
    next(error);
  }
}

export async function getStrategy(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const strategy = await prisma.strategy.findFirst({
      where: {
        id: req.params.id,
        OR: [
          { userId: req.userId },
          { isPublic: true },
        ],
      },
    });

    if (!strategy) {
      throw new NotFoundError("Strategy", req.params.id);
    }

    res.json({
      success: true,
      data: strategy,
    });
  } catch (error) {
    next(error);
  }
}

export async function updateStrategy(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const strategy = await prisma.strategy.findFirst({
      where: { id: req.params.id, userId: req.userId },
    });

    if (!strategy) {
      throw new NotFoundError("Strategy", req.params.id);
    }

    const updated = await prisma.strategy.update({
      where: { id: req.params.id },
      data: {
        ...req.body,
        version: strategy.version + 1,
      },
    });

    res.json({
      success: true,
      data: updated,
    });
  } catch (error) {
    next(error);
  }
}

export async function deleteStrategy(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const strategy = await prisma.strategy.findFirst({
      where: { id: req.params.id, userId: req.userId },
    });

    if (!strategy) {
      throw new NotFoundError("Strategy", req.params.id);
    }

    await prisma.strategy.delete({ where: { id: req.params.id } });

    res.json({
      success: true,
      data: { message: "Strategy deleted successfully" },
    });
  } catch (error) {
    next(error);
  }
}

export async function duplicateStrategy(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const strategy = await prisma.strategy.findFirst({
      where: {
        id: req.params.id,
        OR: [
          { userId: req.userId },
          { isPublic: true },
        ],
      },
    });

    if (!strategy) {
      throw new NotFoundError("Strategy", req.params.id);
    }

    const duplicate = await prisma.strategy.create({
      data: {
        userId: req.userId,
        name: `${strategy.name} (Copy)`,
        description: strategy.description,
        strategyJson: strategy.strategyJson as any,
        conditionBlocks: strategy.conditionBlocks as any,
        isPublic: false,
        tags: strategy.tags,
      },
    });

    res.status(201).json({
      success: true,
      data: duplicate,
    });
  } catch (error) {
    next(error);
  }
}