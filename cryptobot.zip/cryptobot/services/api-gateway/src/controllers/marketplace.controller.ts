import { Request, Response, NextFunction } from "express";
import { prisma } from "../prisma/client";
import { NotFoundError, AppError } from "../utils/errors";
import { ErrorCode } from "../../../shared/types/api.types";
import { logger } from "../utils/logger";

export async function listStrategies(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const page = parseInt(req.query.page as string) || 1;
    const limit = Math.min(parseInt(req.query.limit as string) || 20, 100);
    const tier = req.query.tier as string | undefined;
    const sortBy = req.query.sortBy as string || "thirtyDayROI";

    const where: any = { isPublished: true };
    if (tier) where.tier = tier;

    const orderBy: any = {};
    const allowedSorts = ["thirtyDayROI", "rating", "totalSubscribers", "createdAt"];
    if (allowedSorts.includes(sortBy)) {
      orderBy[sortBy] = "desc";
    }

    const [strategies, total] = await Promise.all([
      prisma.marketplaceStrategy.findMany({
        where,
        orderBy,
        skip: (page - 1) * limit,
        take: limit,
        include: {
          author: { select: { id: true, email: true } },
          reviews: { select: { rating: true }, take: 1 },
        },
      }),
      prisma.marketplaceStrategy.count({ where }),
    ]);

    res.json({
      success: true,
      data: strategies,
      meta: {
        pagination: {
          page,
          limit,
          total,
          totalPages: Math.ceil(total / limit),
          hasNext: page * limit < total,
          hasPrev: page > 1,
        },
      },
    });
  } catch (error) {
    next(error);
  }
}

export async function getStrategy(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const strategy = await prisma.marketplaceStrategy.findUnique({
      where: { id: req.params.id },
      include: {
        author: { select: { id: true, email: true } },
        reviews: {
          include: { user: { select: { id: true, email: true } } },
          orderBy: { createdAt: "desc" },
          take: 50,
        },
      },
    });

    if (!strategy || !strategy.isPublished) {
      throw new NotFoundError("Strategy", req.params.id);
    }

    res.json({
      success: true,
      data: strategy,
    });
  } catch (error) {
    next(error);
  }
}

export async function publishStrategy(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const { strategyId, tier, price, subscriptionPrice } = req.body;

    const strategy = await prisma.strategy.findFirst({
      where: { id: strategyId, userId: req.userId },
    });

    if (!strategy) {
      throw new NotFoundError("Strategy", strategyId);
    }

    const published = await prisma.marketplaceStrategy.create({
      data: {
        authorId: req.userId,
        name: strategy.name,
        description: strategy.description,
        strategyJson: strategy.strategyJson as any,
        tier: tier || "free",
        price: price || 0,
        subscriptionPrice: subscriptionPrice || 0,
        isPublished: true,
      },
    });

    logger.info(`Strategy published to marketplace: ${published.id}`, { userId: req.userId });

    res.status(201).json({
      success: true,
      data: published,
    });
  } catch (error) {
    next(error);
  }
}

export async function addReview(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const { rating, body } = req.body;
    const strategyId = req.params.id;

    const strategy = await prisma.marketplaceStrategy.findUnique({
      where: { id: strategyId },
    });

    if (!strategy) {
      throw new NotFoundError("Strategy", strategyId);
    }

    const review = await prisma.marketplaceReview.upsert({
      where: {
        userId_strategyId: { userId: req.userId, strategyId },
      },
      create: {
        userId: req.userId,
        strategyId,
        rating,
        body,
      },
      update: {
        rating,
        body,
      },
    });

    // Update average rating
    const allReviews = await prisma.marketplaceReview.findMany({
      where: { strategyId },
      select: { rating: true },
    });
    const avgRating = allReviews.reduce((sum, r) => sum + r.rating, 0) / allReviews.length;

    await prisma.marketplaceStrategy.update({
      where: { id: strategyId },
      data: { rating: parseFloat(avgRating.toFixed(2)) },
    });

    res.json({
      success: true,
      data: review,
    });
  } catch (error) {
    next(error);
  }
}

export async function getLeaderboard(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const period = req.query.period as string || "30d";
    const limit = Math.min(parseInt(req.query.limit as string) || 20, 100);

    const strategies = await prisma.marketplaceStrategy.findMany({
      where: { isPublished: true },
      orderBy: { thirtyDayROI: "desc" },
      take: limit,
      include: {
        author: { select: { id: true, email: true } },
      },
    });

    res.json({
      success: true,
      data: strategies,
    });
  } catch (error) {
    next(error);
  }
}