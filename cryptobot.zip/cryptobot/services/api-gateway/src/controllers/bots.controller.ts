import { Request, Response, NextFunction } from "express";
import { prisma } from "../prisma/client";
import { vaultDecryptCredential } from "../utils/vaultClient";
import { NotFoundError, AppError } from "../utils/errors";
import { ErrorCode } from "../../../shared/types/api.types";
import { redis } from "../utils/redis";
import { logger } from "../utils/logger";

export async function createBot(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const { name, credentialId, exchange, pair, strategyType, config, paperTrading, maxActiveDeals, maxDailyDeals, pairlistConfig, protectionConfig, dealStartConditions } = req.body;

    const credential = await prisma.apiCredential.findFirst({
      where: { id: credentialId, userId: req.userId },
    });

    if (!credential) {
      throw new NotFoundError("Credential", credentialId);
    }

    const bot = await prisma.bot.create({
      data: {
        userId: req.userId,
        credentialId,
        name,
        exchange,
        pair,
        strategyType,
        config: config as any,
        status: "stopped",
        paperTrading: paperTrading ?? true,
        maxActiveDeals: maxActiveDeals ?? 5,
        maxDailyDeals: maxDailyDeals ?? 50,
        pairlistConfig: pairlistConfig ?? null,
        protectionConfig: protectionConfig ?? null,
        dealStartConditions: dealStartConditions ?? null,
      },
    });

    logger.info(`Bot created: ${bot.id}`, { userId: req.userId, botId: bot.id });

    res.status(201).json({
      success: true,
      data: bot,
    });
  } catch (error) {
    next(error);
  }
}

export async function getBots(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const page = parseInt(req.query.page as string) || 1;
    const limit = Math.min(parseInt(req.query.limit as string) || 20, 100);
    const status = req.query.status as string | undefined;

    const where: any = { userId: req.userId };
    if (status) where.status = status;

    const [bots, total] = await Promise.all([
      prisma.bot.findMany({
        where,
        orderBy: { createdAt: "desc" },
        skip: (page - 1) * limit,
        take: limit,
      }),
      prisma.bot.count({ where }),
    ]);

    res.json({
      success: true,
      data: bots,
      meta: {
        pagination: {
          page,
          limit,
          total,
          totalPages: Math.ceil(total / limit),
          hasNext: page * limit < total,
          hasPrev: page > 1,
        },
      },
    });
  } catch (error) {
    next(error);
  }
}

export async function getBot(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const bot = await prisma.bot.findFirst({
      where: { id: req.params.id, userId: req.userId },
      include: {
        positions: { where: { status: "open" } },
        trades: { orderBy: { createdAt: "desc" }, take: 50 },
      },
    });

    if (!bot) {
      throw new NotFoundError("Bot", req.params.id);
    }

    res.json({
      success: true,
      data: bot,
    });
  } catch (error) {
    next(error);
  }
}

export async function updateBot(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const bot = await prisma.bot.findFirst({
      where: { id: req.params.id, userId: req.userId },
    });

    if (!bot) {
      throw new NotFoundError("Bot", req.params.id);
    }

    const updated = await prisma.bot.update({
      where: { id: req.params.id },
      data: {
        ...req.body,
        version: bot.version + 1,
      },
    });

    logger.info(`Bot updated: ${bot.id}`, { userId: req.userId });

    res.json({
      success: true,
      data: updated,
    });
  } catch (error) {
    next(error);
  }
}

export async function deleteBot(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const bot = await prisma.bot.findFirst({
      where: { id: req.params.id, userId: req.userId },
    });

    if (!bot) {
      throw new NotFoundError("Bot", req.params.id);
    }

    if (bot.status === "active") {
      throw new AppError(ErrorCode.BOT_ALREADY_RUNNING, "Stop the bot before deleting it");
    }

    await prisma.bot.delete({ where: { id: req.params.id } });

    logger.info(`Bot deleted: ${bot.id}`, { userId: req.userId });

    res.json({
      success: true,
      data: { message: "Bot deleted successfully" },
    });
  } catch (error) {
    next(error);
  }
}

export async function startBot(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const bot = await prisma.bot.findFirst({
      where: { id: req.params.id, userId: req.userId },
    });

    if (!bot) {
      throw new NotFoundError("Bot", req.params.id);
    }

    if (bot.status === "active") {
      throw new AppError(ErrorCode.BOT_ALREADY_RUNNING, "Bot is already running");
    }

    const updated = await prisma.bot.update({
      where: { id: req.params.id },
      data: { status: "active" },
    });

    // Publish to trading engine
    await redis.publish("bot:command:start", JSON.stringify({ botId: bot.id, userId: req.userId }));

    logger.info(`Bot started: ${bot.id}`, { userId: req.userId });

    res.json({
      success: true,
      data: updated,
    });
  } catch (error) {
    next(error);
  }
}

export async function stopBot(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const bot = await prisma.bot.findFirst({
      where: { id: req.params.id, userId: req.userId },
    });

    if (!bot) {
      throw new NotFoundError("Bot", req.params.id);
    }

    const updated = await prisma.bot.update({
      where: { id: req.params.id },
      data: { status: "stopped" },
    });

    await redis.publish("bot:command:stop", JSON.stringify({ botId: bot.id, userId: req.userId }));

    logger.info(`Bot stopped: ${bot.id}`, { userId: req.userId });

    res.json({
      success: true,
      data: updated,
    });
  } catch (error) {
    next(error);
  }
}

export async function pauseBot(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const bot = await prisma.bot.findFirst({
      where: { id: req.params.id, userId: req.userId },
    });

    if (!bot) {
      throw new NotFoundError("Bot", req.params.id);
    }

    const updated = await prisma.bot.update({
      where: { id: req.params.id },
      data: { status: "paused" },
    });

    await redis.publish("bot:command:pause", JSON.stringify({ botId: bot.id, userId: req.userId }));

    res.json({
      success: true,
      data: updated,
    });
  } catch (error) {
    next(error);
  }
}

export async function getBotPerformance(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const bot = await prisma.bot.findFirst({
      where: { id: req.params.id, userId: req.userId },
    });

    if (!bot) {
      throw new NotFoundError("Bot", req.params.id);
    }

    const [totalTrades, winningTrades, positions] = await Promise.all([
      prisma.trade.count({ where: { botId: bot.id, status: "filled" } }),
      prisma.trade.count({
        where: {
          botId: bot.id,
          status: "filled",
          filledPrice: { not: null },
        },
      }),
      prisma.position.findMany({
        where: { botId: bot.id },
        orderBy: { openedAt: "desc" },
        take: 100,
      }),
    ]);

    const closedPositions = positions.filter((p) => p.status === "closed");
    const profitablePositions = closedPositions.filter((p) => p.realizedPnl > 0);

    const stats = {
      totalTrades,
      winningTrades,
      winRate: totalTrades > 0 ? (winningTrades / totalTrades) * 100 : 0,
      totalPnl: bot.totalPnl,
      avgDealDuration: 0,
      bestDeal: null as any,
      worstDeal: null as any,
      positions,
    };

    if (closedPositions.length > 0) {
      const sortedByPnl = [...closedPositions].sort((a, b) => b.realizedPnl - a.realizedPnl);
      stats.bestDeal = {
        pair: sortedByPnl[0]?.pair,
        profit: sortedByPnl[0]?.realizedPnl,
        openedAt: sortedByPnl[0]?.openedAt,
      };
      stats.worstDeal = {
        pair: sortedByPnl[closedPositions.length - 1]?.pair,
        loss: sortedByPnl[closedPositions.length - 1]?.realizedPnl,
        openedAt: sortedByPnl[closedPositions.length - 1]?.openedAt,
      };
    }

    res.json({
      success: true,
      data: stats,
    });
  } catch (error) {
    next(error);
  }
}

export async function getAIGridSuggestion(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const { pair, exchange, balance } = req.query;

    if (!pair || !exchange) {
      throw new AppError(ErrorCode.VAL_MISSING_FIELD, "pair and exchange query parameters are required");
    }

    const balanceNum = parseFloat(balance as string) || 1000;

    // In production, this calls the market-data service for OHLCV data
    // For now, return a reasonable default
    const defaultSuggestions: Record<string, any> = {
      "BTC/USDT": { lower: 60000, upper: 70000, levels: 20, volatility: 0.02 },
      "ETH/USDT": { lower: 3000, upper: 4000, levels: 25, volatility: 0.03 },
      "SOL/USDT": { lower: 120, upper: 180, levels: 30, volatility: 0.04 },
    };

    const key = pair as string;
    const suggestion = defaultSuggestions[key] || { lower: 50, upper: 150, levels: 20, volatility: 0.03 };

    const priceRange = suggestion.upper - suggestion.lower;
    const qtyPerGrid = balanceNum / suggestion.levels;

    res.json({
      success: true,
      data: {
        suggestedLower: suggestion.lower,
        suggestedUpper: suggestion.upper,
        suggestedLevels: suggestion.levels,
        suggestedQtyPerGrid: parseFloat(qtyPerGrid.toFixed(4)),
        explanation: `Based on 7-day range of $${suggestion.lower}-$${suggestion.upper} and average volatility of ${(suggestion.volatility * 100).toFixed(1)}%`,
        volatility: suggestion.volatility,
        priceRange,
        avgCandleSize: priceRange / 168,
      },
    });
  } catch (error) {
    next(error);
  }
}