import { Request, Response, NextFunction } from "express";
import { prisma } from "../prisma/client";
import { vaultEncryptCredential, vaultDecryptCredential, vaultValidateCredential } from "../utils/vaultClient";
import { NotFoundError, AppError } from "../utils/errors";
import { ErrorCode } from "../../../shared/types/api.types";
import { logger } from "../utils/logger";

export async function createCredential(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const { exchange, label, apiKey, apiSecret, passphrase } = req.body;

    // Validate with exchange
    const validation = await vaultValidateCredential(exchange, apiKey, apiSecret, passphrase);
    if (!validation.isValid) {
      throw new AppError(ErrorCode.EXCH_INVALID_CREDENTIALS, validation.errorMessage || "Invalid credentials");
    }
    if (validation.permissions.canWithdraw) {
      throw new AppError(ErrorCode.EXCH_WITHDRAWAL_ENABLED, "API key has withdrawal permissions enabled");
    }

    // Encrypt and store
    const encrypted = await vaultEncryptCredential(apiKey, apiSecret);

    const credential = await prisma.apiCredential.create({
      data: {
        userId: req.userId,
        exchange,
        label,
        encryptedKey: encrypted.encryptedKey,
        encryptedSecret: encrypted.encryptedSecret,
        iv: encrypted.iv,
        authTag: encrypted.authTag,
        permissions: validation.permissions as any,
        isValid: true,
        lastVerifiedAt: new Date(),
      },
    });

    logger.info(`Credential created for ${exchange}`, { userId: req.userId });

    res.status(201).json({
      success: true,
      data: {
        id: credential.id,
        exchange: credential.exchange,
        label: credential.label,
        permissions: credential.permissions,
        isValid: credential.isValid,
      },
    });
  } catch (error) {
    next(error);
  }
}

export async function getCredentials(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const credentials = await prisma.apiCredential.findMany({
      where: { userId: req.userId },
      select: {
        id: true,
        exchange: true,
        label: true,
        permissions: true,
        isValid: true,
        lastVerifiedAt: true,
        createdAt: true,
      },
      orderBy: { createdAt: "desc" },
    });

    res.json({ success: true, data: credentials });
  } catch (error) {
    next(error);
  }
}

export async function getCredential(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const credential = await prisma.apiCredential.findFirst({
      where: { id: req.params.id, userId: req.userId },
      select: {
        id: true, exchange: true, label: true, permissions: true,
        isValid: true, lastVerifiedAt: true, createdAt: true,
      },
    });

    if (!credential) throw new NotFoundError("Credential", req.params.id);

    res.json({ success: true, data: credential });
  } catch (error) {
    next(error);
  }
}

export async function updateCredential(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const credential = await prisma.apiCredential.findFirst({
      where: { id: req.params.id, userId: req.userId },
    });

    if (!credential) throw new NotFoundError("Credential", req.params.id);

    const updated = await prisma.apiCredential.update({
      where: { id: req.params.id },
      data: { label: req.body.label },
    });

    res.json({ success: true, data: updated });
  } catch (error) {
    next(error);
  }
}

export async function deleteCredential(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const credential = await prisma.apiCredential.findFirst({
      where: { id: req.params.id, userId: req.userId },
    });

    if (!credential) throw new NotFoundError("Credential", req.params.id);

    await prisma.apiCredential.delete({ where: { id: req.params.id } });

    res.json({ success: true, data: { message: "Credential deleted" } });
  } catch (error) {
    next(error);
  }
}

export async function validateCredential(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const { exchange, apiKey, apiSecret, passphrase } = req.body;

    const validation = await vaultValidateCredential(exchange, apiKey, apiSecret, passphrase);

    res.json({ success: true, data: validation });
  } catch (error) {
    next(error);
  }
}