import { Request, Response, NextFunction } from "express";
import { prisma } from "../prisma/client";
import { logger } from "../utils/logger";

export async function getPortfolioSummary(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const [bots, positions, trades] = await Promise.all([
      prisma.bot.findMany({
        where: { userId: req.userId },
        select: { id: true, name: true, totalPnl: true, totalTrades: true, winRate: true },
      }),
      prisma.position.findMany({
        where: { userId: req.userId, status: "open" },
      }),
      prisma.trade.findMany({
        where: { userId: req.userId, status: "filled" },
        orderBy: { createdAt: "desc" },
        take: 1000,
      }),
    ]);

    const totalPortfolioValue = positions.reduce((sum, p) => sum + (p.currentPrice * p.quantity), 0);
    const totalUnrealizedPnl = positions.reduce((sum, p) => sum + p.unrealizedPnl, 0);
    const totalRealizedPnl = trades.reduce((sum, t) => {
      if (t.filledPrice && t.price) {
        return sum + ((t.filledPrice - t.price) * t.quantity) - t.fee;
      }
      return sum;
    }, 0);

    const activePositions = positions.length;
    const totalBots = bots.length;
    const activeBots = bots.filter(b => b.totalTrades > 0).length;

    res.json({
      success: true,
      data: {
        totalValue: totalPortfolioValue,
        unrealizedPnl: totalUnrealizedPnl,
        realizedPnl: totalRealizedPnl,
        totalPnl: totalUnrealizedPnl + totalRealizedPnl,
        activePositions,
        totalBots,
        activeBots,
        botPerformance: bots,
      },
    });
  } catch (error) {
    next(error);
  }
}

export async function getPositions(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const status = req.query.status as string || "open";

    const positions = await prisma.position.findMany({
      where: { userId: req.userId, status },
      orderBy: { openedAt: "desc" },
    });

    res.json({
      success: true,
      data: positions,
    });
  } catch (error) {
    next(error);
  }
}

export async function getTradeHistory(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const page = parseInt(req.query.page as string) || 1;
    const limit = Math.min(parseInt(req.query.limit as string) || 50, 200);
    const pair = req.query.pair as string | undefined;
    const days = parseInt(req.query.days as string) || 30;

    const dateFrom = new Date();
    dateFrom.setDate(dateFrom.getDate() - days);

    const where: any = {
      userId: req.userId,
      status: "filled",
      createdAt: { gte: dateFrom },
    };
    if (pair) where.pair = pair;

    const [trades, total] = await Promise.all([
      prisma.trade.findMany({
        where,
        orderBy: { createdAt: "desc" },
        skip: (page - 1) * limit,
        take: limit,
      }),
      prisma.trade.count({ where }),
    ]);

    res.json({
      success: true,
      data: trades,
      meta: {
        pagination: {
          page,
          limit,
          total,
          totalPages: Math.ceil(total / limit),
          hasNext: page * limit < total,
          hasPrev: page > 1,
        },
      },
    });
  } catch (error) {
    next(error);
  }
}

export async function getPerformanceAnalytics(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const days = parseInt(req.query.days as string) || 30;

    const dateFrom = new Date();
    dateFrom.setDate(dateFrom.getDate() - days);

    const trades = await prisma.trade.findMany({
      where: {
        userId: req.userId,
        status: "filled",
        createdAt: { gte: dateFrom },
      },
      orderBy: { createdAt: "asc" },
    });

    // Calculate daily PnL
    const dailyPnl: Record<string, number> = {};
    let cumulativePnl = 0;
    const equityCurve: { date: string; pnl: number }[] = [];

    for (const trade of trades) {
      const date = trade.createdAt.toISOString().split("T")[0]!;
      const tradePnl = trade.filledPrice && trade.price
        ? (trade.filledPrice - trade.price) * trade.quantity - trade.fee
        : 0;

      dailyPnl[date] = (dailyPnl[date] || 0) + tradePnl;
    }

    for (const [date, pnl] of Object.entries(dailyPnl).sort()) {
      cumulativePnl += pnl;
      equityCurve.push({ date, pnl: cumulativePnl });
    }

    // Pair breakdown
    const pairPnl: Record<string, number> = {};
    for (const trade of trades) {
      const tradePnl = trade.filledPrice && trade.price
        ? (trade.filledPrice - trade.price) * trade.quantity - trade.fee
        : 0;
      pairPnl[trade.pair] = (pairPnl[trade.pair] || 0) + tradePnl;
    }

    res.json({
      success: true,
      data: {
        totalTrades: trades.length,
        dailyPnl,
        equityCurve,
        pairBreakdown: Object.entries(pairPnl).map(([pair, pnl]) => ({ pair, pnl })),
        period: { from: dateFrom.toISOString(), days },
      },
    });
  } catch (error) {
    next(error);
  }
}