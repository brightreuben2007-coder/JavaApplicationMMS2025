import { Request, Response, NextFunction } from "express";
import { prisma } from "../prisma/client";
import { NotFoundError } from "../utils/errors";

export async function getTrades(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const page = parseInt(req.query.page as string) || 1;
    const limit = Math.min(parseInt(req.query.limit as string) || 50, 200);
    const botId = req.query.botId as string | undefined;
    const pair = req.query.pair as string | undefined;
    const status = req.query.status as string | undefined;

    const where: any = { userId: req.userId };
    if (botId) where.botId = botId;
    if (pair) where.pair = pair;
    if (status) where.status = status;

    const [trades, total] = await Promise.all([
      prisma.trade.findMany({
        where,
        orderBy: { createdAt: "desc" },
        skip: (page - 1) * limit,
        take: limit,
      }),
      prisma.trade.count({ where }),
    ]);

    res.json({
      success: true,
      data: trades,
      meta: {
        pagination: {
          page,
          limit,
          total,
          totalPages: Math.ceil(total / limit),
          hasNext: page * limit < total,
          hasPrev: page > 1,
        },
      },
    });
  } catch (error) {
    next(error);
  }
}

export async function getTrade(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const trade = await prisma.trade.findFirst({
      where: { id: req.params.id, userId: req.userId },
    });

    if (!trade) {
      throw new NotFoundError("Trade", req.params.id);
    }

    res.json({
      success: true,
      data: trade,
    });
  } catch (error) {
    next(error);
  }
}