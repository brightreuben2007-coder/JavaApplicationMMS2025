import { Request, Response, NextFunction } from "express";
import { prisma } from "../prisma/client";
import { redis } from "../utils/redis";
import { NotFoundError, AppError } from "../utils/errors";
import { ErrorCode } from "../../../shared/types/api.types";
import { v4 as uuidv4 } from "uuid";
import { logger } from "../utils/logger";

export async function runBacktest(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const { strategyId, strategyConfig, pair, timeframe, dateStart, dateEnd, initialBalance, feeRate, slippagePercent } = req.body;

    // Validate strategy exists if strategyId provided
    if (strategyId) {
      const strategy = await prisma.strategy.findFirst({
        where: {
          id: strategyId,
          OR: [{ userId: req.userId }, { isPublic: true }],
        },
      });
      if (!strategy) throw new NotFoundError("Strategy", strategyId);
    }

    // Create job for backtesting service
    const jobId = uuidv4();
    const job = {
      jobId,
      userId: req.userId,
      strategyId,
      strategyConfig,
      pair,
      timeframe,
      dateStart,
      dateEnd,
      initialBalance: initialBalance || 10000,
      feeRate: feeRate || 0.001,
      slippagePercent: slippagePercent || 0.1,
      status: "queued",
      createdAt: new Date().toISOString(),
    };

    await redis.setex(`backtest:job:${jobId}`, 3600, JSON.stringify(job));
    await redis.lpush("backtest:queue", JSON.stringify(job));

    logger.info(`Backtest job created: ${jobId}`, { userId: req.userId });

    res.status(202).json({
      success: true,
      data: { jobId, status: "queued" },
    });
  } catch (error) {
    next(error);
  }
}

export async function getBacktestStatus(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const { jobId } = req.params;
    const jobData = await redis.get(`backtest:job:${jobId}`);

    if (!jobData) {
      throw new NotFoundError("Backtest job", jobId);
    }

    res.json({
      success: true,
      data: JSON.parse(jobData),
    });
  } catch (error) {
    next(error);
  }
}

export async function getBacktestResults(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const page = parseInt(req.query.page as string) || 1;
    const limit = Math.min(parseInt(req.query.limit as string) || 20, 100);

    const [results, total] = await Promise.all([
      prisma.backtestResult.findMany({
        where: { userId: req.userId },
        orderBy: { createdAt: "desc" },
        skip: (page - 1) * limit,
        take: limit,
      }),
      prisma.backtestResult.count({ where: { userId: req.userId } }),
    ]);

    res.json({
      success: true,
      data: results,
      meta: {
        pagination: {
          page,
          limit,
          total,
          totalPages: Math.ceil(total / limit),
          hasNext: page * limit < total,
          hasPrev: page > 1,
        },
      },
    });
  } catch (error) {
    next(error);
  }
}

export async function getBacktestResult(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const result = await prisma.backtestResult.findFirst({
      where: { id: req.params.id, userId: req.userId },
    });

    if (!result) {
      throw new NotFoundError("Backtest result", req.params.id);
    }

    res.json({
      success: true,
      data: result,
    });
  } catch (error) {
    next(error);
  }
}

export async function runHyperopt(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const { strategyId, paramSearchSpace, optimizationTarget, algorithm, dateRange, timeframe, pair, initialBalance } = req.body;

    const strategy = await prisma.strategy.findFirst({
      where: { id: strategyId, userId: req.userId },
    });

    if (!strategy) {
      throw new NotFoundError("Strategy", strategyId);
    }

    const jobId = uuidv4();
    const job = {
      jobId,
      userId: req.userId,
      strategyId,
      paramSearchSpace,
      optimizationTarget: optimizationTarget || "sharpe",
      algorithm: algorithm || "bayesian",
      dateRange,
      timeframe: timeframe || "1h",
      pair,
      initialBalance: initialBalance || 10000,
      status: "queued",
      progress: 0,
      totalCombinations: 0,
      completedCombinations: 0,
      bestResult: null,
      createdAt: new Date().toISOString(),
    };

    await redis.setex(`hyperopt:job:${jobId}`, 7200, JSON.stringify(job));
    await redis.lpush("hyperopt:queue", JSON.stringify(job));

    logger.info(`Hyperopt job created: ${jobId}`, { userId: req.userId });

    res.status(202).json({
      success: true,
      data: { jobId, status: "queued" },
    });
  } catch (error) {
    next(error);
  }
}

export async function getHyperoptStatus(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const { jobId } = req.params;
    const jobData = await redis.get(`hyperopt:job:${jobId}`);

    if (!jobData) {
      throw new NotFoundError("Hyperopt job", jobId);
    }

    res.json({
      success: true,
      data: JSON.parse(jobData),
    });
  } catch (error) {
    next(error);
  }
}