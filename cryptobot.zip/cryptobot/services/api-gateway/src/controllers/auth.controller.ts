import { Request, Response, NextFunction } from "express";
import bcrypt from "bcryptjs";
import speakeasy from "speakeasy";
import QRCode from "qrcode";
import {
  generateRegistrationOptions,
  verifyRegistrationResponse,
  generateAuthenticationOptions,
  verifyAuthenticationResponse,
} from "@simplewebauthn/server";
import type {
  AuthenticatorTransportFuture,
  CredentialDeviceType,
  Base64URLString,
} from "@simplewebauthn/types";
import { v4 as uuidv4 } from "uuid";
import { prisma } from "../prisma/client";
import {
  generateAccessToken,
  generateRefreshToken,
  verifyRefreshToken,
} from "../utils/jwt";
import {
  blacklistToken,
  isTokenBlacklisted,
  cacheSet,
  cacheDel,
} from "../utils/redis";
import { AuthError, ConflictError, AppError } from "../utils/errors";
import { ErrorCode } from "../../../shared/types/api.types";
import { logger } from "../utils/logger";

// ============================================================
// HELPER: Generate token pair
// ============================================================
const ACCESS_TOKEN_TTL = 15 * 60; // 15 minutes in seconds
const REFRESH_TOKEN_TTL = 7 * 24 * 60 * 60; // 7 days in seconds

async function generateTokenPair(userId: string, email: string, planTier: string) {
  const tokenFamily = uuidv4();
  const accessToken = generateAccessToken(userId, email, planTier);
  const refreshToken = generateRefreshToken(userId, tokenFamily);

  // Cache the token family for rotation
  await cacheSet(`token_family:${tokenFamily}`, userId, REFRESH_TOKEN_TTL);

  return { accessToken, refreshToken, tokenFamily, expiresIn: ACCESS_TOKEN_TTL };
}

// ============================================================
// REGISTER
// ============================================================
export async function register(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const { email, password } = req.body;

    // Check if user already exists
    const existingUser = await prisma.user.findUnique({
      where: { email },
    });

    if (existingUser) {
      throw new ConflictError("An account with this email already exists");
    }

    // Hash password
    const passwordHash = await bcrypt.hash(password, 12);

    // Create user
    const user = await prisma.user.create({
      data: {
        email,
        passwordHash,
        demoMode: false,
      },
    });

    // Assign free plan
    const freePlan = await prisma.plan.findFirst({
      where: { tier: "free" as any },
    });

    if (freePlan) {
      await prisma.user.update({
        where: { id: user.id },
        data: { planId: freePlan.id },
      });
    }

    // Generate tokens
    const tokens = await generateTokenPair(user.id, user.email, freePlan?.name?.toLowerCase() || "free");

    // Set refresh token in httpOnly cookie
    res.cookie("refreshToken", tokens.refreshToken, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "strict",
      maxAge: REFRESH_TOKEN_TTL * 1000,
      path: "/api/v1/auth",
    });

    logger.info(`User registered: ${user.email}`, { userId: user.id });

    res.status(201).json({
      success: true,
      data: {
        user: {
          id: user.id,
          email: user.email,
          planTier: freePlan?.name?.toLowerCase() || "free",
          onboardingCompleted: false,
        },
        accessToken: tokens.accessToken,
        expiresIn: tokens.expiresIn,
      },
    });
  } catch (error) {
    next(error);
  }
}

// ============================================================
// LOGIN
// ============================================================
export async function login(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const { email, password, totpCode } = req.body;

    // Find user
    const user = await prisma.user.findUnique({
      where: { email },
      include: { plan: true },
    });

    if (!user) {
      throw new AuthError(ErrorCode.AUTH_INVALID_CREDENTIALS, "Invalid email or password");
    }

    // Verify password
    const isPasswordValid = await bcrypt.compare(password, user.passwordHash);
    if (!isPasswordValid) {
      throw new AuthError(ErrorCode.AUTH_INVALID_CREDENTIALS, "Invalid email or password");
    }

    // Check IP whitelist
    if (user.ipWhitelist.length > 0) {
      const clientIp = req.ip || req.socket.remoteAddress || "";
      if (!user.ipWhitelist.includes(clientIp)) {
        throw new AuthError(
          ErrorCode.AUTH_IP_NOT_WHITELISTED,
          "Your IP address is not whitelisted. Please contact support."
        );
      }
    }

    // Check TOTP if enabled
    if (user.totpSecret) {
      if (!totpCode) {
        // TOTP required but not provided - tell client to prompt for it
        res.status(200).json({
          success: true,
          data: {
            requiresTotp: true,
            message: "TOTP code required",
          },
        });
        return;
      }

      const isTotpValid = speakeasy.totp.verify({
        secret: user.totpSecret,
        encoding: "base32",
        token: totpCode,
        window: 1,
      });

      if (!isTotpValid) {
        throw new AuthError(ErrorCode.AUTH_TOTP_INVALID, "Invalid TOTP code");
      }
    }

    // Generate tokens
    const planTier = user.plan?.name?.toLowerCase() || "free";
    const tokens = await generateTokenPair(user.id, user.email, planTier);

    // Set refresh token
    res.cookie("refreshToken", tokens.refreshToken, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "strict",
      maxAge: REFRESH_TOKEN_TTL * 1000,
      path: "/api/v1/auth",
    });

    logger.info(`User logged in: ${user.email}`, { userId: user.id });

    res.json({
      success: true,
      data: {
        user: {
          id: user.id,
          email: user.email,
          planTier,
          onboardingCompleted: user.onboardingCompleted,
          demoMode: user.demoMode,
        },
        accessToken: tokens.accessToken,
        expiresIn: tokens.expiresIn,
      },
    });
  } catch (error) {
    next(error);
  }
}

// ============================================================
// REFRESH TOKEN
// ============================================================
export async function refreshToken(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    // Get refresh token from cookie
    const token = req.cookies?.refreshToken;

    if (!token) {
      throw new AuthError(ErrorCode.AUTH_TOKEN_INVALID, "Refresh token is required");
    }

    // Verify refresh token
    const payload = verifyRefreshToken(token);

    // Check if token family is blacklisted
    const isBlacklisted = await isTokenBlacklisted(payload.tokenFamily);
    if (isBlacklisted) {
      // Token family has been revoked - possible token theft
      // Blacklist ALL token families for this user to force re-login
      await cacheSet(`token_family:${payload.tokenFamily}:compromised`, true, REFRESH_TOKEN_TTL);
      throw new AuthError(ErrorCode.AUTH_TOKEN_INVALID, "Token has been revoked");
    }

    // Get user
    const user = await prisma.user.findUnique({
      where: { id: payload.sub },
      include: { plan: true },
    });

    if (!user) {
      throw new AuthError(ErrorCode.AUTH_TOKEN_INVALID, "User not found");
    }

    // Rotate: blacklist old token family, issue new one
    await blacklistToken(payload.tokenFamily, REFRESH_TOKEN_TTL);

    // Generate new token pair
    const planTier = user.plan?.name?.toLowerCase() || "free";
    const tokens = await generateTokenPair(user.id, user.email, planTier);

    // Set new refresh token
    res.cookie("refreshToken", tokens.refreshToken, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "strict",
      maxAge: REFRESH_TOKEN_TTL * 1000,
      path: "/api/v1/auth",
    });

    logger.info(`Tokens refreshed for user ${user.id}`);

    res.json({
      success: true,
      data: {
        accessToken: tokens.accessToken,
        expiresIn: tokens.expiresIn,
      },
    });
  } catch (error) {
    // Clear invalid cookie
    res.clearCookie("refreshToken", { path: "/api/v1/auth" });
    next(error);
  }
}

// ============================================================
// LOGOUT
// ============================================================
export async function logout(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const token = req.cookies?.refreshToken;

    if (token) {
      try {
        const payload = verifyRefreshToken(token);
        await blacklistToken(payload.tokenFamily, REFRESH_TOKEN_TTL);
      } catch {
        // Token already invalid - that's fine for logout
      }
    }

    res.clearCookie("refreshToken", { path: "/api/v1/auth" });

    logger.info(`User logged out: ${req.userId}`);

    res.json({
      success: true,
      data: { message: "Logged out successfully" },
    });
  } catch (error) {
    next(error);
  }
}

// ============================================================
// TOTP SETUP (2FA)
// ============================================================
export async function setupTotp(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const user = await prisma.user.findUnique({
      where: { id: req.userId },
    });

    if (!user) {
      throw new AppError(ErrorCode.RES_NOT_FOUND, "User not found");
    }

    if (user.totpSecret) {
      throw new ConflictError("TOTP is already configured. Disable it first to reconfigure.");
    }

    // Generate secret
    const secret = speakeasy.generateSecret({
      name: `CryptoBot (${user.email})`,
      length: 20,
    });

    // Generate QR code
    const qrCodeDataUrl = await QRCode.toDataURL(secret.otpauth_url!);

    // Store secret temporarily (will be confirmed in verify step)
    await cacheSet(`totp_setup:${user.id}`, secret.base32, 600); // 10 min expiry

    res.json({
      success: true,
      data: {
        secret: secret.base32,
        qrCode: qrCodeDataUrl,
        otpauthUrl: secret.otpauth_url,
      },
    });
  } catch (error) {
    next(error);
  }
}

export async function verifyTotp(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const { token } = req.body;

    // Get temporary secret
    const cachedSecret = await cacheGet<string>(`totp_setup:${req.userId}`);
    if (!cachedSecret) {
      throw new AppError(
        ErrorCode.RES_GONE,
        "TOTP setup session expired. Please restart the setup process."
      );
    }

    const isValid = speakeasy.totp.verify({
      secret: cachedSecret,
      encoding: "base32",
      token,
      window: 1,
    });

    if (!isValid) {
      throw new AuthError(ErrorCode.AUTH_TOTP_INVALID, "Invalid TOTP code");
    }

    // Save the secret to user
    await prisma.user.update({
      where: { id: req.userId },
      data: { totpSecret: cachedSecret },
    });

    // Clean up
    await cacheDel(`totp_setup:${req.userId}`);

    logger.info(`TOTP enabled for user ${req.userId}`);

    res.json({
      success: true,
      data: { message: "TOTP enabled successfully" },
    });
  } catch (error) {
    next(error);
  }
}

export async function disableTotp(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const { token } = req.body;

    const user = await prisma.user.findUnique({
      where: { id: req.userId },
    });

    if (!user?.totpSecret) {
      throw new AppError(ErrorCode.RES_NOT_FOUND, "TOTP is not enabled");
    }

    // Verify current TOTP before disabling
    const isValid = speakeasy.totp.verify({
      secret: user.totpSecret,
      encoding: "base32",
      token,
      window: 1,
    });

    if (!isValid) {
      throw new AuthError(ErrorCode.AUTH_TOTP_INVALID, "Invalid TOTP code");
    }

    await prisma.user.update({
      where: { id: req.userId },
      data: { totpSecret: null },
    });

    logger.info(`TOTP disabled for user ${req.userId}`);

    res.json({
      success: true,
      data: { message: "TOTP disabled successfully" },
    });
  } catch (error) {
    next(error);
  }
}

// ============================================================
// WebAuthn (Passkey) Setup
// ============================================================
const RP_NAME = "CryptoBot";
const RP_ID = process.env.WEBAUTHN_RP_ID || "localhost";
const RP_ORIGIN = process.env.FRONTEND_URL || "http://localhost:3001";

export async function webauthnRegistrationOptions(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const user = await prisma.user.findUnique({
      where: { id: req.userId },
    });

    if (!user) {
      throw new AppError(ErrorCode.RES_NOT_FOUND, "User not found");
    }

    // Get existing credentials
    const existingCredentials: any[] = [];
    if (user.webauthnCredentials) {
      const creds = user.webauthnCredentials as any;
      if (Array.isArray(creds)) {
        for (const cred of creds) {
          existingCredentials.push({
            id: cred.id,
            type: "public-key",
            transports: cred.transports as AuthenticatorTransportFuture[],
          });
        }
      }
    }

    const options = await generateRegistrationOptions({
      rpName: RP_NAME,
      rpID: RP_ID,
      userName: user.email,
      userDisplayName: user.email,
      attestationType: "none",
      excludeCredentials: existingCredentials,
      authenticatorSelection: {
        residentKey: "preferred",
        userVerification: "preferred",
      },
    });

    // Store challenge for verification
    await cacheSet(`webauthn:register:${user.id}`, options.challenge, 300);

    res.json({
      success: true,
      data: options,
    });
  } catch (error) {
    next(error);
  }
}

export async function webauthnRegistrationVerify(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const user = await prisma.user.findUnique({
      where: { id: req.userId },
    });

    if (!user) {
      throw new AppError(ErrorCode.RES_NOT_FOUND, "User not found");
    }

    const cachedChallenge = await cacheGet<string>(`webauthn:register:${user.id}`);
    if (!cachedChallenge) {
      throw new AppError(ErrorCode.RES_GONE, "Registration session expired");
    }

    const verification = await verifyRegistrationResponse({
      response: req.body,
      expectedChallenge: cachedChallenge,
      expectedOrigin: RP_ORIGIN,
      expectedRPID: RP_ID,
    });

    if (!verification.verified || !verification.registrationInfo) {
      throw new AuthError(ErrorCode.AUTH_WEB_AUTHN_FAILED, "WebAuthn verification failed");
    }

    // Store the credential
    const newCredential = {
      id: verification.registrationInfo.credential.id,
      publicKey: Buffer.from(
        verification.registrationInfo.credential.publicKey
      ).toString("base64"),
      counter: verification.registrationInfo.credential.counter,
      deviceType: verification.registrationInfo.credentialDeviceType as CredentialDeviceType,
      backedUp: verification.registrationInfo.credentialBackedUp,
      transports: req.body.response?.transports || [],
      createdAt: new Date().toISOString(),
    };

    // Merge with existing credentials
    const existingCredentials = (user.webauthnCredentials as any[]) || [];
    const updatedCredentials = [...existingCredentials, newCredential];

    await prisma.user.update({
      where: { id: req.userId },
      data: { webauthnCredentials: updatedCredentials as any },
    });

    await cacheDel(`webauthn:register:${user.id}`);

    logger.info(`WebAuthn credential registered for user ${user.id}`);

    res.json({
      success: true,
      data: {
        id: newCredential.id,
        deviceType: newCredential.deviceType,
        backedUp: newCredential.backedUp,
      },
    });
  } catch (error) {
    next(error);
  }
}

export async function webauthnAuthenticationOptions(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const { email } = req.body;

    const user = await prisma.user.findUnique({
      where: { email },
    });

    if (!user) {
      // Don't reveal if user exists or not
      res.json({ success: true, data: {} });
      return;
    }

    const options = await generateAuthenticationOptions({
      rpID: RP_ID,
      allowCredentials: [],
      userVerification: "preferred",
    });

    await cacheSet(`webauthn:auth:${user.id}`, options.challenge, 300);

    res.json({
      success: true,
      data: options,
    });
  } catch (error) {
    next(error);
  }
}

export async function webauthnAuthenticationVerify(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const { email, credential } = req.body;

    const user = await prisma.user.findUnique({
      where: { email },
      include: { plan: true },
    });

    if (!user) {
      throw new AuthError(ErrorCode.AUTH_INVALID_CREDENTIALS, "Invalid credentials");
    }

    const cachedChallenge = await cacheGet<string>(`webauthn:auth:${user.id}`);
    if (!cachedChallenge) {
      throw new AppError(ErrorCode.RES_GONE, "Authentication session expired");
    }

    // Find the stored credential
    const storedCredentials = (user.webauthnCredentials as any[]) || [];
    const storedCredential = storedCredentials.find(
      (c: any) => c.id === credential.id
    );

    if (!storedCredential) {
      throw new AuthError(ErrorCode.AUTH_WEB_AUTHN_FAILED, "Credential not found");
    }

    const verification = await verifyAuthenticationResponse({
      response: credential,
      expectedChallenge: cachedChallenge,
      expectedOrigin: RP_ORIGIN,
      expectedRPID: RP_ID,
      credential: {
        id: storedCredential.id,
        publicKey: Buffer.from(storedCredential.publicKey, "base64"),
        counter: storedCredential.counter,
        transports: storedCredential.transports as AuthenticatorTransportFuture[],
      },
    });

    if (!verification.verified) {
      throw new AuthError(ErrorCode.AUTH_WEB_AUTHN_FAILED, "WebAuthn authentication failed");
    }

    // Update counter
    const updatedCredentials = storedCredentials.map((c: any) => {
      if (c.id === storedCredential.id) {
        return { ...c, counter: verification.authenticationInfo.newCounter };
      }
      return c;
    });

    await prisma.user.update({
      where: { id: user.id },
      data: { webauthnCredentials: updatedCredentials as any },
    });

    await cacheDel(`webauthn:auth:${user.id}`);

    // Generate tokens
    const planTier = user.plan?.name?.toLowerCase() || "free";
    const tokens = await generateTokenPair(user.id, user.email, planTier);

    res.cookie("refreshToken", tokens.refreshToken, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "strict",
      maxAge: REFRESH_TOKEN_TTL * 1000,
      path: "/api/v1/auth",
    });

    logger.info(`WebAuthn login for user ${user.id}`);

    res.json({
      success: true,
      data: {
        user: {
          id: user.id,
          email: user.email,
          planTier,
          onboardingCompleted: user.onboardingCompleted,
        },
        accessToken: tokens.accessToken,
        expiresIn: tokens.expiresIn,
      },
    });
  } catch (error) {
    next(error);
  }
}

// ============================================================
// CURRENT USER / ME
// ============================================================
export async function getCurrentUser(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const user = await prisma.user.findUnique({
      where: { id: req.userId },
      include: { plan: true },
    });

    if (!user) {
      throw new AppError(ErrorCode.RES_NOT_FOUND, "User not found");
    }

    res.json({
      success: true,
      data: {
        id: user.id,
        email: user.email,
        planTier: user.plan?.name?.toLowerCase() || "free",
        onboardingCompleted: user.onboardingCompleted,
        demoMode: user.demoMode,
        hasTotp: !!user.totpSecret,
        hasWebAuthn: !!(user.webauthnCredentials as any[])?.length,
        createdAt: user.createdAt,
      },
    });
  } catch (error) {
    next(error);
  }
}