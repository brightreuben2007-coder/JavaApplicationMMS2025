import { Request, Response, NextFunction } from "express";
import { prisma } from "../prisma/client";
import { redis } from "../utils/redis";
import { NotFoundError, AppError } from "../utils/errors";
import { ErrorCode } from "../../../shared/types/api.types";
import { logger } from "../utils/logger";

export async function createSmartTrade(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const { credentialId, exchange, pair, side, entryType, entryPrice, entryQuantity, takeProfitLevels, stopLoss, trailingStop, leverage } = req.body;

    const credential = await prisma.apiCredential.findFirst({
      where: { id: credentialId, userId: req.userId },
    });

    if (!credential) {
      throw new NotFoundError("Credential", credentialId);
    }

    const smartTrade = await prisma.smartTrade.create({
      data: {
        userId: req.userId,
        credentialId,
        exchange,
        pair,
        side,
        entryType,
        entryPrice: entryPrice || null,
        entryQty: entryQuantity,
        tpLevels: takeProfitLevels as any,
        stopLoss: stopLoss?.price || null,
        trailingStop: trailingStop as any,
        status: "pending",
      },
    });

    // Send to trading engine
    await redis.publish("smarttrade:new", JSON.stringify({
      smartTradeId: smartTrade.id,
      userId: req.userId,
      credentialId,
      exchange,
      pair,
      side,
      entryType,
      entryPrice,
      entryQuantity,
      takeProfitLevels,
      stopLoss,
      trailingStop,
      leverage,
    }));

    logger.info(`SmartTrade created: ${smartTrade.id}`, { userId: req.userId });

    res.status(201).json({
      success: true,
      data: smartTrade,
    });
  } catch (error) {
    next(error);
  }
}

export async function getSmartTrades(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const status = req.query.status as string | undefined;
    const page = parseInt(req.query.page as string) || 1;
    const limit = Math.min(parseInt(req.query.limit as string) || 20, 100);

    const where: any = { userId: req.userId };
    if (status) where.status = status;

    const [trades, total] = await Promise.all([
      prisma.smartTrade.findMany({
        where,
        orderBy: { createdAt: "desc" },
        skip: (page - 1) * limit,
        take: limit,
      }),
      prisma.smartTrade.count({ where }),
    ]);

    res.json({
      success: true,
      data: trades,
      meta: {
        pagination: { page, limit, total, totalPages: Math.ceil(total / limit), hasNext: page * limit < total, hasPrev: page > 1 },
      },
    });
  } catch (error) {
    next(error);
  }
}

export async function cancelSmartTrade(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const trade = await prisma.smartTrade.findFirst({
      where: { id: req.params.id, userId: req.userId },
    });

    if (!trade) {
      throw new NotFoundError("SmartTrade", req.params.id);
    }

    if (trade.status === "tp_complete" || trade.status === "sl_triggered") {
      throw new AppError(ErrorCode.TRD_INVALID_ORDER, "Cannot cancel a completed trade");
    }

    const updated = await prisma.smartTrade.update({
      where: { id: req.params.id },
      data: { status: "cancelled", closedAt: new Date() },
    });

    await redis.publish("smarttrade:cancel", JSON.stringify({ smartTradeId: trade.id, userId: req.userId }));

    res.json({
      success: true,
      data: updated,
    });
  } catch (error) {
    next(error);
  }
}