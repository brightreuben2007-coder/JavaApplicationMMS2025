import { Request, Response, NextFunction } from "express";
import { prisma } from "../prisma/client";
import { redis } from "../utils/redis";
import { tradingViewWebhookSchema } from "../../../shared/validation/schemas";
import { AppError } from "../utils/errors";
import { ErrorCode } from "../../../shared/types/api.types";
import { logger } from "../utils/logger";

export async function handleTradingViewWebhook(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const uuid = req.params.uuid;
    if (!uuid) {
      throw new AppError(ErrorCode.VAL_INVALID_INPUT, "Webhook UUID is required");
    }

    const parsed = tradingViewWebhookSchema.safeParse(req.body);
    if (!parsed.success) {
      await prisma.webhookLog.create({
        data: {
          userId: null,
          webhookUuid: uuid,
          payload: req.body as any,
          actionTaken: null,
          success: false,
        },
      });
      throw new AppError(ErrorCode.VAL_INVALID_INPUT, "Invalid webhook payload", parsed.error.errors);
    }

    const { action, pair, price, amount } = parsed.data;

    // Find bot configured for this webhook
    const bot = await prisma.bot.findFirst({
      where: {
        dealStartConditions: {
          path: ["$"],
          array_contains: [{ type: "webhook" }],
        },
        status: "active",
      },
    });

    // Log the webhook
    await prisma.webhookLog.create({
      data: {
        userId: bot?.userId || null,
        webhookUuid: uuid,
        payload: parsed.data as any,
        actionTaken: bot ? `Triggered bot ${bot.id}` : "No matching bot found",
        success: true,
      },
    });

    // Trigger bot
    if (bot) {
      await redis.publish("bot:webhook", JSON.stringify({
        botId: bot.id,
        action,
        pair,
        price,
        amount,
      }));
    }

    logger.info(`Webhook received for UUID ${uuid}`, { action, pair });

    res.json({
      success: true,
      data: { message: "Webhook processed" },
    });
  } catch (error) {
    next(error);
  }
}

export async function getWebhookLogs(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const logs = await prisma.webhookLog.findMany({
      where: { userId: req.userId || undefined },
      orderBy: { receivedAt: "desc" },
      take: 50,
    });

    res.json({
      success: true,
      data: logs,
    });
  } catch (error) {
    next(error);
  }
}