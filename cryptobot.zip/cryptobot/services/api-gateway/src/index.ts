import dotenv from "dotenv";
dotenv.config();

import { httpServer } from "./app";
import { connectDB, disconnectDB } from "./prisma/client";
import { connectRedis, redis } from "./utils/redis";
import { logger } from "./utils/logger";

const PORT = parseInt(process.env.PORT || "3000", 10);

async function startServer(): Promise<void> {
  try {
    // Connect to dependencies
    await connectDB();
    await connectRedis();

    // Start HTTP server
    httpServer.listen(PORT, () => {
      logger.info(`API Gateway started on port ${PORT}`);
      logger.info(`Environment: ${process.env.NODE_ENV || "development"}`);
    });
  } catch (error) {
    logger.error("Failed to start server", { error });
    process.exit(1);
  }
}

// Graceful shutdown
const shutdown = async (signal: string) => {
  logger.info(`Received ${signal}. Shutting down gracefully...`);

  httpServer.close(async () => {
    logger.info("HTTP server closed");

    try {
      await disconnectDB();
      await redis.quit();
      logger.info("All connections closed");
    } catch (error) {
      logger.error("Error during shutdown", { error });
    }

    process.exit(0);
  });

  // Force shutdown after 15s
  setTimeout(() => {
    logger.error("Forced shutdown after timeout");
    process.exit(1);
  }, 15000);
};

process.on("SIGTERM", () => shutdown("SIGTERM"));
process.on("SIGINT", () => shutdown("SIGINT"));
process.on("unhandledRejection", (reason) => {
  logger.error("Unhandled rejection", { reason });
});
process.on("uncaughtException", (error) => {
  logger.error("Uncaught exception", { error: error.message, stack: error.stack });
  process.exit(1);
});

startServer();