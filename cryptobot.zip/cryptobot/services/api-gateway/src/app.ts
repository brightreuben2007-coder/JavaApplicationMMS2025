import crypto from "node:crypto";
import express from "express";
import helmet from "helmet";
import cors from "cors";
import cookieParser from "cookie-parser";
import promClient from "prom-client";
import { createServer } from "node:http";
import { Server as SocketIOServer } from "socket.io";
import { logger } from "./utils/logger";
import { AppError } from "./utils/errors";
import { ErrorCode } from "../../shared/types/api.types";

// Routes
import { authRoutes } from "./routes/auth.routes";
import { botsRoutes } from "./routes/bots.routes";
import { tradesRoutes } from "./routes/trades.routes";
import { strategiesRoutes } from "./routes/strategies.routes";
import { backtestRoutes } from "./routes/backtest.routes";
import { portfolioRoutes } from "./routes/portfolio.routes";
import { credentialsRoutes } from "./routes/credentials.routes";
import { marketplaceRoutes } from "./routes/marketplace.routes";
import { signalsRoutes } from "./routes/signals.routes";
import { webhookRoutes } from "./routes/webhook.routes";
import { smarttradeRoutes } from "./routes/smarttrade.routes";
import { copytradingRoutes } from "./routes/copytrading.routes";
import { billingRoutes } from "./routes/billing.routes";
import { telegramRoutes } from "./routes/telegram.routes";

// Middleware
import { authMiddleware } from "./middleware/auth.middleware";
import { rateLimitMiddleware } from "./middleware/rateLimit.middleware";

// WebSocket
import { setupWebSocket } from "./websocket";

// ============================================================
// PROMETHEUS METRICS
// ============================================================
const register = new promClient.Registry();
promClient.collectDefaultMetrics({ register, prefix: "api_gateway_" });

export const httpRequestDuration = new promClient.Histogram({
  name: "api_gateway_http_request_duration_seconds",
  help: "Duration of HTTP requests in seconds",
  labelNames: ["method", "route", "status"],
  buckets: [0.01, 0.05, 0.1, 0.25, 0.5, 1, 2, 5, 10],
  registers: [register],
});

export const httpRequestTotal = new promClient.Counter({
  name: "api_gateway_http_requests_total",
  help: "Total number of HTTP requests",
  labelNames: ["method", "route", "status"],
  registers: [register],
});

export const activeConnections = new promClient.Gauge({
  name: "api_gateway_active_connections",
  help: "Number of active WebSocket connections",
  registers: [register],
});

export const authFailures = new promClient.Counter({
  name: "api_gateway_auth_failures_total",
  help: "Total authentication failures",
  labelNames: ["reason"],
  registers: [register],
});

// ============================================================
// APP SETUP
// ============================================================
const app = express();

// Trust proxy for rate limiting behind nginx
app.set("trust proxy", 1);

// Security
app.use(
  helmet({
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'self'"],
        scriptSrc: ["'self'", "'unsafe-inline'"],
        styleSrc: ["'self'", "'unsafe-inline'"],
        imgSrc: ["'self'", "data:", "https:"],
        connectSrc: ["'self'", "wss:", "ws:"],
      },
    },
    crossOriginEmbedderPolicy: false,
    hsts: {
      maxAge: 63072000,
      includeSubDomains: true,
      preload: true,
    },
  })
);

app.use(
  cors({
    origin: process.env.FRONTEND_URL || "http://localhost:3001",
    credentials: true,
    methods: ["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
    allowedHeaders: ["Content-Type", "Authorization", "X-Request-ID"],
    maxAge: 86400,
  })
);

app.use(cookieParser());

// ============================================================
// CRITICAL: Stripe webhook MUST be before express.json()
// because it needs the raw body for signature verification
// ============================================================
app.use(
  "/api/v1/billing/webhook",
  express.raw({ type: "application/json", limit: "1mb" })
);

// General body parsing (after Stripe webhook)
app.use(express.json({ limit: "1mb" }));
app.use(express.urlencoded({ extended: true, limit: "1mb" }));

// ============================================================
// REQUEST LOGGING & TRACKING
// ============================================================
app.use((req, res, next) => {
  const requestId =
    (req.headers["x-request-id"] as string) || crypto.randomUUID();
  req.headers["x-request-id"] = requestId;
  res.setHeader("X-Request-ID", requestId);

  const start = Date.now();

  res.on("finish", () => {
    const duration = (Date.now() - start) / 1000;
    const route = req.route?.path || req.path || "unknown";

    httpRequestDuration.observe(
      { method: req.method, route, status: res.statusCode.toString() },
      duration
    );
    httpRequestTotal.inc({
      method: req.method,
      route,
      status: res.statusCode.toString(),
    });

    logger.info(
      `${req.method} ${req.originalUrl} ${res.statusCode} ${duration.toFixed(3)}s`,
      {
        method: req.method,
        path: req.originalUrl,
        status: res.statusCode,
        duration,
        requestId,
        ip: req.ip,
        userAgent: req.headers["user-agent"]?.slice(0, 100),
      }
    );
  });

  next();
});

// ============================================================
// BODY PARSING ERROR HANDLER
// ============================================================
app.use(
  (
    err: Error,
    _req: express.Request,
    res: express.Response,
    next: express.NextFunction
  ) => {
    if (err instanceof SyntaxError && "body" in err) {
      res.status(400).json({
        success: false,
        error: {
          code: ErrorCode.VAL_INVALID_INPUT,
          message: "Invalid JSON in request body",
          timestamp: new Date().toISOString(),
        },
      });
      return;
    }
    next(err);
  }
);

// ============================================================
// PUBLIC ROUTES (no auth required)
// ============================================================
app.get("/health", (_req, res) => {
  res.json({
    status: "healthy",
    service: "api-gateway",
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
    memory: process.memoryUsage(),
  });
});

app.get("/metrics", async (_req, res) => {
  res.set("Content-Type", register.contentType);
  res.end(await register.metrics());
});

// Auth routes are partially public (login, register, refresh)
app.use("/api/v1/auth", authRoutes);

// Webhook routes are public (validated by UUID)
app.use("/api/v1/webhooks", webhookRoutes);

// Billing webhook mounted before express.json (see above)
app.use("/api/v1/billing", billingRoutes);

// Telegram webhook
app.use("/api/v1/telegram", telegramRoutes);

// ============================================================
// AUTHENTICATED ROUTES
// ============================================================
const apiRouter = express.Router();

// Apply rate limiting to all authenticated routes
apiRouter.use(rateLimitMiddleware);

// Apply authentication to all routes
apiRouter.use(authMiddleware);

// Mount all authenticated routes
apiRouter.use("/bots", botsRoutes);
apiRouter.use("/trades", tradesRoutes);
apiRouter.use("/strategies", strategiesRoutes);
apiRouter.use("/backtest", backtestRoutes);
apiRouter.use("/portfolio", portfolioRoutes);
apiRouter.use("/credentials", credentialsRoutes);
apiRouter.use("/marketplace", marketplaceRoutes);
apiRouter.use("/signals", signalsRoutes);
apiRouter.use("/smarttrade", smarttradeRoutes);
apiRouter.use("/copytrading", copytradingRoutes);

app.use("/api/v1", apiRouter);

// ============================================================
// 404 HANDLER
// ============================================================
app.use((_req, res) => {
  res.status(404).json({
    success: false,
    error: {
      code: ErrorCode.RES_NOT_FOUND,
      message: "The requested resource was not found",
      timestamp: new Date().toISOString(),
    },
  });
});

// ============================================================
// GLOBAL ERROR HANDLER
// ============================================================
app.use(
  (
    err: Error,
    _req: express.Request,
    res: express.Response,
    _next: express.NextFunction
  ) => {
    if (err instanceof AppError) {
      res.status(err.statusCode).json({
        success: false,
        error: {
          code: err.code,
          message: err.message,
          details: err.details,
          timestamp: new Date().toISOString(),
        },
      });
      return;
    }

    logger.error("Unhandled application error", {
      error: err.message,
      stack: err.stack,
      name: err.name,
    });

    const message =
      process.env.NODE_ENV === "production"
        ? "An unexpected error occurred"
        : err.message || "An unexpected error occurred";

    res.status(500).json({
      success: false,
      error: {
        code: ErrorCode.SRV_INTERNAL_ERROR,
        message,
        timestamp: new Date().toISOString(),
      },
    });
  }
);

// ============================================================
// HTTP SERVER + SOCKET.IO
// ============================================================
const httpServer = createServer(app);

const io = new SocketIOServer(httpServer, {
  cors: {
    origin: process.env.FRONTEND_URL || "http://localhost:3001",
    methods: ["GET", "POST"],
    credentials: true,
  },
  pingTimeout: 60000,
  pingInterval: 25000,
  transports: ["websocket", "polling"],
  connectTimeout: 45000,
  maxHttpBufferSize: 1e6,
});

setupWebSocket(io);

io.on("connection", () => {
  activeConnections.inc();
});

io.on("disconnect", () => {
  activeConnections.dec();
});

export { app, httpServer, io, register };