import winston from "winston";

const SENSITIVE_FIELDS = [
  "password", "passwordHash", "totpSecret", "apiKey", "apiSecret",
  "encryptedKey", "encryptedSecret", "token", "refreshToken", "accessToken",
  "privateKey", "secret", "authorization", "cookie", "set-cookie",
];

const maskSensitive = winston.format((info) => {
  const masked = { ...info };

  for (const key of SENSITIVE_FIELDS) {
    if (key in masked) {
      masked[key] = "[REDACTED]";
    }
  }

  // Mask in nested objects
  if (masked.body && typeof masked.body === "object") {
    const body = { ...masked.body };
    for (const key of SENSITIVE_FIELDS) {
      if (key in body) body[key] = "[REDACTED]";
    }
    masked.body = body;
  }

  if (masked.headers && typeof masked.headers === "object") {
    const headers = { ...masked.headers };
    for (const key of ["authorization", "cookie", "x-api-key"]) {
      if (key in headers) headers[key] = "[REDACTED]";
    }
    masked.headers = headers;
  }

  return masked;
});

export const logger = winston.createLogger({
  level: process.env.LOG_LEVEL || "info",
  format: winston.format.combine(
    maskSensitive(),
    winston.format.timestamp({ format: "ISO8601" }),
    winston.format.errors({ stack: true }),
    process.env.NODE_ENV === "production"
      ? winston.format.json()
      : winston.format.combine(
          winston.format.colorize(),
          winston.format.printf(({ timestamp, level, message, ...meta }) => {
            const metaStr = Object.keys(meta).length
              ? ` ${JSON.stringify(meta)}`
              : "";
            return `${timestamp} [${level}]: ${message}${metaStr}`;
          })
        )
  ),
  defaultMeta: { service: "api-gateway" },
  transports: [new winston.transports.Console()],
});