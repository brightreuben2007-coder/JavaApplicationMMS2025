import jwt from "jsonwebtoken";
import fs from "node:fs";
import { AuthError } from "./errors";
import { ErrorCode } from "../../../shared/types/api.types";
import { logger } from "./logger";

interface TokenPayload {
  sub: string;       // userId
  email: string;
  planTier: string;
  iat?: number;
  exp?: number;
}

interface RefreshTokenPayload {
  sub: string;
  tokenFamily: string;
  iat?: number;
  exp?: number;
}

let privateKey: string;
let publicKey: string;

function loadKeys(): void {
  const privateKeyFile = process.env.JWT_PRIVATE_KEY_FILE;
  const publicKeyFile = process.env.JWT_PUBLIC_KEY_FILE;

  if (privateKeyFile && publicKeyFile) {
    privateKey = fs.readFileSync(privateKeyFile, "utf-8");
    publicKey = fs.readFileSync(publicKeyFile, "utf-8");
    logger.info("JWT keys loaded from files");
  } else {
    privateKey = process.env.JWT_PRIVATE_KEY || "dev-private-key-change-me";
    publicKey = process.env.JWT_PUBLIC_KEY || "dev-public-key-change-me";
    if (process.env.NODE_ENV === "production") {
      logger.warn("JWT keys loaded from environment variables. Use files in production.");
    }
  }

  if (!privateKey || !publicKey) {
    throw new Error("JWT keys are required. Set JWT_PRIVATE_KEY and JWT_PUBLIC_KEY.");
  }
}

// Initialize keys on module load
try {
  loadKeys();
} catch (error) {
  logger.error("Failed to load JWT keys", { error });
}

const ACCESS_TOKEN_EXPIRY = "15m";
const REFRESH_TOKEN_EXPIRY = "7d";

export function generateAccessToken(userId: string, email: string, planTier: string): string {
  const payload: TokenPayload = {
    sub: userId,
    email,
    planTier,
  };

  return jwt.sign(payload, privateKey, {
    algorithm: "RS256",
    expiresIn: ACCESS_TOKEN_EXPIRY,
    issuer: "cryptobot-api",
  });
}

export function generateRefreshToken(userId: string, tokenFamily: string): string {
  const payload: RefreshTokenPayload = {
    sub: userId,
    tokenFamily,
  };

  return jwt.sign(payload, privateKey, {
    algorithm: "RS256",
    expiresIn: REFRESH_TOKEN_EXPIRY,
    issuer: "cryptobot-api",
  });
}

export function verifyAccessToken(token: string): TokenPayload {
  try {
    const decoded = jwt.verify(token, publicKey, {
      algorithms: ["RS256"],
      issuer: "cryptobot-api",
    }) as TokenPayload;

    if (!decoded.sub || !decoded.email) {
      throw new AuthError(ErrorCode.AUTH_TOKEN_INVALID, "Invalid token payload");
    }

    return decoded;
  } catch (error) {
    if (error instanceof AuthError) throw error;

    if (error instanceof jwt.TokenExpiredError) {
      throw new AuthError(ErrorCode.AUTH_TOKEN_EXPIRED, "Access token has expired");
    }

    if (error instanceof jwt.JsonWebTokenError) {
      throw new AuthError(ErrorCode.AUTH_TOKEN_INVALID, "Invalid access token");
    }

    logger.error("Unexpected JWT verification error", { error });
    throw new AuthError(ErrorCode.AUTH_TOKEN_INVALID, "Token verification failed");
  }
}

export function verifyRefreshToken(token: string): RefreshTokenPayload {
  try {
    const decoded = jwt.verify(token, publicKey, {
      algorithms: ["RS256"],
      issuer: "cryptobot-api",
    }) as RefreshTokenPayload;

    if (!decoded.sub || !decoded.tokenFamily) {
      throw new AuthError(ErrorCode.AUTH_TOKEN_INVALID, "Invalid refresh token payload");
    }

    return decoded;
  } catch (error) {
    if (error instanceof AuthError) throw error;

    if (error instanceof jwt.TokenExpiredError) {
      throw new AuthError(ErrorCode.AUTH_TOKEN_EXPIRED, "Refresh token has expired");
    }

    throw new AuthError(ErrorCode.AUTH_TOKEN_INVALID, "Invalid refresh token");
  }
}

export function decodeTokenExpired(token: string): TokenPayload | null {
  try {
    // Decode without verification to check expiry
    const decoded = jwt.decode(token) as TokenPayload | null;
    return decoded;
  } catch {
    return null;
  }
}