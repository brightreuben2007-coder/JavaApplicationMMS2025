import { ErrorCode, ErrorCodeHttpStatus } from "../../../shared/types/api.types";

export class AppError extends Error {
  public readonly code: ErrorCode;
  public readonly statusCode: number;
  public readonly details?: unknown;
  public readonly isOperational: boolean;

  constructor(
    code: ErrorCode,
    message: string,
    details?: unknown,
    isOperational: boolean = true
  ) {
    super(message);
    this.name = "AppError";
    this.code = code;
    this.statusCode = ErrorCodeHttpStatus[code] || 500;
    this.details = details;
    this.isOperational = isOperational;
    Error.captureStackTrace(this, this.constructor);
  }
}

export class AuthError extends AppError {
  constructor(code: ErrorCode, message: string) {
    super(code, message);
    this.name = "AuthError";
  }
}

export class NotFoundError extends AppError {
  constructor(entity: string, id?: string) {
    const message = id
      ? `${entity} with id "${id}" not found`
      : `${entity} not found`;
    super(ErrorCode.RES_NOT_FOUND, message);
    this.name = "NotFoundError";
  }
}

export class ConflictError extends AppError {
  constructor(message: string) {
    super(ErrorCode.RES_ALREADY_EXISTS, message);
    this.name = "ConflictError";
  }
}

export class PlanLimitError extends AppError {
  constructor(message: string) {
    super(ErrorCode.PLAN_LIMIT_REACHED, message);
    this.name = "PlanLimitError";
  }
}

export class ValidationAppError extends AppError {
  constructor(message: string, details?: unknown) {
    super(ErrorCode.VAL_INVALID_INPUT, message, details);
    this.name = "ValidationAppError";
  }
}