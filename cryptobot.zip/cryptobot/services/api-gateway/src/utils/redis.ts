import Redis from "ioredis";
import { logger } from "./logger";

const REDIS_URL = process.env.REDIS_URL || "redis://localhost:6379";

export const redis = new Redis(REDIS_URL, {
  maxRetriesPerRequest: 3,
  retryStrategy(times) {
    const delay = Math.min(times * 100, 3000);
    logger.warn(`Redis connection retry ${times}, delay ${delay}ms`);
    return delay;
  },
  reconnectOnError(err) {
    const targetErrors = ["READONLY", "ETIMEDOUT", "ECONNRESET"];
    return targetErrors.some((e) => err.message.includes(e));
  },
});

export const subscriber = new Redis(REDIS_URL, {
  maxRetriesPerRequest: 3,
  retryStrategy(times) {
    return Math.min(times * 100, 3000);
  },
});

redis.on("connect", () => {
  logger.info("Redis connected");
});

redis.on("error", (error) => {
  logger.error("Redis connection error", { error: error.message });
});

export async function connectRedis(): Promise<void> {
  try {
    await redis.ping();
    logger.info("Redis connection verified");
  } catch (error) {
    logger.error("Failed to connect to Redis", { error });
    throw error;
  }
}

// Rate limiting helpers
export async function checkRateLimit(
  key: string,
  maxRequests: number,
  windowSeconds: number
): Promise<{ allowed: boolean; remaining: number; resetAt: number }> {
  const now = Math.floor(Date.now() / 1000);
  const windowStart = now - windowSeconds;

  const pipeline = redis.pipeline();
  pipeline.zremrangebyscore(key, 0, windowStart);
  pipeline.zadd(key, now, `${now}-${Math.random().toString(36).slice(2, 10)}`);
  pipeline.zcard(key);
  pipeline.expire(key, windowSeconds + 1);

  const results = await pipeline.exec();
  const requestCount = (results?.[2]?.[1] as number) || 0;
  const allowed = requestCount <= maxRequests;
  const remaining = Math.max(0, maxRequests - requestCount);

  return {
    allowed,
    remaining,
    resetAt: now + windowSeconds,
  };
}

// Token blacklist (for invalidated refresh tokens)
export async function blacklistToken(tokenFamily: string, expirySeconds: number): Promise<void> {
  await redis.set(`blacklist:token:${tokenFamily}`, "revoked", "EX", expirySeconds);
}

export async function isTokenBlacklisted(tokenFamily: string): Promise<boolean> {
  const result = await redis.get(`blacklist:token:${tokenFamily}`);
  return result === "revoked";
}

// Cache helpers
export async function cacheGet<T>(key: string): Promise<T | null> {
  const data = await redis.get(key);
  if (!data) return null;
  try {
    return JSON.parse(data) as T;
  } catch {
    return null;
  }
}

export async function cacheSet(key: string, value: unknown, ttlSeconds: number = 300): Promise<void> {
  await redis.setex(key, ttlSeconds, JSON.stringify(value));
}

export async function cacheDel(key: string): Promise<void> {
  await redis.del(key);
}

export async function cacheDelPattern(pattern: string): Promise<void> {
  const keys = await redis.keys(pattern);
  if (keys.length > 0) {
    await redis.del(...keys);
  }
}