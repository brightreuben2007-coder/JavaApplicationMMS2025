import request from "supertest";
import { app } from "../app";
import { prisma } from "../prisma/client";
import { redis } from "../utils/redis";
import bcrypt from "bcryptjs";

// Clean DB before tests
beforeAll(async () => {
  try {
    await prisma.$connect();
    await prisma.auditLog.deleteMany();
    await prisma.trade.deleteMany();
    await prisma.position.deleteMany();
    await prisma.bot.deleteMany();
    await prisma.apiCredential.deleteMany();
    await prisma.subscription.deleteMany();
    await prisma.user.deleteMany();
    await prisma.plan.deleteMany();

    // Create plans
    await prisma.plan.createMany({
      data: [
        { id: "plan_free_id", name: "Free", tier: "free", price: 0, maxBots: 1, maxDeals: 10 },
        { id: "plan_pro_id", name: "Pro", tier: "pro", price: 49, maxBots: 0, maxDeals: 0, mlAccess: true, marketplaceAccess: true },
      ],
    });
  } catch (e) {
    // Tables might not exist in CI
    console.warn("Database setup skipped:", (e as Error).message);
  }
});

afterAll(async () => {
  try {
    await prisma.$disconnect();
    await redis.quit();
  } catch (e) {
    // Ignore
  }
});

describe("Auth API", () => {
  const testEmail = `test-${Date.now()}@example.com`;
  const testPassword = "StrongP@ssw0rd123!";

  describe("POST /api/v1/auth/register", () => {
    it("should register a new user", async () => {
      const res = await request(app)
        .post("/api/v1/auth/register")
        .send({ email: testEmail, password: testPassword });

      expect(res.status).toBe(201);
      expect(res.body.success).toBe(true);
      expect(res.body.data.user.email).toBe(testEmail);
      expect(res.body.data.accessToken).toBeTruthy();
      expect(res.body.data.user.planTier).toBe("free");
    });

    it("should reject duplicate email", async () => {
      const res = await request(app)
        .post("/api/v1/auth/register")
        .send({ email: testEmail, password: testPassword });

      expect(res.status).toBe(409);
      expect(res.body.success).toBe(false);
      expect(res.body.error.code).toBe("RES_ALREADY_EXISTS");
    });

    it("should reject weak password", async () => {
      const res = await request(app)
        .post("/api/v1/auth/register")
        .send({ email: "weak@example.com", password: "123" });

      expect(res.status).toBe(400);
      expect(res.body.success).toBe(false);
    });

    it("should reject invalid email", async () => {
      const res = await request(app)
        .post("/api/v1/auth/register")
        .send({ email: "not-an-email", password: testPassword });

      expect(res.status).toBe(400);
      expect(res.body.success).toBe(false);
    });

    it("should reject missing fields", async () => {
      const res = await request(app)
        .post("/api/v1/auth/register")
        .send({ email: testEmail });

      expect(res.status).toBe(400);
    });
  });

  describe("POST /api/v1/auth/login", () => {
    it("should login with valid credentials", async () => {
      const res = await request(app)
        .post("/api/v1/auth/login")
        .send({ email: testEmail, password: testPassword });

      expect(res.status).toBe(200);
      expect(res.body.success).toBe(true);
      expect(res.body.data.accessToken).toBeTruthy();
      expect(res.body.data.user.email).toBe(testEmail);

      // Should have refresh token cookie
      expect(res.headers["set-cookie"]).toBeDefined();
    });

    it("should reject invalid password", async () => {
      const res = await request(app)
        .post("/api/v1/auth/login")
        .send({ email: testEmail, password: "wrong" });

      expect(res.status).toBe(401);
      expect(res.body.error.code).toBe("AUTH_INVALID_CREDENTIALS");
    });

    it("should reject non-existent user", async () => {
      const res = await request(app)
        .post("/api/v1/auth/login")
        .send({ email: "nobody@example.com", password: testPassword });

      expect(res.status).toBe(401);
    });
  });

  describe("POST /api/v1/auth/refresh", () => {
    it("should refresh tokens with valid cookie", async () => {
      // First login to get cookie
      const loginRes = await request(app)
        .post("/api/v1/auth/login")
        .send({ email: testEmail, password: testPassword });

      const cookies = loginRes.headers["set-cookie"];

      const res = await request(app)
        .post("/api/v1/auth/refresh")
        .set("Cookie", cookies);

      expect(res.status).toBe(200);
      expect(res.body.data.accessToken).toBeTruthy();
    });

    it("should reject without cookie", async () => {
      const res = await request(app)
        .post("/api/v1/auth/refresh");

      expect(res.status).toBe(401);
      expect(res.body.error.code).toBe("AUTH_TOKEN_INVALID");
    });

    it("should reject with invalid cookie", async () => {
      const res = await request(app)
        .post("/api/v1/auth/refresh")
        .set("Cookie", ["refreshToken=invalid-token"]);

      expect(res.status).toBe(401);
    });
  });

  describe("GET /api/v1/auth/me", () => {
    let accessToken: string;

    beforeAll(async () => {
      const res = await request(app)
        .post("/api/v1/auth/login")
        .send({ email: testEmail, password: testPassword });
      accessToken = res.body.data.accessToken;
    });

    it("should return current user with valid token", async () => {
      const res = await request(app)
        .get("/api/v1/auth/me")
        .set("Authorization", `Bearer ${accessToken}`);

      expect(res.status).toBe(200);
      expect(res.body.data.email).toBe(testEmail);
      expect(res.body.data.planTier).toBe("free");
    });

    it("should reject without token", async () => {
      const res = await request(app).get("/api/v1/auth/me");
      expect(res.status).toBe(401);
    });

    it("should reject with invalid token", async () => {
      const res = await request(app)
        .get("/api/v1/auth/me")
        .set("Authorization", "Bearer invalid-token");

      expect(res.status).toBe(401);
    });
  });

  describe("POST /api/v1/auth/2fa/setup", () => {
    let accessToken: string;

    beforeAll(async () => {
      const res = await request(app)
        .post("/api/v1/auth/login")
        .send({ email: testEmail, password: testPassword });
      accessToken = res.body.data.accessToken;
    });

    it("should generate TOTP secret and QR code", async () => {
      const res = await request(app)
        .post("/api/v1/auth/2fa/setup")
        .set("Authorization", `Bearer ${accessToken}`);

      expect(res.status).toBe(200);
      expect(res.body.data.secret).toBeTruthy();
      expect(res.body.data.qrCode).toBeTruthy();
      expect(res.body.data.otpauthUrl).toBeTruthy();
    });
  });
});