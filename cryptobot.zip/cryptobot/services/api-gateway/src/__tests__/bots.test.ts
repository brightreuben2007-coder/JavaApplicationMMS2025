import request from "supertest";
import { app } from "../app";
import { prisma } from "../prisma/client";

let accessToken: string;
let credentialId: string;
const testEmail = `bots-test-${Date.now()}@example.com`;

beforeAll(async () => {
  try {
    // Register and login
    await request(app)
      .post("/api/v1/auth/register")
      .send({ email: testEmail, password: "StrongP@ssw0rd123!" });

    const loginRes = await request(app)
      .post("/api/v1/auth/login")
      .send({ email: testEmail, password: "StrongP@ssw0rd123!" });

    accessToken = loginRes.body.data.accessToken;

    // Create a credential (mock — vault may not be running in tests)
    credentialId = "mock-credential-id";
  } catch (e) {
    console.warn("Test setup warning:", (e as Error).message);
  }
});

afterAll(async () => {
  try {
    await prisma.bot.deleteMany({ where: { userId: { contains: "bots-test" } } });
    await prisma.$disconnect();
  } catch (e) {
    // Ignore
  }
});

describe("Bots API", () => {
  describe("POST /api/v1/bots", () => {
    it("should reject without auth", async () => {
      const res = await request(app)
        .post("/api/v1/bots")
        .send({
          name: "Test Bot",
          credentialId: "some-id",
          exchange: "binance",
          pair: "BTC/USDT",
          strategyType: "dca",
          config: {
            baseOrderSize: 100,
            safetyOrderSize: 50,
            maxSafetyOrders: 5,
            priceDeviationPercent: 2,
            safetyOrderVolumeScale: 1.5,
            safetyOrderStepScale: 1.2,
            takeProfitPercent: 2,
            trailingTakeProfit: false,
            trailingDeviationPercent: 0.5,
            dealStartConditions: [],
            cooldownBetweenDealsMinutes: 30,
            minimumROI: {},
          },
        });

      expect(res.status).toBe(401);
    });

    it("should reject invalid strategy type", async () => {
      const res = await request(app)
        .post("/api/v1/bots")
        .set("Authorization", `Bearer ${accessToken}`)
        .send({
          name: "Test",
          credentialId: "some-id",
          exchange: "binance",
          pair: "BTC/USDT",
          strategyType: "invalid_strategy",
          config: {},
        });

      expect(res.status).toBe(400);
    });

    it("should reject missing required fields", async () => {
      const res = await request(app)
        .post("/api/v1/bots")
        .set("Authorization", `Bearer ${accessToken}`)
        .send({ name: "Test" });

      expect(res.status).toBe(400);
    });
  });

  describe("GET /api/v1/bots", () => {
    it("should return bot list (may be empty)", async () => {
      const res = await request(app)
        .get("/api/v1/bots")
        .set("Authorization", `Bearer ${accessToken}`);

      expect(res.status).toBe(200);
      expect(res.body.success).toBe(true);
      expect(Array.isArray(res.body.data)).toBe(true);
      expect(res.body.meta.pagination).toBeDefined();
    });

    it("should reject without auth", async () => {
      const res = await request(app).get("/api/v1/bots");
      expect(res.status).toBe(401);
    });
  });

  describe("GET /api/v1/bots/grid-suggestion", () => {
    it("should return AI grid suggestion for BTC/USDT", async () => {
      const res = await request(app)
        .get("/api/v1/bots/grid-suggestion")
        .query({ pair: "BTC/USDT", exchange: "binance", balance: "1000" })
        .set("Authorization", `Bearer ${accessToken}`);

      expect(res.status).toBe(200);
      expect(res.body.data.suggestedLower).toBeGreaterThan(0);
      expect(res.body.data.suggestedUpper).toBeGreaterThan(res.body.data.suggestedLower);
      expect(res.body.data.suggestedLevels).toBeGreaterThan(0);
      expect(res.body.data.explanation).toBeTruthy();
    });

    it("should reject without query params", async () => {
      const res = await request(app)
        .get("/api/v1/bots/grid-suggestion")
        .set("Authorization", `Bearer ${accessToken}`);

      expect(res.status).toBe(400);
    });
  });
});