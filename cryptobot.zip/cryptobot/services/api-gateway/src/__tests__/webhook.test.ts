import request from "supertest";
import { app } from "../app";
import { prisma } from "../prisma/client";
import { v4 as uuidv4 } from "uuid";

const testWebhookUuid = uuidv4();

afterAll(async () => {
  try {
    await prisma.webhookLog.deleteMany({ where: { webhookUuid: testWebhookUuid } });
    await prisma.$disconnect();
  } catch (e) {
    // Ignore
  }
});

describe("Webhook API", () => {
  describe("POST /api/v1/webhooks/:uuid", () => {
    it("should accept valid TradingView webhook payload", async () => {
      const res = await request(app)
        .post(`/api/v1/webhooks/${testWebhookUuid}`)
        .send({
          action: "buy",
          pair: "BTCUSDT",
          price: "67000",
          amount: "0.01",
        });

      expect(res.status).toBe(200);
      expect(res.body.success).toBe(true);
      expect(res.body.data.message).toBe("Webhook processed");
    });

    it("should reject invalid payload", async () => {
      const res = await request(app)
        .post(`/api/v1/webhooks/${testWebhookUuid}`)
        .send({
          action: "invalid_action",
          pair: "BTCUSDT",
        });

      expect(res.status).toBe(400);
      expect(res.body.success).toBe(false);
    });

    it("should reject empty body", async () => {
      const res = await request(app)
        .post(`/api/v1/webhooks/${testWebhookUuid}`)
        .send({});

      expect(res.status).toBe(400);
      expect(res.body.success).toBe(false);
    });
  });
});