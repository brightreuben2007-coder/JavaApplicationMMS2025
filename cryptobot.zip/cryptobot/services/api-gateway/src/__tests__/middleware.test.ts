import request from "supertest";
import { app } from "../app";
import { prisma } from "../prisma/client";

const testEmail = `middleware-test-${Date.now()}@example.com`;
let accessToken: string;

beforeAll(async () => {
  try {
    await request(app)
      .post("/api/v1/auth/register")
      .send({ email: testEmail, password: "StrongP@ssw0rd123!" });

    const loginRes = await request(app)
      .post("/api/v1/auth/login")
      .send({ email: testEmail, password: "StrongP@ssw0rd123!" });

    accessToken = loginRes.body.data.accessToken;
  } catch (e) {
    console.warn("Setup warning:", (e as Error).message);
  }
});

afterAll(async () => {
  try {
    await prisma.$disconnect();
  } catch (e) {
    // Ignore
  }
});

describe("Rate Limiting", () => {
  it("should include rate limit headers", async () => {
    const res = await request(app)
      .get("/api/v1/bots")
      .set("Authorization", `Bearer ${accessToken}`);

    expect(res.headers["x-ratelimit-limit"]).toBeDefined();
    expect(res.headers["x-ratelimit-remaining"]).toBeDefined();
    expect(res.headers["x-ratelimit-reset"]).toBeDefined();
  });

  it("should rate limit login attempts", async () => {
    const promises = [];
    const email = `ratelimit-${Date.now()}@example.com`;

    for (let i = 0; i < 7; i++) {
      promises.push(
        request(app)
          .post("/api/v1/auth/login")
          .send({ email, password: "wrong" })
      );
    }

    const results = await Promise.all(promises);
    const rateLimited = results.filter((r) => r.status === 429);

    // At least some should be rate limited after 5 attempts
    expect(rateLimited.length).toBeGreaterThan(0);
  });
});

describe("Request ID Headers", () => {
  it("should add X-Request-ID header to responses", async () => {
    const res = await request(app).get("/health");

    expect(res.headers["x-request-id"]).toBeDefined();
  });
});

describe("CORS Headers", () => {
  it("should include CORS headers", async () => {
    const res = await request(app)
      .options("/api/v1/auth/login")
      .set("Origin", "http://localhost:3001")
      .set("Access-Control-Request-Method", "POST");

    expect(res.headers["access-control-allow-origin"]).toBeDefined();
  });
});

describe("Security Headers", () => {
  it("should include Helmet security headers", async () => {
    const res = await request(app).get("/health");

    expect(res.headers["x-content-type-options"]).toBe("nosniff");
    expect(res.headers["x-frame-options"]).toBeDefined();
    expect(res.headers["strict-transport-security"]).toBeDefined();
  });
});

describe("Health Check", () => {
  it("should return healthy status", async () => {
    const res = await request(app).get("/health");

    expect(res.status).toBe(200);
    expect(res.body.status).toBe("healthy");
    expect(res.body.uptime).toBeGreaterThan(0);
    expect(res.body.memory).toBeDefined();
  });
});

describe("Metrics Endpoint", () => {
  it("should return Prometheus metrics", async () => {
    const res = await request(app).get("/metrics");

    expect(res.status).toBe(200);
    expect(res.text).toContain("api_gateway_");
    expect(res.text).toContain("process_");
    expect(res.headers["content-type"]).toContain("text/plain");
  });
});

describe("404 Handler", () => {
  it("should return 404 for unknown routes", async () => {
    const res = await request(app)
      .get("/api/v1/nonexistent")
      .set("Authorization", `Bearer ${accessToken}`);

    expect(res.status).toBe(404);
    expect(res.body.success).toBe(false);
    expect(res.body.error.code).toBe("RES_NOT_FOUND");
  });
});