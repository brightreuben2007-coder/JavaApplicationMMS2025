import request from "supertest";
import { app } from "../app";
import { prisma } from "../prisma/client";

const testEmail = `validate-test-${Date.now()}@example.com`;
let accessToken: string;

beforeAll(async () => {
  try {
    await request(app)
      .post("/api/v1/auth/register")
      .send({ email: testEmail, password: "StrongP@ssw0rd123!" });

    const loginRes = await request(app)
      .post("/api/v1/auth/login")
      .send({ email: testEmail, password: "StrongP@ssw0rd123!" });

    accessToken = loginRes.body.data.accessToken;
  } catch (e) {
    console.warn("Setup warning:", (e as Error).message);
  }
});

afterAll(async () => {
  try {
    await prisma.$disconnect();
  } catch (e) {
    // Ignore
  }
});

describe("Zod Validation Middleware", () => {
  describe("Body Validation", () => {
    it("should return formatted validation errors for bot creation", async () => {
      const res = await request(app)
        .post("/api/v1/bots")
        .set("Authorization", `Bearer ${accessToken}`)
        .send({
          name: "",
          credentialId: "not-a-uuid",
          exchange: "invalid",
          pair: "badformat",
          strategyType: "nonexistent",
          config: "not-an-object",
        });

      expect(res.status).toBe(400);
      expect(res.body.success).toBe(false);
      expect(res.body.error.code).toBe("VAL_INVALID_INPUT");
      expect(res.body.error.details).toBeDefined();
      expect(Array.isArray(res.body.error.details)).toBe(true);
    });

    it("should return formatted validation errors for registration", async () => {
      const res = await request(app)
        .post("/api/v1/auth/register")
        .send({
          email: "invalid",
          password: "12",
        });

      expect(res.status).toBe(400);
      expect(res.body.success).toBe(false);
      expect(res.body.error.details).toBeDefined();
    });
  });

  describe("Body Malformation", () => {
    it("should handle malformed JSON", async () => {
      const res = await request(app)
        .post("/api/v1/auth/login")
        .set("Content-Type", "application/json")
        .set("Authorization", `Bearer ${accessToken}`)
        .send('{"email": "test@test.com", "password":');

      expect(res.status).toBe(400);
      expect(res.body.success).toBe(false);
      expect(res.body.error.code).toBe("VAL_INVALID_INPUT");
    });
  });
});