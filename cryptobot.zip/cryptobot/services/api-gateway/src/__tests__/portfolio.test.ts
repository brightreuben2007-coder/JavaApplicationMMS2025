import request from "supertest";
import { app } from "../app";
import { prisma } from "../prisma/client";

const testEmail = `portfolio-test-${Date.now()}@example.com`;
let accessToken: string;

beforeAll(async () => {
  try {
    await request(app)
      .post("/api/v1/auth/register")
      .send({ email: testEmail, password: "StrongP@ssw0rd123!" });

    const loginRes = await request(app)
      .post("/api/v1/auth/login")
      .send({ email: testEmail, password: "StrongP@ssw0rd123!" });

    accessToken = loginRes.body.data.accessToken;
  } catch (e) {
    console.warn("Setup warning:", (e as Error).message);
  }
});

afterAll(async () => {
  try {
    await prisma.$disconnect();
  } catch (e) {
    // Ignore
  }
});

describe("Portfolio API", () => {
  describe("GET /api/v1/portfolio/summary", () => {
    it("should return portfolio summary", async () => {
      const res = await request(app)
        .get("/api/v1/portfolio/summary")
        .set("Authorization", `Bearer ${accessToken}`);

      expect(res.status).toBe(200);
      expect(res.body.success).toBe(true);
      expect(res.body.data).toHaveProperty("totalValue");
      expect(res.body.data).toHaveProperty("unrealizedPnl");
      expect(res.body.data).toHaveProperty("realizedPnl");
      expect(res.body.data).toHaveProperty("activePositions");
      expect(res.body.data).toHaveProperty("totalBots");
    });

    it("should reject without auth", async () => {
      const res = await request(app).get("/api/v1/portfolio/summary");
      expect(res.status).toBe(401);
    });
  });

  describe("GET /api/v1/portfolio/positions", () => {
    it("should return positions list", async () => {
      const res = await request(app)
        .get("/api/v1/portfolio/positions")
        .set("Authorization", `Bearer ${accessToken}`);

      expect(res.status).toBe(200);
      expect(Array.isArray(res.body.data)).toBe(true);
    });
  });

  describe("GET /api/v1/portfolio/trades", () => {
    it("should return trade history with pagination", async () => {
      const res = await request(app)
        .get("/api/v1/portfolio/trades?page=1&limit=10")
        .set("Authorization", `Bearer ${accessToken}`);

      expect(res.status).toBe(200);
      expect(res.body.meta.pagination).toBeDefined();
      expect(res.body.meta.pagination.page).toBe(1);
    });
  });

  describe("GET /api/v1/portfolio/analytics", () => {
    it("should return performance analytics", async () => {
      const res = await request(app)
        .get("/api/v1/portfolio/analytics?days=7")
        .set("Authorization", `Bearer ${accessToken}`);

      expect(res.status).toBe(200);
      expect(res.body.data).toHaveProperty("totalTrades");
      expect(res.body.data).toHaveProperty("equityCurve");
      expect(res.body.data).toHaveProperty("pairBreakdown");
      expect(res.body.data.period.days).toBe(7);
    });
  });
});