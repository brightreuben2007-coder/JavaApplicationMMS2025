import dotenv from "dotenv";

// Load test environment variables
dotenv.config({ path: ".env.test" });

// Set critical env vars for tests
process.env.NODE_ENV = "test";
process.env.DATABASE_URL = process.env.DATABASE_URL || "postgresql://test:test@localhost:5432/cryptobot_test";
process.env.REDIS_URL = process.env.REDIS_URL || "redis://localhost:6379";
process.env.JWT_PRIVATE_KEY = process.env.JWT_PRIVATE_KEY || "test-private-key-change-in-production";
process.env.JWT_PUBLIC_KEY = process.env.JWT_PUBLIC_KEY || "test-public-key-change-in-production";
process.env.ENCRYPTION_MASTER_KEY = "test-master-key-at-least-32-characters-long-for-testing!!";
process.env.VAULT_URL = "http://localhost:3003";
process.env.VAULT_AUTH_TOKEN = "test-vault-token";
process.env.FRONTEND_URL = "http://localhost:3001";
process.env.STRIPE_WEBHOOK_SECRET = "whsec_test";

// Mock console.log to reduce noise during tests
global.console = {
  ...console,
  log: jest.fn(),
  info: jest.fn(),
  debug: jest.fn(),
};