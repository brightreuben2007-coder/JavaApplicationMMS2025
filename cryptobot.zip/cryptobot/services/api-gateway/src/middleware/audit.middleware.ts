import { Request, Response, NextFunction } from "express";
import { prisma } from "../prisma/client";
import { logger } from "../utils/logger";

/**
 * Logs all mutation operations (POST, PUT, PATCH, DELETE) to audit_logs.
 * Reads (GET) are not logged to avoid excessive storage.
 */
export function auditMiddleware(
  req: Request,
  res: Response,
  next: NextFunction
): void {
  // Only log mutations
  const auditableMethods = ["POST", "PUT", "PATCH", "DELETE"];

  if (!auditableMethods.includes(req.method)) {
    return next();
  }

  // Capture the original response end to log after completion
  const originalEnd = res.end;

  res.end = function (...args: any[]) {
    // Restore original
    res.end = originalEnd;

    // Log asynchronously - don't block the response
    logAuditEvent(req, res.statusCode).catch((error) => {
      logger.error("Failed to write audit log", { error });
    });

    return originalEnd.apply(res, args);
  };

  next();
}

async function logAuditEvent(
  req: Request,
  statusCode: number
): Promise<void> {
  // Only log successful mutations (2xx)
  if (statusCode < 200 || statusCode >= 300) {
    return;
  }

  if (!req.userId) {
    return; // Shouldn't happen for authenticated routes, but safety check
  }

  // Determine entity type and ID from the URL
  const parts = req.path.split("/").filter(Boolean);
  // Expected: v1, resource, [id], [action]
  const entityType = parts[1] || "unknown";
  const entityId = parts[2] || undefined;

  // Sanitize payload - remove sensitive fields
  const sanitizedPayload = sanitizePayload(req.body);

  try {
    await prisma.auditLog.create({
      data: {
        userId: req.userId,
        action: `${req.method} ${req.path}`,
        entityType,
        entityId,
        payload: sanitizedPayload,
        ipAddress: req.ip || null,
        userAgent: req.headers["user-agent"]?.slice(0, 500) || null,
      },
    });
  } catch (error) {
    logger.error("Failed to create audit log entry", { error });
  }
}

function sanitizePayload(body: unknown): Record<string, unknown> | null {
  if (!body || typeof body !== "object") {
    return null;
  }

  const sanitized: Record<string, unknown> = {};
  const sensitiveKeys = [
    "password",
    "passwordHash",
    "totpSecret",
    "apiKey",
    "apiSecret",
    "token",
    "refreshToken",
    "accessToken",
  ];

  for (const [key, value] of Object.entries(body as Record<string, unknown>)) {
    if (sensitiveKeys.includes(key)) {
      sanitized[key] = "[REDACTED]";
    } else if (typeof value === "object" && value !== null) {
      sanitized[key] = sanitizePayload(value);
    } else {
      sanitized[key] = value;
    }
  }

  return sanitized;
}