import { Request, Response, NextFunction } from "express";
import { checkRateLimit } from "../utils/redis";
import { AppError } from "../utils/errors";
import { ErrorCode } from "../../../shared/types/api.types";
import { logger } from "../utils/logger";

interface RateLimitConfig {
  authenticated: {
    maxRequests: number;
    windowSeconds: number;
  };
  anonymous: {
    maxRequests: number;
    windowSeconds: number;
  };
}

const RATE_LIMITS: RateLimitConfig = {
  authenticated: {
    maxRequests: 100,
    windowSeconds: 60,
  },
  anonymous: {
    maxRequests: 20,
    windowSeconds: 60,
  },
};

// Stricter limits for sensitive endpoints
// Keys match req.path as seen by the router (without /api/v1 prefix)
const SENSITIVE_LIMITS: Record<string, { maxRequests: number; windowSeconds: number }> = {
  "/auth/login": { maxRequests: 5, windowSeconds: 60 },
  "/auth/register": { maxRequests: 3, windowSeconds: 300 },
  "/auth/2fa/verify": { maxRequests: 5, windowSeconds: 60 },
  "/auth/refresh": { maxRequests: 10, windowSeconds: 60 },
  "/credentials/validate": { maxRequests: 5, windowSeconds: 60 },
};

// Also match full URL paths (in case req.originalUrl is used)
const SENSITIVE_LIMITS_FULL: Record<string, { maxRequests: number; windowSeconds: number }> = {
  "/api/v1/auth/login": { maxRequests: 5, windowSeconds: 60 },
  "/api/v1/auth/register": { maxRequests: 3, windowSeconds: 300 },
  "/api/v1/auth/2fa/verify": { maxRequests: 5, windowSeconds: 60 },
  "/api/v1/auth/refresh": { maxRequests: 10, windowSeconds: 60 },
  "/api/v1/credentials/validate": { maxRequests: 5, windowSeconds: 60 },
};

export async function rateLimitMiddleware(
  req: Request,
  _res: Response,
  next: NextFunction
): Promise<void> {
  try {
    // Determine which path to check
    // req.route.path gives the route pattern (e.g., "/login")
    // req.path gives the mounted path (e.g., "/auth/login")
    // req.originalUrl gives the full URL (e.g., "/api/v1/auth/login")
    const routePath = req.route?.path || req.path || req.originalUrl;
    const originalUrl = req.originalUrl || "";

    let maxRequests: number;
    let windowSeconds: number;

    // Check both path formats for sensitive limits
    const sensitiveLimit =
      SENSITIVE_LIMITS[routePath] ||
      SENSITIVE_LIMITS[req.path] ||
      SENSITIVE_LIMITS_FULL[originalUrl] ||
      null;

    if (sensitiveLimit) {
      maxRequests = sensitiveLimit.maxRequests;
      windowSeconds = sensitiveLimit.windowSeconds;
    } else if (req.userId) {
      maxRequests = RATE_LIMITS.authenticated.maxRequests;
      windowSeconds = RATE_LIMITS.authenticated.windowSeconds;
    } else {
      maxRequests = RATE_LIMITS.anonymous.maxRequests;
      windowSeconds = RATE_LIMITS.anonymous.windowSeconds;
    }

    // Use userId if authenticated, otherwise IP
    const identifier = req.userId || req.ip || "unknown";
    const key = `ratelimit:${identifier}:${routePath}`;

    const result = await checkRateLimit(key, maxRequests, windowSeconds);

    // Set rate limit headers
    _res.setHeader("X-RateLimit-Limit", maxRequests.toString());
    _res.setHeader("X-RateLimit-Remaining", result.remaining.toString());
    _res.setHeader("X-RateLimit-Reset", result.resetAt.toString());

    if (!result.allowed) {
      const retryAfter = Math.ceil(
        (result.resetAt - Date.now() / 1000)
      );
      _res.setHeader("Retry-After", retryAfter.toString());

      throw new AppError(
        ErrorCode.RATE_LIMIT_EXCEEDED,
        `Rate limit exceeded. Try again in ${retryAfter} seconds.`
      );
    }

    next();
  } catch (error) {
    if (error instanceof AppError) {
      next(error);
      return;
    }

    logger.error("Rate limit middleware error", { error });

    // If rate limiting fails, allow the request through rather than blocking all traffic
    next();
  }
}