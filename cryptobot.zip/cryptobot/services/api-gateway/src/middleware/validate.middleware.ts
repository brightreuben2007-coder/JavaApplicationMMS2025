import { Request, Response, NextFunction } from "express";
import { ZodSchema, ZodError } from "zod";
import { ValidationAppError } from "../utils/errors";

export function validateBody(schema: ZodSchema) {
  return (req: Request, _res: Response, next: NextFunction): void => {
    try {
      const result = schema.safeParse(req.body);

      if (!result.success) {
        const details = formatZodErrors(result.error);
        throw new ValidationAppError("Validation failed", details);
      }

      // Replace req.body with parsed (and transformed) data
      req.body = result.data;
      next();
    } catch (error) {
      next(error);
    }
  };
}

export function validateQuery(schema: ZodSchema) {
  return (req: Request, _res: Response, next: NextFunction): void => {
    try {
      const result = schema.safeParse(req.query);

      if (!result.success) {
        const details = formatZodErrors(result.error);
        throw new ValidationAppError("Invalid query parameters", details);
      }

      req.query = result.data as any;
      next();
    } catch (error) {
      next(error);
    }
  };
}

export function validateParams(schema: ZodSchema) {
  return (req: Request, _res: Response, next: NextFunction): void => {
    try {
      const result = schema.safeParse(req.params);

      if (!result.success) {
        const details = formatZodErrors(result.error);
        throw new ValidationAppError("Invalid route parameters", details);
      }

      next();
    } catch (error) {
      next(error);
    }
  };
}

interface ZodErrorDetail {
  field: string;
  message: string;
  code: string;
}

function formatZodErrors(error: ZodError): ZodErrorDetail[] {
  return error.errors.map((err) => ({
    field: err.path.join("."),
    message: err.message,
    code: err.code,
  }));
}