import { Request, Response, NextFunction } from "express";
import { prisma } from "../prisma/client";
import { AppError, PlanLimitError } from "../utils/errors";
import { ErrorCode } from "../../../shared/types/api.types";
import { logger } from "../utils/logger";

/**
 * Checks if the user has reached their plan limit for a specific resource.
 * Must be used after authMiddleware.
 */
export function checkPlanLimit(resource: "bots" | "deals" | "ml" | "marketplace") {
  return async (req: Request, _res: Response, next: NextFunction): Promise<void> => {
    try {
      const userId = req.userId;

      // Get user with plan
      const user = await prisma.user.findUnique({
        where: { id: userId },
        include: {
          plan: true,
          subscription: {
            where: { status: "active" },
            orderBy: { createdAt: "desc" },
            take: 1,
          },
        },
      });

      if (!user) {
        throw new AppError(ErrorCode.AUTH_UNAUTHORIZED, "User not found");
      }

      const plan = user.plan;
      if (!plan) {
        // No plan assigned = free tier
        return checkFreePlanLimits(userId, resource, next);
      }

      // Check subscription status
      const activeSubscription = user.subscription[0];
      if (activeSubscription && activeSubscription.status !== "active" && activeSubscription.status !== "past_due") {
        // Subscription not active, fall back to free
        return checkFreePlanLimits(userId, resource, next);
      }

      switch (resource) {
        case "bots": {
          if (plan.maxBots === 0) return next(); // Unlimited

          const botCount = await prisma.bot.count({
            where: { userId, status: { not: "stopped" } },
          });

          if (botCount >= plan.maxBots) {
            throw new PlanLimitError(
              `You have reached your plan limit of ${plan.maxBots} active bots. Upgrade to add more.`
            );
          }
          break;
        }

        case "deals": {
          if (plan.maxDeals === 0) return next(); // Unlimited

          // Count today's deals
          const today = new Date();
          today.setHours(0, 0, 0, 0);

          const dealCount = await prisma.trade.count({
            where: {
              userId,
              createdAt: { gte: today },
            },
          });

          if (dealCount >= plan.maxDeals) {
            throw new PlanLimitError(
              `You have reached your daily deal limit of ${plan.maxDeals}. Upgrade or wait until tomorrow.`
            );
          }
          break;
        }

        case "ml": {
          if (!plan.mlAccess) {
            throw new PlanLimitError(
              "Machine learning features require a Pro plan or higher."
            );
          }
          break;
        }

        case "marketplace": {
          if (!plan.marketplaceAccess) {
            throw new PlanLimitError(
              "Marketplace access requires a Starter plan or higher."
            );
          }
          break;
        }
      }

      next();
    } catch (error) {
      if (error instanceof AppError) {
        next(error);
        return;
      }
      logger.error("Plan limit check failed", { error });
      next(new AppError(ErrorCode.SRV_INTERNAL_ERROR, "Failed to verify plan limits"));
    }
  };
}

async function checkFreePlanLimits(
  userId: string,
  resource: "bots" | "deals" | "ml" | "marketplace",
  next: NextFunction
): Promise<void> {
  switch (resource) {
    case "bots": {
      const botCount = await prisma.bot.count({
        where: { userId, status: { not: "stopped" } },
      });

      if (botCount >= 1) {
        throw new PlanLimitError(
          "Free plan allows 1 active bot. Upgrade to add more."
        );
      }
      break;
    }

    case "deals": {
      const today = new Date();
      today.setHours(0, 0, 0, 0);

      const dealCount = await prisma.trade.count({
        where: { userId, createdAt: { gte: today } },
      });

      if (dealCount >= 10) {
        throw new PlanLimitError(
          "Free plan allows 10 deals per day. Upgrade or wait until tomorrow."
        );
      }
      break;
    }

    case "ml": {
      throw new PlanLimitError(
        "Machine learning features require a Pro plan or higher."
      );
    }

    case "marketplace": {
      throw new PlanLimitError(
        "Marketplace access requires a Starter plan or higher."
      );
    }
  }

  next();
}