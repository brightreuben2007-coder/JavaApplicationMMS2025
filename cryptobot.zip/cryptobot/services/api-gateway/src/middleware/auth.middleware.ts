import { Request, Response, NextFunction } from "express";
import { verifyAccessToken } from "../utils/jwt";
import { AuthError } from "../utils/errors";
import { ErrorCode } from "../../../shared/types/api.types";
import { logger } from "../utils/logger";
import { authFailures } from "../app";

// Extend Express Request to include user data
declare global {
  namespace Express {
    interface Request {
      userId: string;
      userEmail: string;
      userPlanTier: string;
    }
  }
}

export function authMiddleware(
  req: Request,
  _res: Response,
  next: NextFunction
): void {
  try {
    // Extract token from Authorization header
    const authHeader = req.headers.authorization;

    if (!authHeader) {
      authFailures.inc({ reason: "missing_header" });
      throw new AuthError(
        ErrorCode.AUTH_UNAUTHORIZED,
        "Authorization header is required"
      );
    }

    if (!authHeader.startsWith("Bearer ")) {
      authFailures.inc({ reason: "invalid_format" });
      throw new AuthError(
        ErrorCode.AUTH_UNAUTHORIZED,
        "Authorization header must be in format: Bearer <token>"
      );
    }

    const token = authHeader.substring(7).trim();

    if (!token) {
      authFailures.inc({ reason: "empty_token" });
      throw new AuthError(
        ErrorCode.AUTH_UNAUTHORIZED,
        "Access token is required"
      );
    }

    // Verify the access token
    const payload = verifyAccessToken(token);

    // Attach user info to request
    req.userId = payload.sub;
    req.userEmail = payload.email;
    req.userPlanTier = payload.planTier;

    next();
  } catch (error) {
    if (error instanceof AuthError) {
      next(error);
      return;
    }

    authFailures.inc({ reason: "unknown" });
    logger.error("Unexpected auth middleware error", { error });
    next(
      new AuthError(
        ErrorCode.AUTH_TOKEN_INVALID,
        "Authentication failed"
      )
    );
  }
}

/**
 * Optional auth middleware - attaches user if token present, but doesn't require it.
 * Used for endpoints that behave differently for authenticated users.
 */
export function optionalAuthMiddleware(
  req: Request,
  _res: Response,
  next: NextFunction
): void {
  try {
    const authHeader = req.headers.authorization;

    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      // No token, continue without authentication
      return next();
    }

    const token = authHeader.substring(7).trim();

    if (!token) {
      return next();
    }

    const payload = verifyAccessToken(token);
    req.userId = payload.sub;
    req.userEmail = payload.email;
    req.userPlanTier = payload.planTier;

    next();
  } catch {
    // Token invalid but it's optional - just continue
    next();
  }
}

/**
 * Require specific plan tier or higher.
 * Plan tiers: free < starter < pro < enterprise
 */
const PLAN_TIER_LEVELS: Record<string, number> = {
  free: 0,
  starter: 1,
  pro: 2,
  enterprise: 3,
};

export function requirePlanTier(minimumTier: string) {
  return (req: Request, _res: Response, next: NextFunction): void => {
    const userLevel = PLAN_TIER_LEVELS[req.userPlanTier] ?? 0;
    const requiredLevel = PLAN_TIER_LEVELS[minimumTier] ?? 0;

    if (userLevel < requiredLevel) {
      next(
        new AuthError(
          ErrorCode.PLAN_FEATURE_NOT_AVAILABLE,
          `This feature requires a ${minimumTier} plan or higher. Your current plan: ${req.userPlanTier}.`
        )
      );
      return;
    }

    next();
  };
}