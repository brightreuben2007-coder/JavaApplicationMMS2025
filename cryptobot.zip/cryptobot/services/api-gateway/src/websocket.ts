import { Server as SocketIOServer, Socket } from "socket.io";
import { verifyAccessToken } from "./utils/jwt";
import { AuthError } from "./utils/errors";
import { logger } from "./utils/logger";
import { redis } from "./utils/redis";
import { authFailures } from "./app";

// Redis subscriber for market data
import { subscriber } from "./utils/redis";

export function setupWebSocket(io: SocketIOServer): void {
  // ============================================================
  // AUTHENTICATION MIDDLEWARE
  // ============================================================
  io.use(async (socket, next) => {
    try {
      const token =
        socket.handshake.auth.token ||
        socket.handshake.query.token as string;

      if (!token) {
        authFailures.inc({ reason: "missing_token" });
        return next(new Error("Authentication token is required"));
      }

      const payload = verifyAccessToken(token);
      socket.data.userId = payload.sub;
      socket.data.email = payload.email;
      socket.data.planTier = payload.planTier;

      logger.info(`WebSocket authenticated for user ${payload.sub}`, {
        userId: payload.sub,
        socketId: socket.id,
      });

      next();
    } catch (error) {
      authFailures.inc({ reason: "invalid_token" });
      logger.warn("WebSocket authentication failed", { error });
      next(new Error("Invalid or expired authentication token"));
    }
  });

  io.on("connection", (socket: Socket) => {
    logger.info(`Client connected: ${socket.id}`, {
      userId: socket.data.userId,
      socketId: socket.id,
    });

    // ============================================================
    // NAMESPACE: /market - Real-time market data subscriptions
    // ============================================================
    socket.on("subscribe:market", async (data: { exchange: string; pair: string }) => {
      const { exchange, pair } = data;

      if (!exchange || !pair) {
        socket.emit("error", { message: "exchange and pair are required" });
        return;
      }

      const channel = `market:${exchange}:${pair}`;
      const room = `market:${exchange}:${pair}`;

      // Leave previous market rooms
      const rooms = Array.from(socket.rooms);
      for (const r of rooms) {
        if (r.startsWith("market:") && r !== room) {
          socket.leave(r);
        }
      }

      socket.join(room);

      // Send cached data immediately
      try {
        const [ticker, orderBook] = await Promise.all([
          redis.get(`cache:${channel}:ticker`),
          redis.get(`cache:${channel}:orderbook`),
        ]);

        if (ticker) {
          socket.emit("ticker", JSON.parse(ticker));
        }
        if (orderBook) {
          socket.emit("orderbook", JSON.parse(orderBook));
        }
      } catch (error) {
        logger.error("Failed to fetch cached market data", { error });
      }

      logger.info(`Client subscribed to market ${channel}`, {
        userId: socket.data.userId,
        channel,
      });
    });

    socket.on("subscribe:candles", async (data: { exchange: string; pair: string; timeframe: string }) => {
      const { exchange, pair, timeframe } = data;
      if (!exchange || !pair || !timeframe) {
        socket.emit("error", { message: "exchange, pair, and timeframe are required" });
        return;
      }

      const room = `candles:${exchange}:${pair}:${timeframe}`;
      socket.join(room);

      // Send cached candles
      try {
        const cacheKey = `cache:candles:${exchange}:${pair}:${timeframe}`;
        const cached = await redis.get(cacheKey);
        if (cached) {
          socket.emit("candles", JSON.parse(cached));
        }
      } catch (error) {
        logger.error("Failed to fetch cached candles", { error });
      }
    });

    socket.on("unsubscribe:market", (data: { exchange: string; pair: string }) => {
      const { exchange, pair } = data;
      const room = `market:${exchange}:${pair}`;
      socket.leave(room);
    });

    // ============================================================
    // NAMESPACE: /bots - Bot status updates
    // ============================================================
    socket.on("subscribe:bots", async () => {
      const userId = socket.data.userId;
      const room = `user:${userId}:bots`;
      socket.join(room);

      // Send current bot statuses
      try {
        const botStatuses = await redis.get(`cache:user:${userId}:bots`);
        if (botStatuses) {
          socket.emit("bot:status", JSON.parse(botStatuses));
        }
      } catch (error) {
        logger.error("Failed to fetch bot status cache", { error });
      }
    });

    socket.on("unsubscribe:bots", () => {
      const userId = socket.data.userId;
      const room = `user:${userId}:bots`;
      socket.leave(room);
    });

    // ============================================================
    // NAMESPACE: /alerts - Risk events, notifications
    // ============================================================
    socket.on("subscribe:alerts", () => {
      const userId = socket.data.userId;
      const room = `user:${userId}:alerts`;
      socket.join(room);
    });

    // ============================================================
    // NAMESPACE: /backtest - Backtest/hyperopt progress
    // ============================================================
    socket.on("subscribe:backtest", (data: { jobId: string }) => {
      const { jobId } = data;
      const room = `backtest:${jobId}`;
      socket.join(room);
    });

    // ============================================================
    // DISCONNECT
    // ============================================================
    socket.on("disconnect", (reason) => {
      logger.info(`Client disconnected: ${socket.id}`, {
        userId: socket.data.userId,
        reason,
        socketId: socket.id,
      });
    });

    // ============================================================
    // PING/PONG FOR LATENCY
    // ============================================================
    socket.on("ping:latency", (clientTimestamp: number) => {
      socket.emit("pong:latency", {
        clientTimestamp,
        serverTimestamp: Date.now(),
      });
    });
  });

  // ============================================================
  // REDIS PUB/SUB BRIDGE
  // Broadcast market data from market-data service to sockets
  // ============================================================
  const marketChannelPattern = "market:*:*:*";
  const candleChannelPattern = "candles:*:*:*:*";

  subscriber.psubscribe(marketChannelPattern, candleChannelPattern);

  subscriber.on("pmessage", (pattern: string, channel: string, message: string) => {
    try {
      const data = JSON.parse(message);

      if (channel.startsWith("market:")) {
        // channel format: market:{exchange}:{pair}:ticker|orderbook|trades
        const parts = channel.split(":");
        if (parts.length >= 4) {
          const exchange = parts[1];
          const pair = parts[2];
          const type = parts[3];
          const room = `market:${exchange}:${pair}`;

          io.to(room).emit(type, data);
        }
      } else if (channel.startsWith("candles:")) {
        // channel format: candles:{exchange}:{pair}:{timeframe}
        const parts = channel.split(":");
        if (parts.length >= 4) {
          const exchange = parts[1];
          const pair = parts[2];
          const timeframe = parts[3];
          const room = `candles:${exchange}:${pair}:${timeframe}`;

          io.to(room).emit("candles:update", data);
        }
      }
    } catch (error) {
      logger.error("Failed to process Redis pub/sub message", {
        channel,
        error,
      });
    }
  });

  // Broadcast bot status changes
  const botChannelPattern = "bot:status:*";
  subscriber.psubscribe(botChannelPattern);

  subscriber.on("pmessage", (_pattern: string, channel: string, message: string) => {
    if (channel.startsWith("bot:status:")) {
      try {
        const data = JSON.parse(message);
        const userId = data.userId;
        if (userId) {
          const room = `user:${userId}:bots`;
          io.to(room).emit("bot:status", data);
        }
      } catch (error) {
        logger.error("Failed to process bot status message", { channel, error });
      }
    }
  });

  // Broadcast alerts
  const alertChannelPattern = "alert:user:*";
  subscriber.psubscribe(alertChannelPattern);

  subscriber.on("pmessage", (_pattern: string, channel: string, message: string) => {
    if (channel.startsWith("alert:user:")) {
      try {
        const parts = channel.split(":");
        const userId = parts[2];
        if (userId) {
          const data = JSON.parse(message);
          const room = `user:${userId}:alerts`;
          io.to(room).emit("alert", data);
        }
      } catch (error) {
        logger.error("Failed to process alert message", { channel, error });
      }
    }
  });

  logger.info("WebSocket server initialized with Redis pub/sub bridge");
}