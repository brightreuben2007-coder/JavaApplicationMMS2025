import { Router } from "express";
import { handleTradingViewWebhook, getWebhookLogs } from "../controllers/webhook.controller";

const router = Router();

// TradingView webhook - public (validated by UUID)
router.post("/:uuid", handleTradingViewWebhook);
router.get("/logs", getWebhookLogs);

export { router as webhookRoutes };