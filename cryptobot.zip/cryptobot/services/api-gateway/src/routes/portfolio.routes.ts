import { Router } from "express";
import { authMiddleware } from "../middleware/auth.middleware";
import {
  getPortfolioSummary, getPositions, getTradeHistory, getPerformanceAnalytics,
} from "../controllers/portfolio.controller";

const router = Router();
router.use(authMiddleware);

router.get("/summary", getPortfolioSummary);
router.get("/positions", getPositions);
router.get("/trades", getTradeHistory);
router.get("/analytics", getPerformanceAnalytics);

export { router as portfolioRoutes };