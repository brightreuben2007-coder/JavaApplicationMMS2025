import { Router } from "express";
import { prisma } from "../prisma/client";
import { logger } from "../utils/logger";

const router = Router();

// Telegram bot webhook (public - verified by Telegram secret)
router.post("/webhook", async (req, res) => {
  try {
    const { message } = req.body;

    if (!message?.chat?.id || !message?.text) {
      res.json({ ok: true });
      return;
    }

    const chatId = message.chat.id.toString();
    const text = message.text as string;

    // Handle /link command
    if (text.startsWith("/link ")) {
      const code = text.replace("/link ", "").trim();
      const user = await prisma.user.findFirst({
        where: { id: code },
      });

      if (user) {
        await prisma.user.update({
          where: { id: user.id },
          data: { telegramChatId: chatId },
        });
        logger.info(`Telegram linked for user ${user.id}`);
      }
    }

    res.json({ ok: true });
  } catch (error) {
    logger.error("Telegram webhook error", { error });
    res.json({ ok: true });
  }
});

export { router as telegramRoutes };