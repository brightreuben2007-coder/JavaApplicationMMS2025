import { Router } from "express";
import { authMiddleware } from "../middleware/auth.middleware";
import { validateBody } from "../middleware/validate.middleware";
import {
  createCredentialSchema,
  updateCredentialSchema,
} from "../../../shared/validation/schemas";
import {
  createCredential,
  getCredentials,
  getCredential,
  updateCredential,
  deleteCredential,
  validateCredential,
} from "../controllers/credentials.controller";

const router = Router();

router.use(authMiddleware);

router.post("/", validateBody(createCredentialSchema), createCredential);
router.get("/", getCredentials);
router.get("/:id", getCredential);
router.put("/:id", validateBody(updateCredentialSchema), updateCredential);
router.delete("/:id", deleteCredential);
router.post("/validate", validateBody(createCredentialSchema), validateCredential);

export { router as credentialsRoutes };