import { Router } from "express";
import { authMiddleware } from "../middleware/auth.middleware";
import { validateBody } from "../middleware/validate.middleware";
import { createSubscriptionSchema, cancelSubscriptionSchema } from "../../../shared/validation/schemas";
import { prisma } from "../prisma/client";
import { logger } from "../utils/logger";
import { AppError } from "../utils/errors";
import { ErrorCode } from "../../../shared/types/api.types";

const router = Router();

// Stripe webhook handler - raw body already handled by express.raw() in app.ts
router.post("/webhook", async (req, res) => {
  try {
    const sig = req.headers["stripe-signature"] as string;
    const stripeSecret = process.env.STRIPE_WEBHOOK_SECRET;

    if (!sig || !stripeSecret) {
      res.status(400).json({ error: "Missing Stripe signature or secret" });
      return;
    }

    // In production: verify with Stripe SDK
    // const stripe = require("stripe")(process.env.STRIPE_SECRET_KEY);
    // const event = stripe.webhooks.constructEvent(req.body, sig, stripeSecret);

    const event = JSON.parse(req.body.toString());
    logger.info(`Stripe webhook received: ${event.type}`);

    switch (event.type) {
      case "customer.subscription.updated":
      case "customer.subscription.deleted": {
        const subscription = event.data.object;
        await prisma.subscription.updateMany({
          where: { stripeSubscriptionId: subscription.id },
          data: {
            status: subscription.status,
            currentPeriodEnd: subscription.current_period_end
              ? new Date(subscription.current_period_end * 1000)
              : null,
          },
        });
        break;
      }

      case "invoice.payment_succeeded": {
        const invoice = event.data.object;
        if (invoice.subscription) {
          await prisma.subscription.updateMany({
            where: { stripeSubscriptionId: invoice.subscription },
            data: { status: "active" },
          });
        }
        break;
      }

      case "invoice.payment_failed": {
        const invoice = event.data.object;
        if (invoice.subscription) {
          await prisma.subscription.updateMany({
            where: { stripeSubscriptionId: invoice.subscription },
            data: { status: "past_due" },
          });
        }
        break;
      }
    }

    res.json({ received: true });
  } catch (error) {
    logger.error("Stripe webhook error", { error });
    res.status(400).json({ error: "Webhook error" });
  }
});

// Authenticated billing routes
const authRouter = Router();
authRouter.use(authMiddleware);

authRouter.post("/subscribe", validateBody(createSubscriptionSchema), async (req, res, next) => {
  try {
    const { planId } = req.body;

    const plan = await prisma.plan.findUnique({ where: { id: planId } });
    if (!plan) {
      throw new AppError(ErrorCode.RES_NOT_FOUND, "Plan not found");
    }

    // Check if user already has active subscription
    const existing = await prisma.subscription.findFirst({
      where: { userId: req.userId, status: "active" },
    });

    if (existing) {
      throw new AppError(ErrorCode.RES_ALREADY_EXISTS, "You already have an active subscription");
    }

    // Create subscription in DB (Stripe integration would create it on Stripe first)
    const subscription = await prisma.subscription.create({
      data: {
        userId: req.userId,
        planId,
        status: "active",
        currentPeriodEnd: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
      },
    });

    // Update user's plan
    await prisma.user.update({
      where: { id: req.userId },
      data: { planId },
    });

    logger.info(`Subscription created for user ${req.userId}`, { planId });

    res.status(201).json({
      success: true,
      data: subscription,
    });
  } catch (error) {
    next(error);
  }
});

authRouter.post("/cancel", validateBody(cancelSubscriptionSchema), async (req, res, next) => {
  try {
    const { immediate } = req.body;

    const subscription = await prisma.subscription.findFirst({
      where: { userId: req.userId, status: "active" },
    });

    if (!subscription) {
      throw new AppError(ErrorCode.RES_NOT_FOUND, "No active subscription found");
    }

    const updated = await prisma.subscription.update({
      where: { id: subscription.id },
      data: {
        status: immediate ? "cancelled" : "active",
        currentPeriodEnd: immediate ? new Date() : subscription.currentPeriodEnd,
      },
    });

    if (immediate) {
      // Downgrade to free plan
      const freePlan = await prisma.plan.findFirst({ where: { name: "Free" } });
      if (freePlan) {
        await prisma.user.update({
          where: { id: req.userId },
          data: { planId: freePlan.id },
        });
      }
    }

    logger.info(`Subscription cancelled for user ${req.userId}`);

    res.json({
      success: true,
      data: updated,
    });
  } catch (error) {
    next(error);
  }
});

authRouter.get("/invoices", async (_req, res, next) => {
  try {
    // In production: fetch from Stripe API
    res.json({
      success: true,
      data: [],
    });
  } catch (error) {
    next(error);
  }
});

authRouter.get("/usage", async (req, res, next) => {
  try {
    const user = await prisma.user.findUnique({
      where: { id: req.userId },
      include: { plan: true },
    });

    if (!user) {
      throw new AppError(ErrorCode.RES_NOT_FOUND, "User not found");
    }

    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const [botCount, dealCount] = await Promise.all([
      prisma.bot.count({ where: { userId: req.userId, status: { not: "stopped" } } }),
      prisma.trade.count({ where: { userId: req.userId, createdAt: { gte: today } } }),
    ]);

    const plan = user.plan;
    const limits = {
      botsUsed: botCount,
      botsLimit: plan?.maxBots === 0 ? "Unlimited" : (plan?.maxBots || 1),
      dealsToday: dealCount,
      dealsLimit: plan?.maxDeals === 0 ? "Unlimited" : (plan?.maxDeals || 10),
      mlAccess: plan?.mlAccess || false,
      marketplaceAccess: plan?.marketplaceAccess || false,
    };

    res.json({
      success: true,
      data: {
        planName: plan?.name || "Free",
        limits,
      },
    });
  } catch (error) {
    next(error);
  }
});

router.use("/", authRouter);

export { router as billingRoutes };