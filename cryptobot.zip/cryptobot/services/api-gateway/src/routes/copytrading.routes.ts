import { Router } from "express";
import { authMiddleware } from "../middleware/auth.middleware";
import { validateBody } from "../middleware/validate.middleware";
import { registerSignalProviderSchema, subscribeToProviderSchema } from "../../../shared/validation/schemas";

const router = Router();
router.use(authMiddleware);

router.post("/provider/register", validateBody(registerSignalProviderSchema), (_req, res) => {
  res.json({ success: true, data: { message: "Coming soon" } });
});

router.post("/subscribe", validateBody(subscribeToProviderSchema), (_req, res) => {
  res.json({ success: true, data: { message: "Coming soon" } });
});

router.get("/subscriptions", (_req, res) => {
  res.json({ success: true, data: [] });
});

export { router as copytradingRoutes };