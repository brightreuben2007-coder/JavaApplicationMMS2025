import { Router } from "express";
import { authMiddleware } from "../middleware/auth.middleware";
import { getTrades, getTrade } from "../controllers/trades.controller";

const router = Router();
router.use(authMiddleware);

router.get("/", getTrades);
router.get("/:id", getTrade);

export { router as tradesRoutes };