import { Router } from "express";
import { authMiddleware } from "../middleware/auth.middleware";
import { validateBody } from "../middleware/validate.middleware";
import { createSmartTradeSchema } from "../../../shared/validation/schemas";
import { createSmartTrade, getSmartTrades, cancelSmartTrade } from "../controllers/smarttrade.controller";

const router = Router();
router.use(authMiddleware);

router.post("/", validateBody(createSmartTradeSchema), createSmartTrade);
router.get("/", getSmartTrades);
router.post("/:id/cancel", cancelSmartTrade);

export { router as smarttradeRoutes };