import { Router } from "express";
import { authMiddleware } from "../middleware/auth.middleware";
import { validateBody } from "../middleware/validate.middleware";
import { publishMarketplaceStrategySchema, createMarketplaceReviewSchema } from "../../../shared/validation/schemas";
import {
  listStrategies, getStrategy, publishStrategy, addReview, getLeaderboard,
} from "../controllers/marketplace.controller";

const router = Router();
router.use(authMiddleware);

router.get("/", listStrategies);
router.get("/leaderboard", getLeaderboard);
router.get("/:id", getStrategy);
router.post("/publish", validateBody(publishMarketplaceStrategySchema), publishStrategy);
router.post("/:id/review", validateBody(createMarketplaceReviewSchema), addReview);

export { router as marketplaceRoutes };