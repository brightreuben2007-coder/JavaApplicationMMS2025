import { Router } from "express";
import { authMiddleware } from "../middleware/auth.middleware";

const router = Router();
router.use(authMiddleware);

router.get("/providers", (_req, res) => {
  res.json({ success: true, data: [] });
});

router.post("/subscribe", (_req, res) => {
  res.json({ success: true, data: { message: "Coming soon" } });
});

export { router as signalsRoutes };