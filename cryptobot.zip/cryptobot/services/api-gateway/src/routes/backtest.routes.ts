import { Router } from "express";
import { authMiddleware } from "../middleware/auth.middleware";
import { validateBody } from "../middleware/validate.middleware";
import { createBacktestSchema, createHyperoptSchema } from "../../../shared/validation/schemas";
import {
  runBacktest, getBacktestStatus, getBacktestResults, getBacktestResult,
  runHyperopt, getHyperoptStatus,
} from "../controllers/backtest.controller";

const router = Router();
router.use(authMiddleware);

router.post("/", validateBody(createBacktestSchema), runBacktest);
router.get("/", getBacktestResults);
router.get("/job/:jobId", getBacktestStatus);
router.get("/:id", getBacktestResult);
router.post("/hyperopt", validateBody(createHyperoptSchema), runHyperopt);
router.get("/hyperopt/:jobId", getHyperoptStatus);

export { router as backtestRoutes };