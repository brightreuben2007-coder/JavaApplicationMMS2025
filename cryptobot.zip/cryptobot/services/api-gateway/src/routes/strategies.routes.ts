import { Router } from "express";
import { authMiddleware } from "../middleware/auth.middleware";
import { validateBody } from "../middleware/validate.middleware";
import { createStrategySchema, updateStrategySchema } from "../../../shared/validation/schemas";
import {
  createStrategy, getStrategies, getStrategy, updateStrategy,
  deleteStrategy, duplicateStrategy,
} from "../controllers/strategies.controller";

const router = Router();
router.use(authMiddleware);

router.post("/", validateBody(createStrategySchema), createStrategy);
router.get("/", getStrategies);
router.get("/:id", getStrategy);
router.put("/:id", validateBody(updateStrategySchema), updateStrategy);
router.delete("/:id", deleteStrategy);
router.post("/:id/duplicate", duplicateStrategy);

export { router as strategiesRoutes };