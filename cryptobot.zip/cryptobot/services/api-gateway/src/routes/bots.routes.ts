import { Router } from "express";
import { authMiddleware, requirePlanTier } from "../middleware/auth.middleware";
import { validateBody } from "../middleware/validate.middleware";
import { checkPlanLimit } from "../middleware/plan.middleware";
import { createBotSchema, updateBotSchema } from "../../../shared/validation/schemas";
import {
  createBot, getBots, getBot, updateBot, deleteBot,
  startBot, stopBot, pauseBot, getBotPerformance, getAIGridSuggestion,
} from "../controllers/bots.controller";

const router = Router();
router.use(authMiddleware);

router.post("/", checkPlanLimit("bots"), validateBody(createBotSchema), createBot);
router.get("/", getBots);
router.get("/grid-suggestion", getAIGridSuggestion);
router.get("/:id", getBot);
router.put("/:id", validateBody(updateBotSchema), updateBot);
router.delete("/:id", deleteBot);
router.post("/:id/start", startBot);
router.post("/:id/stop", stopBot);
router.post("/:id/pause", pauseBot);
router.get("/:id/performance", getBotPerformance);

export { router as botsRoutes };