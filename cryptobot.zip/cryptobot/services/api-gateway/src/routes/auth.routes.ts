import { Router } from "express";
import { authMiddleware } from "../middleware/auth.middleware";
import { validateBody } from "../middleware/validate.middleware";
import {
  registerSchema,
  loginSchema,
  totpSetupSchema,
} from "../../../shared/validation/schemas";
import {
  register,
  login,
  refreshToken,
  logout,
  setupTotp,
  verifyTotp,
  disableTotp,
  webauthnRegistrationOptions,
  webauthnRegistrationVerify,
  webauthnAuthenticationOptions,
  webauthnAuthenticationVerify,
  getCurrentUser,
} from "../controllers/auth.controller";

const router = Router();

// Public routes
router.post("/register", validateBody(registerSchema), register);
router.post("/login", validateBody(loginSchema), login);
router.post("/refresh", refreshToken);

// WebAuthn (some endpoints need email only)
router.post("/webauthn/register-options", webauthnRegistrationOptions);
router.post("/webauthn/register-verify", webauthnRegistrationVerify);
router.post("/webauthn/auth-options", webauthnAuthenticationOptions);
router.post("/webauthn/auth-verify", webauthnAuthenticationVerify);

// Authenticated routes
router.use(authMiddleware);

router.get("/me", getCurrentUser);
router.post("/logout", logout);

// TOTP
router.post("/2fa/setup", setupTotp);
router.post("/2fa/verify", validateBody(totpSetupSchema), verifyTotp);
router.post("/2fa/disable", validateBody(totpSetupSchema), disableTotp);

export { router as authRoutes };