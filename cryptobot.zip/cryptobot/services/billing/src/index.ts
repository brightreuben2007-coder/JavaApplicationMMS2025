import dotenv from "dotenv";
dotenv.config();

import express from "express";
import helmet from "helmet";
import promClient from "prom-client";
import Redis from "ioredis";
import Stripe from "stripe";
import { StripeService, type PlanDefinition } from "./stripe";
import { logger } from "./utils/logger";

const app = express();
const PORT = parseInt(process.env.PORT || "3009", 10);
const REDIS_URL = process.env.REDIS_URL || "redis://localhost:6379";

// Metrics
const register = new promClient.Registry();
promClient.collectDefaultMetrics({ register, prefix: "billing_" });

const subscriptionCounter = new promClient.Counter({
  name: "billing_subscriptions_total",
  help: "Total subscription events",
  labelNames: ["event"],
  registers: [register],
});

const revenueGauge = new promClient.Gauge({
  name: "billing_monthly_recurring_revenue",
  help: "Estimated monthly recurring revenue",
  registers: [register],
});

// Stripe service
const stripeService = new StripeService(process.env.STRIPE_SECRET_KEY || "");

// Register plans
const PLANS: PlanDefinition[] = [
  {
    id: "plan_free",
    name: "Free",
    tier: "free",
    price: 0,
    currency: "usd",
    interval: "month",
    maxBots: 1,
    maxDeals: 10,
    mlAccess: false,
    marketplaceAccess: false,
    apiAccess: false,
    features: ["1 trading bot", "Paper trading", "Basic DCA strategy", "1 exchange connection"],
    stripeProductId: null,
    stripePriceId: null,
  },
  {
    id: "plan_starter",
    name: "Starter",
    tier: "starter",
    price: 19,
    currency: "usd",
    interval: "month",
    maxBots: 5,
    maxDeals: 50,
    mlAccess: false,
    marketplaceAccess: true,
    apiAccess: false,
    features: ["5 trading bots", "All strategies", "SmartTrade terminal", "Backtesting", "Marketplace access", "3 exchange connections"],
    stripeProductId: null,
    stripePriceId: null,
  },
  {
    id: "plan_pro",
    name: "Pro",
    tier: "pro",
    price: 49,
    currency: "usd",
    interval: "month",
    maxBots: 0, // unlimited
    maxDeals: 0,
    mlAccess: true,
    marketplaceAccess: true,
    apiAccess: true,
    features: ["Unlimited bots", "ML-powered strategies", "Full backtesting", "Hyperopt optimization", "Copy trading", "Priority support", "API access"],
    stripeProductId: null,
    stripePriceId: null,
  },
  {
    id: "plan_enterprise",
    name: "Enterprise",
    tier: "enterprise",
    price: 199,
    currency: "usd",
    interval: "month",
    maxBots: 0,
    maxDeals: 0,
    mlAccess: true,
    marketplaceAccess: true,
    apiAccess: true,
    features: ["Everything in Pro", "Custom strategies", "Dedicated manager", "SLA guarantee", "Team management", "White-label option"],
    stripeProductId: null,
    stripePriceId: null,
  },
];

PLANS.forEach((p) => stripeService.registerPlan(p));

// Redis
const redis = new Redis(REDIS_URL, { maxRetriesPerRequest: 3 });

// Express — Stripe webhook needs raw body
app.use("/webhook", express.raw({ type: "application/json" }));
app.use(express.json());
app.use(helmet());

app.get("/health", (_req, res) => {
  res.json({
    status: "healthy",
    service: "billing",
    plans: PLANS.length,
    uptime: process.uptime(),
  });
});

app.get("/metrics", async (_req, res) => {
  res.set("Content-Type", register.contentType);
  res.end(await register.metrics());
});

// === PUBLIC ROUTES ===

// Stripe webhook
app.post("/webhook", (req, res) => {
  try {
    const sig = req.headers["stripe-signature"] as string;
    const secret = process.env.STRIPE_WEBHOOK_SECRET || "";

    if (!sig || !secret) {
      res.status(400).json({ error: "Missing signature or webhook secret" });
      return;
    }

    const event = stripeService.verifyWebhookSignature(req.body, sig, secret);

    switch (event.type) {
      case "customer.subscription.created":
        subscriptionCounter.inc({ event: "created" });
        logger.info(`Subscription created: ${(event.data.object as any).id}`);
        break;

      case "customer.subscription.updated": {
        const sub = event.data.object as Stripe.Subscription;
        subscriptionCounter.inc({ event: "updated" });
        logger.info(`Subscription updated: ${sub.id} → ${sub.status}`);
        break;
      }

      case "customer.subscription.deleted": {
        const sub = event.data.object as Stripe.Subscription;
        subscriptionCounter.inc({ event: "deleted" });
        logger.info(`Subscription deleted: ${sub.id}`);
        break;
      }

      case "invoice.payment_succeeded": {
        const invoice = event.data.object as Stripe.Invoice;
        subscriptionCounter.inc({ event: "payment_succeeded" });
        logger.info(`Payment succeeded: ${invoice.id} — $${(invoice.amount_paid / 100).toFixed(2)}`);

        // Publish to Redis for plan enforcement
        if (invoice.subscription) {
          redis.publish("billing:payment:success", JSON.stringify({
            invoiceId: invoice.id,
            subscriptionId: invoice.subscription,
            amount: invoice.amount_paid / 100,
            customerId: invoice.customer,
          })).catch(() => {});
        }
        break;
      }

      case "invoice.payment_failed": {
        const invoice = event.data.object as Stripe.Invoice;
        subscriptionCounter.inc({ event: "payment_failed" });
        logger.warn(`Payment failed: ${invoice.id}`);

        redis.publish("billing:payment:failed", JSON.stringify({
          invoiceId: invoice.id,
          customerId: invoice.customer,
        })).catch(() => {});
        break;
      }

      case "customer.subscription.trial_will_end": {
        const sub = event.data.object as Stripe.Subscription;
        logger.info(`Trial ending soon: ${sub.id}`);
        break;
      }
    }

    res.json({ received: true });
  } catch (error) {
    logger.error("Webhook error", { error: (error as Error).message });
    res.status(400).json({ error: (error as Error).message });
  }
});

// Get public plans
app.get("/plans", (_req, res) => {
  const plans = stripeService.getPlans().map((p) => ({
    id: p.id,
    name: p.name,
    tier: p.tier,
    price: p.price,
    currency: p.currency,
    interval: p.interval,
    features: p.features,
  }));
  res.json({ success: true, data: plans });
});

// === API ROUTES (authenticated by API gateway) ===

// Get customer info
app.get("/customer/:customerId", async (req, res) => {
  try {
    const info = await stripeService.getCustomerInfo(req.params.customerId);
    res.json({ success: true, data: info });
  } catch (error) {
    res.status(500).json({ success: false, error: { message: (error as Error).message } });
  }
});

// Create checkout session
app.post("/checkout", async (req, res) => {
  try {
    const { customerId, priceId, successUrl, cancelUrl } = req.body;

    if (!customerId || !priceId) {
      res.status(400).json({ success: false, error: { message: "customerId and priceId are required" } });
      return;
    }

    const session = await stripeService.createCheckoutSession(
      customerId,
      priceId,
      successUrl || `${process.env.FRONTEND_URL}/settings/billing?success=true`,
      cancelUrl || `${process.env.FRONTEND_URL}/settings/billing?canceled=true`
    );

    res.json({ success: true, data: session });
  } catch (error) {
    res.status(500).json({ success: false, error: { message: (error as Error).message } });
  }
});

// Create billing portal session
app.post("/portal", async (req, res) => {
  try {
    const { customerId, returnUrl } = req.body;

    if (!customerId) {
      res.status(400).json({ success: false, error: { message: "customerId is required" } });
      return;
    }

    const url = await stripeService.createPortalSession(
      customerId,
      returnUrl || `${process.env.FRONTEND_URL}/settings/billing`
    );

    res.json({ success: true, data: { url } });
  } catch (error) {
    res.status(500).json({ success: false, error: { message: (error as Error).message } });
  }
});

// Cancel subscription
app.post("/cancel", async (req, res) => {
  try {
    const { subscriptionId, immediate } = req.body;

    if (!subscriptionId) {
      res.status(400).json({ success: false, error: { message: "subscriptionId is required" } });
      return;
    }

    const result = await stripeService.cancelSubscription(subscriptionId, immediate || false);

    subscriptionCounter.inc({ event: "canceled" });

    res.json({ success: true, data: result });
  } catch (error) {
    res.status(500).json({ success: false, error: { message: (error as Error).message } });
  }
});

// Resume subscription
app.post("/resume", async (req, res) => {
  try {
    const { subscriptionId } = req.body;

    if (!subscriptionId) {
      res.status(400).json({ success: false, error: { message: "subscriptionId is required" } });
      return;
    }

    await stripeService.resumeSubscription(subscriptionId);
    res.json({ success: true, data: { message: "Subscription resumed" } });
  } catch (error) {
    res.status(500).json({ success: false, error: { message: (error as Error).message } });
  }
});

// Change plan
app.post("/change-plan", async (req, res) => {
  try {
    const { subscriptionId, newPriceId } = req.body;

    if (!subscriptionId || !newPriceId) {
      res.status(400).json({ success: false, error: { message: "subscriptionId and newPriceId are required" } });
      return;
    }

    await stripeService.changePlan(subscriptionId, newPriceId);
    res.json({ success: true, data: { message: "Plan changed" } });
  } catch (error) {
    res.status(500).json({ success: false, error: { message: (error as Error).message } });
  }
});

// Create customer
app.post("/create-customer", async (req, res) => {
  try {
    const { userId, email, name } = req.body;

    if (!userId || !email) {
      res.status(400).json({ success: false, error: { message: "userId and email are required" } });
      return;
    }

    const customerId = await stripeService.createCustomer(userId, email, name);
    res.json({ success: true, data: { customerId } });
  } catch (error) {
    res.status(500).json({ success: false, error: { message: (error as Error).message } });
  }
});

// Start
app.listen(PORT, async () => {
  logger.info(`Billing Service started on port ${PORT}`);

  // Sync plans with Stripe on startup
  if (process.env.STRIPE_SECRET_KEY) {
    await stripeService.syncPlansWithStripe();
  }
});

process.on("SIGTERM", async () => {
  await redis.quit();
  process.exit(0);
});