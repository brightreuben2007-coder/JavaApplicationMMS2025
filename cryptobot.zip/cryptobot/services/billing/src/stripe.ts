import Stripe from "stripe";
import { logger } from "./utils/logger";

export interface PlanDefinition {
  id: string;
  name: string;
  tier: "free" | "starter" | "pro" | "enterprise";
  price: number;
  currency: string;
  interval: "month" | "year";
  maxBots: number;
  maxDeals: number;
  mlAccess: boolean;
  marketplaceAccess: boolean;
  apiAccess: boolean;
  features: string[];
  stripeProductId: string | null;
  stripePriceId: string | null;
}

export interface CustomerInfo {
  userId: string;
  email: string;
  stripeCustomerId: string | null;
  subscription: {
    status: string;
    planId: string;
    planName: string;
    currentPeriodEnd: Date | null;
    cancelAtPeriodEnd: boolean;
  } | null;
  paymentMethods: Array<{
    id: string;
    brand: string;
    last4: string;
    expMonth: number;
    expYear: number;
    isDefault: boolean;
  }>;
  invoices: Array<{
    id: string;
    amount: number;
    currency: string;
    status: string;
    createdAt: Date;
    pdfUrl: string | null;
  }>;
}

/**
 * Stripe Service.
 * Manages Stripe customers, subscriptions, payment methods, and invoices.
 */
export class StripeService {
  private stripe: Stripe;
  private plans: Map<string, PlanDefinition> = new Map();

  constructor(secretKey: string) {
    this.stripe = new Stripe(secretKey, {
      apiVersion: "2024-06-20",
      typescript: true,
    });
  }

  /**
   * Register a plan definition.
   */
  registerPlan(plan: PlanDefinition): void {
    this.plans.set(plan.id, plan);
    logger.info(`Plan registered: ${plan.name} (${plan.tier})`);
  }

  /**
   * Get all registered plans.
   */
  getPlans(): PlanDefinition[] {
    return Array.from(this.plans.values());
  }

  /**
   * Get a plan by ID.
   */
  getPlan(planId: string): PlanDefinition | null {
    return this.plans.get(planId) || null;
  }

  /**
   * Create a Stripe customer for a user.
   */
  async createCustomer(userId: string, email: string, name?: string): Promise<string> {
    try {
      const customer = await this.stripe.customers.create({
        email,
        name: name || email,
        metadata: { userId },
      });

      logger.info(`Stripe customer created: ${customer.id} for user ${userId}`);
      return customer.id;
    } catch (error) {
      logger.error("Failed to create Stripe customer", { error, userId });
      throw error;
    }
  }

  /**
   * Create a subscription for a customer.
   */
  async createSubscription(
    customerId: string,
    priceId: string,
    paymentMethodId?: string,
    trialDays: number = 0
  ): Promise<{
    subscriptionId: string;
    clientSecret: string | null;
    status: string;
    currentPeriodEnd: Date;
  }> {
    try {
      // Attach payment method if provided
      if (paymentMethodId) {
        await this.stripe.paymentMethods.attach(paymentMethodId, {
          customer: customerId,
        });

        await this.stripe.customers.update(customerId, {
          invoice_settings: {
            default_payment_method: paymentMethodId,
          },
        });
      }

      // Create subscription
      const subscription = await this.stripe.subscriptions.create({
        customer: customerId,
        items: [{ price: priceId }],
        payment_behavior: paymentMethodId ? "default_incomplete" : "default_incomplete",
        trial_period_days: trialDays > 0 ? trialDays : undefined,
        expand: ["latest_invoice.payment_intent"],
      });

      const invoice = subscription.latest_invoice as Stripe.Invoice | null;
      const paymentIntent = invoice?.payment_intent as Stripe.PaymentIntent | null;

      logger.info(`Subscription created: ${subscription.id} for customer ${customerId}`);

      return {
        subscriptionId: subscription.id,
        clientSecret: paymentIntent?.client_secret || null,
        status: subscription.status,
        currentPeriodEnd: new Date(subscription.current_period_end * 1000),
      };
    } catch (error) {
      logger.error("Failed to create subscription", { error, customerId });
      throw error;
    }
  }

  /**
   * Cancel a subscription.
   */
  async cancelSubscription(
    subscriptionId: string,
    immediate: boolean = false
  ): Promise<{ canceledAt: Date | null; status: string }> {
    try {
      if (immediate) {
        const canceled = await this.stripe.subscriptions.cancel(subscriptionId);
        return {
          canceledAt: new Date(),
          status: canceled.status,
        };
      } else {
        // Cancel at period end
        const updated = await this.stripe.subscriptions.update(subscriptionId, {
          cancel_at_period_end: true,
        });
        return {
          canceledAt: updated.cancel_at ? new Date(updated.cancel_at * 1000) : null,
          status: updated.status,
        };
      }
    } catch (error) {
      logger.error("Failed to cancel subscription", { error, subscriptionId });
      throw error;
    }
  }

  /**
   * Resume a subscription that was set to cancel at period end.
   */
  async resumeSubscription(subscriptionId: string): Promise<void> {
    try {
      await this.stripe.subscriptions.update(subscriptionId, {
        cancel_at_period_end: false,
      });
      logger.info(`Subscription resumed: ${subscriptionId}`);
    } catch (error) {
      logger.error("Failed to resume subscription", { error, subscriptionId });
      throw error;
    }
  }

  /**
   * Change subscription plan.
   */
  async changePlan(subscriptionId: string, newPriceId: string): Promise<void> {
    try {
      const subscription = await this.stripe.subscriptions.retrieve(subscriptionId);
      const itemId = subscription.items.data[0]?.id;

      if (!itemId) throw new Error("No subscription item found");

      await this.stripe.subscriptions.update(subscriptionId, {
        items: [
          { id: itemId, price: newPriceId },
        ],
      });

      logger.info(`Subscription plan changed: ${subscriptionId} → ${newPriceId}`);
    } catch (error) {
      logger.error("Failed to change plan", { error, subscriptionId });
      throw error;
    }
  }

  /**
   * Get customer information including subscriptions, payment methods, and invoices.
   */
  async getCustomerInfo(customerId: string): Promise<CustomerInfo> {
    try {
      const [customer, subscriptions, paymentMethods, invoices] = await Promise.all([
        this.stripe.customers.retrieve(customerId),
        this.stripe.subscriptions.list({ customer: customerId, limit: 1, status: "all" }),
        this.stripe.paymentMethods.list({ customer: customerId, type: "card" }),
        this.stripe.invoices.list({ customer: customerId, limit: 12 }),
      ]);

      if ((customer as any).deleted) {
        throw new Error("Customer has been deleted");
      }

      const activeSub = subscriptions.data[0] || null;
      const planId = activeSub?.items.data[0]?.price.id || "";
      const plan = Array.from(this.plans.values()).find(
        (p) => p.stripePriceId === planId
      );

      return {
        userId: (customer as Stripe.Customer).metadata?.userId || "",
        email: (customer as Stripe.Customer).email || "",
        stripeCustomerId: customerId,
        subscription: activeSub
          ? {
              status: activeSub.status,
              planId: plan?.id || "",
              planName: plan?.name || "Unknown",
              currentPeriodEnd: new Date(activeSub.current_period_end * 1000),
              cancelAtPeriodEnd: activeSub.cancel_at_period_end,
            }
          : null,
        paymentMethods: paymentMethods.data.map((pm) => ({
          id: pm.id,
          brand: (pm as any).card?.brand || "unknown",
          last4: (pm as any).card?.last4 || "****",
          expMonth: (pm as any).card?.exp_month || 0,
          expYear: (pm as any).card?.exp_year || 0,
          isDefault: (customer as Stripe.Customer).invoice_settings?.default_payment_method === pm.id,
        })),
        invoices: invoices.data.map((inv) => ({
          id: inv.id,
          amount: inv.amount_paid / 100,
          currency: inv.currency,
          status: inv.status || "unknown",
          createdAt: new Date(inv.created * 1000),
          pdfUrl: inv.invoice_pdf,
        })),
      };
    } catch (error) {
      logger.error("Failed to get customer info", { error, customerId });
      throw error;
    }
  }

  /**
   * Create a checkout session for the frontend.
   */
  async createCheckoutSession(
    customerId: string,
    priceId: string,
    successUrl: string,
    cancelUrl: string
  ): Promise<{ sessionId: string; url: string | null }> {
    try {
      const session = await this.stripe.checkout.sessions.create({
        customer: customerId,
        mode: "subscription",
        payment_method_types: ["card"],
        line_items: [{ price: priceId, quantity: 1 }],
        success_url: successUrl,
        cancel_url: cancelUrl,
        allow_promotion_codes: true,
        billing_address_collection: "auto",
      });

      return {
        sessionId: session.id,
        url: session.url,
      };
    } catch (error) {
      logger.error("Failed to create checkout session", { error, customerId });
      throw error;
    }
  }

  /**
   * Create a billing portal session.
   */
  async createPortalSession(
    customerId: string,
    returnUrl: string
  ): Promise<string> {
    try {
      const session = await this.stripe.billingPortal.sessions.create({
        customer: customerId,
        return_url: returnUrl,
      });

      return session.url;
    } catch (error) {
      logger.error("Failed to create portal session", { error, customerId });
      throw error;
    }
  }

  /**
   * Verify a webhook signature.
   */
  verifyWebhookSignature(payload: Buffer, signature: string, secret: string): Stripe.Event {
    return this.stripe.webhooks.constructEvent(payload, signature, secret);
  }

  /**
   * Sync Stripe products and prices with local plan definitions.
   */
  async syncPlansWithStripe(): Promise<void> {
    try {
      const products = await this.stripe.products.list({ active: true, limit: 10 });

      for (const product of products.data) {
        const prices = await this.stripe.prices.list({
          product: product.id,
          active: true,
          limit: 1,
        });

        const price = prices.data[0];
        if (!price) continue;

        // Find matching plan by name
        const plan = Array.from(this.plans.values()).find(
          (p) => p.name.toLowerCase() === product.name.toLowerCase()
        );

        if (plan) {
          plan.stripeProductId = product.id;
          plan.stripePriceId = price.id;
          plan.price = (price.unit_amount || 0) / 100;

          logger.info(`Synced plan: ${plan.name} → ${price.id} ($${plan.price})`);
        }
      }
    } catch (error) {
      logger.error("Failed to sync plans with Stripe", { error });
    }
  }
}