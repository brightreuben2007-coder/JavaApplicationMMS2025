import { StripeService, type PlanDefinition } from "../stripe";

describe("Stripe Service (Unit)", () => {
  let stripeService: StripeService;

  const mockPlan: PlanDefinition = {
    id: "plan_pro",
    name: "Pro",
    tier: "pro",
    price: 49,
    currency: "usd",
    interval: "month",
    maxBots: 0,
    maxDeals: 0,
    mlAccess: true,
    marketplaceAccess: true,
    apiAccess: true,
    features: ["Unlimited bots", "ML access"],
    stripeProductId: null,
    stripePriceId: null,
  };

  beforeEach(() => {
    // Use a fake key for unit tests
    stripeService = new StripeService("sk_test_fake_key_for_unit_tests");
  });

  it("should register and retrieve plans", () => {
    stripeService.registerPlan(mockPlan);

    const plans = stripeService.getPlans();
    expect(plans.length).toBe(1);
    expect(plans[0]?.name).toBe("Pro");
  });

  it("should get plan by ID", () => {
    stripeService.registerPlan(mockPlan);

    const plan = stripeService.getPlan("plan_pro");
    expect(plan?.tier).toBe("pro");
    expect(plan?.price).toBe(49);
  });

  it("should return null for unknown plan", () => {
    const plan = stripeService.getPlan("nonexistent");
    expect(plan).toBeNull();
  });

  it("should register multiple plans", () => {
    const freePlan: PlanDefinition = {
      ...mockPlan,
      id: "plan_free",
      name: "Free",
      tier: "free",
      price: 0,
    };

    stripeService.registerPlan(freePlan);
    stripeService.registerPlan(mockPlan);

    const plans = stripeService.getPlans();
    expect(plans.length).toBe(2);
  });

  it("should have correct plan tier hierarchy", () => {
    const tiers = ["free", "starter", "pro", "enterprise"];

    for (const tier of tiers) {
      const plan: PlanDefinition = {
        ...mockPlan,
        id: `plan_test_${tier}`,
        tier: tier as any,
      };

      stripeService.registerPlan(plan);
      const retrieved = stripeService.getPlan(`plan_test_${tier}`);
      expect(retrieved?.tier).toBe(tier);
    }
  });
});